/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.auth.restore.RestoreView
 *  com.swiftsoft.anixartd.presentation.auth.restore.RestoreView$$State$OnCodeAlreadySentCommand
 *  com.swiftsoft.anixartd.presentation.auth.restore.RestoreView$$State$OnCodeCannotSendCommand
 *  com.swiftsoft.anixartd.presentation.auth.restore.RestoreView$$State$OnDataEmptyCommand
 *  com.swiftsoft.anixartd.presentation.auth.restore.RestoreView$$State$OnHideLoadingViewCommand
 *  com.swiftsoft.anixartd.presentation.auth.restore.RestoreView$$State$OnPasswordIncorrectCommand
 *  com.swiftsoft.anixartd.presentation.auth.restore.RestoreView$$State$OnPasswordNotMatchCommand
 *  com.swiftsoft.anixartd.presentation.auth.restore.RestoreView$$State$OnPasswordRepeatIncorrectCommand
 *  com.swiftsoft.anixartd.presentation.auth.restore.RestoreView$$State$OnProfileNotFoundCommand
 *  com.swiftsoft.anixartd.presentation.auth.restore.RestoreView$$State$OnRestoreVerifyCommand
 *  com.swiftsoft.anixartd.presentation.auth.restore.RestoreView$$State$OnShowLoadingViewCommand
 *  com.swiftsoft.anixartd.presentation.auth.restore.RestoreView$$State$OnUnknownErrorCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.auth.restore;

import com.swiftsoft.anixartd.presentation.auth.restore.RestoreView;
import com.swiftsoft.anixartd.presentation.auth.restore.RestoreView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class RestoreView$$State
extends MvpViewState<RestoreView>
implements RestoreView {
    func C1(String string, String string2, String string3, long l) -> void {
        OnRestoreVerifyCommand onRestoreVerifyCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onRestoreVerifyCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((RestoreView)iterator.next()).C1(string, string2, string3, l);
        }
        this.viewCommands.afterApply((ViewCommand)onRestoreVerifyCommand);
    }

    func E(String string) -> void {
        OnUnknownErrorCommand onUnknownErrorCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onUnknownErrorCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((RestoreView)iterator.next()).E(string);
        }
        this.viewCommands.afterApply((ViewCommand)onUnknownErrorCommand);
    }

    func G0() -> void {
        OnPasswordRepeatIncorrectCommand onPasswordRepeatIncorrectCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onPasswordRepeatIncorrectCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((RestoreView)iterator.next()).G0();
        }
        this.viewCommands.afterApply((ViewCommand)onPasswordRepeatIncorrectCommand);
    }

    func I() -> void {
        OnCodeAlreadySentCommand onCodeAlreadySentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCodeAlreadySentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((RestoreView)iterator.next()).I();
        }
        this.viewCommands.afterApply((ViewCommand)onCodeAlreadySentCommand);
    }

    func S() -> void {
        OnPasswordNotMatchCommand onPasswordNotMatchCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onPasswordNotMatchCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((RestoreView)iterator.next()).S();
        }
        this.viewCommands.afterApply((ViewCommand)onPasswordNotMatchCommand);
    }

    func Z() -> void {
        OnPasswordIncorrectCommand onPasswordIncorrectCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onPasswordIncorrectCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((RestoreView)iterator.next()).Z();
        }
        this.viewCommands.afterApply((ViewCommand)onPasswordIncorrectCommand);
    }

    func Z0() -> void {
        OnCodeCannotSendCommand onCodeCannotSendCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCodeCannotSendCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((RestoreView)iterator.next()).Z0();
        }
        this.viewCommands.afterApply((ViewCommand)onCodeCannotSendCommand);
    }

    func f3() -> void {
        OnDataEmptyCommand onDataEmptyCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onDataEmptyCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((RestoreView)iterator.next()).f3();
        }
        this.viewCommands.afterApply((ViewCommand)onDataEmptyCommand);
    }

    func h() -> void {
        OnShowLoadingViewCommand onShowLoadingViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowLoadingViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((RestoreView)iterator.next()).h();
        }
        this.viewCommands.afterApply((ViewCommand)onShowLoadingViewCommand);
    }

    func j() -> void {
        OnHideLoadingViewCommand onHideLoadingViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideLoadingViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((RestoreView)iterator.next()).j();
        }
        this.viewCommands.afterApply((ViewCommand)onHideLoadingViewCommand);
    }

    func k0() -> void {
        OnProfileNotFoundCommand onProfileNotFoundCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onProfileNotFoundCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((RestoreView)iterator.next()).k0();
        }
        this.viewCommands.afterApply((ViewCommand)onProfileNotFoundCommand);
    }
}

