/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.auth.AuthView
 *  com.swiftsoft.anixartd.presentation.auth.AuthView$$State$OnCheckForInAppUpdatesCommand
 *  com.swiftsoft.anixartd.presentation.auth.AuthView$$State$OnGoogleLoginFailedCommand
 *  com.swiftsoft.anixartd.presentation.auth.AuthView$$State$OnHideLoadingViewCommand
 *  com.swiftsoft.anixartd.presentation.auth.AuthView$$State$OnImmediateUpdateCommand
 *  com.swiftsoft.anixartd.presentation.auth.AuthView$$State$OnInvalidRequestCommand
 *  com.swiftsoft.anixartd.presentation.auth.AuthView$$State$OnMainCommand
 *  com.swiftsoft.anixartd.presentation.auth.AuthView$$State$OnShowLoadingViewCommand
 *  com.swiftsoft.anixartd.presentation.auth.AuthView$$State$OnSignUpWithGoogleCommand
 *  com.swiftsoft.anixartd.presentation.auth.AuthView$$State$OnSignUpWithVkCommand
 *  com.swiftsoft.anixartd.presentation.auth.AuthView$$State$OnVkLoginFailedCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.auth;

import com.swiftsoft.anixartd.presentation.auth.AuthView;
import com.swiftsoft.anixartd.presentation.auth.AuthView$$State;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class AuthView$$State
extends MvpViewState<AuthView>
implements AuthView {
    func M1(HashMap<String, Object> hashMap) -> void {
        OnSignUpWithVkCommand onSignUpWithVkCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onSignUpWithVkCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((AuthView)iterator.next()).M1(hashMap);
        }
        this.viewCommands.afterApply((ViewCommand)onSignUpWithVkCommand);
    }

    func P() -> void {
        OnInvalidRequestCommand onInvalidRequestCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onInvalidRequestCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((AuthView)iterator.next()).P();
        }
        this.viewCommands.afterApply((ViewCommand)onInvalidRequestCommand);
    }

    func e0() -> void {
        OnImmediateUpdateCommand onImmediateUpdateCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onImmediateUpdateCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((AuthView)iterator.next()).e0();
        }
        this.viewCommands.afterApply((ViewCommand)onImmediateUpdateCommand);
    }

    func f1() -> void {
        OnCheckForInAppUpdatesCommand onCheckForInAppUpdatesCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCheckForInAppUpdatesCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((AuthView)iterator.next()).f1();
        }
        this.viewCommands.afterApply((ViewCommand)onCheckForInAppUpdatesCommand);
    }

    func h() -> void {
        OnShowLoadingViewCommand onShowLoadingViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowLoadingViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((AuthView)iterator.next()).h();
        }
        this.viewCommands.afterApply((ViewCommand)onShowLoadingViewCommand);
    }

    func j() -> void {
        OnHideLoadingViewCommand onHideLoadingViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideLoadingViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((AuthView)iterator.next()).j();
        }
        this.viewCommands.afterApply((ViewCommand)onHideLoadingViewCommand);
    }

    func o0() -> void {
        OnVkLoginFailedCommand onVkLoginFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVkLoginFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((AuthView)iterator.next()).o0();
        }
        this.viewCommands.afterApply((ViewCommand)onVkLoginFailedCommand);
    }

    func q3(String string, String string2) -> void {
        OnSignUpWithGoogleCommand onSignUpWithGoogleCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onSignUpWithGoogleCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((AuthView)iterator.next()).q3(string, string2);
        }
        this.viewCommands.afterApply((ViewCommand)onSignUpWithGoogleCommand);
    }

    func t() -> void {
        OnMainCommand onMainCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onMainCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((AuthView)iterator.next()).t();
        }
        this.viewCommands.afterApply((ViewCommand)onMainCommand);
    }

    func w0() -> void {
        OnGoogleLoginFailedCommand onGoogleLoginFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onGoogleLoginFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((AuthView)iterator.next()).w0();
        }
        this.viewCommands.afterApply((ViewCommand)onGoogleLoginFailedCommand);
    }
}

