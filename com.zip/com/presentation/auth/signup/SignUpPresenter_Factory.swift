/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.auth.signup.SignUpPresenter
 *  com.swiftsoft.anixartd.repository.AuthRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.auth.signup;

import com.swiftsoft.anixartd.presentation.auth.signup.SignUpPresenter;
import com.swiftsoft.anixartd.repository.AuthRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class SignUpPresenter_Factory
implements Factory<SignUpPresenter> {
    final Provider<AuthRepository> a;

    init(Provider<AuthRepository> provider) {
        this.a = provider;
    }

    func get() -> Object {
        return new SignUpPresenter((AuthRepository)this.a.get());
    }
}

