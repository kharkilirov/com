/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.auth.signup.google.SignUpWithGoogleView
 *  com.swiftsoft.anixartd.presentation.auth.signup.google.SignUpWithGoogleView$$State$OnCodeAlreadySentCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.google.SignUpWithGoogleView$$State$OnConfirmCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.google.SignUpWithGoogleView$$State$OnEmailAlreadyTakenCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.google.SignUpWithGoogleView$$State$OnEmailEmptyCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.google.SignUpWithGoogleView$$State$OnEmailInvalidCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.google.SignUpWithGoogleView$$State$OnEmailServiceDisallowedCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.google.SignUpWithGoogleView$$State$OnHideLoadingViewCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.google.SignUpWithGoogleView$$State$OnInvalidRequestCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.google.SignUpWithGoogleView$$State$OnLoginAlreadyTakenCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.google.SignUpWithGoogleView$$State$OnLoginEmptyCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.google.SignUpWithGoogleView$$State$OnLoginInvalidCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.google.SignUpWithGoogleView$$State$OnMainCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.google.SignUpWithGoogleView$$State$OnShowLoadingViewCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.google.SignUpWithGoogleView$$State$OnTooManyRegistrationsCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.auth.signup.google;

import com.swiftsoft.anixartd.presentation.auth.signup.google.SignUpWithGoogleView;
import com.swiftsoft.anixartd.presentation.auth.signup.google.SignUpWithGoogleView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class SignUpWithGoogleView$$State
extends MvpViewState<SignUpWithGoogleView>
implements SignUpWithGoogleView {
    func C() -> void {
        OnEmailAlreadyTakenCommand onEmailAlreadyTakenCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onEmailAlreadyTakenCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpWithGoogleView)iterator.next()).C();
        }
        this.viewCommands.afterApply((ViewCommand)onEmailAlreadyTakenCommand);
    }

    func I() -> void {
        OnCodeAlreadySentCommand onCodeAlreadySentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCodeAlreadySentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpWithGoogleView)iterator.next()).I();
        }
        this.viewCommands.afterApply((ViewCommand)onCodeAlreadySentCommand);
    }

    func J() -> void {
        OnTooManyRegistrationsCommand onTooManyRegistrationsCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onTooManyRegistrationsCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpWithGoogleView)iterator.next()).J();
        }
        this.viewCommands.afterApply((ViewCommand)onTooManyRegistrationsCommand);
    }

    func L() -> void {
        OnLoginEmptyCommand onLoginEmptyCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLoginEmptyCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpWithGoogleView)iterator.next()).L();
        }
        this.viewCommands.afterApply((ViewCommand)onLoginEmptyCommand);
    }

    func P() -> void {
        OnInvalidRequestCommand onInvalidRequestCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onInvalidRequestCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpWithGoogleView)iterator.next()).P();
        }
        this.viewCommands.afterApply((ViewCommand)onInvalidRequestCommand);
    }

    func Q() -> void {
        OnEmailServiceDisallowedCommand onEmailServiceDisallowedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onEmailServiceDisallowedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpWithGoogleView)iterator.next()).Q();
        }
        this.viewCommands.afterApply((ViewCommand)onEmailServiceDisallowedCommand);
    }

    func R(String string, String string2, String string3, String string4, long l) -> void {
        OnConfirmCommand onConfirmCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onConfirmCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpWithGoogleView)iterator.next()).R(string, string2, string3, string4, l);
        }
        this.viewCommands.afterApply((ViewCommand)onConfirmCommand);
    }

    func b0() -> void {
        OnEmailEmptyCommand onEmailEmptyCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onEmailEmptyCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpWithGoogleView)iterator.next()).b0();
        }
        this.viewCommands.afterApply((ViewCommand)onEmailEmptyCommand);
    }

    func h() -> void {
        OnShowLoadingViewCommand onShowLoadingViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowLoadingViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpWithGoogleView)iterator.next()).h();
        }
        this.viewCommands.afterApply((ViewCommand)onShowLoadingViewCommand);
    }

    func j() -> void {
        OnHideLoadingViewCommand onHideLoadingViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideLoadingViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpWithGoogleView)iterator.next()).j();
        }
        this.viewCommands.afterApply((ViewCommand)onHideLoadingViewCommand);
    }

    func r() -> void {
        OnLoginInvalidCommand onLoginInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLoginInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpWithGoogleView)iterator.next()).r();
        }
        this.viewCommands.afterApply((ViewCommand)onLoginInvalidCommand);
    }

    func t() -> void {
        OnMainCommand onMainCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onMainCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpWithGoogleView)iterator.next()).t();
        }
        this.viewCommands.afterApply((ViewCommand)onMainCommand);
    }

    func w() -> void {
        OnEmailInvalidCommand onEmailInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onEmailInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpWithGoogleView)iterator.next()).w();
        }
        this.viewCommands.afterApply((ViewCommand)onEmailInvalidCommand);
    }

    func y() -> void {
        OnLoginAlreadyTakenCommand onLoginAlreadyTakenCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLoginAlreadyTakenCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpWithGoogleView)iterator.next()).y();
        }
        this.viewCommands.afterApply((ViewCommand)onLoginAlreadyTakenCommand);
    }
}

