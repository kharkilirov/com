/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  moxy.MvpView
 *  moxy.ViewStateProvider
 *  moxy.viewstate.MvpViewState
 */
package com.swiftsoft.anixartd.presentation.auth.signup.vk;

import com.swiftsoft.anixartd.presentation.auth.signup.vk.SignUpWithVkView$$State;
import moxy.MvpView;
import moxy.ViewStateProvider;
import moxy.viewstate.MvpViewState;

class SignUpWithVkPresenter$$ViewStateProvider
extends ViewStateProvider {
    MvpViewState<? extends MvpView> getViewState() {
        return new SignUpWithVkView$$State();
    }
}

