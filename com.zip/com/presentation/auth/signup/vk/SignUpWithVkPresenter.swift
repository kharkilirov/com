/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.network.api.AuthApi
 *  com.swiftsoft.anixartd.presentation.auth.restore.a
 *  com.swiftsoft.anixartd.presentation.auth.signup.vk.SignUpWithVkPresenter$onSignUpWithVk
 *  com.swiftsoft.anixartd.presentation.auth.signup.vk.SignUpWithVkPresenter$onSignUpWithVk$1
 *  com.swiftsoft.anixartd.presentation.auth.signup.vk.SignUpWithVkPresenter$onSignUpWithVk$3
 *  com.swiftsoft.anixartd.presentation.auth.signup.vk.SignUpWithVkPresenter$onSignUpWithVk$4
 *  com.swiftsoft.anixartd.presentation.auth.signup.vk.SignUpWithVkView
 *  com.swiftsoft.anixartd.repository.AuthRepository
 *  io.reactivex.Observable
 *  io.reactivex.Scheduler
 *  io.reactivex.android.schedulers.AndroidSchedulers
 *  io.reactivex.disposables.Disposable
 *  io.reactivex.functions.Action
 *  io.reactivex.functions.Consumer
 *  io.reactivex.internal.functions.Functions
 *  io.reactivex.schedulers.Schedulers
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 *  javax.inject.Inject
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  moxy.InjectViewState
 *  moxy.MvpPresenter
 *  moxy.MvpView
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.presentation.auth.signup.vk;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.network.api.AuthApi;
import com.swiftsoft.anixartd.presentation.auth.restore.a;
import com.swiftsoft.anixartd.presentation.auth.signup.verify.b;
import com.swiftsoft.anixartd.presentation.auth.signup.vk.SignUpWithVkPresenter;
import com.swiftsoft.anixartd.presentation.auth.signup.vk.SignUpWithVkView;
import com.swiftsoft.anixartd.repository.AuthRepository;
import io.reactivex.Observable;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.internal.functions.Functions;
import io.reactivex.schedulers.Schedulers;
import java.util.Objects;
import javax.inject.Inject;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import moxy.InjectViewState;
import moxy.MvpPresenter;
import moxy.MvpView;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001\u00a8\u0006\u0003"}, d2={"Lcom/swiftsoft/anixartd/presentation/auth/signup/vk/SignUpWithVkPresenter;", "Lmoxy/MvpPresenter;", "Lcom/swiftsoft/anixartd/presentation/auth/signup/vk/SignUpWithVkView;", "app_release"}, k=1, mv={1, 7, 1})
@InjectViewState
final class SignUpWithVkPresenter
extends MvpPresenter<SignUpWithVkView> {
    @NotNull
    AuthRepository a;

    @Inject
    init(@NotNull AuthRepository authRepository, @NotNull Prefs prefs) {
        Intrinsics.h((Object)authRepository, (String)"authRepository");
        Intrinsics.h((Object)prefs, (String)"prefs");
        this.a = authRepository;
    }

    final void a(@NotNull String string, @NotNull String string2, @NotNull String string3) {
        Bool bl;
        Bool bl2;
        Intrinsics.h((Object)string3, (String)"vkAccessToken");
        Int n = string.length();
        Bool bl3 = true;
        Bool bl4 = n == 0;
        if (bl4) {
            ((SignUpWithVkView)this.getViewState()).L();
            bl2 = false;
        } else {
            bl2 = true;
        }
        if (string2.length() != 0) {
            bl3 = false;
        }
        if (bl3) {
            ((SignUpWithVkView)this.getViewState()).b0();
            bl = false;
        } else {
            bl = bl2;
        }
        if (bl) {
            AuthRepository authRepository = this.a;
            Objects.requireNonNull((Object)authRepository);
            authRepository.a.signUpWithVk(string, string2, string3).n(Schedulers.c).k(AndroidSchedulers.a()).i((Consumer)new b((Function1)new onSignUpWithVk.1(this), 2)).g((Action)new a((MvpPresenter)this, 4)).l((Consumer)new b((Function1)new onSignUpWithVk.3(this, string, string2, string3), 3), (Consumer)new b((Function1)onSignUpWithVk.4.b, 4), Functions.b, Functions.c);
        }
    }
}

