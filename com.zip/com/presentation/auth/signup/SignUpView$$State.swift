/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.auth.signup.SignUpView
 *  com.swiftsoft.anixartd.presentation.auth.signup.SignUpView$$State$OnCodeAlreadySentCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.SignUpView$$State$OnCodeCannotSendCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.SignUpView$$State$OnConfirmCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.SignUpView$$State$OnEmailAlreadyTakenCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.SignUpView$$State$OnEmailEmptyCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.SignUpView$$State$OnEmailInvalidCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.SignUpView$$State$OnEmailServiceDisallowedCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.SignUpView$$State$OnHideLoadingViewCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.SignUpView$$State$OnLoginAlreadyTakenCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.SignUpView$$State$OnLoginEmptyCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.SignUpView$$State$OnLoginInvalidCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.SignUpView$$State$OnPasswordIncorrectCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.SignUpView$$State$OnPasswordInvalidCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.SignUpView$$State$OnPasswordNotMatchCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.SignUpView$$State$OnPasswordRepeatIncorrectCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.SignUpView$$State$OnShowLoadingViewCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.SignUpView$$State$OnTooManyRegistrationsCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.SignUpView$$State$OnUnknownErrorCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.auth.signup;

import com.swiftsoft.anixartd.presentation.auth.signup.SignUpView;
import com.swiftsoft.anixartd.presentation.auth.signup.SignUpView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class SignUpView$$State
extends MvpViewState<SignUpView>
implements SignUpView {
    func C() -> void {
        OnEmailAlreadyTakenCommand onEmailAlreadyTakenCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onEmailAlreadyTakenCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpView)iterator.next()).C();
        }
        this.viewCommands.afterApply((ViewCommand)onEmailAlreadyTakenCommand);
    }

    func E(String string) -> void {
        OnUnknownErrorCommand onUnknownErrorCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onUnknownErrorCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpView)iterator.next()).E(string);
        }
        this.viewCommands.afterApply((ViewCommand)onUnknownErrorCommand);
    }

    func G0() -> void {
        OnPasswordRepeatIncorrectCommand onPasswordRepeatIncorrectCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onPasswordRepeatIncorrectCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpView)iterator.next()).G0();
        }
        this.viewCommands.afterApply((ViewCommand)onPasswordRepeatIncorrectCommand);
    }

    func I() -> void {
        OnCodeAlreadySentCommand onCodeAlreadySentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCodeAlreadySentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpView)iterator.next()).I();
        }
        this.viewCommands.afterApply((ViewCommand)onCodeAlreadySentCommand);
    }

    func J() -> void {
        OnTooManyRegistrationsCommand onTooManyRegistrationsCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onTooManyRegistrationsCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpView)iterator.next()).J();
        }
        this.viewCommands.afterApply((ViewCommand)onTooManyRegistrationsCommand);
    }

    func L() -> void {
        OnLoginEmptyCommand onLoginEmptyCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLoginEmptyCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpView)iterator.next()).L();
        }
        this.viewCommands.afterApply((ViewCommand)onLoginEmptyCommand);
    }

    func Q() -> void {
        OnEmailServiceDisallowedCommand onEmailServiceDisallowedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onEmailServiceDisallowedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpView)iterator.next()).Q();
        }
        this.viewCommands.afterApply((ViewCommand)onEmailServiceDisallowedCommand);
    }

    func R(String string, String string2, String string3, String string4, long l) -> void {
        OnConfirmCommand onConfirmCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onConfirmCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpView)iterator.next()).R(string, string2, string3, string4, l);
        }
        this.viewCommands.afterApply((ViewCommand)onConfirmCommand);
    }

    func S() -> void {
        OnPasswordNotMatchCommand onPasswordNotMatchCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onPasswordNotMatchCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpView)iterator.next()).S();
        }
        this.viewCommands.afterApply((ViewCommand)onPasswordNotMatchCommand);
    }

    func Z() -> void {
        OnPasswordIncorrectCommand onPasswordIncorrectCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onPasswordIncorrectCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpView)iterator.next()).Z();
        }
        this.viewCommands.afterApply((ViewCommand)onPasswordIncorrectCommand);
    }

    func Z0() -> void {
        OnCodeCannotSendCommand onCodeCannotSendCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCodeCannotSendCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpView)iterator.next()).Z0();
        }
        this.viewCommands.afterApply((ViewCommand)onCodeCannotSendCommand);
    }

    func b0() -> void {
        OnEmailEmptyCommand onEmailEmptyCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onEmailEmptyCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpView)iterator.next()).b0();
        }
        this.viewCommands.afterApply((ViewCommand)onEmailEmptyCommand);
    }

    func h() -> void {
        OnShowLoadingViewCommand onShowLoadingViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowLoadingViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpView)iterator.next()).h();
        }
        this.viewCommands.afterApply((ViewCommand)onShowLoadingViewCommand);
    }

    func j() -> void {
        OnHideLoadingViewCommand onHideLoadingViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideLoadingViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpView)iterator.next()).j();
        }
        this.viewCommands.afterApply((ViewCommand)onHideLoadingViewCommand);
    }

    func r() -> void {
        OnLoginInvalidCommand onLoginInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLoginInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpView)iterator.next()).r();
        }
        this.viewCommands.afterApply((ViewCommand)onLoginInvalidCommand);
    }

    func w() -> void {
        OnEmailInvalidCommand onEmailInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onEmailInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpView)iterator.next()).w();
        }
        this.viewCommands.afterApply((ViewCommand)onEmailInvalidCommand);
    }

    func y() -> void {
        OnLoginAlreadyTakenCommand onLoginAlreadyTakenCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLoginAlreadyTakenCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpView)iterator.next()).y();
        }
        this.viewCommands.afterApply((ViewCommand)onLoginAlreadyTakenCommand);
    }

    func z() -> void {
        OnPasswordInvalidCommand onPasswordInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onPasswordInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignUpView)iterator.next()).z();
        }
        this.viewCommands.afterApply((ViewCommand)onPasswordInvalidCommand);
    }
}

