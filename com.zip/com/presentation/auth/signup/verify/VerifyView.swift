/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  moxy.MvpView
 *  moxy.viewstate.strategy.StateStrategyType
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.presentation.auth.signup.verify;

import kotlin.Metadata;
import moxy.MvpView;
import moxy.viewstate.strategy.StateStrategyType;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bg\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"}, d2={"Lcom/swiftsoft/anixartd/presentation/auth/signup/verify/VerifyView;", "Lmoxy/MvpView;", "app_release"}, k=1, mv={1, 7, 1})
@StateStrategyType(value="Lmoxy/viewstate/strategy/OneExecutionStateStrategy;")
interface VerifyView
extends MvpView {
    void B0(long var1);

    void C();

    void E(@NotNull String var1);

    void J();

    void O0();

    void Q();

    void X0();

    void b1();

    void h();

    void j();

    void r();

    void r0();

    void t();

    void w();

    void y();

    void z();
}

