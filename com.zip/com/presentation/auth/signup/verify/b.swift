/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  io.reactivex.functions.Consumer
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 */
package com.swiftsoft.anixartd.presentation.auth.signup.verify;

import io.reactivex.functions.Consumer;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

final class b
implements Consumer {
    final /* synthetic */ Int b;
    final /* synthetic */ Function1 c;

    /* synthetic */ b(Function1 function1, Int n) {
        this.b = n;
        this.c = function1;
    }

    final void accept(Object object) {
        switch (this.b) {
            default: {
                break;
            }
            case 28: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 27: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 26: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 25: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 24: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 23: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 22: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 21: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 20: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 19: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 18: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 17: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 16: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 15: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 14: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 13: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 12: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 11: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 10: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 9: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 8: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 7: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 6: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 5: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 4: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 3: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 2: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 1: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
            case 0: {
                Function1 function1 = this.c;
                Intrinsics.h((Object)function1, (String)"$tmp0");
                function1.invoke(object);
                return;
            }
        }
        Function1 function1 = this.c;
        Intrinsics.h((Object)function1, (String)"$tmp0");
        function1.invoke(object);
    }
}

