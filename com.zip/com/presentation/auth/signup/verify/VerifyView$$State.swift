/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyView
 *  com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyView$$State$OnCodeExpiredCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyView$$State$OnCodeInvalidCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyView$$State$OnCodeStillActualCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyView$$State$OnCodeSuccessfullyResentCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyView$$State$OnEmailAlreadyTakenCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyView$$State$OnEmailInvalidCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyView$$State$OnEmailServiceDisallowedCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyView$$State$OnHashInvalidCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyView$$State$OnHideLoadingViewCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyView$$State$OnLoginAlreadyTakenCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyView$$State$OnLoginInvalidCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyView$$State$OnMainCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyView$$State$OnPasswordInvalidCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyView$$State$OnShowLoadingViewCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyView$$State$OnTooManyRegistrationsCommand
 *  com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyView$$State$OnUnknownErrorCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.auth.signup.verify;

import com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyView;
import com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class VerifyView$$State
extends MvpViewState<VerifyView>
implements VerifyView {
    func B0(long l) -> void {
        OnCodeStillActualCommand onCodeStillActualCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCodeStillActualCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((VerifyView)iterator.next()).B0(l);
        }
        this.viewCommands.afterApply((ViewCommand)onCodeStillActualCommand);
    }

    func C() -> void {
        OnEmailAlreadyTakenCommand onEmailAlreadyTakenCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onEmailAlreadyTakenCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((VerifyView)iterator.next()).C();
        }
        this.viewCommands.afterApply((ViewCommand)onEmailAlreadyTakenCommand);
    }

    func E(String string) -> void {
        OnUnknownErrorCommand onUnknownErrorCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onUnknownErrorCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((VerifyView)iterator.next()).E(string);
        }
        this.viewCommands.afterApply((ViewCommand)onUnknownErrorCommand);
    }

    func J() -> void {
        OnTooManyRegistrationsCommand onTooManyRegistrationsCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onTooManyRegistrationsCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((VerifyView)iterator.next()).J();
        }
        this.viewCommands.afterApply((ViewCommand)onTooManyRegistrationsCommand);
    }

    func O0() -> void {
        OnHashInvalidCommand onHashInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHashInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((VerifyView)iterator.next()).O0();
        }
        this.viewCommands.afterApply((ViewCommand)onHashInvalidCommand);
    }

    func Q() -> void {
        OnEmailServiceDisallowedCommand onEmailServiceDisallowedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onEmailServiceDisallowedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((VerifyView)iterator.next()).Q();
        }
        this.viewCommands.afterApply((ViewCommand)onEmailServiceDisallowedCommand);
    }

    func X0() -> void {
        OnCodeSuccessfullyResentCommand onCodeSuccessfullyResentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCodeSuccessfullyResentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((VerifyView)iterator.next()).X0();
        }
        this.viewCommands.afterApply((ViewCommand)onCodeSuccessfullyResentCommand);
    }

    func b1() -> void {
        OnCodeExpiredCommand onCodeExpiredCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCodeExpiredCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((VerifyView)iterator.next()).b1();
        }
        this.viewCommands.afterApply((ViewCommand)onCodeExpiredCommand);
    }

    func h() -> void {
        OnShowLoadingViewCommand onShowLoadingViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowLoadingViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((VerifyView)iterator.next()).h();
        }
        this.viewCommands.afterApply((ViewCommand)onShowLoadingViewCommand);
    }

    func j() -> void {
        OnHideLoadingViewCommand onHideLoadingViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideLoadingViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((VerifyView)iterator.next()).j();
        }
        this.viewCommands.afterApply((ViewCommand)onHideLoadingViewCommand);
    }

    func r() -> void {
        OnLoginInvalidCommand onLoginInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLoginInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((VerifyView)iterator.next()).r();
        }
        this.viewCommands.afterApply((ViewCommand)onLoginInvalidCommand);
    }

    func r0() -> void {
        OnCodeInvalidCommand onCodeInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCodeInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((VerifyView)iterator.next()).r0();
        }
        this.viewCommands.afterApply((ViewCommand)onCodeInvalidCommand);
    }

    func t() -> void {
        OnMainCommand onMainCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onMainCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((VerifyView)iterator.next()).t();
        }
        this.viewCommands.afterApply((ViewCommand)onMainCommand);
    }

    func w() -> void {
        OnEmailInvalidCommand onEmailInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onEmailInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((VerifyView)iterator.next()).w();
        }
        this.viewCommands.afterApply((ViewCommand)onEmailInvalidCommand);
    }

    func y() -> void {
        OnLoginAlreadyTakenCommand onLoginAlreadyTakenCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLoginAlreadyTakenCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((VerifyView)iterator.next()).y();
        }
        this.viewCommands.afterApply((ViewCommand)onLoginAlreadyTakenCommand);
    }

    func z() -> void {
        OnPasswordInvalidCommand onPasswordInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onPasswordInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((VerifyView)iterator.next()).z();
        }
        this.viewCommands.afterApply((ViewCommand)onPasswordInvalidCommand);
    }
}

