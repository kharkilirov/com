/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyPresenter
 *  io.reactivex.functions.Action
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.internal.Intrinsics
 *  moxy.MvpView
 */
package com.swiftsoft.anixartd.presentation.auth.signup.verify;

import com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyPresenter;
import com.swiftsoft.anixartd.presentation.auth.signup.verify.VerifyView;
import io.reactivex.functions.Action;
import kotlin.jvm.internal.Intrinsics;
import moxy.MvpView;

final class a
implements Action {
    final /* synthetic */ Int b;
    final /* synthetic */ VerifyPresenter c;

    /* synthetic */ a(VerifyPresenter verifyPresenter, Int n) {
        this.b = n;
        this.c = verifyPresenter;
    }

    final void run() {
        switch (this.b) {
            default: {
                break;
            }
            case 0: {
                VerifyPresenter verifyPresenter = this.c;
                Intrinsics.h((Object)verifyPresenter, (String)"this$0");
                ((VerifyView)verifyPresenter.getViewState()).j();
                return;
            }
        }
        VerifyPresenter verifyPresenter = this.c;
        Intrinsics.h((Object)verifyPresenter, (String)"this$0");
        ((VerifyView)verifyPresenter.getViewState()).j();
    }
}

