/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.auth.AuthPresenter
 *  com.swiftsoft.anixartd.repository.AuthRepository
 *  com.swiftsoft.anixartd.repository.ConfigRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.auth;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.auth.AuthPresenter;
import com.swiftsoft.anixartd.repository.AuthRepository;
import com.swiftsoft.anixartd.repository.ConfigRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class AuthPresenter_Factory
implements Factory<AuthPresenter> {
    final Provider<AuthRepository> a;
    final Provider<ConfigRepository> b;
    final Provider<Prefs> c;

    init(Provider<AuthRepository> provider, Provider<ConfigRepository> provider2, Provider<Prefs> provider3) {
        this.a = provider;
        this.b = provider2;
        this.c = provider3;
    }

    func get() -> Object {
        return new AuthPresenter((AuthRepository)this.a.get(), (ConfigRepository)this.b.get(), (Prefs)this.c.get());
    }
}

