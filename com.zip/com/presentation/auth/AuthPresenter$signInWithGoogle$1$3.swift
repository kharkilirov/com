/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Profile
 *  com.swiftsoft.anixartd.database.entity.ProfileToken
 *  com.swiftsoft.anixartd.database.entity.User
 *  com.swiftsoft.anixartd.network.response.auth.GoogleResponse
 *  com.swiftsoft.anixartd.presentation.auth.AuthPresenter
 *  com.swiftsoft.anixartd.presentation.auth.AuthView
 *  com.swiftsoft.anixartd.repository.AuthRepository
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Lambda
 *  moxy.MvpView
 */
package com.swiftsoft.anixartd.presentation.auth;

import com.swiftsoft.anixartd.database.entity.Profile;
import com.swiftsoft.anixartd.database.entity.ProfileToken;
import com.swiftsoft.anixartd.database.entity.User;
import com.swiftsoft.anixartd.network.response.auth.GoogleResponse;
import com.swiftsoft.anixartd.presentation.auth.AuthPresenter;
import com.swiftsoft.anixartd.presentation.auth.AuthView;
import com.swiftsoft.anixartd.repository.AuthRepository;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Lambda;
import moxy.MvpView;

@Metadata(d1={"\u0000\u0010\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0000\u001a\u00020\u00012\u000e\u0010\u0002\u001a\n \u0004*\u0004\u0018\u00010\u00030\u0003H\n\u00a2\u0006\u0002\b\u0005"}, d2={"<anonymous>", "", "googleResponse", "Lcom/swiftsoft/anixartd/network/response/auth/GoogleResponse;", "kotlin.jvm.PlatformType", "invoke"}, k=3, mv={1, 7, 1}, xi=48)
final class AuthPresenter$signInWithGoogle$1$3
extends Lambda
implements Function1<GoogleResponse, Unit> {
    final /* synthetic */ AuthPresenter b;
    final /* synthetic */ String c;
    final /* synthetic */ String d;

    AuthPresenter$signInWithGoogle$1$3(AuthPresenter authPresenter, String string, String string2) {
        this.b = authPresenter;
        this.c = string;
        this.d = string2;
        super(1);
    }

    func invoke(Object object) -> Object {
        GoogleResponse googleResponse = (GoogleResponse)object;
        if (googleResponse.isSuccess()) {
            Profile profile = googleResponse.getProfile();
            ProfileToken profileToken = googleResponse.getProfileToken();
            if (profile != null && profileToken != null) {
                this.b.a.d(profile.getId());
                this.b.a.c(profile.getPrivilegeLevel());
                this.b.a.e(profileToken.getToken());
                this.b.a.b(false);
                User user = new User();
                user.setName(profile.getLogin());
                user.setAvatar(profile.getAvatar());
                this.b.a.a(user);
                ((AuthView)this.b.getViewState()).t();
            }
        } else {
            Int n = googleResponse.getCode();
            if (n != 2) {
                if (n == 3) {
                    ((AuthView)this.b.getViewState()).q3(this.c, this.d);
                }
            } else {
                ((AuthView)this.b.getViewState()).P();
            }
        }
        return Unit.a;
    }
}

