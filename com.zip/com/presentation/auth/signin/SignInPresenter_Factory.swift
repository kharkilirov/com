/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.auth.signin.SignInPresenter
 *  com.swiftsoft.anixartd.repository.AuthRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.auth.signin;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.auth.signin.SignInPresenter;
import com.swiftsoft.anixartd.repository.AuthRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class SignInPresenter_Factory
implements Factory<SignInPresenter> {
    final Provider<AuthRepository> a;
    final Provider<Prefs> b;

    init(Provider<AuthRepository> provider, Provider<Prefs> provider2) {
        this.a = provider;
        this.b = provider2;
    }

    func get() -> Object {
        return new SignInPresenter((AuthRepository)this.a.get(), (Prefs)this.b.get());
    }
}

