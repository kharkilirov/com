/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.auth.signin.SignInView
 *  com.swiftsoft.anixartd.presentation.auth.signin.SignInView$$State$OnHideLoadingViewCommand
 *  com.swiftsoft.anixartd.presentation.auth.signin.SignInView$$State$OnLoginEmptyCommand
 *  com.swiftsoft.anixartd.presentation.auth.signin.SignInView$$State$OnLoginInvalidCommand
 *  com.swiftsoft.anixartd.presentation.auth.signin.SignInView$$State$OnMainCommand
 *  com.swiftsoft.anixartd.presentation.auth.signin.SignInView$$State$OnPasswordIncorrectCommand
 *  com.swiftsoft.anixartd.presentation.auth.signin.SignInView$$State$OnPasswordInvalidCommand
 *  com.swiftsoft.anixartd.presentation.auth.signin.SignInView$$State$OnShowLoadingViewCommand
 *  com.swiftsoft.anixartd.presentation.auth.signin.SignInView$$State$OnUnknownErrorCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.auth.signin;

import com.swiftsoft.anixartd.presentation.auth.signin.SignInView;
import com.swiftsoft.anixartd.presentation.auth.signin.SignInView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class SignInView$$State
extends MvpViewState<SignInView>
implements SignInView {
    func E(String string) -> void {
        OnUnknownErrorCommand onUnknownErrorCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onUnknownErrorCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignInView)iterator.next()).E(string);
        }
        this.viewCommands.afterApply((ViewCommand)onUnknownErrorCommand);
    }

    func L() -> void {
        OnLoginEmptyCommand onLoginEmptyCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLoginEmptyCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignInView)iterator.next()).L();
        }
        this.viewCommands.afterApply((ViewCommand)onLoginEmptyCommand);
    }

    func Z() -> void {
        OnPasswordIncorrectCommand onPasswordIncorrectCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onPasswordIncorrectCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignInView)iterator.next()).Z();
        }
        this.viewCommands.afterApply((ViewCommand)onPasswordIncorrectCommand);
    }

    func h() -> void {
        OnShowLoadingViewCommand onShowLoadingViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowLoadingViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignInView)iterator.next()).h();
        }
        this.viewCommands.afterApply((ViewCommand)onShowLoadingViewCommand);
    }

    func j() -> void {
        OnHideLoadingViewCommand onHideLoadingViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideLoadingViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignInView)iterator.next()).j();
        }
        this.viewCommands.afterApply((ViewCommand)onHideLoadingViewCommand);
    }

    func r() -> void {
        OnLoginInvalidCommand onLoginInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLoginInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignInView)iterator.next()).r();
        }
        this.viewCommands.afterApply((ViewCommand)onLoginInvalidCommand);
    }

    func z() -> void {
        OnPasswordInvalidCommand onPasswordInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onPasswordInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignInView)iterator.next()).z();
        }
        this.viewCommands.afterApply((ViewCommand)onPasswordInvalidCommand);
    }

    func z3(Bool bl) -> void {
        OnMainCommand onMainCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onMainCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SignInView)iterator.next()).z3(bl);
        }
        this.viewCommands.afterApply((ViewCommand)onMainCommand);
    }
}

