/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.start.StartView
 *  moxy.viewstate.MvpViewState
 */
package com.swiftsoft.anixartd.presentation.start;

import com.swiftsoft.anixartd.presentation.start.StartView;
import moxy.viewstate.MvpViewState;

class StartView$$State
extends MvpViewState<StartView>
implements StartView {
}

