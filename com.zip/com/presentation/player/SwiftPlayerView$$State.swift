/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.player.SwiftPlayerView
 *  com.swiftsoft.anixartd.presentation.player.SwiftPlayerView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.player.SwiftPlayerView$$State$OnParsingFailedCommand
 *  com.swiftsoft.anixartd.presentation.player.SwiftPlayerView$$State$OnQualitiesCommand
 *  com.swiftsoft.anixartd.presentation.player.SwiftPlayerView$$State$OnSetupEpisodeNameCommand
 *  com.swiftsoft.anixartd.presentation.player.SwiftPlayerView$$State$OnSetupReleaseTitleCommand
 *  com.swiftsoft.anixartd.presentation.player.SwiftPlayerView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.player.SwiftPlayerView$$State$OnShowTooltipPlayerSkipOpeningCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.player;

import com.swiftsoft.anixartd.presentation.player.SwiftPlayerView;
import com.swiftsoft.anixartd.presentation.player.SwiftPlayerView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class SwiftPlayerView$$State
extends MvpViewState<SwiftPlayerView>
implements SwiftPlayerView {
    func S1() -> void {
        OnShowTooltipPlayerSkipOpeningCommand onShowTooltipPlayerSkipOpeningCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowTooltipPlayerSkipOpeningCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SwiftPlayerView)iterator.next()).S1();
        }
        this.viewCommands.afterApply((ViewCommand)onShowTooltipPlayerSkipOpeningCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SwiftPlayerView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func a4() -> void {
        OnSetupEpisodeNameCommand onSetupEpisodeNameCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onSetupEpisodeNameCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SwiftPlayerView)iterator.next()).a4();
        }
        this.viewCommands.afterApply((ViewCommand)onSetupEpisodeNameCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SwiftPlayerView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func h4() -> void {
        OnParsingFailedCommand onParsingFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onParsingFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SwiftPlayerView)iterator.next()).h4();
        }
        this.viewCommands.afterApply((ViewCommand)onParsingFailedCommand);
    }

    func k2(String string, String string2, String string3, String string4, String string5, long l, Bool bl, Bool bl2) -> void {
        OnQualitiesCommand onQualitiesCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onQualitiesCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SwiftPlayerView)iterator.next()).k2(string, string2, string3, string4, string5, l, bl, bl2);
        }
        this.viewCommands.afterApply((ViewCommand)onQualitiesCommand);
    }

    func l1() -> void {
        OnSetupReleaseTitleCommand onSetupReleaseTitleCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onSetupReleaseTitleCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SwiftPlayerView)iterator.next()).l1();
        }
        this.viewCommands.afterApply((ViewCommand)onSetupReleaseTitleCommand);
    }
}

