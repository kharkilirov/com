/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.genres.ChooseGenresPresenter
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.genres;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.genres.ChooseGenresPresenter;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class ChooseGenresPresenter_Factory
implements Factory<ChooseGenresPresenter> {
    final Provider<Prefs> a;

    init(Provider<Prefs> provider) {
        this.a = provider;
    }

    func get() -> Object {
        return new ChooseGenresPresenter((Prefs)this.a.get());
    }
}

