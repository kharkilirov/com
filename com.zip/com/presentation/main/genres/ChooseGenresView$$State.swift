/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.genres.ChooseGenresView
 *  com.swiftsoft.anixartd.presentation.main.genres.ChooseGenresView$$State$OnCheckOrUncheckCommand
 *  com.swiftsoft.anixartd.presentation.main.genres.ChooseGenresView$$State$OnFailedCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.genres;

import com.swiftsoft.anixartd.presentation.main.genres.ChooseGenresView;
import com.swiftsoft.anixartd.presentation.main.genres.ChooseGenresView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class ChooseGenresView$$State
extends MvpViewState<ChooseGenresView>
implements ChooseGenresView {
    func W1() -> void {
        OnCheckOrUncheckCommand onCheckOrUncheckCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCheckOrUncheckCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ChooseGenresView)iterator.next()).W1();
        }
        this.viewCommands.afterApply((ViewCommand)onCheckOrUncheckCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ChooseGenresView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }
}

