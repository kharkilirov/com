/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.widget.ImageView
 *  com.swiftsoft.anixartd.database.entity.Collection
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.database.entity.ReleaseComment
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnAddShortcutCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnAddShortcutFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnBannedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnChooseTypeDialogCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnCollectionReleaseAddedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnCollectionReleaseAlreadyInCollectionCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnCollectionReleaseLimitReachedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnCommentCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnCommentDeletedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnCommentLimitReachedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnCommentNegativeVoteLimitReachedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnCommentSentCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnCommentVoteBannedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnDelVoteFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnHideDelVoteProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnHideLoadingViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnHideRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnHideSendingCommentProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnHideVotingProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnProfileCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnReleaseCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnReleaseLoadedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnReleaseUnavailableCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnRepliesCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnReplyCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnReportSentCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnScreenshotCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnShowCommentReportFragmentCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnShowDelVoteProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnShowLoadingViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnShowNeedAuthCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnShowRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnShowReleaseReportFragmentCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnShowSendingCommentProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnShowTooltipRandomReleaseCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnShowVotingProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnVideoCategoryBannerCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnVideoCategoryBannerMoreCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnVoteCommentCommand
 *  com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State$OnVoteFailedCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.release;

import android.widget.ImageView;
import com.swiftsoft.anixartd.database.entity.Collection;
import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.database.entity.ReleaseComment;
import com.swiftsoft.anixartd.presentation.main.release.ReleaseView;
import com.swiftsoft.anixartd.presentation.main.release.ReleaseView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class ReleaseView$$State
extends MvpViewState<ReleaseView>
implements ReleaseView {
    func A() -> void {
        OnCommentLimitReachedCommand onCommentLimitReachedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentLimitReachedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).A();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentLimitReachedCommand);
    }

    func B() -> void {
        OnCommentSentCommand onCommentSentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentSentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).B();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentSentCommand);
    }

    func C3(Collection collection) -> void {
        OnCollectionReleaseAddedCommand onCollectionReleaseAddedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCollectionReleaseAddedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).C3(collection);
        }
        this.viewCommands.afterApply((ViewCommand)onCollectionReleaseAddedCommand);
    }

    func D() -> void {
        OnHideSendingCommentProgressViewCommand onHideSendingCommentProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideSendingCommentProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).D();
        }
        this.viewCommands.afterApply((ViewCommand)onHideSendingCommentProgressViewCommand);
    }

    func F() -> void {
        OnCommentDeletedCommand onCommentDeletedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentDeletedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).F();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentDeletedCommand);
    }

    func G() -> void {
        OnCommentVoteBannedCommand onCommentVoteBannedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentVoteBannedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).G();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentVoteBannedCommand);
    }

    func I0(long l, long l2, String string, String string2) -> void {
        OnVideoCategoryBannerCommand onVideoCategoryBannerCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVideoCategoryBannerCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).I0(l, l2, string, string2);
        }
        this.viewCommands.afterApply((ViewCommand)onVideoCategoryBannerCommand);
    }

    func I3(Release release) -> void {
        OnShowReleaseReportFragmentCommand onShowReleaseReportFragmentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowReleaseReportFragmentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).I3(release);
        }
        this.viewCommands.afterApply((ViewCommand)onShowReleaseReportFragmentCommand);
    }

    func P0(String string, ImageView imageView) -> void {
        OnScreenshotCommand onScreenshotCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onScreenshotCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).P0(string, imageView);
        }
        this.viewCommands.afterApply((ViewCommand)onScreenshotCommand);
    }

    func P3() -> void {
        OnChooseTypeDialogCommand onChooseTypeDialogCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onChooseTypeDialogCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).P3();
        }
        this.viewCommands.afterApply((ViewCommand)onChooseTypeDialogCommand);
    }

    func T2() -> void {
        OnAddShortcutFailedCommand onAddShortcutFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onAddShortcutFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).T2();
        }
        this.viewCommands.afterApply((ViewCommand)onAddShortcutFailedCommand);
    }

    func U(ReleaseComment releaseComment) -> void {
        OnCommentCommand onCommentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).U(releaseComment);
        }
        this.viewCommands.afterApply((ViewCommand)onCommentCommand);
    }

    func W(ReleaseComment releaseComment, Int n) -> void {
        OnVoteCommentCommand onVoteCommentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVoteCommentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).W(releaseComment, n);
        }
        this.viewCommands.afterApply((ViewCommand)onVoteCommentCommand);
    }

    func X(ReleaseComment releaseComment) -> void {
        OnReplyCommand onReplyCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReplyCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).X(releaseComment);
        }
        this.viewCommands.afterApply((ViewCommand)onReplyCommand);
    }

    func Y0(long l) -> void {
        OnVideoCategoryBannerMoreCommand onVideoCategoryBannerMoreCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVideoCategoryBannerMoreCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).Y0(l);
        }
        this.viewCommands.afterApply((ViewCommand)onVideoCategoryBannerMoreCommand);
    }

    func Z1() -> void {
        OnHideVotingProgressViewCommand onHideVotingProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideVotingProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).Z1();
        }
        this.viewCommands.afterApply((ViewCommand)onHideVotingProgressViewCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func c0(ReleaseComment releaseComment) -> void {
        OnShowCommentReportFragmentCommand onShowCommentReportFragmentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowCommentReportFragmentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).c0(releaseComment);
        }
        this.viewCommands.afterApply((ViewCommand)onShowCommentReportFragmentCommand);
    }

    func d() -> void {
        OnShowRefreshViewCommand onShowRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).d();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRefreshViewCommand);
    }

    func e() -> void {
        OnHideRefreshViewCommand onHideRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).e();
        }
        this.viewCommands.afterApply((ViewCommand)onHideRefreshViewCommand);
    }

    func e3() -> void {
        OnShowTooltipRandomReleaseCommand onShowTooltipRandomReleaseCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowTooltipRandomReleaseCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).e3();
        }
        this.viewCommands.afterApply((ViewCommand)onShowTooltipRandomReleaseCommand);
    }

    func f(long l) -> void {
        OnProfileCommand onProfileCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onProfileCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).f(l);
        }
        this.viewCommands.afterApply((ViewCommand)onProfileCommand);
    }

    func g(long l) -> void {
        OnReleaseCommand onReleaseCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReleaseCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).g(l);
        }
        this.viewCommands.afterApply((ViewCommand)onReleaseCommand);
    }

    func h() -> void {
        OnShowLoadingViewCommand onShowLoadingViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowLoadingViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).h();
        }
        this.viewCommands.afterApply((ViewCommand)onShowLoadingViewCommand);
    }

    func j() -> void {
        OnHideLoadingViewCommand onHideLoadingViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideLoadingViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).j();
        }
        this.viewCommands.afterApply((ViewCommand)onHideLoadingViewCommand);
    }

    func m() -> void {
        OnShowNeedAuthCommand onShowNeedAuthCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowNeedAuthCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).m();
        }
        this.viewCommands.afterApply((ViewCommand)onShowNeedAuthCommand);
    }

    func m3() -> void {
        OnCollectionReleaseAlreadyInCollectionCommand onCollectionReleaseAlreadyInCollectionCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCollectionReleaseAlreadyInCollectionCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).m3();
        }
        this.viewCommands.afterApply((ViewCommand)onCollectionReleaseAlreadyInCollectionCommand);
    }

    func n() -> void {
        OnReportSentCommand onReportSentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReportSentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).n();
        }
        this.viewCommands.afterApply((ViewCommand)onReportSentCommand);
    }

    func o() -> void {
        OnBannedCommand onBannedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onBannedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).o();
        }
        this.viewCommands.afterApply((ViewCommand)onBannedCommand);
    }

    func p1() -> void {
        OnDelVoteFailedCommand onDelVoteFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onDelVoteFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).p1();
        }
        this.viewCommands.afterApply((ViewCommand)onDelVoteFailedCommand);
    }

    func p2() -> void {
        OnReleaseUnavailableCommand onReleaseUnavailableCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReleaseUnavailableCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).p2();
        }
        this.viewCommands.afterApply((ViewCommand)onReleaseUnavailableCommand);
    }

    func q1(Release release) -> void {
        OnAddShortcutCommand onAddShortcutCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onAddShortcutCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).q1(release);
        }
        this.viewCommands.afterApply((ViewCommand)onAddShortcutCommand);
    }

    func s() -> void {
        OnShowSendingCommentProgressViewCommand onShowSendingCommentProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowSendingCommentProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).s();
        }
        this.viewCommands.afterApply((ViewCommand)onShowSendingCommentProgressViewCommand);
    }

    func s1() -> void {
        OnShowDelVoteProgressViewCommand onShowDelVoteProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowDelVoteProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).s1();
        }
        this.viewCommands.afterApply((ViewCommand)onShowDelVoteProgressViewCommand);
    }

    func u1() -> void {
        OnVoteFailedCommand onVoteFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVoteFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).u1();
        }
        this.viewCommands.afterApply((ViewCommand)onVoteFailedCommand);
    }

    func w3() -> void {
        OnCollectionReleaseLimitReachedCommand onCollectionReleaseLimitReachedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCollectionReleaseLimitReachedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).w3();
        }
        this.viewCommands.afterApply((ViewCommand)onCollectionReleaseLimitReachedCommand);
    }

    func x() -> void {
        OnCommentNegativeVoteLimitReachedCommand onCommentNegativeVoteLimitReachedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentNegativeVoteLimitReachedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).x();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentNegativeVoteLimitReachedCommand);
    }

    func x3(Release release) -> void {
        OnReleaseLoadedCommand onReleaseLoadedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReleaseLoadedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).x3(release);
        }
        this.viewCommands.afterApply((ViewCommand)onReleaseLoadedCommand);
    }

    func y1() -> void {
        OnShowVotingProgressViewCommand onShowVotingProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowVotingProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).y1();
        }
        this.viewCommands.afterApply((ViewCommand)onShowVotingProgressViewCommand);
    }

    func z0(ReleaseComment releaseComment) -> void {
        OnRepliesCommand onRepliesCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onRepliesCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).z0(releaseComment);
        }
        this.viewCommands.afterApply((ViewCommand)onRepliesCommand);
    }

    func z1() -> void {
        OnHideDelVoteProgressViewCommand onHideDelVoteProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideDelVoteProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseView)iterator.next()).z1();
        }
        this.viewCommands.afterApply((ViewCommand)onHideDelVoteProgressViewCommand);
    }
}

