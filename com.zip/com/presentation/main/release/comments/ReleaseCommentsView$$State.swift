/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.ReleaseComment
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnBannedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnCommentCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnCommentDeletedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnCommentLimitReachedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnCommentNegativeVoteLimitReachedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnCommentSentCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnCommentVoteBannedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnHideLoadingCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnHideRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnHideSendingCommentProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnInBlockListCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnLoadingCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnProfileCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnRefreshAfterSortCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnRepliesCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnReplyCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnReportSentCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnShowCommentReportFragmentCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnShowNeedAuthCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnShowRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnShowSendingCommentProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State$OnVoteCommentCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.release.comments;

import com.swiftsoft.anixartd.database.entity.ReleaseComment;
import com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView;
import com.swiftsoft.anixartd.presentation.main.release.comments.ReleaseCommentsView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class ReleaseCommentsView$$State
extends MvpViewState<ReleaseCommentsView>
implements ReleaseCommentsView {
    func A() -> void {
        OnCommentLimitReachedCommand onCommentLimitReachedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentLimitReachedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).A();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentLimitReachedCommand);
    }

    func B() -> void {
        OnCommentSentCommand onCommentSentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentSentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).B();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentSentCommand);
    }

    func D() -> void {
        OnHideSendingCommentProgressViewCommand onHideSendingCommentProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideSendingCommentProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).D();
        }
        this.viewCommands.afterApply((ViewCommand)onHideSendingCommentProgressViewCommand);
    }

    func F() -> void {
        OnCommentDeletedCommand onCommentDeletedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentDeletedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).F();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentDeletedCommand);
    }

    func G() -> void {
        OnCommentVoteBannedCommand onCommentVoteBannedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentVoteBannedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).G();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentVoteBannedCommand);
    }

    func H() -> void {
        OnInBlockListCommand onInBlockListCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onInBlockListCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).H();
        }
        this.viewCommands.afterApply((ViewCommand)onInBlockListCommand);
    }

    func U(ReleaseComment releaseComment) -> void {
        OnCommentCommand onCommentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).U(releaseComment);
        }
        this.viewCommands.afterApply((ViewCommand)onCommentCommand);
    }

    func W(ReleaseComment releaseComment, Int n) -> void {
        OnVoteCommentCommand onVoteCommentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVoteCommentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).W(releaseComment, n);
        }
        this.viewCommands.afterApply((ViewCommand)onVoteCommentCommand);
    }

    func X(ReleaseComment releaseComment) -> void {
        OnReplyCommand onReplyCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReplyCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).X(releaseComment);
        }
        this.viewCommands.afterApply((ViewCommand)onReplyCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func c0(ReleaseComment releaseComment) -> void {
        OnShowCommentReportFragmentCommand onShowCommentReportFragmentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowCommentReportFragmentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).c0(releaseComment);
        }
        this.viewCommands.afterApply((ViewCommand)onShowCommentReportFragmentCommand);
    }

    func d() -> void {
        OnShowRefreshViewCommand onShowRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).d();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRefreshViewCommand);
    }

    func e() -> void {
        OnHideRefreshViewCommand onHideRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).e();
        }
        this.viewCommands.afterApply((ViewCommand)onHideRefreshViewCommand);
    }

    func f(long l) -> void {
        OnProfileCommand onProfileCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onProfileCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).f(l);
        }
        this.viewCommands.afterApply((ViewCommand)onProfileCommand);
    }

    func l() -> void {
        OnRefreshAfterSortCommand onRefreshAfterSortCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onRefreshAfterSortCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).l();
        }
        this.viewCommands.afterApply((ViewCommand)onRefreshAfterSortCommand);
    }

    func m() -> void {
        OnShowNeedAuthCommand onShowNeedAuthCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowNeedAuthCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).m();
        }
        this.viewCommands.afterApply((ViewCommand)onShowNeedAuthCommand);
    }

    func n() -> void {
        OnReportSentCommand onReportSentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReportSentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).n();
        }
        this.viewCommands.afterApply((ViewCommand)onReportSentCommand);
    }

    func o() -> void {
        OnBannedCommand onBannedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onBannedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).o();
        }
        this.viewCommands.afterApply((ViewCommand)onBannedCommand);
    }

    func p() -> void {
        OnHideLoadingCommand onHideLoadingCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideLoadingCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).p();
        }
        this.viewCommands.afterApply((ViewCommand)onHideLoadingCommand);
    }

    func q() -> void {
        OnLoadingCommand onLoadingCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLoadingCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).q();
        }
        this.viewCommands.afterApply((ViewCommand)onLoadingCommand);
    }

    func s() -> void {
        OnShowSendingCommentProgressViewCommand onShowSendingCommentProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowSendingCommentProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).s();
        }
        this.viewCommands.afterApply((ViewCommand)onShowSendingCommentProgressViewCommand);
    }

    func x() -> void {
        OnCommentNegativeVoteLimitReachedCommand onCommentNegativeVoteLimitReachedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentNegativeVoteLimitReachedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).x();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentNegativeVoteLimitReachedCommand);
    }

    func z0(ReleaseComment releaseComment) -> void {
        OnRepliesCommand onRepliesCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onRepliesCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsView)iterator.next()).z0(releaseComment);
        }
        this.viewCommands.afterApply((ViewCommand)onRepliesCommand);
    }
}

