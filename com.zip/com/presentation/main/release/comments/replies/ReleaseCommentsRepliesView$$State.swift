/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.ReleaseComment
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnBannedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnCommentCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnCommentDeletedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnCommentLimitReachedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnCommentNegativeVoteLimitReachedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnCommentSentCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnCommentVoteBannedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnHideLoadingCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnHideRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnHideSendingCommentProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnInBlockListCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnLoadingCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnParentCommentLoadedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnParentCommentRemovedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnProfileCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnRefreshAfterSortCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnReleaseCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnReplyCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnReportSentCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnShowCommentReportFragmentCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnShowNeedAuthCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnShowRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnShowSendingCommentProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State$OnVoteCommentCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.release.comments.replies;

import com.swiftsoft.anixartd.database.entity.ReleaseComment;
import com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView;
import com.swiftsoft.anixartd.presentation.main.release.comments.replies.ReleaseCommentsRepliesView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class ReleaseCommentsRepliesView$$State
extends MvpViewState<ReleaseCommentsRepliesView>
implements ReleaseCommentsRepliesView {
    func A() -> void {
        OnCommentLimitReachedCommand onCommentLimitReachedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentLimitReachedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).A();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentLimitReachedCommand);
    }

    func B() -> void {
        OnCommentSentCommand onCommentSentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentSentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).B();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentSentCommand);
    }

    func D() -> void {
        OnHideSendingCommentProgressViewCommand onHideSendingCommentProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideSendingCommentProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).D();
        }
        this.viewCommands.afterApply((ViewCommand)onHideSendingCommentProgressViewCommand);
    }

    func F() -> void {
        OnCommentDeletedCommand onCommentDeletedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentDeletedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).F();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentDeletedCommand);
    }

    func G() -> void {
        OnCommentVoteBannedCommand onCommentVoteBannedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentVoteBannedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).G();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentVoteBannedCommand);
    }

    func H() -> void {
        OnInBlockListCommand onInBlockListCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onInBlockListCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).H();
        }
        this.viewCommands.afterApply((ViewCommand)onInBlockListCommand);
    }

    func J2(ReleaseComment releaseComment) -> void {
        OnParentCommentLoadedCommand onParentCommentLoadedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onParentCommentLoadedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).J2(releaseComment);
        }
        this.viewCommands.afterApply((ViewCommand)onParentCommentLoadedCommand);
    }

    func U(ReleaseComment releaseComment) -> void {
        OnCommentCommand onCommentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).U(releaseComment);
        }
        this.viewCommands.afterApply((ViewCommand)onCommentCommand);
    }

    func W(ReleaseComment releaseComment, Int n) -> void {
        OnVoteCommentCommand onVoteCommentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVoteCommentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).W(releaseComment, n);
        }
        this.viewCommands.afterApply((ViewCommand)onVoteCommentCommand);
    }

    func X(ReleaseComment releaseComment) -> void {
        OnReplyCommand onReplyCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReplyCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).X(releaseComment);
        }
        this.viewCommands.afterApply((ViewCommand)onReplyCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func c0(ReleaseComment releaseComment) -> void {
        OnShowCommentReportFragmentCommand onShowCommentReportFragmentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowCommentReportFragmentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).c0(releaseComment);
        }
        this.viewCommands.afterApply((ViewCommand)onShowCommentReportFragmentCommand);
    }

    func d() -> void {
        OnShowRefreshViewCommand onShowRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).d();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRefreshViewCommand);
    }

    func e() -> void {
        OnHideRefreshViewCommand onHideRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).e();
        }
        this.viewCommands.afterApply((ViewCommand)onHideRefreshViewCommand);
    }

    func f(long l) -> void {
        OnProfileCommand onProfileCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onProfileCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).f(l);
        }
        this.viewCommands.afterApply((ViewCommand)onProfileCommand);
    }

    func g(long l) -> void {
        OnReleaseCommand onReleaseCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReleaseCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).g(l);
        }
        this.viewCommands.afterApply((ViewCommand)onReleaseCommand);
    }

    func l() -> void {
        OnRefreshAfterSortCommand onRefreshAfterSortCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onRefreshAfterSortCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).l();
        }
        this.viewCommands.afterApply((ViewCommand)onRefreshAfterSortCommand);
    }

    func m() -> void {
        OnShowNeedAuthCommand onShowNeedAuthCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowNeedAuthCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).m();
        }
        this.viewCommands.afterApply((ViewCommand)onShowNeedAuthCommand);
    }

    func n() -> void {
        OnReportSentCommand onReportSentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReportSentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).n();
        }
        this.viewCommands.afterApply((ViewCommand)onReportSentCommand);
    }

    func o() -> void {
        OnBannedCommand onBannedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onBannedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).o();
        }
        this.viewCommands.afterApply((ViewCommand)onBannedCommand);
    }

    func p() -> void {
        OnHideLoadingCommand onHideLoadingCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideLoadingCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).p();
        }
        this.viewCommands.afterApply((ViewCommand)onHideLoadingCommand);
    }

    func q() -> void {
        OnLoadingCommand onLoadingCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLoadingCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).q();
        }
        this.viewCommands.afterApply((ViewCommand)onLoadingCommand);
    }

    func s() -> void {
        OnShowSendingCommentProgressViewCommand onShowSendingCommentProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowSendingCommentProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).s();
        }
        this.viewCommands.afterApply((ViewCommand)onShowSendingCommentProgressViewCommand);
    }

    func v0() -> void {
        OnParentCommentRemovedCommand onParentCommentRemovedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onParentCommentRemovedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).v0();
        }
        this.viewCommands.afterApply((ViewCommand)onParentCommentRemovedCommand);
    }

    func x() -> void {
        OnCommentNegativeVoteLimitReachedCommand onCommentNegativeVoteLimitReachedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentNegativeVoteLimitReachedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseCommentsRepliesView)iterator.next()).x();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentNegativeVoteLimitReachedCommand);
    }
}

