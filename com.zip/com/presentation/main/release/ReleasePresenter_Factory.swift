/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.release.ReleasePresenter
 *  com.swiftsoft.anixartd.repository.AuthRepository
 *  com.swiftsoft.anixartd.repository.CollectionRepository
 *  com.swiftsoft.anixartd.repository.NotificationPreferenceRepository
 *  com.swiftsoft.anixartd.repository.ReleaseCommentRepository
 *  com.swiftsoft.anixartd.repository.ReleaseRepository
 *  com.swiftsoft.anixartd.repository.TypeRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.release;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.release.ReleasePresenter;
import com.swiftsoft.anixartd.repository.AuthRepository;
import com.swiftsoft.anixartd.repository.CollectionRepository;
import com.swiftsoft.anixartd.repository.NotificationPreferenceRepository;
import com.swiftsoft.anixartd.repository.ReleaseCommentRepository;
import com.swiftsoft.anixartd.repository.ReleaseRepository;
import com.swiftsoft.anixartd.repository.TypeRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class ReleasePresenter_Factory
implements Factory<ReleasePresenter> {
    final Provider<AuthRepository> a;
    final Provider<TypeRepository> b;
    final Provider<ReleaseRepository> c;
    final Provider<ReleaseCommentRepository> d;
    final Provider<CollectionRepository> e;
    final Provider<NotificationPreferenceRepository> f;
    final Provider<Prefs> g;

    init(Provider<AuthRepository> provider, Provider<TypeRepository> provider2, Provider<ReleaseRepository> provider3, Provider<ReleaseCommentRepository> provider4, Provider<CollectionRepository> provider5, Provider<NotificationPreferenceRepository> provider6, Provider<Prefs> provider7) {
        this.a = provider;
        this.b = provider2;
        this.c = provider3;
        this.d = provider4;
        this.e = provider5;
        this.f = provider6;
        this.g = provider7;
    }

    func get() -> Object {
        AuthRepository authRepository = (AuthRepository)this.a.get();
        TypeRepository typeRepository = (TypeRepository)this.b.get();
        ReleaseRepository releaseRepository = (ReleaseRepository)this.c.get();
        ReleaseCommentRepository releaseCommentRepository = (ReleaseCommentRepository)this.d.get();
        CollectionRepository collectionRepository = (CollectionRepository)this.e.get();
        NotificationPreferenceRepository notificationPreferenceRepository = (NotificationPreferenceRepository)this.f.get();
        Prefs prefs = (Prefs)this.g.get();
        ReleasePresenter releasePresenter = new ReleasePresenter(authRepository, typeRepository, releaseRepository, releaseCommentRepository, collectionRepository, notificationPreferenceRepository, prefs);
        return releasePresenter;
    }
}

