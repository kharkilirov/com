/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.ReleaseVideo
 *  com.swiftsoft.anixartd.database.entity.ReleaseVideoCategory
 *  com.swiftsoft.anixartd.presentation.main.release.video.ReleaseVideosView
 *  com.swiftsoft.anixartd.presentation.main.release.video.ReleaseVideosView$$State$OnCanAppealCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.ReleaseVideosView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.ReleaseVideosView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.ReleaseVideosView$$State$OnHideRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.ReleaseVideosView$$State$OnSectionHeaderButtonCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.ReleaseVideosView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.ReleaseVideosView$$State$OnShowRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.ReleaseVideosView$$State$OnStreamingPlatformCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.ReleaseVideosView$$State$OnVideoCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.release.video;

import com.swiftsoft.anixartd.database.entity.ReleaseVideo;
import com.swiftsoft.anixartd.database.entity.ReleaseVideoCategory;
import com.swiftsoft.anixartd.presentation.main.release.video.ReleaseVideosView;
import com.swiftsoft.anixartd.presentation.main.release.video.ReleaseVideosView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class ReleaseVideosView$$State
extends MvpViewState<ReleaseVideosView>
implements ReleaseVideosView {
    func K(ReleaseVideo releaseVideo) -> void {
        OnVideoCommand onVideoCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVideoCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideosView)iterator.next()).K(releaseVideo);
        }
        this.viewCommands.afterApply((ViewCommand)onVideoCommand);
    }

    func K1(Bool bl) -> void {
        OnCanAppealCommand onCanAppealCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCanAppealCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideosView)iterator.next()).K1(bl);
        }
        this.viewCommands.afterApply((ViewCommand)onCanAppealCommand);
    }

    func T0(String string) -> void {
        OnStreamingPlatformCommand onStreamingPlatformCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onStreamingPlatformCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideosView)iterator.next()).T0(string);
        }
        this.viewCommands.afterApply((ViewCommand)onStreamingPlatformCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideosView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideosView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideosView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func d() -> void {
        OnShowRefreshViewCommand onShowRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideosView)iterator.next()).d();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRefreshViewCommand);
    }

    func e() -> void {
        OnHideRefreshViewCommand onHideRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideosView)iterator.next()).e();
        }
        this.viewCommands.afterApply((ViewCommand)onHideRefreshViewCommand);
    }

    func x1(ReleaseVideoCategory releaseVideoCategory) -> void {
        OnSectionHeaderButtonCommand onSectionHeaderButtonCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onSectionHeaderButtonCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideosView)iterator.next()).x1(releaseVideoCategory);
        }
        this.viewCommands.afterApply((ViewCommand)onSectionHeaderButtonCommand);
    }
}

