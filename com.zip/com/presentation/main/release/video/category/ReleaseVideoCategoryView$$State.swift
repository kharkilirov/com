/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.ReleaseVideo
 *  com.swiftsoft.anixartd.presentation.main.release.video.category.ReleaseVideoCategoryView
 *  com.swiftsoft.anixartd.presentation.main.release.video.category.ReleaseVideoCategoryView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.category.ReleaseVideoCategoryView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.category.ReleaseVideoCategoryView$$State$OnHideRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.category.ReleaseVideoCategoryView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.category.ReleaseVideoCategoryView$$State$OnShowRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.category.ReleaseVideoCategoryView$$State$OnVideoCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.release.video.category;

import com.swiftsoft.anixartd.database.entity.ReleaseVideo;
import com.swiftsoft.anixartd.presentation.main.release.video.category.ReleaseVideoCategoryView;
import com.swiftsoft.anixartd.presentation.main.release.video.category.ReleaseVideoCategoryView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class ReleaseVideoCategoryView$$State
extends MvpViewState<ReleaseVideoCategoryView>
implements ReleaseVideoCategoryView {
    func K(ReleaseVideo releaseVideo) -> void {
        OnVideoCommand onVideoCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVideoCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideoCategoryView)iterator.next()).K(releaseVideo);
        }
        this.viewCommands.afterApply((ViewCommand)onVideoCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideoCategoryView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideoCategoryView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideoCategoryView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func d() -> void {
        OnShowRefreshViewCommand onShowRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideoCategoryView)iterator.next()).d();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRefreshViewCommand);
    }

    func e() -> void {
        OnHideRefreshViewCommand onHideRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideoCategoryView)iterator.next()).e();
        }
        this.viewCommands.afterApply((ViewCommand)onHideRefreshViewCommand);
    }
}

