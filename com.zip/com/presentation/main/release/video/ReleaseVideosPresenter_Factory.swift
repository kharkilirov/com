/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.release.video.ReleaseVideosPresenter
 *  com.swiftsoft.anixartd.repository.ReleaseVideoRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.release.video;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.release.video.ReleaseVideosPresenter;
import com.swiftsoft.anixartd.repository.ReleaseVideoRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class ReleaseVideosPresenter_Factory
implements Factory<ReleaseVideosPresenter> {
    final Provider<ReleaseVideoRepository> a;
    final Provider<Prefs> b;

    init(Provider<ReleaseVideoRepository> provider, Provider<Prefs> provider2) {
        this.a = provider;
        this.b = provider2;
    }

    func get() -> Object {
        return new ReleaseVideosPresenter((ReleaseVideoRepository)this.a.get(), (Prefs)this.b.get());
    }
}

