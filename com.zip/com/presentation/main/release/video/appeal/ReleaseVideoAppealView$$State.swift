/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.release.video.appeal.ReleaseVideoAppealView
 *  com.swiftsoft.anixartd.presentation.main.release.video.appeal.ReleaseVideoAppealView$$State$OnAppealAlreadySentCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.appeal.ReleaseVideoAppealView$$State$OnAppealCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.appeal.ReleaseVideoAppealView$$State$OnCategoriesCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.appeal.ReleaseVideoAppealView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.appeal.ReleaseVideoAppealView$$State$OnHideLoadingCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.appeal.ReleaseVideoAppealView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.appeal.ReleaseVideoAppealView$$State$OnLoadingCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.appeal.ReleaseVideoAppealView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.appeal.ReleaseVideoAppealView$$State$OnTitleInvalidCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.appeal.ReleaseVideoAppealView$$State$OnTooManyAppealsCommand
 *  com.swiftsoft.anixartd.presentation.main.release.video.appeal.ReleaseVideoAppealView$$State$OnUrlInvalidCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.release.video.appeal;

import com.swiftsoft.anixartd.presentation.main.release.video.appeal.ReleaseVideoAppealView;
import com.swiftsoft.anixartd.presentation.main.release.video.appeal.ReleaseVideoAppealView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class ReleaseVideoAppealView$$State
extends MvpViewState<ReleaseVideoAppealView>
implements ReleaseVideoAppealView {
    func M2() -> void {
        OnTooManyAppealsCommand onTooManyAppealsCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onTooManyAppealsCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideoAppealView)iterator.next()).M2();
        }
        this.viewCommands.afterApply((ViewCommand)onTooManyAppealsCommand);
    }

    func Q1() -> void {
        OnAppealAlreadySentCommand onAppealAlreadySentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onAppealAlreadySentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideoAppealView)iterator.next()).Q1();
        }
        this.viewCommands.afterApply((ViewCommand)onAppealAlreadySentCommand);
    }

    func V0() -> void {
        OnTitleInvalidCommand onTitleInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onTitleInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideoAppealView)iterator.next()).V0();
        }
        this.viewCommands.afterApply((ViewCommand)onTitleInvalidCommand);
    }

    func V1() -> void {
        OnCategoriesCommand onCategoriesCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCategoriesCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideoAppealView)iterator.next()).V1();
        }
        this.viewCommands.afterApply((ViewCommand)onCategoriesCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideoAppealView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideoAppealView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideoAppealView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func d4() -> void {
        OnAppealCommand onAppealCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onAppealCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideoAppealView)iterator.next()).d4();
        }
        this.viewCommands.afterApply((ViewCommand)onAppealCommand);
    }

    func k4() -> void {
        OnUrlInvalidCommand onUrlInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onUrlInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideoAppealView)iterator.next()).k4();
        }
        this.viewCommands.afterApply((ViewCommand)onUrlInvalidCommand);
    }

    func p() -> void {
        OnHideLoadingCommand onHideLoadingCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideLoadingCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideoAppealView)iterator.next()).p();
        }
        this.viewCommands.afterApply((ViewCommand)onHideLoadingCommand);
    }

    func q() -> void {
        OnLoadingCommand onLoadingCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLoadingCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseVideoAppealView)iterator.next()).q();
        }
        this.viewCommands.afterApply((ViewCommand)onLoadingCommand);
    }
}

