/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.streaming.ReleaseStreamingPlatformPresenter
 *  com.swiftsoft.anixartd.repository.ReleaseStreamingPlatformRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.streaming;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.streaming.ReleaseStreamingPlatformPresenter;
import com.swiftsoft.anixartd.repository.ReleaseStreamingPlatformRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class ReleaseStreamingPlatformPresenter_Factory
implements Factory<ReleaseStreamingPlatformPresenter> {
    final Provider<ReleaseStreamingPlatformRepository> a;
    final Provider<Prefs> b;

    init(Provider<ReleaseStreamingPlatformRepository> provider, Provider<Prefs> provider2) {
        this.a = provider;
        this.b = provider2;
    }

    func get() -> Object {
        return new ReleaseStreamingPlatformPresenter((ReleaseStreamingPlatformRepository)this.a.get(), (Prefs)this.b.get());
    }
}

