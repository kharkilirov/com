/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.streaming.ReleaseStreamingPlatformView
 *  com.swiftsoft.anixartd.presentation.main.streaming.ReleaseStreamingPlatformView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.streaming.ReleaseStreamingPlatformView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.streaming.ReleaseStreamingPlatformView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.streaming.ReleaseStreamingPlatformView$$State$OnStreamingPlatformCommand
 *  com.swiftsoft.anixartd.presentation.main.streaming.ReleaseStreamingPlatformView$$State$OnThirdPartyStreamingPlatformCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.streaming;

import com.swiftsoft.anixartd.presentation.main.streaming.ReleaseStreamingPlatformView;
import com.swiftsoft.anixartd.presentation.main.streaming.ReleaseStreamingPlatformView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class ReleaseStreamingPlatformView$$State
extends MvpViewState<ReleaseStreamingPlatformView>
implements ReleaseStreamingPlatformView {
    func K0() -> void {
        OnThirdPartyStreamingPlatformCommand onThirdPartyStreamingPlatformCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onThirdPartyStreamingPlatformCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseStreamingPlatformView)iterator.next()).K0();
        }
        this.viewCommands.afterApply((ViewCommand)onThirdPartyStreamingPlatformCommand);
    }

    func T0(String string) -> void {
        OnStreamingPlatformCommand onStreamingPlatformCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onStreamingPlatformCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseStreamingPlatformView)iterator.next()).T0(string);
        }
        this.viewCommands.afterApply((ViewCommand)onStreamingPlatformCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseStreamingPlatformView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseStreamingPlatformView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReleaseStreamingPlatformView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }
}

