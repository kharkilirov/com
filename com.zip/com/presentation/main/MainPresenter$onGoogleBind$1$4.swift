/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.MainPresenter
 *  com.swiftsoft.anixartd.presentation.main.MainView
 *  java.lang.Object
 *  java.lang.Throwable
 *  kotlin.Metadata
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Lambda
 *  moxy.MvpView
 */
package com.swiftsoft.anixartd.presentation.main;

import com.swiftsoft.anixartd.presentation.main.MainPresenter;
import com.swiftsoft.anixartd.presentation.main.MainView;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Lambda;
import moxy.MvpView;

@Metadata(d1={"\u0000\u0010\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0003\n\u0002\b\u0002\u0010\u0000\u001a\u00020\u00012\u000e\u0010\u0002\u001a\n \u0004*\u0004\u0018\u00010\u00030\u0003H\n\u00a2\u0006\u0002\b\u0005"}, d2={"<anonymous>", "", "it", "", "kotlin.jvm.PlatformType", "invoke"}, k=3, mv={1, 7, 1}, xi=48)
final class MainPresenter$onGoogleBind$1$4
extends Lambda
implements Function1<Throwable, Unit> {
    final /* synthetic */ MainPresenter b;

    MainPresenter$onGoogleBind$1$4(MainPresenter mainPresenter) {
        this.b = mainPresenter;
        super(1);
    }

    func invoke(Object object) -> Object {
        Throwable throwable = (Throwable)object;
        ((MainView)this.b.getViewState()).P();
        throwable.printStackTrace();
        return Unit.a;
    }
}

