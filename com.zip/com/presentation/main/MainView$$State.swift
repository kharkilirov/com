/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.MainView
 *  com.swiftsoft.anixartd.presentation.main.MainView$$State$OnAndroidTvHintCommand
 *  com.swiftsoft.anixartd.presentation.main.MainView$$State$OnAuthCommand
 *  com.swiftsoft.anixartd.presentation.main.MainView$$State$OnCheckForInAppUpdatesCommand
 *  com.swiftsoft.anixartd.presentation.main.MainView$$State$OnGoogleAlreadyBoundCommand
 *  com.swiftsoft.anixartd.presentation.main.MainView$$State$OnGoogleLoginFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.MainView$$State$OnGoogleNotBoundCommand
 *  com.swiftsoft.anixartd.presentation.main.MainView$$State$OnHideLoadingViewCommand
 *  com.swiftsoft.anixartd.presentation.main.MainView$$State$OnImmediateUpdateCommand
 *  com.swiftsoft.anixartd.presentation.main.MainView$$State$OnInvalidRequestCommand
 *  com.swiftsoft.anixartd.presentation.main.MainView$$State$OnNotificationCountCommand
 *  com.swiftsoft.anixartd.presentation.main.MainView$$State$OnPermBannedCommand
 *  com.swiftsoft.anixartd.presentation.main.MainView$$State$OnShowLoadingViewCommand
 *  com.swiftsoft.anixartd.presentation.main.MainView$$State$OnShowRateAppCommand
 *  com.swiftsoft.anixartd.presentation.main.MainView$$State$OnShowSubscribeVKCommand
 *  com.swiftsoft.anixartd.presentation.main.MainView$$State$OnShowTooltipBookmarksCommand
 *  com.swiftsoft.anixartd.presentation.main.MainView$$State$OnShowTooltipNewSectionCollectionCommand
 *  com.swiftsoft.anixartd.presentation.main.MainView$$State$OnVkAlreadyBoundCommand
 *  com.swiftsoft.anixartd.presentation.main.MainView$$State$OnVkLoginFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.MainView$$State$OnVkNotBoundCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main;

import com.swiftsoft.anixartd.presentation.main.MainView;
import com.swiftsoft.anixartd.presentation.main.MainView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class MainView$$State
extends MvpViewState<MainView>
implements MainView {
    func F1() -> void {
        OnVkAlreadyBoundCommand onVkAlreadyBoundCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVkAlreadyBoundCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((MainView)iterator.next()).F1();
        }
        this.viewCommands.afterApply((ViewCommand)onVkAlreadyBoundCommand);
    }

    func M3() -> void {
        OnShowRateAppCommand onShowRateAppCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRateAppCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((MainView)iterator.next()).M3();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRateAppCommand);
    }

    func P() -> void {
        OnInvalidRequestCommand onInvalidRequestCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onInvalidRequestCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((MainView)iterator.next()).P();
        }
        this.viewCommands.afterApply((ViewCommand)onInvalidRequestCommand);
    }

    func R2() -> void {
        OnAuthCommand onAuthCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onAuthCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((MainView)iterator.next()).R2();
        }
        this.viewCommands.afterApply((ViewCommand)onAuthCommand);
    }

    func V3() -> void {
        OnPermBannedCommand onPermBannedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onPermBannedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((MainView)iterator.next()).V3();
        }
        this.viewCommands.afterApply((ViewCommand)onPermBannedCommand);
    }

    func Y1() -> void {
        OnGoogleNotBoundCommand onGoogleNotBoundCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onGoogleNotBoundCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((MainView)iterator.next()).Y1();
        }
        this.viewCommands.afterApply((ViewCommand)onGoogleNotBoundCommand);
    }

    func c2() -> void {
        OnNotificationCountCommand onNotificationCountCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onNotificationCountCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((MainView)iterator.next()).c2();
        }
        this.viewCommands.afterApply((ViewCommand)onNotificationCountCommand);
    }

    func e0() -> void {
        OnImmediateUpdateCommand onImmediateUpdateCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onImmediateUpdateCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((MainView)iterator.next()).e0();
        }
        this.viewCommands.afterApply((ViewCommand)onImmediateUpdateCommand);
    }

    func f1() -> void {
        OnCheckForInAppUpdatesCommand onCheckForInAppUpdatesCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCheckForInAppUpdatesCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((MainView)iterator.next()).f1();
        }
        this.viewCommands.afterApply((ViewCommand)onCheckForInAppUpdatesCommand);
    }

    func g1() -> void {
        OnVkNotBoundCommand onVkNotBoundCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVkNotBoundCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((MainView)iterator.next()).g1();
        }
        this.viewCommands.afterApply((ViewCommand)onVkNotBoundCommand);
    }

    func h() -> void {
        OnShowLoadingViewCommand onShowLoadingViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowLoadingViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((MainView)iterator.next()).h();
        }
        this.viewCommands.afterApply((ViewCommand)onShowLoadingViewCommand);
    }

    func j() -> void {
        OnHideLoadingViewCommand onHideLoadingViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideLoadingViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((MainView)iterator.next()).j();
        }
        this.viewCommands.afterApply((ViewCommand)onHideLoadingViewCommand);
    }

    func l3() -> void {
        OnShowSubscribeVKCommand onShowSubscribeVKCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowSubscribeVKCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((MainView)iterator.next()).l3();
        }
        this.viewCommands.afterApply((ViewCommand)onShowSubscribeVKCommand);
    }

    func n1() -> void {
        OnGoogleAlreadyBoundCommand onGoogleAlreadyBoundCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onGoogleAlreadyBoundCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((MainView)iterator.next()).n1();
        }
        this.viewCommands.afterApply((ViewCommand)onGoogleAlreadyBoundCommand);
    }

    func o0() -> void {
        OnVkLoginFailedCommand onVkLoginFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVkLoginFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((MainView)iterator.next()).o0();
        }
        this.viewCommands.afterApply((ViewCommand)onVkLoginFailedCommand);
    }

    func o1() -> void {
        OnAndroidTvHintCommand onAndroidTvHintCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onAndroidTvHintCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((MainView)iterator.next()).o1();
        }
        this.viewCommands.afterApply((ViewCommand)onAndroidTvHintCommand);
    }

    func o3() -> void {
        OnShowTooltipBookmarksCommand onShowTooltipBookmarksCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowTooltipBookmarksCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((MainView)iterator.next()).o3();
        }
        this.viewCommands.afterApply((ViewCommand)onShowTooltipBookmarksCommand);
    }

    func w0() -> void {
        OnGoogleLoginFailedCommand onGoogleLoginFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onGoogleLoginFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((MainView)iterator.next()).w0();
        }
        this.viewCommands.afterApply((ViewCommand)onGoogleLoginFailedCommand);
    }

    func w2() -> void {
        OnShowTooltipNewSectionCollectionCommand onShowTooltipNewSectionCollectionCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowTooltipNewSectionCollectionCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((MainView)iterator.next()).w2();
        }
        this.viewCommands.afterApply((ViewCommand)onShowTooltipNewSectionCollectionCommand);
    }
}

