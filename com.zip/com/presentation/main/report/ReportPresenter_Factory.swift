/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.report.ReportPresenter
 *  com.swiftsoft.anixartd.repository.ReportRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.report;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.report.ReportPresenter;
import com.swiftsoft.anixartd.repository.ReportRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class ReportPresenter_Factory
implements Factory<ReportPresenter> {
    final Provider<ReportRepository> a;
    final Provider<Prefs> b;

    init(Provider<ReportRepository> provider, Provider<Prefs> provider2) {
        this.a = provider;
        this.b = provider2;
    }

    func get() -> Object {
        return new ReportPresenter((ReportRepository)this.a.get(), (Prefs)this.b.get());
    }
}

