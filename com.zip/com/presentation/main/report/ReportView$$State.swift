/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.ReportReason
 *  com.swiftsoft.anixartd.presentation.main.report.ReportView
 *  com.swiftsoft.anixartd.presentation.main.report.ReportView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.report.ReportView$$State$OnHideLoadingCommand
 *  com.swiftsoft.anixartd.presentation.main.report.ReportView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.report.ReportView$$State$OnLoadingCommand
 *  com.swiftsoft.anixartd.presentation.main.report.ReportView$$State$OnMessageInvalidCommand
 *  com.swiftsoft.anixartd.presentation.main.report.ReportView$$State$OnMessageInvalidTooLongCommand
 *  com.swiftsoft.anixartd.presentation.main.report.ReportView$$State$OnMessageInvalidTooShortCommand
 *  com.swiftsoft.anixartd.presentation.main.report.ReportView$$State$OnReasonInvalidCommand
 *  com.swiftsoft.anixartd.presentation.main.report.ReportView$$State$OnReportCommand
 *  com.swiftsoft.anixartd.presentation.main.report.ReportView$$State$OnReportSentCommand
 *  com.swiftsoft.anixartd.presentation.main.report.ReportView$$State$OnShowProgressViewCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.report;

import com.swiftsoft.anixartd.database.entity.ReportReason;
import com.swiftsoft.anixartd.presentation.main.report.ReportView;
import com.swiftsoft.anixartd.presentation.main.report.ReportView$$State;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class ReportView$$State
extends MvpViewState<ReportView>
implements ReportView {
    func A2() -> void {
        OnMessageInvalidCommand onMessageInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onMessageInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReportView)iterator.next()).A2();
        }
        this.viewCommands.afterApply((ViewCommand)onMessageInvalidCommand);
    }

    func F3() -> void {
        OnMessageInvalidTooLongCommand onMessageInvalidTooLongCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onMessageInvalidTooLongCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReportView)iterator.next()).F3();
        }
        this.viewCommands.afterApply((ViewCommand)onMessageInvalidTooLongCommand);
    }

    func J1() -> void {
        OnMessageInvalidTooShortCommand onMessageInvalidTooShortCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onMessageInvalidTooShortCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReportView)iterator.next()).J1();
        }
        this.viewCommands.afterApply((ViewCommand)onMessageInvalidTooShortCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReportView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReportView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReportView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func m2() -> void {
        OnReasonInvalidCommand onReasonInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReasonInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReportView)iterator.next()).m2();
        }
        this.viewCommands.afterApply((ViewCommand)onReasonInvalidCommand);
    }

    func n() -> void {
        OnReportSentCommand onReportSentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReportSentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReportView)iterator.next()).n();
        }
        this.viewCommands.afterApply((ViewCommand)onReportSentCommand);
    }

    func n2(List<ReportReason> list) -> void {
        OnReportCommand onReportCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReportCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReportView)iterator.next()).n2(list);
        }
        this.viewCommands.afterApply((ViewCommand)onReportCommand);
    }

    func p() -> void {
        OnHideLoadingCommand onHideLoadingCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideLoadingCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReportView)iterator.next()).p();
        }
        this.viewCommands.afterApply((ViewCommand)onHideLoadingCommand);
    }

    func q() -> void {
        OnLoadingCommand onLoadingCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLoadingCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ReportView)iterator.next()).q();
        }
        this.viewCommands.afterApply((ViewCommand)onLoadingCommand);
    }
}

