/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.home.CustomFilterTabPresenter
 *  com.swiftsoft.anixartd.repository.FilterRepository
 *  com.swiftsoft.anixartd.repository.HomeRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.home;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.home.CustomFilterTabPresenter;
import com.swiftsoft.anixartd.repository.FilterRepository;
import com.swiftsoft.anixartd.repository.HomeRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class CustomFilterTabPresenter_Factory
implements Factory<CustomFilterTabPresenter> {
    final Provider<HomeRepository> a;
    final Provider<FilterRepository> b;
    final Provider<Prefs> c;

    init(Provider<HomeRepository> provider, Provider<FilterRepository> provider2, Provider<Prefs> provider3) {
        this.a = provider;
        this.b = provider2;
        this.c = provider3;
    }

    func get() -> Object {
        return new CustomFilterTabPresenter((HomeRepository)this.a.get(), (FilterRepository)this.b.get(), (Prefs)this.c.get());
    }
}

