/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.home.TabsView
 *  moxy.viewstate.MvpViewState
 */
package com.swiftsoft.anixartd.presentation.main.home;

import com.swiftsoft.anixartd.presentation.main.home.TabsView;
import moxy.viewstate.MvpViewState;

class TabsView$$State
extends MvpViewState<TabsView>
implements TabsView {
}

