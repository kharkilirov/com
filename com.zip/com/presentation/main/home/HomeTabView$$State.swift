/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.presentation.main.home.HomeTabView
 *  com.swiftsoft.anixartd.presentation.main.home.HomeTabView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.home.HomeTabView$$State$OnFullVersionCommand
 *  com.swiftsoft.anixartd.presentation.main.home.HomeTabView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.home.HomeTabView$$State$OnHideRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.home.HomeTabView$$State$OnHomeTabCommand
 *  com.swiftsoft.anixartd.presentation.main.home.HomeTabView$$State$OnImpMessageOpenLinkCommand
 *  com.swiftsoft.anixartd.presentation.main.home.HomeTabView$$State$OnReleaseCommand
 *  com.swiftsoft.anixartd.presentation.main.home.HomeTabView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.home.HomeTabView$$State$OnShowRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.home.HomeTabView$$State$OnUpdateCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.home;

import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.presentation.main.home.HomeTabView;
import com.swiftsoft.anixartd.presentation.main.home.HomeTabView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class HomeTabView$$State
extends MvpViewState<HomeTabView>
implements HomeTabView {
    func L1() -> void {
        OnHomeTabCommand onHomeTabCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHomeTabCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((HomeTabView)iterator.next()).L1();
        }
        this.viewCommands.afterApply((ViewCommand)onHomeTabCommand);
    }

    func T() -> void {
        OnFullVersionCommand onFullVersionCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFullVersionCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((HomeTabView)iterator.next()).T();
        }
        this.viewCommands.afterApply((ViewCommand)onFullVersionCommand);
    }

    func V() -> void {
        OnUpdateCommand onUpdateCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onUpdateCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((HomeTabView)iterator.next()).V();
        }
        this.viewCommands.afterApply((ViewCommand)onUpdateCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((HomeTabView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func a0(String string) -> void {
        OnImpMessageOpenLinkCommand onImpMessageOpenLinkCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onImpMessageOpenLinkCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((HomeTabView)iterator.next()).a0(string);
        }
        this.viewCommands.afterApply((ViewCommand)onImpMessageOpenLinkCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((HomeTabView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c1(String string) -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((HomeTabView)iterator.next()).c1(string);
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func d() -> void {
        OnShowRefreshViewCommand onShowRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((HomeTabView)iterator.next()).d();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRefreshViewCommand);
    }

    func e() -> void {
        OnHideRefreshViewCommand onHideRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((HomeTabView)iterator.next()).e();
        }
        this.viewCommands.afterApply((ViewCommand)onHideRefreshViewCommand);
    }

    func i(Release release) -> void {
        OnReleaseCommand onReleaseCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReleaseCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((HomeTabView)iterator.next()).i(release);
        }
        this.viewCommands.afterApply((ViewCommand)onReleaseCommand);
    }
}

