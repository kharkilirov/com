/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.presentation.main.home.CustomFilterTabView
 *  com.swiftsoft.anixartd.presentation.main.home.CustomFilterTabView$$State$OnCustomTabHintCommand
 *  com.swiftsoft.anixartd.presentation.main.home.CustomFilterTabView$$State$OnCustomTabSettingsCommand
 *  com.swiftsoft.anixartd.presentation.main.home.CustomFilterTabView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.home.CustomFilterTabView$$State$OnFullVersionCommand
 *  com.swiftsoft.anixartd.presentation.main.home.CustomFilterTabView$$State$OnHideCustomTabInfoCommand
 *  com.swiftsoft.anixartd.presentation.main.home.CustomFilterTabView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.home.CustomFilterTabView$$State$OnHideRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.home.CustomFilterTabView$$State$OnImpMessageOpenLinkCommand
 *  com.swiftsoft.anixartd.presentation.main.home.CustomFilterTabView$$State$OnReleaseCommand
 *  com.swiftsoft.anixartd.presentation.main.home.CustomFilterTabView$$State$OnShowCustomTabInfoCommand
 *  com.swiftsoft.anixartd.presentation.main.home.CustomFilterTabView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.home.CustomFilterTabView$$State$OnShowRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.home.CustomFilterTabView$$State$OnUpdateCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.home;

import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.presentation.main.home.CustomFilterTabView;
import com.swiftsoft.anixartd.presentation.main.home.CustomFilterTabView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class CustomFilterTabView$$State
extends MvpViewState<CustomFilterTabView>
implements CustomFilterTabView {
    func E3() -> void {
        OnHideCustomTabInfoCommand onHideCustomTabInfoCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideCustomTabInfoCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CustomFilterTabView)iterator.next()).E3();
        }
        this.viewCommands.afterApply((ViewCommand)onHideCustomTabInfoCommand);
    }

    func H3() -> void {
        OnShowCustomTabInfoCommand onShowCustomTabInfoCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowCustomTabInfoCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CustomFilterTabView)iterator.next()).H3();
        }
        this.viewCommands.afterApply((ViewCommand)onShowCustomTabInfoCommand);
    }

    func J0() -> void {
        OnCustomTabSettingsCommand onCustomTabSettingsCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCustomTabSettingsCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CustomFilterTabView)iterator.next()).J0();
        }
        this.viewCommands.afterApply((ViewCommand)onCustomTabSettingsCommand);
    }

    func T() -> void {
        OnFullVersionCommand onFullVersionCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFullVersionCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CustomFilterTabView)iterator.next()).T();
        }
        this.viewCommands.afterApply((ViewCommand)onFullVersionCommand);
    }

    func V() -> void {
        OnUpdateCommand onUpdateCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onUpdateCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CustomFilterTabView)iterator.next()).V();
        }
        this.viewCommands.afterApply((ViewCommand)onUpdateCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CustomFilterTabView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func a0(String string) -> void {
        OnImpMessageOpenLinkCommand onImpMessageOpenLinkCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onImpMessageOpenLinkCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CustomFilterTabView)iterator.next()).a0(string);
        }
        this.viewCommands.afterApply((ViewCommand)onImpMessageOpenLinkCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CustomFilterTabView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c1(String string) -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CustomFilterTabView)iterator.next()).c1(string);
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func d() -> void {
        OnShowRefreshViewCommand onShowRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CustomFilterTabView)iterator.next()).d();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRefreshViewCommand);
    }

    func e() -> void {
        OnHideRefreshViewCommand onHideRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CustomFilterTabView)iterator.next()).e();
        }
        this.viewCommands.afterApply((ViewCommand)onHideRefreshViewCommand);
    }

    func i(Release release) -> void {
        OnReleaseCommand onReleaseCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReleaseCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CustomFilterTabView)iterator.next()).i(release);
        }
        this.viewCommands.afterApply((ViewCommand)onReleaseCommand);
    }

    func l0() -> void {
        OnCustomTabHintCommand onCustomTabHintCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCustomTabHintCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CustomFilterTabView)iterator.next()).l0();
        }
        this.viewCommands.afterApply((ViewCommand)onCustomTabHintCommand);
    }
}

