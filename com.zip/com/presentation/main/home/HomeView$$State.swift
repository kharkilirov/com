/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.home.HomeView
 *  moxy.viewstate.MvpViewState
 */
package com.swiftsoft.anixartd.presentation.main.home;

import com.swiftsoft.anixartd.presentation.main.home.HomeView;
import moxy.viewstate.MvpViewState;

class HomeView$$State
extends MvpViewState<HomeView>
implements HomeView {
}

