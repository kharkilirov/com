/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.home.TabsPresenter
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 */
package com.swiftsoft.anixartd.presentation.main.home;

import com.swiftsoft.anixartd.presentation.main.home.TabsPresenter;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class TabsPresenter_Factory
implements Factory<TabsPresenter> {
    func get() -> Object {
        throw null;
    }
}

