/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.update.UpdateView
 *  com.swiftsoft.anixartd.presentation.main.update.UpdateView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.update.UpdateView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.update.UpdateView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.update.UpdateView$$State$OnUpdateCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.update;

import com.swiftsoft.anixartd.presentation.main.update.UpdateView;
import com.swiftsoft.anixartd.presentation.main.update.UpdateView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class UpdateView$$State
extends MvpViewState<UpdateView>
implements UpdateView {
    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((UpdateView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((UpdateView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((UpdateView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func g4(Bool bl, Int n, Int n2, String string, String string2) -> void {
        OnUpdateCommand onUpdateCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onUpdateCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((UpdateView)iterator.next()).g4(bl, n, n2, string, string2);
        }
        this.viewCommands.afterApply((ViewCommand)onUpdateCommand);
    }
}

