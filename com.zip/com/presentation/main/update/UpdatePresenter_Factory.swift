/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.update.UpdatePresenter
 *  com.swiftsoft.anixartd.repository.ConfigRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.update;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.update.UpdatePresenter;
import com.swiftsoft.anixartd.repository.ConfigRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class UpdatePresenter_Factory
implements Factory<UpdatePresenter> {
    final Provider<ConfigRepository> a;
    final Provider<Prefs> b;

    init(Provider<ConfigRepository> provider, Provider<Prefs> provider2) {
        this.a = provider;
        this.b = provider2;
    }

    func get() -> Object {
        return new UpdatePresenter((ConfigRepository)this.a.get(), (Prefs)this.b.get());
    }
}

