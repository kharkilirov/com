/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.MainPresenter
 *  com.swiftsoft.anixartd.repository.AuthRepository
 *  com.swiftsoft.anixartd.repository.CollectionRepository
 *  com.swiftsoft.anixartd.repository.ConfigRepository
 *  com.swiftsoft.anixartd.repository.MainRepository
 *  com.swiftsoft.anixartd.repository.NotificationRepository
 *  com.swiftsoft.anixartd.repository.ProfilePreferenceRepository
 *  com.swiftsoft.anixartd.repository.ProfileRepository
 *  com.swiftsoft.anixartd.repository.ReleaseRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.MainPresenter;
import com.swiftsoft.anixartd.repository.AuthRepository;
import com.swiftsoft.anixartd.repository.CollectionRepository;
import com.swiftsoft.anixartd.repository.ConfigRepository;
import com.swiftsoft.anixartd.repository.MainRepository;
import com.swiftsoft.anixartd.repository.NotificationRepository;
import com.swiftsoft.anixartd.repository.ProfilePreferenceRepository;
import com.swiftsoft.anixartd.repository.ProfileRepository;
import com.swiftsoft.anixartd.repository.ReleaseRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class MainPresenter_Factory
implements Factory<MainPresenter> {
    final Provider<ConfigRepository> a;
    final Provider<AuthRepository> b;
    final Provider<MainRepository> c;
    final Provider<ReleaseRepository> d;
    final Provider<ProfileRepository> e;
    final Provider<ProfilePreferenceRepository> f;
    final Provider<CollectionRepository> g;
    final Provider<NotificationRepository> h;
    final Provider<Prefs> i;

    init(Provider<ConfigRepository> provider, Provider<AuthRepository> provider2, Provider<MainRepository> provider3, Provider<ReleaseRepository> provider4, Provider<ProfileRepository> provider5, Provider<ProfilePreferenceRepository> provider6, Provider<CollectionRepository> provider7, Provider<NotificationRepository> provider8, Provider<Prefs> provider9) {
        this.a = provider;
        this.b = provider2;
        this.c = provider3;
        this.d = provider4;
        this.e = provider5;
        this.f = provider6;
        this.g = provider7;
        this.h = provider8;
        this.i = provider9;
    }

    func get() -> Object {
        ConfigRepository configRepository = (ConfigRepository)this.a.get();
        AuthRepository authRepository = (AuthRepository)this.b.get();
        MainRepository mainRepository = (MainRepository)this.c.get();
        ReleaseRepository releaseRepository = (ReleaseRepository)this.d.get();
        ProfileRepository profileRepository = (ProfileRepository)this.e.get();
        ProfilePreferenceRepository profilePreferenceRepository = (ProfilePreferenceRepository)this.f.get();
        CollectionRepository collectionRepository = (CollectionRepository)this.g.get();
        NotificationRepository notificationRepository = (NotificationRepository)this.h.get();
        Prefs prefs = (Prefs)this.i.get();
        MainPresenter mainPresenter = new MainPresenter(configRepository, authRepository, mainRepository, releaseRepository, profileRepository, profilePreferenceRepository, collectionRepository, notificationRepository, prefs);
        return mainPresenter;
    }
}

