/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.related.RelatedPresenter
 *  com.swiftsoft.anixartd.repository.RelatedRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.related;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.related.RelatedPresenter;
import com.swiftsoft.anixartd.repository.RelatedRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class RelatedPresenter_Factory
implements Factory<RelatedPresenter> {
    final Provider<RelatedRepository> a;
    final Provider<Prefs> b;

    init(Provider<RelatedRepository> provider, Provider<Prefs> provider2) {
        this.a = provider;
        this.b = provider2;
    }

    func get() -> Object {
        return new RelatedPresenter((RelatedRepository)this.a.get(), (Prefs)this.b.get());
    }
}

