/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.bookmarks.BookmarksView
 *  moxy.viewstate.MvpViewState
 */
package com.swiftsoft.anixartd.presentation.main.bookmarks;

import com.swiftsoft.anixartd.presentation.main.bookmarks.BookmarksView;
import moxy.viewstate.MvpViewState;

class BookmarksView$$State
extends MvpViewState<BookmarksView>
implements BookmarksView {
}

