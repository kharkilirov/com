/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.database.entity.Collection
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.network.response.PageableResponse
 *  com.swiftsoft.anixartd.presentation.main.bookmarks.BookmarksTabPresenter
 *  com.swiftsoft.anixartd.ui.controller.main.bookmarks.BookmarksTabUiController
 *  java.lang.Boolean
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  java.util.List
 *  java.util.Objects
 *  kotlin.Metadata
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.jvm.internal.Lambda
 */
package com.swiftsoft.anixartd.presentation.main.bookmarks;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.network.response.PageableResponse;
import com.swiftsoft.anixartd.presentation.main.bookmarks.BookmarksTabPresenter;
import com.swiftsoft.anixartd.ui.controller.main.bookmarks.BookmarksTabUiController;
import com.swiftsoft.anixartd.ui.logic.main.bookmarks.BookmarksTabUiLogic;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

@Metadata(d1={"\u0000\u0014\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0000\u001a\u00020\u00012\u001a\u0010\u0002\u001a\u0016\u0012\u0004\u0012\u00020\u0004 \u0005*\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u00030\u0003H\n\u00a2\u0006\u0002\b\u0006"}, d2={"<anonymous>", "", "pageableResponse", "Lcom/swiftsoft/anixartd/network/response/PageableResponse;", "Lcom/swiftsoft/anixartd/database/entity/Collection;", "kotlin.jvm.PlatformType", "invoke"}, k=3, mv={1, 7, 1}, xi=48)
final class BookmarksTabPresenter$onFavoriteCollections$3
extends Lambda
implements Function1<PageableResponse<com.swiftsoft.anixartd.database.entity.Collection>, Unit> {
    final /* synthetic */ BookmarksTabPresenter b;

    BookmarksTabPresenter$onFavoriteCollections$3(BookmarksTabPresenter bookmarksTabPresenter) {
        this.b = bookmarksTabPresenter;
        super(1);
    }

    func invoke(Object object) -> Object {
        PageableResponse pageableResponse = (PageableResponse)object;
        BookmarksTabUiLogic bookmarksTabUiLogic = this.b.d;
        List list = pageableResponse.getContent();
        Objects.requireNonNull((Object)((Object)bookmarksTabUiLogic));
        Intrinsics.h((Object)list, (String)"collections");
        Bool bl = bookmarksTabUiLogic.i;
        Bool bl2 = true;
        if (!bl) {
            if (bl) {
                bookmarksTabUiLogic.g.clear();
            }
            bookmarksTabUiLogic.g.addAll((Collection)list);
            bookmarksTabUiLogic.i = bl2;
        } else {
            bookmarksTabUiLogic.g.addAll((Collection)list);
        }
        this.b.d.d = pageableResponse.getTotalCount();
        BookmarksTabPresenter bookmarksTabPresenter = this.b;
        BookmarksTabUiController bookmarksTabUiController = bookmarksTabPresenter.e;
        Integer n = bookmarksTabPresenter.c.x();
        BookmarksTabUiLogic bookmarksTabUiLogic2 = this.b.d;
        List<Release> list2 = bookmarksTabUiLogic2.f;
        List<com.swiftsoft.anixartd.database.entity.Collection> list3 = bookmarksTabUiLogic2.g;
        String string = bookmarksTabUiLogic2.b;
        Long l = bookmarksTabUiLogic2.d;
        Integer n2 = this.b.d.e;
        Boolean bl3 = this.b.d.j;
        if (pageableResponse.getContent().size() < 25) {
            bl2 = false;
        }
        bookmarksTabUiController.setData((Object)n, list2, list3, (Object)string, (Object)l, (Object)n2, (Object)bl3, (Object)bl2, (Object)this.b.f);
        if (pageableResponse.getContent().isEmpty()) {
            BookmarksTabUiLogic bookmarksTabUiLogic3 = this.b.d;
            bookmarksTabUiLogic3.c = -1 + bookmarksTabUiLogic3.c;
        }
        return Unit.a;
    }
}

