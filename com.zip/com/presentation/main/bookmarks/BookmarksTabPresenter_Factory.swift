/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.bookmarks.BookmarksTabPresenter
 *  com.swiftsoft.anixartd.repository.BookmarksRepository
 *  com.swiftsoft.anixartd.repository.CollectionRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.bookmarks;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.bookmarks.BookmarksTabPresenter;
import com.swiftsoft.anixartd.repository.BookmarksRepository;
import com.swiftsoft.anixartd.repository.CollectionRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class BookmarksTabPresenter_Factory
implements Factory<BookmarksTabPresenter> {
    final Provider<BookmarksRepository> a;
    final Provider<CollectionRepository> b;
    final Provider<Prefs> c;

    init(Provider<BookmarksRepository> provider, Provider<CollectionRepository> provider2, Provider<Prefs> provider3) {
        this.a = provider;
        this.b = provider2;
        this.c = provider3;
    }

    func get() -> Object {
        return new BookmarksTabPresenter((BookmarksRepository)this.a.get(), (CollectionRepository)this.b.get(), (Prefs)this.c.get());
    }
}

