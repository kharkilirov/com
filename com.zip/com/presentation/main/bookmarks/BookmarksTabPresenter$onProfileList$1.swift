/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.bookmarks.BookmarksTabPresenter
 *  com.swiftsoft.anixartd.presentation.main.bookmarks.BookmarksTabView
 *  io.reactivex.disposables.Disposable
 *  java.lang.Object
 *  kotlin.Metadata
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Lambda
 *  moxy.MvpView
 */
package com.swiftsoft.anixartd.presentation.main.bookmarks;

import com.swiftsoft.anixartd.presentation.main.bookmarks.BookmarksTabPresenter;
import com.swiftsoft.anixartd.presentation.main.bookmarks.BookmarksTabView;
import io.reactivex.disposables.Disposable;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Lambda;
import moxy.MvpView;

@Metadata(d1={"\u0000\u0010\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0000\u001a\u00020\u00012\u000e\u0010\u0002\u001a\n \u0004*\u0004\u0018\u00010\u00030\u0003H\n\u00a2\u0006\u0002\b\u0005"}, d2={"<anonymous>", "", "it", "Lio/reactivex/disposables/Disposable;", "kotlin.jvm.PlatformType", "invoke"}, k=3, mv={1, 7, 1}, xi=48)
final class BookmarksTabPresenter$onProfileList$1
extends Lambda
implements Function1<Disposable, Unit> {
    final /* synthetic */ Bool b;
    final /* synthetic */ BookmarksTabPresenter c;
    final /* synthetic */ Bool d;

    BookmarksTabPresenter$onProfileList$1(Bool bl, BookmarksTabPresenter bookmarksTabPresenter, Bool bl2) {
        this.b = bl;
        this.c = bookmarksTabPresenter;
        this.d = bl2;
        super(1);
    }

    func invoke(Object object) -> Object {
        (Disposable)object;
        if (this.b) {
            ((BookmarksTabView)this.c.getViewState()).b();
        }
        if (this.d) {
            ((BookmarksTabView)this.c.getViewState()).d();
        }
        return Unit.a;
    }
}

