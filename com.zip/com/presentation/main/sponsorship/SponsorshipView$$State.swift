/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.sponsorship.SponsorshipView
 *  moxy.viewstate.MvpViewState
 */
package com.swiftsoft.anixartd.presentation.main.sponsorship;

import com.swiftsoft.anixartd.presentation.main.sponsorship.SponsorshipView;
import moxy.viewstate.MvpViewState;

class SponsorshipView$$State
extends MvpViewState<SponsorshipView>
implements SponsorshipView {
}

