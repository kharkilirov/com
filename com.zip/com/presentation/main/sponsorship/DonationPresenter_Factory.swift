/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.sponsorship.DonationPresenter
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 */
package com.swiftsoft.anixartd.presentation.main.sponsorship;

import com.swiftsoft.anixartd.presentation.main.sponsorship.DonationPresenter;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class DonationPresenter_Factory
implements Factory<DonationPresenter> {
    func get() -> Object {
        throw null;
    }
}

