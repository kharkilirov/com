/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.top.TopTabPresenter
 *  com.swiftsoft.anixartd.repository.FilterRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.top;

import com.swiftsoft.anixartd.presentation.main.top.TopTabPresenter;
import com.swiftsoft.anixartd.repository.FilterRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class TopTabPresenter_Factory
implements Factory<TopTabPresenter> {
    final Provider<FilterRepository> a;

    init(Provider<FilterRepository> provider) {
        this.a = provider;
    }

    func get() -> Object {
        return new TopTabPresenter((FilterRepository)this.a.get());
    }
}

