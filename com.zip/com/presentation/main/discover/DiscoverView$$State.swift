/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.presentation.main.discover.DiscoverView
 *  com.swiftsoft.anixartd.presentation.main.discover.DiscoverView$$State$OnCollectionIdCommand
 *  com.swiftsoft.anixartd.presentation.main.discover.DiscoverView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.discover.DiscoverView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.discover.DiscoverView$$State$OnHideRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.discover.DiscoverView$$State$OnInterestCommand
 *  com.swiftsoft.anixartd.presentation.main.discover.DiscoverView$$State$OnLoadedCommand
 *  com.swiftsoft.anixartd.presentation.main.discover.DiscoverView$$State$OnProfileCommand
 *  com.swiftsoft.anixartd.presentation.main.discover.DiscoverView$$State$OnReleaseCommand
 *  com.swiftsoft.anixartd.presentation.main.discover.DiscoverView$$State$OnReleaseIdCommand
 *  com.swiftsoft.anixartd.presentation.main.discover.DiscoverView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.discover.DiscoverView$$State$OnShowRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.discover.DiscoverView$$State$OnSuperMenuCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.discover;

import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.presentation.main.discover.DiscoverView;
import com.swiftsoft.anixartd.presentation.main.discover.DiscoverView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class DiscoverView$$State
extends MvpViewState<DiscoverView>
implements DiscoverView {
    func I1(long l) -> void {
        OnCollectionIdCommand onCollectionIdCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCollectionIdCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((DiscoverView)iterator.next()).I1(l);
        }
        this.viewCommands.afterApply((ViewCommand)onCollectionIdCommand);
    }

    func I2(Int n, Int n2, Int n3, Int n4, Int n5, Int n6) -> void {
        OnLoadedCommand onLoadedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLoadedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((DiscoverView)iterator.next()).I2(n, n2, n3, n4, n5, n6);
        }
        this.viewCommands.afterApply((ViewCommand)onLoadedCommand);
    }

    func L2(long l) -> void {
        OnReleaseIdCommand onReleaseIdCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReleaseIdCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((DiscoverView)iterator.next()).L2(l);
        }
        this.viewCommands.afterApply((ViewCommand)onReleaseIdCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((DiscoverView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((DiscoverView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((DiscoverView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func d() -> void {
        OnShowRefreshViewCommand onShowRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((DiscoverView)iterator.next()).d();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRefreshViewCommand);
    }

    func e() -> void {
        OnHideRefreshViewCommand onHideRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((DiscoverView)iterator.next()).e();
        }
        this.viewCommands.afterApply((ViewCommand)onHideRefreshViewCommand);
    }

    func f(long l) -> void {
        OnProfileCommand onProfileCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onProfileCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((DiscoverView)iterator.next()).f(l);
        }
        this.viewCommands.afterApply((ViewCommand)onProfileCommand);
    }

    func i(Release release) -> void {
        OnReleaseCommand onReleaseCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReleaseCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((DiscoverView)iterator.next()).i(release);
        }
        this.viewCommands.afterApply((ViewCommand)onReleaseCommand);
    }

    func q0(long l, Int n, String string) -> void {
        OnInterestCommand onInterestCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onInterestCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((DiscoverView)iterator.next()).q0(l, n, string);
        }
        this.viewCommands.afterApply((ViewCommand)onInterestCommand);
    }

    func q2(long l) -> void {
        OnSuperMenuCommand onSuperMenuCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onSuperMenuCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((DiscoverView)iterator.next()).q2(l);
        }
        this.viewCommands.afterApply((ViewCommand)onSuperMenuCommand);
    }
}

