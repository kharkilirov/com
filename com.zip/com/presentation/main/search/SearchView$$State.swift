/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Collection
 *  com.swiftsoft.anixartd.database.entity.Profile
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.presentation.main.search.SearchView
 *  com.swiftsoft.anixartd.presentation.main.search.SearchView$$State$OnCollectionCommand
 *  com.swiftsoft.anixartd.presentation.main.search.SearchView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.search.SearchView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.search.SearchView$$State$OnHideRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.search.SearchView$$State$OnLoadedCommand
 *  com.swiftsoft.anixartd.presentation.main.search.SearchView$$State$OnProfileCommand
 *  com.swiftsoft.anixartd.presentation.main.search.SearchView$$State$OnRelatedCommand
 *  com.swiftsoft.anixartd.presentation.main.search.SearchView$$State$OnReleaseCommand
 *  com.swiftsoft.anixartd.presentation.main.search.SearchView$$State$OnSearchCommand
 *  com.swiftsoft.anixartd.presentation.main.search.SearchView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.search.SearchView$$State$OnShowRefreshViewCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.search;

import com.swiftsoft.anixartd.database.entity.Collection;
import com.swiftsoft.anixartd.database.entity.Profile;
import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.presentation.main.search.SearchView;
import com.swiftsoft.anixartd.presentation.main.search.SearchView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class SearchView$$State
extends MvpViewState<SearchView>
implements SearchView {
    func B2(String string) -> void {
        OnSearchCommand onSearchCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onSearchCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SearchView)iterator.next()).B2(string);
        }
        this.viewCommands.afterApply((ViewCommand)onSearchCommand);
    }

    func O() -> void {
        OnLoadedCommand onLoadedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLoadedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SearchView)iterator.next()).O();
        }
        this.viewCommands.afterApply((ViewCommand)onLoadedCommand);
    }

    func P2(long l, String string, String string2, String string3) -> void {
        OnRelatedCommand onRelatedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onRelatedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SearchView)iterator.next()).P2(l, string, string2, string3);
        }
        this.viewCommands.afterApply((ViewCommand)onRelatedCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SearchView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SearchView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SearchView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func d() -> void {
        OnShowRefreshViewCommand onShowRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SearchView)iterator.next()).d();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRefreshViewCommand);
    }

    func e() -> void {
        OnHideRefreshViewCommand onHideRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SearchView)iterator.next()).e();
        }
        this.viewCommands.afterApply((ViewCommand)onHideRefreshViewCommand);
    }

    func i(Release release) -> void {
        OnReleaseCommand onReleaseCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReleaseCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SearchView)iterator.next()).i(release);
        }
        this.viewCommands.afterApply((ViewCommand)onReleaseCommand);
    }

    func j3(Profile profile) -> void {
        OnProfileCommand onProfileCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onProfileCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SearchView)iterator.next()).j3(profile);
        }
        this.viewCommands.afterApply((ViewCommand)onProfileCommand);
    }

    func v(Collection collection) -> void {
        OnCollectionCommand onCollectionCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCollectionCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((SearchView)iterator.next()).v(collection);
        }
        this.viewCommands.afterApply((ViewCommand)onCollectionCommand);
    }
}

