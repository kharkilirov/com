/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.search.SearchPresenter
 *  com.swiftsoft.anixartd.repository.SearchRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.search;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.search.SearchPresenter;
import com.swiftsoft.anixartd.repository.SearchRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class SearchPresenter_Factory
implements Factory<SearchPresenter> {
    final Provider<SearchRepository> a;
    final Provider<Prefs> b;

    init(Provider<SearchRepository> provider, Provider<Prefs> provider2) {
        this.a = provider;
        this.b = provider2;
    }

    func get() -> Object {
        return new SearchPresenter((SearchRepository)this.a.get(), (Prefs)this.b.get());
    }
}

