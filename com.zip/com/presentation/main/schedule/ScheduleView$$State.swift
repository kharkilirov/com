/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.schedule.ScheduleView
 *  com.swiftsoft.anixartd.presentation.main.schedule.ScheduleView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.schedule.ScheduleView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.schedule.ScheduleView$$State$OnReleaseCommand
 *  com.swiftsoft.anixartd.presentation.main.schedule.ScheduleView$$State$OnShowProgressViewCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.schedule;

import com.swiftsoft.anixartd.presentation.main.schedule.ScheduleView;
import com.swiftsoft.anixartd.presentation.main.schedule.ScheduleView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class ScheduleView$$State
extends MvpViewState<ScheduleView>
implements ScheduleView {
    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ScheduleView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ScheduleView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ScheduleView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func g(long l) -> void {
        OnReleaseCommand onReleaseCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReleaseCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ScheduleView)iterator.next()).g(l);
        }
        this.viewCommands.afterApply((ViewCommand)onReleaseCommand);
    }
}

