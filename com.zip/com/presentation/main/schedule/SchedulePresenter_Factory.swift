/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.schedule.SchedulePresenter
 *  com.swiftsoft.anixartd.repository.ScheduleRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.schedule;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.schedule.SchedulePresenter;
import com.swiftsoft.anixartd.repository.ScheduleRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class SchedulePresenter_Factory
implements Factory<SchedulePresenter> {
    final Provider<ScheduleRepository> a;
    final Provider<Prefs> b;

    init(Provider<ScheduleRepository> provider, Provider<Prefs> provider2) {
        this.a = provider;
        this.b = provider2;
    }

    func get() -> Object {
        return new SchedulePresenter((ScheduleRepository)this.a.get(), (Prefs)this.b.get());
    }
}

