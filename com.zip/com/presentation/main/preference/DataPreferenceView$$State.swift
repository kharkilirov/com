/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.presentation.main.preference.DataPreferenceView
 *  com.swiftsoft.anixartd.presentation.main.preference.DataPreferenceView$$State$OnBookmarksExportCommand
 *  com.swiftsoft.anixartd.presentation.main.preference.DataPreferenceView$$State$OnBookmarksImportCommand
 *  com.swiftsoft.anixartd.presentation.main.preference.DataPreferenceView$$State$OnBookmarksImportFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.preference.DataPreferenceView$$State$OnBookmarksImportLimitReachedCommand
 *  com.swiftsoft.anixartd.presentation.main.preference.DataPreferenceView$$State$OnBookmarksImportStatusCommand
 *  java.lang.Boolean
 *  java.lang.Integer
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.preference;

import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.presentation.main.preference.DataPreferenceView;
import com.swiftsoft.anixartd.presentation.main.preference.DataPreferenceView$$State;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class DataPreferenceView$$State
extends MvpViewState<DataPreferenceView>
implements DataPreferenceView {
    func Q2() -> void {
        OnBookmarksImportStatusCommand onBookmarksImportStatusCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onBookmarksImportStatusCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((DataPreferenceView)iterator.next()).Q2();
        }
        this.viewCommands.afterApply((ViewCommand)onBookmarksImportStatusCommand);
    }

    func i2() -> void {
        OnBookmarksImportFailedCommand onBookmarksImportFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onBookmarksImportFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((DataPreferenceView)iterator.next()).i2();
        }
        this.viewCommands.afterApply((ViewCommand)onBookmarksImportFailedCommand);
    }

    func j2(Int n, List<Integer> list, List<Integer> list2, List<Release> list3) -> void {
        OnBookmarksExportCommand onBookmarksExportCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onBookmarksExportCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((DataPreferenceView)iterator.next()).j2(n, list, list2, list3);
        }
        this.viewCommands.afterApply((ViewCommand)onBookmarksExportCommand);
    }

    func m1() -> void {
        OnBookmarksImportCommand onBookmarksImportCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onBookmarksImportCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((DataPreferenceView)iterator.next()).m1();
        }
        this.viewCommands.afterApply((ViewCommand)onBookmarksImportCommand);
    }

    func r1() -> void {
        OnBookmarksImportLimitReachedCommand onBookmarksImportLimitReachedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onBookmarksImportLimitReachedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((DataPreferenceView)iterator.next()).r1();
        }
        this.viewCommands.afterApply((ViewCommand)onBookmarksImportLimitReachedCommand);
    }
}

