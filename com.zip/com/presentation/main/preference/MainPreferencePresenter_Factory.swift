/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.preference.MainPreferencePresenter
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.preference;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.preference.MainPreferencePresenter;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class MainPreferencePresenter_Factory
implements Factory<MainPreferencePresenter> {
    final Provider<Prefs> a;

    init(Provider<Prefs> provider) {
        this.a = provider;
    }

    func get() -> Object {
        return new MainPreferencePresenter((Prefs)this.a.get());
    }
}

