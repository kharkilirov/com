/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.preference.ProfileReleaseNotificationPreferencesPresenter
 *  com.swiftsoft.anixartd.repository.NotificationPreferenceRepository
 *  com.swiftsoft.anixartd.repository.TypeRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.preference;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.preference.ProfileReleaseNotificationPreferencesPresenter;
import com.swiftsoft.anixartd.repository.NotificationPreferenceRepository;
import com.swiftsoft.anixartd.repository.TypeRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class ProfileReleaseNotificationPreferencesPresenter_Factory
implements Factory<ProfileReleaseNotificationPreferencesPresenter> {
    final Provider<TypeRepository> a;
    final Provider<NotificationPreferenceRepository> b;
    final Provider<Prefs> c;

    init(Provider<TypeRepository> provider, Provider<NotificationPreferenceRepository> provider2, Provider<Prefs> provider3) {
        this.a = provider;
        this.b = provider2;
        this.c = provider3;
    }

    func get() -> Object {
        return new ProfileReleaseNotificationPreferencesPresenter((TypeRepository)this.a.get(), (NotificationPreferenceRepository)this.b.get(), (Prefs)this.c.get());
    }
}

