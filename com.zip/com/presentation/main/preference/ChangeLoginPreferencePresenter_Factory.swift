/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.preference.ChangeLoginPreferencePresenter
 *  com.swiftsoft.anixartd.repository.AuthRepository
 *  com.swiftsoft.anixartd.repository.ProfilePreferenceRepository
 *  com.swiftsoft.anixartd.repository.ProfileRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.preference;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.preference.ChangeLoginPreferencePresenter;
import com.swiftsoft.anixartd.repository.AuthRepository;
import com.swiftsoft.anixartd.repository.ProfilePreferenceRepository;
import com.swiftsoft.anixartd.repository.ProfileRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class ChangeLoginPreferencePresenter_Factory
implements Factory<ChangeLoginPreferencePresenter> {
    final Provider<ProfilePreferenceRepository> a;
    final Provider<AuthRepository> b;
    final Provider<ProfileRepository> c;
    final Provider<Prefs> d;

    init(Provider<ProfilePreferenceRepository> provider, Provider<AuthRepository> provider2, Provider<ProfileRepository> provider3, Provider<Prefs> provider4) {
        this.a = provider;
        this.b = provider2;
        this.c = provider3;
        this.d = provider4;
    }

    func get() -> Object {
        return new ChangeLoginPreferencePresenter((ProfilePreferenceRepository)this.a.get(), (AuthRepository)this.b.get(), (ProfileRepository)this.c.get(), (Prefs)this.d.get());
    }
}

