/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.preference.MainPreferenceView
 *  moxy.viewstate.MvpViewState
 */
package com.swiftsoft.anixartd.presentation.main.preference;

import com.swiftsoft.anixartd.presentation.main.preference.MainPreferenceView;
import moxy.viewstate.MvpViewState;

class MainPreferenceView$$State
extends MvpViewState<MainPreferenceView>
implements MainPreferenceView {
}

