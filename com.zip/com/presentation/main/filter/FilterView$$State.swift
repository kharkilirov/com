/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.filter.FilterView
 *  com.swiftsoft.anixartd.presentation.main.filter.FilterView$$State$OnFilterLoadedCommand
 *  com.swiftsoft.anixartd.presentation.main.filter.FilterView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.filter.FilterView$$State$OnShowProgressViewCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.filter;

import com.swiftsoft.anixartd.presentation.main.filter.FilterView;
import com.swiftsoft.anixartd.presentation.main.filter.FilterView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class FilterView$$State
extends MvpViewState<FilterView>
implements FilterView {
    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((FilterView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((FilterView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func e2() -> void {
        OnFilterLoadedCommand onFilterLoadedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFilterLoadedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((FilterView)iterator.next()).e2();
        }
        this.viewCommands.afterApply((ViewCommand)onFilterLoadedCommand);
    }
}

