/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesPresenter
 *  com.swiftsoft.anixartd.repository.CollectionCommentRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.collection.comments.replies;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesPresenter;
import com.swiftsoft.anixartd.repository.CollectionCommentRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class CollectionCommentsRepliesPresenter_Factory
implements Factory<CollectionCommentsRepliesPresenter> {
    final Provider<CollectionCommentRepository> a;
    final Provider<Prefs> b;

    init(Provider<CollectionCommentRepository> provider, Provider<Prefs> provider2) {
        this.a = provider;
        this.b = provider2;
    }

    func get() -> Object {
        return new CollectionCommentsRepliesPresenter((CollectionCommentRepository)this.a.get(), (Prefs)this.b.get());
    }
}

