/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.CollectionComment
 *  com.swiftsoft.anixartd.network.response.PageableResponse
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesPresenter
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  java.util.List
 *  java.util.Objects
 *  kotlin.Metadata
 *  kotlin.Pair
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.jvm.internal.Lambda
 *  moxy.MvpView
 */
package com.swiftsoft.anixartd.presentation.main.collection.comments.replies;

import com.swiftsoft.anixartd.database.entity.CollectionComment;
import com.swiftsoft.anixartd.network.response.PageableResponse;
import com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesPresenter;
import com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView;
import com.swiftsoft.anixartd.ui.logic.main.collection.CollectionCommentsRepliesUiLogic;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import moxy.MvpView;

@Metadata(d1={"\u0000\u0018\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0000\u001a\u00020\u000122\u0010\u0002\u001a.\u0012\u0004\u0012\u00020\u0004\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00040\u0005 \u0006*\u0016\u0012\u0004\u0012\u00020\u0004\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00040\u0005\u0018\u00010\u00030\u0003H\n\u00a2\u0006\u0002\b\u0007"}, d2={"<anonymous>", "", "<name for destructuring parameter 0>", "Lkotlin/Pair;", "Lcom/swiftsoft/anixartd/database/entity/CollectionComment;", "Lcom/swiftsoft/anixartd/network/response/PageableResponse;", "kotlin.jvm.PlatformType", "invoke"}, k=3, mv={1, 7, 1}, xi=48)
final class CollectionCommentsRepliesPresenter$onReplies$3
extends Lambda
implements Function1<Pair<? extends CollectionComment, ? extends PageableResponse<CollectionComment>>, Unit> {
    final /* synthetic */ CollectionCommentsRepliesPresenter b;
    final /* synthetic */ Int c;

    CollectionCommentsRepliesPresenter$onReplies$3(CollectionCommentsRepliesPresenter collectionCommentsRepliesPresenter, Int n) {
        this.b = collectionCommentsRepliesPresenter;
        this.c = n;
        super(1);
    }

    func invoke(Object object) -> Object {
        Pair pair = (Pair)object;
        CollectionComment collectionComment = (CollectionComment)pair.b;
        PageableResponse pageableResponse = (PageableResponse)pair.c;
        CollectionCommentsRepliesUiLogic collectionCommentsRepliesUiLogic = this.b.d;
        Objects.requireNonNull((Object)((Object)collectionCommentsRepliesUiLogic));
        Intrinsics.h((Object)collectionComment, (String)"<set-?>");
        collectionCommentsRepliesUiLogic.f = collectionComment;
        this.b.d.e = collectionComment.isDeleted();
        CollectionCommentsRepliesUiLogic collectionCommentsRepliesUiLogic2 = this.b.d;
        List list = pageableResponse.getContent();
        long l = pageableResponse.getTotalCount();
        Objects.requireNonNull((Object)((Object)collectionCommentsRepliesUiLogic2));
        Intrinsics.h((Object)list, (String)"replies");
        Bool bl = collectionCommentsRepliesUiLogic2.i;
        if (!bl) {
            if (bl) {
                collectionCommentsRepliesUiLogic2.a();
            }
            collectionCommentsRepliesUiLogic2.h.addAll((Collection)list);
            collectionCommentsRepliesUiLogic2.j = l;
            collectionCommentsRepliesUiLogic2.i = true;
        } else {
            collectionCommentsRepliesUiLogic2.h.addAll((Collection)list);
            collectionCommentsRepliesUiLogic2.j = l;
        }
        CollectionCommentsRepliesPresenter.a((CollectionCommentsRepliesPresenter)this.b, (Bool)false, (Int)1);
        Int n = this.c;
        if (n != 2) {
            if (n == 3) {
                ((CollectionCommentsRepliesView)this.b.getViewState()).F();
            }
        } else {
            ((CollectionCommentsRepliesView)this.b.getViewState()).B();
        }
        ((CollectionCommentsRepliesView)this.b.getViewState()).R3(collectionComment);
        return Unit.a;
    }
}

