/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.CollectionComment
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnBannedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnCollectionCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnCommentCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnCommentDeletedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnCommentLimitReachedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnCommentNegativeVoteLimitReachedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnCommentSentCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnCommentVoteBannedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnHideLoadingCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnHideRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnHideSendingCommentProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnInBlockListCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnLoadingCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnParentCommentLoadedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnParentCommentRemovedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnProfileCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnRefreshAfterSortCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnReplyCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnReportSentCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnShowCommentReportFragmentCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnShowNeedAuthCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnShowRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnShowSendingCommentProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State$OnVoteCommentCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.collection.comments.replies;

import com.swiftsoft.anixartd.database.entity.CollectionComment;
import com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView;
import com.swiftsoft.anixartd.presentation.main.collection.comments.replies.CollectionCommentsRepliesView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class CollectionCommentsRepliesView$$State
extends MvpViewState<CollectionCommentsRepliesView>
implements CollectionCommentsRepliesView {
    func A() -> void {
        OnCommentLimitReachedCommand onCommentLimitReachedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentLimitReachedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).A();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentLimitReachedCommand);
    }

    func B() -> void {
        OnCommentSentCommand onCommentSentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentSentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).B();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentSentCommand);
    }

    func D() -> void {
        OnHideSendingCommentProgressViewCommand onHideSendingCommentProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideSendingCommentProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).D();
        }
        this.viewCommands.afterApply((ViewCommand)onHideSendingCommentProgressViewCommand);
    }

    func F() -> void {
        OnCommentDeletedCommand onCommentDeletedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentDeletedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).F();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentDeletedCommand);
    }

    func G() -> void {
        OnCommentVoteBannedCommand onCommentVoteBannedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentVoteBannedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).G();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentVoteBannedCommand);
    }

    func H() -> void {
        OnInBlockListCommand onInBlockListCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onInBlockListCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).H();
        }
        this.viewCommands.afterApply((ViewCommand)onInBlockListCommand);
    }

    func L0(CollectionComment collectionComment) -> void {
        OnReplyCommand onReplyCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReplyCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).L0(collectionComment);
        }
        this.viewCommands.afterApply((ViewCommand)onReplyCommand);
    }

    func R0(CollectionComment collectionComment) -> void {
        OnCommentCommand onCommentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).R0(collectionComment);
        }
        this.viewCommands.afterApply((ViewCommand)onCommentCommand);
    }

    func R3(CollectionComment collectionComment) -> void {
        OnParentCommentLoadedCommand onParentCommentLoadedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onParentCommentLoadedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).R3(collectionComment);
        }
        this.viewCommands.afterApply((ViewCommand)onParentCommentLoadedCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func d() -> void {
        OnShowRefreshViewCommand onShowRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).d();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRefreshViewCommand);
    }

    func d0(long l) -> void {
        OnCollectionCommand onCollectionCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCollectionCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).d0(l);
        }
        this.viewCommands.afterApply((ViewCommand)onCollectionCommand);
    }

    func d1(CollectionComment collectionComment, Int n) -> void {
        OnVoteCommentCommand onVoteCommentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVoteCommentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).d1(collectionComment, n);
        }
        this.viewCommands.afterApply((ViewCommand)onVoteCommentCommand);
    }

    func e() -> void {
        OnHideRefreshViewCommand onHideRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).e();
        }
        this.viewCommands.afterApply((ViewCommand)onHideRefreshViewCommand);
    }

    func f(long l) -> void {
        OnProfileCommand onProfileCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onProfileCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).f(l);
        }
        this.viewCommands.afterApply((ViewCommand)onProfileCommand);
    }

    func f0(CollectionComment collectionComment) -> void {
        OnShowCommentReportFragmentCommand onShowCommentReportFragmentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowCommentReportFragmentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).f0(collectionComment);
        }
        this.viewCommands.afterApply((ViewCommand)onShowCommentReportFragmentCommand);
    }

    func l() -> void {
        OnRefreshAfterSortCommand onRefreshAfterSortCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onRefreshAfterSortCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).l();
        }
        this.viewCommands.afterApply((ViewCommand)onRefreshAfterSortCommand);
    }

    func m() -> void {
        OnShowNeedAuthCommand onShowNeedAuthCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowNeedAuthCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).m();
        }
        this.viewCommands.afterApply((ViewCommand)onShowNeedAuthCommand);
    }

    func n() -> void {
        OnReportSentCommand onReportSentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReportSentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).n();
        }
        this.viewCommands.afterApply((ViewCommand)onReportSentCommand);
    }

    func o() -> void {
        OnBannedCommand onBannedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onBannedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).o();
        }
        this.viewCommands.afterApply((ViewCommand)onBannedCommand);
    }

    func p() -> void {
        OnHideLoadingCommand onHideLoadingCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideLoadingCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).p();
        }
        this.viewCommands.afterApply((ViewCommand)onHideLoadingCommand);
    }

    func q() -> void {
        OnLoadingCommand onLoadingCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLoadingCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).q();
        }
        this.viewCommands.afterApply((ViewCommand)onLoadingCommand);
    }

    func s() -> void {
        OnShowSendingCommentProgressViewCommand onShowSendingCommentProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowSendingCommentProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).s();
        }
        this.viewCommands.afterApply((ViewCommand)onShowSendingCommentProgressViewCommand);
    }

    func v0() -> void {
        OnParentCommentRemovedCommand onParentCommentRemovedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onParentCommentRemovedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).v0();
        }
        this.viewCommands.afterApply((ViewCommand)onParentCommentRemovedCommand);
    }

    func x() -> void {
        OnCommentNegativeVoteLimitReachedCommand onCommentNegativeVoteLimitReachedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentNegativeVoteLimitReachedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsRepliesView)iterator.next()).x();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentNegativeVoteLimitReachedCommand);
    }
}

