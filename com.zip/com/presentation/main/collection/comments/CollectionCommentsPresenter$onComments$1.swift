/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsPresenter
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView
 *  io.reactivex.disposables.Disposable
 *  java.lang.Object
 *  kotlin.Metadata
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Lambda
 *  moxy.MvpView
 */
package com.swiftsoft.anixartd.presentation.main.collection.comments;

import com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsPresenter;
import com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView;
import io.reactivex.disposables.Disposable;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Lambda;
import moxy.MvpView;

@Metadata(d1={"\u0000\u0010\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0000\u001a\u00020\u00012\u000e\u0010\u0002\u001a\n \u0004*\u0004\u0018\u00010\u00030\u0003H\n\u00a2\u0006\u0002\b\u0005"}, d2={"<anonymous>", "", "it", "Lio/reactivex/disposables/Disposable;", "kotlin.jvm.PlatformType", "invoke"}, k=3, mv={1, 7, 1}, xi=48)
final class CollectionCommentsPresenter$onComments$1
extends Lambda
implements Function1<Disposable, Unit> {
    final /* synthetic */ Bool b;
    final /* synthetic */ CollectionCommentsPresenter c;
    final /* synthetic */ Bool d;

    CollectionCommentsPresenter$onComments$1(Bool bl, CollectionCommentsPresenter collectionCommentsPresenter, Bool bl2) {
        this.b = bl;
        this.c = collectionCommentsPresenter;
        this.d = bl2;
        super(1);
    }

    func invoke(Object object) -> Object {
        (Disposable)object;
        if (this.b) {
            ((CollectionCommentsView)this.c.getViewState()).b();
        }
        if (this.d) {
            ((CollectionCommentsView)this.c.getViewState()).d();
        }
        return Unit.a;
    }
}

