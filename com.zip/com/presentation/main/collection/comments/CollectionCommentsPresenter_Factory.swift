/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsPresenter
 *  com.swiftsoft.anixartd.repository.CollectionCommentRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.collection.comments;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsPresenter;
import com.swiftsoft.anixartd.repository.CollectionCommentRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class CollectionCommentsPresenter_Factory
implements Factory<CollectionCommentsPresenter> {
    final Provider<CollectionCommentRepository> a;
    final Provider<Prefs> b;

    init(Provider<CollectionCommentRepository> provider, Provider<Prefs> provider2) {
        this.a = provider;
        this.b = provider2;
    }

    func get() -> Object {
        return new CollectionCommentsPresenter((CollectionCommentRepository)this.a.get(), (Prefs)this.b.get());
    }
}

