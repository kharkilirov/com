/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.CollectionComment
 *  com.swiftsoft.anixartd.network.response.PageableResponse
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsPresenter
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView
 *  com.swiftsoft.anixartd.ui.controller.main.collection.CollectionCommentsUiController
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  java.util.List
 *  java.util.Objects
 *  kotlin.Metadata
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.jvm.internal.Lambda
 *  moxy.MvpView
 */
package com.swiftsoft.anixartd.presentation.main.collection.comments;

import com.swiftsoft.anixartd.database.entity.CollectionComment;
import com.swiftsoft.anixartd.network.response.PageableResponse;
import com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsPresenter;
import com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView;
import com.swiftsoft.anixartd.ui.controller.main.collection.CollectionCommentsUiController;
import com.swiftsoft.anixartd.ui.logic.main.collection.CollectionCommentsUiLogic;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import moxy.MvpView;

@Metadata(d1={"\u0000\u0014\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0000\u001a\u00020\u00012\u001a\u0010\u0002\u001a\u0016\u0012\u0004\u0012\u00020\u0004 \u0005*\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u00030\u0003H\n\u00a2\u0006\u0002\b\u0006"}, d2={"<anonymous>", "", "pageableResponse", "Lcom/swiftsoft/anixartd/network/response/PageableResponse;", "Lcom/swiftsoft/anixartd/database/entity/CollectionComment;", "kotlin.jvm.PlatformType", "invoke"}, k=3, mv={1, 7, 1}, xi=48)
final class CollectionCommentsPresenter$onComments$3
extends Lambda
implements Function1<PageableResponse<CollectionComment>, Unit> {
    final /* synthetic */ CollectionCommentsPresenter b;
    final /* synthetic */ Int c;

    CollectionCommentsPresenter$onComments$3(CollectionCommentsPresenter collectionCommentsPresenter, Int n) {
        this.b = collectionCommentsPresenter;
        this.c = n;
        super(1);
    }

    func invoke(Object object) -> Object {
        PageableResponse pageableResponse = (PageableResponse)object;
        CollectionCommentsUiLogic collectionCommentsUiLogic = this.b.d;
        List list = pageableResponse.getContent();
        long l = pageableResponse.getTotalCount();
        Objects.requireNonNull((Object)((Object)collectionCommentsUiLogic));
        Intrinsics.h((Object)list, (String)"collectionComments");
        Bool bl = collectionCommentsUiLogic.i;
        Bool bl2 = true;
        if (!bl) {
            if (bl) {
                collectionCommentsUiLogic.a();
            }
            collectionCommentsUiLogic.f.addAll((Collection)list);
            collectionCommentsUiLogic.g = l;
            collectionCommentsUiLogic.i = bl2;
        } else {
            collectionCommentsUiLogic.f.addAll((Collection)list);
            collectionCommentsUiLogic.g = l;
        }
        CollectionCommentsPresenter collectionCommentsPresenter = this.b;
        CollectionCommentsUiController collectionCommentsUiController = collectionCommentsPresenter.e;
        CollectionCommentsUiLogic collectionCommentsUiLogic2 = collectionCommentsPresenter.d;
        List<CollectionComment> list2 = collectionCommentsUiLogic2.f;
        Long l2 = collectionCommentsUiLogic2.g;
        Integer n = this.b.d.e;
        if (pageableResponse.getContent().size() < 25) {
            bl2 = false;
        }
        collectionCommentsUiController.setData(list2, (Object)l2, (Object)n, (Object)bl2, (Object)this.b.c);
        Int n2 = this.c;
        if (n2 != 2) {
            if (n2 == 3) {
                ((CollectionCommentsView)this.b.getViewState()).F();
            }
        } else {
            ((CollectionCommentsView)this.b.getViewState()).B();
        }
        return Unit.a;
    }
}

