/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.CollectionComment
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnBannedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnCommentCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnCommentDeletedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnCommentLimitReachedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnCommentNegativeVoteLimitReachedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnCommentSentCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnCommentVoteBannedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnHideLoadingCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnHideRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnHideSendingCommentProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnInBlockListCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnLoadingCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnProfileCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnRefreshAfterSortCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnRepliesCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnReplyCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnReportSentCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnShowCommentReportFragmentCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnShowNeedAuthCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnShowRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnShowSendingCommentProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State$OnVoteCommentCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.collection.comments;

import com.swiftsoft.anixartd.database.entity.CollectionComment;
import com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView;
import com.swiftsoft.anixartd.presentation.main.collection.comments.CollectionCommentsView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class CollectionCommentsView$$State
extends MvpViewState<CollectionCommentsView>
implements CollectionCommentsView {
    func A() -> void {
        OnCommentLimitReachedCommand onCommentLimitReachedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentLimitReachedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).A();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentLimitReachedCommand);
    }

    func B() -> void {
        OnCommentSentCommand onCommentSentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentSentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).B();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentSentCommand);
    }

    func D() -> void {
        OnHideSendingCommentProgressViewCommand onHideSendingCommentProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideSendingCommentProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).D();
        }
        this.viewCommands.afterApply((ViewCommand)onHideSendingCommentProgressViewCommand);
    }

    func F() -> void {
        OnCommentDeletedCommand onCommentDeletedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentDeletedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).F();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentDeletedCommand);
    }

    func G() -> void {
        OnCommentVoteBannedCommand onCommentVoteBannedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentVoteBannedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).G();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentVoteBannedCommand);
    }

    func H() -> void {
        OnInBlockListCommand onInBlockListCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onInBlockListCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).H();
        }
        this.viewCommands.afterApply((ViewCommand)onInBlockListCommand);
    }

    func L0(CollectionComment collectionComment) -> void {
        OnReplyCommand onReplyCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReplyCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).L0(collectionComment);
        }
        this.viewCommands.afterApply((ViewCommand)onReplyCommand);
    }

    func N2(CollectionComment collectionComment) -> void {
        OnRepliesCommand onRepliesCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onRepliesCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).N2(collectionComment);
        }
        this.viewCommands.afterApply((ViewCommand)onRepliesCommand);
    }

    func R0(CollectionComment collectionComment) -> void {
        OnCommentCommand onCommentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).R0(collectionComment);
        }
        this.viewCommands.afterApply((ViewCommand)onCommentCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func d() -> void {
        OnShowRefreshViewCommand onShowRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).d();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRefreshViewCommand);
    }

    func d1(CollectionComment collectionComment, Int n) -> void {
        OnVoteCommentCommand onVoteCommentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVoteCommentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).d1(collectionComment, n);
        }
        this.viewCommands.afterApply((ViewCommand)onVoteCommentCommand);
    }

    func e() -> void {
        OnHideRefreshViewCommand onHideRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).e();
        }
        this.viewCommands.afterApply((ViewCommand)onHideRefreshViewCommand);
    }

    func f(long l) -> void {
        OnProfileCommand onProfileCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onProfileCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).f(l);
        }
        this.viewCommands.afterApply((ViewCommand)onProfileCommand);
    }

    func f0(CollectionComment collectionComment) -> void {
        OnShowCommentReportFragmentCommand onShowCommentReportFragmentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowCommentReportFragmentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).f0(collectionComment);
        }
        this.viewCommands.afterApply((ViewCommand)onShowCommentReportFragmentCommand);
    }

    func l() -> void {
        OnRefreshAfterSortCommand onRefreshAfterSortCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onRefreshAfterSortCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).l();
        }
        this.viewCommands.afterApply((ViewCommand)onRefreshAfterSortCommand);
    }

    func m() -> void {
        OnShowNeedAuthCommand onShowNeedAuthCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowNeedAuthCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).m();
        }
        this.viewCommands.afterApply((ViewCommand)onShowNeedAuthCommand);
    }

    func n() -> void {
        OnReportSentCommand onReportSentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReportSentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).n();
        }
        this.viewCommands.afterApply((ViewCommand)onReportSentCommand);
    }

    func o() -> void {
        OnBannedCommand onBannedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onBannedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).o();
        }
        this.viewCommands.afterApply((ViewCommand)onBannedCommand);
    }

    func p() -> void {
        OnHideLoadingCommand onHideLoadingCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideLoadingCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).p();
        }
        this.viewCommands.afterApply((ViewCommand)onHideLoadingCommand);
    }

    func q() -> void {
        OnLoadingCommand onLoadingCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLoadingCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).q();
        }
        this.viewCommands.afterApply((ViewCommand)onLoadingCommand);
    }

    func s() -> void {
        OnShowSendingCommentProgressViewCommand onShowSendingCommentProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowSendingCommentProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).s();
        }
        this.viewCommands.afterApply((ViewCommand)onShowSendingCommentProgressViewCommand);
    }

    func x() -> void {
        OnCommentNegativeVoteLimitReachedCommand onCommentNegativeVoteLimitReachedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentNegativeVoteLimitReachedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionCommentsView)iterator.next()).x();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentNegativeVoteLimitReachedCommand);
    }
}

