/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Collection
 *  com.swiftsoft.anixartd.presentation.main.collection.list.CollectionProfileListView
 *  com.swiftsoft.anixartd.presentation.main.collection.list.CollectionProfileListView$$State$OnCollectionCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.list.CollectionProfileListView$$State$OnCreateCollectionCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.list.CollectionProfileListView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.list.CollectionProfileListView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.list.CollectionProfileListView$$State$OnHideRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.list.CollectionProfileListView$$State$OnRefreshAfterSortCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.list.CollectionProfileListView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.list.CollectionProfileListView$$State$OnShowRefreshViewCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.collection.list;

import com.swiftsoft.anixartd.database.entity.Collection;
import com.swiftsoft.anixartd.presentation.main.collection.list.CollectionProfileListView;
import com.swiftsoft.anixartd.presentation.main.collection.list.CollectionProfileListView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class CollectionProfileListView$$State
extends MvpViewState<CollectionProfileListView>
implements CollectionProfileListView {
    func M() -> void {
        OnCreateCollectionCommand onCreateCollectionCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCreateCollectionCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionProfileListView)iterator.next()).M();
        }
        this.viewCommands.afterApply((ViewCommand)onCreateCollectionCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionProfileListView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionProfileListView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionProfileListView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func d() -> void {
        OnShowRefreshViewCommand onShowRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionProfileListView)iterator.next()).d();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRefreshViewCommand);
    }

    func e() -> void {
        OnHideRefreshViewCommand onHideRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionProfileListView)iterator.next()).e();
        }
        this.viewCommands.afterApply((ViewCommand)onHideRefreshViewCommand);
    }

    func l() -> void {
        OnRefreshAfterSortCommand onRefreshAfterSortCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onRefreshAfterSortCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionProfileListView)iterator.next()).l();
        }
        this.viewCommands.afterApply((ViewCommand)onRefreshAfterSortCommand);
    }

    func v(Collection collection) -> void {
        OnCollectionCommand onCollectionCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCollectionCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionProfileListView)iterator.next()).v(collection);
        }
        this.viewCommands.afterApply((ViewCommand)onCollectionCommand);
    }
}

