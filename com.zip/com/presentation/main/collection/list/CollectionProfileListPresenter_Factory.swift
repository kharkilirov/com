/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.collection.list.CollectionProfileListPresenter
 *  com.swiftsoft.anixartd.repository.CollectionRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.collection.list;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.collection.list.CollectionProfileListPresenter;
import com.swiftsoft.anixartd.repository.CollectionRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class CollectionProfileListPresenter_Factory
implements Factory<CollectionProfileListPresenter> {
    final Provider<CollectionRepository> a;
    final Provider<Prefs> b;

    init(Provider<CollectionRepository> provider, Provider<Prefs> provider2) {
        this.a = provider;
        this.b = provider2;
    }

    func get() -> Object {
        return new CollectionProfileListPresenter((CollectionRepository)this.a.get(), (Prefs)this.b.get());
    }
}

