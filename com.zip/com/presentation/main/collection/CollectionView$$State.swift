/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Collection
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnCollectionIsDeletedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnCollectionIsPrivateCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnCollectionLoadedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnCommentsShowAllCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnDeleteCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnDeleteFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnDeletedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnEditCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnHideLoadingViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnHideRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnImageCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnRandomCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnReleaseCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnReportCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnReportSentCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnShareCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnShortcutCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnShortcutFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnShowLoadingViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnShowNeedAuthCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State$OnShowRefreshViewCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.collection;

import com.swiftsoft.anixartd.database.entity.Collection;
import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.presentation.main.collection.CollectionView;
import com.swiftsoft.anixartd.presentation.main.collection.CollectionView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class CollectionView$$State
extends MvpViewState<CollectionView>
implements CollectionView {
    func D0() -> void {
        OnDeleteCommand onDeleteCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onDeleteCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).D0();
        }
        this.viewCommands.afterApply((ViewCommand)onDeleteCommand);
    }

    func E0() -> void {
        OnEditCommand onEditCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onEditCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).E0();
        }
        this.viewCommands.afterApply((ViewCommand)onEditCommand);
    }

    func N3() -> void {
        OnShortcutFailedCommand onShortcutFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShortcutFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).N3();
        }
        this.viewCommands.afterApply((ViewCommand)onShortcutFailedCommand);
    }

    func Q0() -> void {
        OnShareCommand onShareCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShareCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).Q0();
        }
        this.viewCommands.afterApply((ViewCommand)onShareCommand);
    }

    func T1() -> void {
        OnDeletedCommand onDeletedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onDeletedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).T1();
        }
        this.viewCommands.afterApply((ViewCommand)onDeletedCommand);
    }

    func W0() -> void {
        OnReportCommand onReportCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReportCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).W0();
        }
        this.viewCommands.afterApply((ViewCommand)onReportCommand);
    }

    func Y() -> void {
        OnRandomCommand onRandomCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onRandomCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).Y();
        }
        this.viewCommands.afterApply((ViewCommand)onRandomCommand);
    }

    func Y3(Collection collection) -> void {
        OnCollectionLoadedCommand onCollectionLoadedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCollectionLoadedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).Y3(collection);
        }
        this.viewCommands.afterApply((ViewCommand)onCollectionLoadedCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func d() -> void {
        OnShowRefreshViewCommand onShowRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).d();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRefreshViewCommand);
    }

    func e() -> void {
        OnHideRefreshViewCommand onHideRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).e();
        }
        this.viewCommands.afterApply((ViewCommand)onHideRefreshViewCommand);
    }

    func h() -> void {
        OnShowLoadingViewCommand onShowLoadingViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowLoadingViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).h();
        }
        this.viewCommands.afterApply((ViewCommand)onShowLoadingViewCommand);
    }

    func i(Release release) -> void {
        OnReleaseCommand onReleaseCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReleaseCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).i(release);
        }
        this.viewCommands.afterApply((ViewCommand)onReleaseCommand);
    }

    func i0() -> void {
        OnCommentsShowAllCommand onCommentsShowAllCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCommentsShowAllCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).i0();
        }
        this.viewCommands.afterApply((ViewCommand)onCommentsShowAllCommand);
    }

    func i3() -> void {
        OnDeleteFailedCommand onDeleteFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onDeleteFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).i3();
        }
        this.viewCommands.afterApply((ViewCommand)onDeleteFailedCommand);
    }

    func i4() -> void {
        OnCollectionIsPrivateCommand onCollectionIsPrivateCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCollectionIsPrivateCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).i4();
        }
        this.viewCommands.afterApply((ViewCommand)onCollectionIsPrivateCommand);
    }

    func j() -> void {
        OnHideLoadingViewCommand onHideLoadingViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideLoadingViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).j();
        }
        this.viewCommands.afterApply((ViewCommand)onHideLoadingViewCommand);
    }

    func j0() -> void {
        OnShortcutCommand onShortcutCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShortcutCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).j0();
        }
        this.viewCommands.afterApply((ViewCommand)onShortcutCommand);
    }

    func m() -> void {
        OnShowNeedAuthCommand onShowNeedAuthCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowNeedAuthCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).m();
        }
        this.viewCommands.afterApply((ViewCommand)onShowNeedAuthCommand);
    }

    func n() -> void {
        OnReportSentCommand onReportSentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReportSentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).n();
        }
        this.viewCommands.afterApply((ViewCommand)onReportSentCommand);
    }

    func p0() -> void {
        OnImageCommand onImageCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onImageCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).p0();
        }
        this.viewCommands.afterApply((ViewCommand)onImageCommand);
    }

    func s3() -> void {
        OnCollectionIsDeletedCommand onCollectionIsDeletedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCollectionIsDeletedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionView)iterator.next()).s3();
        }
        this.viewCommands.afterApply((ViewCommand)onCollectionIsDeletedCommand);
    }
}

