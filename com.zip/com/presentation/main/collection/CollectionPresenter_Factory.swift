/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.collection.CollectionPresenter
 *  com.swiftsoft.anixartd.repository.AuthRepository
 *  com.swiftsoft.anixartd.repository.CollectionRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.collection;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.collection.CollectionPresenter;
import com.swiftsoft.anixartd.repository.AuthRepository;
import com.swiftsoft.anixartd.repository.CollectionRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class CollectionPresenter_Factory
implements Factory<CollectionPresenter> {
    final Provider<CollectionRepository> a;
    final Provider<AuthRepository> b;
    final Provider<Prefs> c;

    init(Provider<CollectionRepository> provider, Provider<AuthRepository> provider2, Provider<Prefs> provider3) {
        this.a = provider;
        this.b = provider2;
        this.c = provider3;
    }

    func get() -> Object {
        return new CollectionPresenter((CollectionRepository)this.a.get(), (AuthRepository)this.b.get(), (Prefs)this.c.get());
    }
}

