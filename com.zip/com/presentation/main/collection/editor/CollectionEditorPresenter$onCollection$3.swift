/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Collection
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.network.response.PageableResponse
 *  com.swiftsoft.anixartd.network.response.collection.CollectionResponse
 *  com.swiftsoft.anixartd.presentation.main.collection.editor.CollectionEditorPresenter
 *  com.swiftsoft.anixartd.presentation.main.collection.editor.CollectionEditorView
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.Pair
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.jvm.internal.Lambda
 *  moxy.MvpView
 */
package com.swiftsoft.anixartd.presentation.main.collection.editor;

import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.network.response.PageableResponse;
import com.swiftsoft.anixartd.network.response.collection.CollectionResponse;
import com.swiftsoft.anixartd.presentation.main.collection.editor.CollectionEditorPresenter;
import com.swiftsoft.anixartd.presentation.main.collection.editor.CollectionEditorView;
import com.swiftsoft.anixartd.ui.logic.main.collection.create.CollectionEditorUiLogic;
import java.util.Collection;
import java.util.List;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import moxy.MvpView;

@Metadata(d1={"\u0000\u001c\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0000\u001a\u00020\u000122\u0010\u0002\u001a.\u0012\u0004\u0012\u00020\u0004\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u0005 \u0007*\u0016\u0012\u0004\u0012\u00020\u0004\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u0005\u0018\u00010\u00030\u0003H\n\u00a2\u0006\u0002\b\b"}, d2={"<anonymous>", "", "<name for destructuring parameter 0>", "Lkotlin/Pair;", "Lcom/swiftsoft/anixartd/network/response/collection/CollectionResponse;", "Lcom/swiftsoft/anixartd/network/response/PageableResponse;", "Lcom/swiftsoft/anixartd/database/entity/Release;", "kotlin.jvm.PlatformType", "invoke"}, k=3, mv={1, 7, 1}, xi=48)
final class CollectionEditorPresenter$onCollection$3
extends Lambda
implements Function1<Pair<? extends CollectionResponse, ? extends PageableResponse<Release>>, Unit> {
    final /* synthetic */ CollectionEditorPresenter b;

    CollectionEditorPresenter$onCollection$3(CollectionEditorPresenter collectionEditorPresenter) {
        this.b = collectionEditorPresenter;
        super(1);
    }

    func invoke(Object object) -> Object {
        Pair pair = (Pair)object;
        CollectionResponse collectionResponse = (CollectionResponse)pair.b;
        PageableResponse pageableResponse = (PageableResponse)pair.c;
        if (collectionResponse.isSuccess()) {
            com.swiftsoft.anixartd.database.entity.Collection collection = collectionResponse.getCollection();
            if (collection == null) {
                ((CollectionEditorView)this.b.getViewState()).c();
            } else {
                CollectionEditorUiLogic collectionEditorUiLogic = this.b.b;
                collectionEditorUiLogic.c = collection;
                String string = collection.getTitle();
                Intrinsics.h((Object)string, (String)"<set-?>");
                collectionEditorUiLogic.d = string;
                String string2 = collection.getDescription();
                Intrinsics.h((Object)string2, (String)"<set-?>");
                collectionEditorUiLogic.e = string2;
                collectionEditorUiLogic.f = collection.isPrivate();
                collectionEditorUiLogic.h = pageableResponse.getTotalCount();
                List list = pageableResponse.getContent();
                Intrinsics.h((Object)list, (String)"releases");
                if (collectionEditorUiLogic.k) {
                    collectionEditorUiLogic.g.clear();
                }
                collectionEditorUiLogic.g.addAll((Collection)list);
                collectionEditorUiLogic.k = true;
                this.b.a();
            }
        } else {
            Int n = collectionResponse.getCode();
            if (n == 2 || n == 3 || n == 4) {
                ((CollectionEditorView)this.b.getViewState()).c();
            }
        }
        return Unit.a;
    }
}

