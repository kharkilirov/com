/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.collection.editor.CollectionEditorView
 *  com.swiftsoft.anixartd.presentation.main.collection.editor.CollectionEditorView$$State$OnAddReleaseCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.editor.CollectionEditorView$$State$OnBannedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.editor.CollectionEditorView$$State$OnChooseImageCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.editor.CollectionEditorView$$State$OnCollectionCreateCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.editor.CollectionEditorView$$State$OnCollectionEditCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.editor.CollectionEditorView$$State$OnCollectionLimitReachedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.editor.CollectionEditorView$$State$OnDescriptionInvalidCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.editor.CollectionEditorView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.editor.CollectionEditorView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.editor.CollectionEditorView$$State$OnImageInvalidCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.editor.CollectionEditorView$$State$OnReleaseLimitReachedCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.editor.CollectionEditorView$$State$OnReleasesInvalidCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.editor.CollectionEditorView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.collection.editor.CollectionEditorView$$State$OnTitleInvalidCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.collection.editor;

import com.swiftsoft.anixartd.presentation.main.collection.editor.CollectionEditorView;
import com.swiftsoft.anixartd.presentation.main.collection.editor.CollectionEditorView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class CollectionEditorView$$State
extends MvpViewState<CollectionEditorView>
implements CollectionEditorView {
    func E1() -> void {
        OnDescriptionInvalidCommand onDescriptionInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onDescriptionInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionEditorView)iterator.next()).E1();
        }
        this.viewCommands.afterApply((ViewCommand)onDescriptionInvalidCommand);
    }

    func H2() -> void {
        OnReleasesInvalidCommand onReleasesInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReleasesInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionEditorView)iterator.next()).H2();
        }
        this.viewCommands.afterApply((ViewCommand)onReleasesInvalidCommand);
    }

    func O1() -> void {
        OnReleaseLimitReachedCommand onReleaseLimitReachedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReleaseLimitReachedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionEditorView)iterator.next()).O1();
        }
        this.viewCommands.afterApply((ViewCommand)onReleaseLimitReachedCommand);
    }

    func O3() -> void {
        OnCollectionEditCommand onCollectionEditCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCollectionEditCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionEditorView)iterator.next()).O3();
        }
        this.viewCommands.afterApply((ViewCommand)onCollectionEditCommand);
    }

    func U2() -> void {
        OnImageInvalidCommand onImageInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onImageInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionEditorView)iterator.next()).U2();
        }
        this.viewCommands.afterApply((ViewCommand)onImageInvalidCommand);
    }

    func V0() -> void {
        OnTitleInvalidCommand onTitleInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onTitleInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionEditorView)iterator.next()).V0();
        }
        this.viewCommands.afterApply((ViewCommand)onTitleInvalidCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionEditorView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionEditorView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func b2() -> void {
        OnCollectionCreateCommand onCollectionCreateCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCollectionCreateCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionEditorView)iterator.next()).b2();
        }
        this.viewCommands.afterApply((ViewCommand)onCollectionCreateCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionEditorView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func m0() -> void {
        OnAddReleaseCommand onAddReleaseCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onAddReleaseCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionEditorView)iterator.next()).m0();
        }
        this.viewCommands.afterApply((ViewCommand)onAddReleaseCommand);
    }

    func o() -> void {
        OnBannedCommand onBannedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onBannedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionEditorView)iterator.next()).o();
        }
        this.viewCommands.afterApply((ViewCommand)onBannedCommand);
    }

    func onChooseImage() -> void {
        OnChooseImageCommand onChooseImageCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onChooseImageCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionEditorView)iterator.next()).onChooseImage();
        }
        this.viewCommands.afterApply((ViewCommand)onChooseImageCommand);
    }

    func v3() -> void {
        OnCollectionLimitReachedCommand onCollectionLimitReachedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCollectionLimitReachedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((CollectionEditorView)iterator.next()).v3();
        }
        this.viewCommands.afterApply((ViewCommand)onCollectionLimitReachedCommand);
    }
}

