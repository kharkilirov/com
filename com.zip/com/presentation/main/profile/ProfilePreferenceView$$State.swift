/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfilePreferenceView
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfilePreferenceView$$State$OnCurrentEmailIncorrectCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfilePreferenceView$$State$OnCurrentPasswordIncorrectCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfilePreferenceView$$State$OnEmailAlreadyTakenCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfilePreferenceView$$State$OnEmailChangeConfirmedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfilePreferenceView$$State$OnEmailChangedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfilePreferenceView$$State$OnEmailInvalidCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfilePreferenceView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfilePreferenceView$$State$OnForgotPasswordCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfilePreferenceView$$State$OnHideLoadingViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfilePreferenceView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfilePreferenceView$$State$OnNewPasswordIncorrectCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfilePreferenceView$$State$OnPasswordChangedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfilePreferenceView$$State$OnPasswordInvalidCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfilePreferenceView$$State$OnPasswordNotMatchCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfilePreferenceView$$State$OnSettingsLoadedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfilePreferenceView$$State$OnShowLoadingViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfilePreferenceView$$State$OnShowProgressViewCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.profile;

import com.swiftsoft.anixartd.presentation.main.profile.ProfilePreferenceView;
import com.swiftsoft.anixartd.presentation.main.profile.ProfilePreferenceView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class ProfilePreferenceView$$State
extends MvpViewState<ProfilePreferenceView>
implements ProfilePreferenceView {
    func C() -> void {
        OnEmailAlreadyTakenCommand onEmailAlreadyTakenCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onEmailAlreadyTakenCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfilePreferenceView)iterator.next()).C();
        }
        this.viewCommands.afterApply((ViewCommand)onEmailAlreadyTakenCommand);
    }

    func C2(String string, String string2) -> void {
        OnEmailChangeConfirmedCommand onEmailChangeConfirmedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onEmailChangeConfirmedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfilePreferenceView)iterator.next()).C2(string, string2);
        }
        this.viewCommands.afterApply((ViewCommand)onEmailChangeConfirmedCommand);
    }

    func D3() -> void {
        OnEmailChangedCommand onEmailChangedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onEmailChangedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfilePreferenceView)iterator.next()).D3();
        }
        this.viewCommands.afterApply((ViewCommand)onEmailChangedCommand);
    }

    func K2() -> void {
        OnPasswordChangedCommand onPasswordChangedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onPasswordChangedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfilePreferenceView)iterator.next()).K2();
        }
        this.viewCommands.afterApply((ViewCommand)onPasswordChangedCommand);
    }

    func Q3() -> void {
        OnCurrentPasswordIncorrectCommand onCurrentPasswordIncorrectCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCurrentPasswordIncorrectCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfilePreferenceView)iterator.next()).Q3();
        }
        this.viewCommands.afterApply((ViewCommand)onCurrentPasswordIncorrectCommand);
    }

    func S() -> void {
        OnPasswordNotMatchCommand onPasswordNotMatchCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onPasswordNotMatchCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfilePreferenceView)iterator.next()).S();
        }
        this.viewCommands.afterApply((ViewCommand)onPasswordNotMatchCommand);
    }

    func U3() -> void {
        OnCurrentEmailIncorrectCommand onCurrentEmailIncorrectCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCurrentEmailIncorrectCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfilePreferenceView)iterator.next()).U3();
        }
        this.viewCommands.afterApply((ViewCommand)onCurrentEmailIncorrectCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfilePreferenceView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfilePreferenceView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfilePreferenceView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func h() -> void {
        OnShowLoadingViewCommand onShowLoadingViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowLoadingViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfilePreferenceView)iterator.next()).h();
        }
        this.viewCommands.afterApply((ViewCommand)onShowLoadingViewCommand);
    }

    func h1() -> void {
        OnForgotPasswordCommand onForgotPasswordCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onForgotPasswordCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfilePreferenceView)iterator.next()).h1();
        }
        this.viewCommands.afterApply((ViewCommand)onForgotPasswordCommand);
    }

    func j() -> void {
        OnHideLoadingViewCommand onHideLoadingViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideLoadingViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfilePreferenceView)iterator.next()).j();
        }
        this.viewCommands.afterApply((ViewCommand)onHideLoadingViewCommand);
    }

    func j1(String string, String string2, Int n, Int n2, Int n3, Int n4, Bool bl, Bool bl2) -> void {
        OnSettingsLoadedCommand onSettingsLoadedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onSettingsLoadedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfilePreferenceView)iterator.next()).j1(string, string2, n, n2, n3, n4, bl, bl2);
        }
        this.viewCommands.afterApply((ViewCommand)onSettingsLoadedCommand);
    }

    func t2() -> void {
        OnNewPasswordIncorrectCommand onNewPasswordIncorrectCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onNewPasswordIncorrectCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfilePreferenceView)iterator.next()).t2();
        }
        this.viewCommands.afterApply((ViewCommand)onNewPasswordIncorrectCommand);
    }

    func w() -> void {
        OnEmailInvalidCommand onEmailInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onEmailInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfilePreferenceView)iterator.next()).w();
        }
        this.viewCommands.afterApply((ViewCommand)onEmailInvalidCommand);
    }

    func z() -> void {
        OnPasswordInvalidCommand onPasswordInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onPasswordInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfilePreferenceView)iterator.next()).z();
        }
        this.viewCommands.afterApply((ViewCommand)onPasswordInvalidCommand);
    }
}

