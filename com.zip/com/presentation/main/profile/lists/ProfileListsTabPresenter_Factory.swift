/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.profile.lists.ProfileListsTabPresenter
 *  com.swiftsoft.anixartd.repository.BookmarksRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.profile.lists;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.profile.lists.ProfileListsTabPresenter;
import com.swiftsoft.anixartd.repository.BookmarksRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class ProfileListsTabPresenter_Factory
implements Factory<ProfileListsTabPresenter> {
    final Provider<BookmarksRepository> a;
    final Provider<Prefs> b;

    init(Provider<BookmarksRepository> provider, Provider<Prefs> provider2) {
        this.a = provider;
        this.b = provider2;
    }

    func get() -> Object {
        return new ProfileListsTabPresenter((BookmarksRepository)this.a.get(), (Prefs)this.b.get());
    }
}

