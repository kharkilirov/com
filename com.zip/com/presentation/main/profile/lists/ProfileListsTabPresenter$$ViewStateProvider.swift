/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  moxy.MvpView
 *  moxy.ViewStateProvider
 *  moxy.viewstate.MvpViewState
 */
package com.swiftsoft.anixartd.presentation.main.profile.lists;

import com.swiftsoft.anixartd.presentation.main.profile.lists.ProfileListsTabView$$State;
import moxy.MvpView;
import moxy.ViewStateProvider;
import moxy.viewstate.MvpViewState;

class ProfileListsTabPresenter$$ViewStateProvider
extends ViewStateProvider {
    MvpViewState<? extends MvpView> getViewState() {
        return new ProfileListsTabView$$State();
    }
}

