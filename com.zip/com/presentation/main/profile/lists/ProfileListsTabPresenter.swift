/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.network.api.ProfileListApi
 *  com.swiftsoft.anixartd.presentation.auth.restore.a
 *  com.swiftsoft.anixartd.presentation.main.profile.lists.ProfileListsTabPresenter$listener
 *  com.swiftsoft.anixartd.presentation.main.profile.lists.ProfileListsTabPresenter$listener$1
 *  com.swiftsoft.anixartd.presentation.main.profile.lists.ProfileListsTabPresenter$onProfileLists
 *  com.swiftsoft.anixartd.presentation.main.profile.lists.ProfileListsTabPresenter$onProfileLists$1
 *  com.swiftsoft.anixartd.presentation.main.profile.lists.ProfileListsTabPresenter$onProfileLists$3
 *  com.swiftsoft.anixartd.presentation.main.profile.lists.ProfileListsTabPresenter$onProfileLists$4
 *  com.swiftsoft.anixartd.presentation.main.profile.lists.ProfileListsTabView
 *  com.swiftsoft.anixartd.repository.BookmarksRepository
 *  com.swiftsoft.anixartd.ui.controller.main.profile.lists.ProfileListsTabUiController
 *  com.swiftsoft.anixartd.ui.controller.main.profile.lists.ProfileListsTabUiController$Listener
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  io.reactivex.Observable
 *  io.reactivex.Scheduler
 *  io.reactivex.android.schedulers.AndroidSchedulers
 *  io.reactivex.disposables.Disposable
 *  io.reactivex.functions.Action
 *  io.reactivex.functions.Consumer
 *  io.reactivex.internal.functions.Functions
 *  io.reactivex.schedulers.Schedulers
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  javax.inject.Inject
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  moxy.InjectViewState
 *  moxy.MvpPresenter
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.presentation.main.profile.lists;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.network.api.ProfileListApi;
import com.swiftsoft.anixartd.presentation.main.profile.friends.a;
import com.swiftsoft.anixartd.presentation.main.profile.lists.ProfileListsTabPresenter;
import com.swiftsoft.anixartd.presentation.main.profile.lists.ProfileListsTabView;
import com.swiftsoft.anixartd.repository.BookmarksRepository;
import com.swiftsoft.anixartd.ui.controller.main.profile.lists.ProfileListsTabUiController;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import com.swiftsoft.anixartd.ui.logic.main.profile.lists.ProfileListsTabUiLogic;
import io.reactivex.Observable;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.internal.functions.Functions;
import io.reactivex.schedulers.Schedulers;
import javax.inject.Inject;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import moxy.InjectViewState;
import moxy.MvpPresenter;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u0003\u00a8\u0006\u0004"}, d2={"Lcom/swiftsoft/anixartd/presentation/main/profile/lists/ProfileListsTabPresenter;", "Lmoxy/MvpPresenter;", "Lcom/swiftsoft/anixartd/presentation/main/profile/lists/ProfileListsTabView;", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@InjectViewState
final class ProfileListsTabPresenter
extends MvpPresenter<ProfileListsTabView> {
    @NotNull
    BookmarksRepository a;
    @NotNull
    Prefs b;
    @NotNull
    ProfileListsTabUiLogic c;
    @NotNull
    ProfileListsTabUiController d;
    @NotNull
    Listener e;

    @Inject
    init(@NotNull BookmarksRepository bookmarksRepository, @NotNull Prefs prefs) {
        Intrinsics.h((Object)bookmarksRepository, (String)"bookmarksRepository");
        Intrinsics.h((Object)prefs, (String)"prefs");
        this.a = bookmarksRepository;
        this.b = prefs;
        this.c = new ProfileListsTabUiLogic();
        this.d = new ProfileListsTabUiController();
        this.e = new listener.1(this);
    }

    static /* synthetic */ void c(ProfileListsTabPresenter profileListsTabPresenter, Bool bl, Bool bl2, Int n) {
        if ((n & 1) != 0) {
            bl = profileListsTabPresenter.a();
        }
        if ((n & 2) != 0) {
            bl2 = false;
        }
        profileListsTabPresenter.b(bl, bl2);
    }

    final Bool a() {
        return this.d.isEmpty();
    }

    final void b(Bool bl, Bool bl2) {
        block11 : {
            Int n;
            BookmarksRepository bookmarksRepository = this.a;
            ProfileListsTabUiLogic profileListsTabUiLogic = this.c;
            long l = profileListsTabUiLogic.b;
            String string = profileListsTabUiLogic.c;
            switch (string.hashCode()) {
                default: {
                    break block11;
                }
                case 1871259922: {
                    if (string.equals((Object)"INNER_TAB_PROFILE_LIST_PLANS")) {
                        n = 2;
                        break;
                    }
                    break block11;
                }
                case 1109108840: {
                    if (string.equals((Object)"INNER_TAB_PROFILE_LIST_DROPPED")) {
                        n = 5;
                        break;
                    }
                    break block11;
                }
                case 999506155: {
                    if (string.equals((Object)"INNER_TAB_PROFILE_LIST_WATCHING")) {
                        n = 1;
                        break;
                    }
                    break block11;
                }
                case 275155495: {
                    if (string.equals((Object)"INNER_TAB_PROFILE_LIST_HOLD_ON")) {
                        n = 4;
                        break;
                    }
                    break block11;
                }
                case -202987277: {
                    if (!string.equals((Object)"INNER_TAB_PROFILE_LIST_COMPLETED")) break block11;
                    n = 3;
                }
            }
            ProfileListsTabUiLogic profileListsTabUiLogic2 = this.c;
            Int n2 = profileListsTabUiLogic2.d;
            Integer n3 = profileListsTabUiLogic2.f;
            bookmarksRepository.c.profileListByProfile(l, n, n2, n3, bookmarksRepository.d.w()).n(Schedulers.c).k(AndroidSchedulers.a()).i((Consumer)new a((Function1)new onProfileLists.1(bl, this, bl2), 19)).j((Action)new com.swiftsoft.anixartd.presentation.auth.restore.a((MvpPresenter)this, 14)).l((Consumer)new a((Function1)new onProfileLists.3(this), 20), (Consumer)new a((Function1)new onProfileLists.4(this), 21), Functions.b, Functions.c);
            return;
        }
        throw new Exception("Invalid inner position");
    }

    final void d() {
        ProfileListsTabUiLogic profileListsTabUiLogic = this.c;
        if (profileListsTabUiLogic.a) {
            profileListsTabUiLogic.a();
            if (this.a()) {
                ProfileListsTabPresenter.c(this, false, false, 3);
                return;
            }
            this.b(false, true);
        }
    }

    final void e() {
        ProfileListsTabUiLogic profileListsTabUiLogic = this.c;
        if (profileListsTabUiLogic.a) {
            profileListsTabUiLogic.a();
            if (this.a()) {
                ProfileListsTabPresenter.c(this, false, false, 3);
                return;
            }
            ProfileListsTabPresenter.c(this, false, false, 2);
        }
    }

}

