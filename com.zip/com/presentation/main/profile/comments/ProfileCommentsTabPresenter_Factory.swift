/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.profile.comments.ProfileCommentsTabPresenter
 *  com.swiftsoft.anixartd.repository.CollectionCommentRepository
 *  com.swiftsoft.anixartd.repository.ReleaseCommentRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.profile.comments;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.profile.comments.ProfileCommentsTabPresenter;
import com.swiftsoft.anixartd.repository.CollectionCommentRepository;
import com.swiftsoft.anixartd.repository.ReleaseCommentRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class ProfileCommentsTabPresenter_Factory
implements Factory<ProfileCommentsTabPresenter> {
    final Provider<ReleaseCommentRepository> a;
    final Provider<CollectionCommentRepository> b;
    final Provider<Prefs> c;

    init(Provider<ReleaseCommentRepository> provider, Provider<CollectionCommentRepository> provider2, Provider<Prefs> provider3) {
        this.a = provider;
        this.b = provider2;
        this.c = provider3;
    }

    func get() -> Object {
        return new ProfileCommentsTabPresenter((ReleaseCommentRepository)this.a.get(), (CollectionCommentRepository)this.b.get(), (Prefs)this.c.get());
    }
}

