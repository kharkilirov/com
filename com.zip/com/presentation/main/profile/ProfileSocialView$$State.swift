/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileSocialView
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileSocialView$$State$OnChangedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileSocialView$$State$OnDiscordInvalidCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileSocialView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileSocialView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileSocialView$$State$OnInstInvalidCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileSocialView$$State$OnLoadedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileSocialView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileSocialView$$State$OnTgInvalidCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileSocialView$$State$OnTtInvalidCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileSocialView$$State$OnVkInvalidCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.profile;

import com.swiftsoft.anixartd.presentation.main.profile.ProfileSocialView;
import com.swiftsoft.anixartd.presentation.main.profile.ProfileSocialView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class ProfileSocialView$$State
extends MvpViewState<ProfileSocialView>
implements ProfileSocialView {
    func J3() -> void {
        OnTgInvalidCommand onTgInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onTgInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileSocialView)iterator.next()).J3();
        }
        this.viewCommands.afterApply((ViewCommand)onTgInvalidCommand);
    }

    func O() -> void {
        OnLoadedCommand onLoadedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLoadedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileSocialView)iterator.next()).O();
        }
        this.viewCommands.afterApply((ViewCommand)onLoadedCommand);
    }

    func P1() -> void {
        OnInstInvalidCommand onInstInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onInstInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileSocialView)iterator.next()).P1();
        }
        this.viewCommands.afterApply((ViewCommand)onInstInvalidCommand);
    }

    func W2() -> void {
        OnTtInvalidCommand onTtInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onTtInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileSocialView)iterator.next()).W2();
        }
        this.viewCommands.afterApply((ViewCommand)onTtInvalidCommand);
    }

    func X1() -> void {
        OnVkInvalidCommand onVkInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVkInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileSocialView)iterator.next()).X1();
        }
        this.viewCommands.afterApply((ViewCommand)onVkInvalidCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileSocialView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileSocialView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func b3() -> void {
        OnChangedCommand onChangedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onChangedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileSocialView)iterator.next()).b3();
        }
        this.viewCommands.afterApply((ViewCommand)onChangedCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileSocialView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func h3() -> void {
        OnDiscordInvalidCommand onDiscordInvalidCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onDiscordInvalidCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileSocialView)iterator.next()).h3();
        }
        this.viewCommands.afterApply((ViewCommand)onDiscordInvalidCommand);
    }
}

