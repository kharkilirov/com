/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideosTabPresenter
 *  com.swiftsoft.anixartd.repository.ReleaseVideoAppealRepository
 *  com.swiftsoft.anixartd.repository.ReleaseVideoRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.profile.videos;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideosTabPresenter;
import com.swiftsoft.anixartd.repository.ReleaseVideoAppealRepository;
import com.swiftsoft.anixartd.repository.ReleaseVideoRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class ProfileReleaseVideosTabPresenter_Factory
implements Factory<ProfileReleaseVideosTabPresenter> {
    final Provider<ReleaseVideoRepository> a;
    final Provider<ReleaseVideoAppealRepository> b;
    final Provider<Prefs> c;

    init(Provider<ReleaseVideoRepository> provider, Provider<ReleaseVideoAppealRepository> provider2, Provider<Prefs> provider3) {
        this.a = provider;
        this.b = provider2;
        this.c = provider3;
    }

    func get() -> Object {
        return new ProfileReleaseVideosTabPresenter((ReleaseVideoRepository)this.a.get(), (ReleaseVideoAppealRepository)this.b.get(), (Prefs)this.c.get());
    }
}

