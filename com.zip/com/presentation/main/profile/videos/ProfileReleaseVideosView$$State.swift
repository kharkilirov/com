/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.ReleaseVideo
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideosView
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideosView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideosView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideosView$$State$OnHideRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideosView$$State$OnProfileCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideosView$$State$OnRefreshAfterSortCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideosView$$State$OnReleaseVideoAppealDeleteFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideosView$$State$OnReleaseVideoAppealDeletedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideosView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideosView$$State$OnShowRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideosView$$State$OnVideoAppealDeleteCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideosView$$State$OnVideoAppealsCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideosView$$State$OnVideoCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideosView$$State$OnVideoUploadsCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideosView$$State$OnVideosCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.profile.videos;

import com.swiftsoft.anixartd.database.entity.ReleaseVideo;
import com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideosView;
import com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideosView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class ProfileReleaseVideosView$$State
extends MvpViewState<ProfileReleaseVideosView>
implements ProfileReleaseVideosView {
    func K(ReleaseVideo releaseVideo) -> void {
        OnVideoCommand onVideoCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVideoCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideosView)iterator.next()).K(releaseVideo);
        }
        this.viewCommands.afterApply((ViewCommand)onVideoCommand);
    }

    func U0(ReleaseVideo releaseVideo) -> void {
        OnReleaseVideoAppealDeletedCommand onReleaseVideoAppealDeletedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReleaseVideoAppealDeletedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideosView)iterator.next()).U0(releaseVideo);
        }
        this.viewCommands.afterApply((ViewCommand)onReleaseVideoAppealDeletedCommand);
    }

    func V2() -> void {
        OnVideoAppealsCommand onVideoAppealsCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVideoAppealsCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideosView)iterator.next()).V2();
        }
        this.viewCommands.afterApply((ViewCommand)onVideoAppealsCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideosView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideosView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideosView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func d() -> void {
        OnShowRefreshViewCommand onShowRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideosView)iterator.next()).d();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRefreshViewCommand);
    }

    func e() -> void {
        OnHideRefreshViewCommand onHideRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideosView)iterator.next()).e();
        }
        this.viewCommands.afterApply((ViewCommand)onHideRefreshViewCommand);
    }

    func f(long l) -> void {
        OnProfileCommand onProfileCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onProfileCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideosView)iterator.next()).f(l);
        }
        this.viewCommands.afterApply((ViewCommand)onProfileCommand);
    }

    func k3(long l, long l2) -> void {
        OnVideoUploadsCommand onVideoUploadsCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVideoUploadsCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideosView)iterator.next()).k3(l, l2);
        }
        this.viewCommands.afterApply((ViewCommand)onVideoUploadsCommand);
    }

    func l() -> void {
        OnRefreshAfterSortCommand onRefreshAfterSortCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onRefreshAfterSortCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideosView)iterator.next()).l();
        }
        this.viewCommands.afterApply((ViewCommand)onRefreshAfterSortCommand);
    }

    func u0() -> void {
        OnReleaseVideoAppealDeleteFailedCommand onReleaseVideoAppealDeleteFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReleaseVideoAppealDeleteFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideosView)iterator.next()).u0();
        }
        this.viewCommands.afterApply((ViewCommand)onReleaseVideoAppealDeleteFailedCommand);
    }

    func w1(long l, long l2) -> void {
        OnVideosCommand onVideosCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVideosCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideosView)iterator.next()).w1(l, l2);
        }
        this.viewCommands.afterApply((ViewCommand)onVideosCommand);
    }

    func x0(ReleaseVideo releaseVideo) -> void {
        OnVideoAppealDeleteCommand onVideoAppealDeleteCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVideoAppealDeleteCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideosView)iterator.next()).x0(releaseVideo);
        }
        this.viewCommands.afterApply((ViewCommand)onVideoAppealDeleteCommand);
    }
}

