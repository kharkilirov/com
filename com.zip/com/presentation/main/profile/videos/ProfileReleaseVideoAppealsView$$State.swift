/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.ReleaseVideo
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideoAppealsView
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideoAppealsView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideoAppealsView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideoAppealsView$$State$OnHideRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideoAppealsView$$State$OnReleaseVideoAppealDeleteFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideoAppealsView$$State$OnReleaseVideoAppealDeletedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideoAppealsView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideoAppealsView$$State$OnShowRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideoAppealsView$$State$OnVideoAppealDeleteCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideoAppealsView$$State$OnVideoCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.profile.videos;

import com.swiftsoft.anixartd.database.entity.ReleaseVideo;
import com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideoAppealsView;
import com.swiftsoft.anixartd.presentation.main.profile.videos.ProfileReleaseVideoAppealsView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class ProfileReleaseVideoAppealsView$$State
extends MvpViewState<ProfileReleaseVideoAppealsView>
implements ProfileReleaseVideoAppealsView {
    func K(ReleaseVideo releaseVideo) -> void {
        OnVideoCommand onVideoCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVideoCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideoAppealsView)iterator.next()).K(releaseVideo);
        }
        this.viewCommands.afterApply((ViewCommand)onVideoCommand);
    }

    func U0(ReleaseVideo releaseVideo) -> void {
        OnReleaseVideoAppealDeletedCommand onReleaseVideoAppealDeletedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReleaseVideoAppealDeletedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideoAppealsView)iterator.next()).U0(releaseVideo);
        }
        this.viewCommands.afterApply((ViewCommand)onReleaseVideoAppealDeletedCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideoAppealsView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideoAppealsView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideoAppealsView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func d() -> void {
        OnShowRefreshViewCommand onShowRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideoAppealsView)iterator.next()).d();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRefreshViewCommand);
    }

    func e() -> void {
        OnHideRefreshViewCommand onHideRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideoAppealsView)iterator.next()).e();
        }
        this.viewCommands.afterApply((ViewCommand)onHideRefreshViewCommand);
    }

    func u0() -> void {
        OnReleaseVideoAppealDeleteFailedCommand onReleaseVideoAppealDeleteFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReleaseVideoAppealDeleteFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideoAppealsView)iterator.next()).u0();
        }
        this.viewCommands.afterApply((ViewCommand)onReleaseVideoAppealDeleteFailedCommand);
    }

    func x0(ReleaseVideo releaseVideo) -> void {
        OnVideoAppealDeleteCommand onVideoAppealDeleteCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onVideoAppealDeleteCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileReleaseVideoAppealsView)iterator.next()).x0(releaseVideo);
        }
        this.viewCommands.afterApply((ViewCommand)onVideoAppealDeleteCommand);
    }
}

