/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileChangeLoginHistoryView
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileChangeLoginHistoryView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileChangeLoginHistoryView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileChangeLoginHistoryView$$State$OnHideRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileChangeLoginHistoryView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileChangeLoginHistoryView$$State$OnShowRefreshViewCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.profile;

import com.swiftsoft.anixartd.presentation.main.profile.ProfileChangeLoginHistoryView;
import com.swiftsoft.anixartd.presentation.main.profile.ProfileChangeLoginHistoryView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class ProfileChangeLoginHistoryView$$State
extends MvpViewState<ProfileChangeLoginHistoryView>
implements ProfileChangeLoginHistoryView {
    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileChangeLoginHistoryView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileChangeLoginHistoryView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileChangeLoginHistoryView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func d() -> void {
        OnShowRefreshViewCommand onShowRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileChangeLoginHistoryView)iterator.next()).d();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRefreshViewCommand);
    }

    func e() -> void {
        OnHideRefreshViewCommand onHideRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileChangeLoginHistoryView)iterator.next()).e();
        }
        this.viewCommands.afterApply((ViewCommand)onHideRefreshViewCommand);
    }
}

