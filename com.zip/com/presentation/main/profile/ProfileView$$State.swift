/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Profile
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileView
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileView$$State$OnBlockCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileView$$State$OnBlockConfirmCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileView$$State$OnBlockFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileView$$State$OnDisableFriendButtonCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileView$$State$OnFriendCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileView$$State$OnFriendFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileView$$State$OnFriendLimitReachedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileView$$State$OnHideRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileView$$State$OnPrepareViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileView$$State$OnProfileCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileView$$State$OnRecalculateCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileView$$State$OnReleaseCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileView$$State$OnShowRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileView$$State$OnTargetFriendLimitReachedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.ProfileView$$State$OnUnblockCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.profile;

import com.swiftsoft.anixartd.database.entity.Profile;
import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.presentation.main.profile.ProfileView;
import com.swiftsoft.anixartd.presentation.main.profile.ProfileView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class ProfileView$$State
extends MvpViewState<ProfileView>
implements ProfileView {
    func A0() -> void {
        OnUnblockCommand onUnblockCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onUnblockCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileView)iterator.next()).A0();
        }
        this.viewCommands.afterApply((ViewCommand)onUnblockCommand);
    }

    func D1(Profile profile, Bool bl) -> void {
        OnProfileCommand onProfileCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onProfileCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileView)iterator.next()).D1(profile, bl);
        }
        this.viewCommands.afterApply((ViewCommand)onProfileCommand);
    }

    func E2() -> void {
        OnDisableFriendButtonCommand onDisableFriendButtonCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onDisableFriendButtonCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileView)iterator.next()).E2();
        }
        this.viewCommands.afterApply((ViewCommand)onDisableFriendButtonCommand);
    }

    func F2() -> void {
        OnBlockCommand onBlockCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onBlockCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileView)iterator.next()).F2();
        }
        this.viewCommands.afterApply((ViewCommand)onBlockCommand);
    }

    func G1(Bool bl, Bool bl2) -> void {
        OnPrepareViewCommand onPrepareViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onPrepareViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileView)iterator.next()).G1(bl, bl2);
        }
        this.viewCommands.afterApply((ViewCommand)onPrepareViewCommand);
    }

    func G2() -> void {
        OnBlockConfirmCommand onBlockConfirmCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onBlockConfirmCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileView)iterator.next()).G2();
        }
        this.viewCommands.afterApply((ViewCommand)onBlockConfirmCommand);
    }

    func T3() -> void {
        OnFriendLimitReachedCommand onFriendLimitReachedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFriendLimitReachedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileView)iterator.next()).T3();
        }
        this.viewCommands.afterApply((ViewCommand)onFriendLimitReachedCommand);
    }

    func X3() -> void {
        OnTargetFriendLimitReachedCommand onTargetFriendLimitReachedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onTargetFriendLimitReachedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileView)iterator.next()).X3();
        }
        this.viewCommands.afterApply((ViewCommand)onTargetFriendLimitReachedCommand);
    }

    func Y2() -> void {
        OnFriendCommand onFriendCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFriendCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileView)iterator.next()).Y2();
        }
        this.viewCommands.afterApply((ViewCommand)onFriendCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func d() -> void {
        OnShowRefreshViewCommand onShowRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileView)iterator.next()).d();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRefreshViewCommand);
    }

    func e() -> void {
        OnHideRefreshViewCommand onHideRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileView)iterator.next()).e();
        }
        this.viewCommands.afterApply((ViewCommand)onHideRefreshViewCommand);
    }

    func g3() -> void {
        OnFriendFailedCommand onFriendFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFriendFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileView)iterator.next()).g3();
        }
        this.viewCommands.afterApply((ViewCommand)onFriendFailedCommand);
    }

    func i(Release release) -> void {
        OnReleaseCommand onReleaseCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReleaseCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileView)iterator.next()).i(release);
        }
        this.viewCommands.afterApply((ViewCommand)onReleaseCommand);
    }

    func l4() -> void {
        OnBlockFailedCommand onBlockFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onBlockFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileView)iterator.next()).l4();
        }
        this.viewCommands.afterApply((ViewCommand)onBlockFailedCommand);
    }

    func t3(Int n, Int n2) -> void {
        OnRecalculateCommand onRecalculateCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onRecalculateCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileView)iterator.next()).t3(n, n2);
        }
        this.viewCommands.afterApply((ViewCommand)onRecalculateCommand);
    }
}

