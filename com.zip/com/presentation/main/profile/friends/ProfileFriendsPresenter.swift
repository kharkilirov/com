/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.network.api.ProfileFriendApi
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsPresenter$listener
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsPresenter$listener$1
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsPresenter$onProfileFriends
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsPresenter$onProfileFriends$
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsPresenter$onProfileFriends$$inlined
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsPresenter$onProfileFriends$$inlined$combineLatest
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsPresenter$onProfileFriends$2
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsPresenter$onProfileFriends$4
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsPresenter$onProfileFriends$5
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsPresenter$onProfileFriends$6
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsPresenter$onProfileFriends$8
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsPresenter$onProfileFriends$9
 *  com.swiftsoft.anixartd.repository.ProfileRepository
 *  com.swiftsoft.anixartd.ui.controller.main.profile.friends.ProfileFriendsUiController
 *  com.swiftsoft.anixartd.ui.controller.main.profile.friends.ProfileFriendsUiController$Listener
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  io.reactivex.Flowable
 *  io.reactivex.Observable
 *  io.reactivex.ObservableSource
 *  io.reactivex.Scheduler
 *  io.reactivex.android.schedulers.AndroidSchedulers
 *  io.reactivex.disposables.Disposable
 *  io.reactivex.functions.Action
 *  io.reactivex.functions.Consumer
 *  io.reactivex.functions.Function
 *  io.reactivex.functions.Function4
 *  io.reactivex.internal.functions.Functions
 *  io.reactivex.schedulers.Schedulers
 *  java.lang.Object
 *  java.lang.String
 *  javax.inject.Inject
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  moxy.InjectViewState
 *  moxy.MvpPresenter
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.presentation.main.profile.friends;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.network.api.ProfileFriendApi;
import com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsPresenter;
import com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsPresenter$onProfileFriends$;
import com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsView;
import com.swiftsoft.anixartd.presentation.main.profile.friends.a;
import com.swiftsoft.anixartd.presentation.main.profile.friends.b;
import com.swiftsoft.anixartd.repository.ProfileRepository;
import com.swiftsoft.anixartd.ui.controller.main.profile.friends.ProfileFriendsUiController;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import com.swiftsoft.anixartd.ui.logic.main.profile.friends.ProfileFriendsUiLogic;
import io.reactivex.Flowable;
import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.functions.Function4;
import io.reactivex.internal.functions.Functions;
import io.reactivex.schedulers.Schedulers;
import javax.inject.Inject;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import moxy.InjectViewState;
import moxy.MvpPresenter;
import org.jetbrains.annotations.NotNull;

/*
 * Exception performing whole class analysis.
 */
@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/presentation/main/profile/friends/ProfileFriendsPresenter;", "Lmoxy/MvpPresenter;", "Lcom/swiftsoft/anixartd/presentation/main/profile/friends/ProfileFriendsView;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@InjectViewState
final class ProfileFriendsPresenter
extends MvpPresenter<ProfileFriendsView> {
    @NotNull
    ProfileRepository a;
    @NotNull
    Prefs b;
    @NotNull
    Listener c;
    @NotNull
    ProfileFriendsUiLogic d;
    @NotNull
    ProfileFriendsUiController e;

    @Inject
    init(@NotNull ProfileRepository profileRepository, @NotNull Prefs prefs) {
        Intrinsics.h((Object)profileRepository, (String)"profileRepository");
        Intrinsics.h((Object)prefs, (String)"prefs");
        this.a = profileRepository;
        this.b = prefs;
        this.c = new listener.1(this);
        this.d = new ProfileFriendsUiLogic();
        this.e = new ProfileFriendsUiController();
    }

    static void b(ProfileFriendsPresenter profileFriendsPresenter, Bool bl, Bool bl2, Int n) {
        if ((n & 1) != 0) {
            bl = profileFriendsPresenter.e.isEmpty();
        }
        if ((n & 2) != 0) {
            bl2 = false;
        }
        profileFriendsPresenter.a(bl, bl2);
    }

    final void a(Bool bl, Bool bl2) {
        ProfileRepository profileRepository = this.a;
        ProfileFriendsUiLogic profileFriendsUiLogic = this.d;
        long l = profileFriendsUiLogic.b;
        Int n = profileFriendsUiLogic.c;
        Observable observable = profileRepository.b.friends(l, n, profileRepository.d.w());
        Scheduler scheduler = Schedulers.c;
        Observable observable2 = observable.n(scheduler).k(AndroidSchedulers.a());
        ProfileRepository profileRepository2 = this.a;
        Observable observable3 = profileRepository2.b.recommendations(profileRepository2.d.w()).n(scheduler).k(AndroidSchedulers.a());
        ProfileRepository profileRepository3 = this.a;
        Observable observable4 = profileRepository3.b.requestsInLast(profileRepository3.d.w()).n(scheduler).k(AndroidSchedulers.a());
        ProfileRepository profileRepository4 = this.a;
        Observable observable5 = profileRepository4.b.requestsOutLast(profileRepository4.d.w()).n(scheduler).k(AndroidSchedulers.a());
        Bool bl3 = this.d.b == this.b.d();
        if (bl3 && this.d.c == 0) {
            Observable.f((Function)Functions.c(}
    }
    java.lang.IllegalStateException: Inner class got unexpected class file - revert this change
    
    