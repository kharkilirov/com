/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileOutFriendRequestsView
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileOutFriendRequestsView$$State$OnCancelFriendRequestCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileOutFriendRequestsView$$State$OnCancelFriendRequestFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileOutFriendRequestsView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileOutFriendRequestsView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileOutFriendRequestsView$$State$OnHideRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileOutFriendRequestsView$$State$OnProfileCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileOutFriendRequestsView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileOutFriendRequestsView$$State$OnShowRefreshViewCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.profile.friends;

import com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileOutFriendRequestsView;
import com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileOutFriendRequestsView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class ProfileOutFriendRequestsView$$State
extends MvpViewState<ProfileOutFriendRequestsView>
implements ProfileOutFriendRequestsView {
    func W3() -> void {
        OnCancelFriendRequestCommand onCancelFriendRequestCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCancelFriendRequestCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileOutFriendRequestsView)iterator.next()).W3();
        }
        this.viewCommands.afterApply((ViewCommand)onCancelFriendRequestCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileOutFriendRequestsView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileOutFriendRequestsView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileOutFriendRequestsView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func d() -> void {
        OnShowRefreshViewCommand onShowRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileOutFriendRequestsView)iterator.next()).d();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRefreshViewCommand);
    }

    func e() -> void {
        OnHideRefreshViewCommand onHideRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileOutFriendRequestsView)iterator.next()).e();
        }
        this.viewCommands.afterApply((ViewCommand)onHideRefreshViewCommand);
    }

    func f(long l) -> void {
        OnProfileCommand onProfileCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onProfileCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileOutFriendRequestsView)iterator.next()).f(l);
        }
        this.viewCommands.afterApply((ViewCommand)onProfileCommand);
    }

    func s0() -> void {
        OnCancelFriendRequestFailedCommand onCancelFriendRequestFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCancelFriendRequestFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileOutFriendRequestsView)iterator.next()).s0();
        }
        this.viewCommands.afterApply((ViewCommand)onCancelFriendRequestFailedCommand);
    }
}

