/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsView
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsView$$State$OnAcceptFriendRequestFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsView$$State$OnCancelFriendRequestFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsView$$State$OnFriendRequestsCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsView$$State$OnHideFriendRequestFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsView$$State$OnHideRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsView$$State$OnNotSocialCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsView$$State$OnOutFriendRequestsCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsView$$State$OnProfileCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsView$$State$OnShowRefreshViewCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.profile.friends;

import com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsView;
import com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class ProfileFriendsView$$State
extends MvpViewState<ProfileFriendsView>
implements ProfileFriendsView {
    func B3() -> void {
        OnNotSocialCommand onNotSocialCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onNotSocialCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileFriendsView)iterator.next()).B3();
        }
        this.viewCommands.afterApply((ViewCommand)onNotSocialCommand);
    }

    func C0() -> void {
        OnHideFriendRequestFailedCommand onHideFriendRequestFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideFriendRequestFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileFriendsView)iterator.next()).C0();
        }
        this.viewCommands.afterApply((ViewCommand)onHideFriendRequestFailedCommand);
    }

    func H0() -> void {
        OnAcceptFriendRequestFailedCommand onAcceptFriendRequestFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onAcceptFriendRequestFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileFriendsView)iterator.next()).H0();
        }
        this.viewCommands.afterApply((ViewCommand)onAcceptFriendRequestFailedCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileFriendsView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileFriendsView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileFriendsView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func d() -> void {
        OnShowRefreshViewCommand onShowRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileFriendsView)iterator.next()).d();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRefreshViewCommand);
    }

    func e() -> void {
        OnHideRefreshViewCommand onHideRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileFriendsView)iterator.next()).e();
        }
        this.viewCommands.afterApply((ViewCommand)onHideRefreshViewCommand);
    }

    func f(long l) -> void {
        OnProfileCommand onProfileCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onProfileCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileFriendsView)iterator.next()).f(l);
        }
        this.viewCommands.afterApply((ViewCommand)onProfileCommand);
    }

    func f2() -> void {
        OnFriendRequestsCommand onFriendRequestsCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFriendRequestsCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileFriendsView)iterator.next()).f2();
        }
        this.viewCommands.afterApply((ViewCommand)onFriendRequestsCommand);
    }

    func s0() -> void {
        OnCancelFriendRequestFailedCommand onCancelFriendRequestFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCancelFriendRequestFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileFriendsView)iterator.next()).s0();
        }
        this.viewCommands.afterApply((ViewCommand)onCancelFriendRequestFailedCommand);
    }

    func y2() -> void {
        OnOutFriendRequestsCommand onOutFriendRequestsCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onOutFriendRequestsCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((ProfileFriendsView)iterator.next()).y2();
        }
        this.viewCommands.afterApply((ViewCommand)onOutFriendRequestsCommand);
    }
}

