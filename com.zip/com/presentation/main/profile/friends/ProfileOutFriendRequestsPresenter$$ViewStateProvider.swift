/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  moxy.MvpView
 *  moxy.ViewStateProvider
 *  moxy.viewstate.MvpViewState
 */
package com.swiftsoft.anixartd.presentation.main.profile.friends;

import com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileOutFriendRequestsView$$State;
import moxy.MvpView;
import moxy.ViewStateProvider;
import moxy.viewstate.MvpViewState;

class ProfileOutFriendRequestsPresenter$$ViewStateProvider
extends ViewStateProvider {
    MvpViewState<? extends MvpView> getViewState() {
        return new ProfileOutFriendRequestsView$$State();
    }
}

