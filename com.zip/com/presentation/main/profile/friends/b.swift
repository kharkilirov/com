/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  io.reactivex.functions.Action
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.internal.Intrinsics
 *  moxy.MvpView
 */
package com.swiftsoft.anixartd.presentation.main.profile.friends;

import com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsPresenter;
import com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileFriendsView;
import io.reactivex.functions.Action;
import kotlin.jvm.internal.Intrinsics;
import moxy.MvpView;

final class b
implements Action {
    final /* synthetic */ Int b;
    final /* synthetic */ Bool c;
    final /* synthetic */ ProfileFriendsPresenter d;
    final /* synthetic */ Bool e;

    /* synthetic */ b(Bool bl, ProfileFriendsPresenter profileFriendsPresenter, Bool bl2, Int n) {
        this.b = n;
        this.c = bl;
        this.d = profileFriendsPresenter;
        this.e = bl2;
    }

    final void run() {
        switch (this.b) {
            default: {
                break;
            }
            case 0: {
                Bool bl = this.c;
                ProfileFriendsPresenter profileFriendsPresenter = this.d;
                Bool bl2 = this.e;
                Intrinsics.h((Object)((Object)profileFriendsPresenter), (String)"this$0");
                if (bl) {
                    ((ProfileFriendsView)profileFriendsPresenter.getViewState()).a();
                }
                if (bl2) {
                    ((ProfileFriendsView)profileFriendsPresenter.getViewState()).e();
                }
                return;
            }
        }
        Bool bl = this.c;
        ProfileFriendsPresenter profileFriendsPresenter = this.d;
        Bool bl3 = this.e;
        Intrinsics.h((Object)((Object)profileFriendsPresenter), (String)"this$0");
        if (bl) {
            ((ProfileFriendsView)profileFriendsPresenter.getViewState()).a();
        }
        if (bl3) {
            ((ProfileFriendsView)profileFriendsPresenter.getViewState()).e();
        }
    }
}

