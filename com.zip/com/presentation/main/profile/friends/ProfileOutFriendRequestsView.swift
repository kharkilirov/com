/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.Metadata
 *  moxy.MvpView
 *  moxy.viewstate.strategy.OneExecutionStateStrategy
 *  moxy.viewstate.strategy.StateStrategyType
 */
package com.swiftsoft.anixartd.presentation.main.profile.friends;

import kotlin.Metadata;
import moxy.MvpView;
import moxy.viewstate.strategy.OneExecutionStateStrategy;
import moxy.viewstate.strategy.StateStrategyType;

@Metadata(bv={}, d1={"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bg\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"}, d2={"Lcom/swiftsoft/anixartd/presentation/main/profile/friends/ProfileOutFriendRequestsView;", "Lmoxy/MvpView;", "app_release"}, k=1, mv={1, 7, 1})
@StateStrategyType(value="Lmoxy/viewstate/strategy/AddToEndSingleTagStrategy;")
interface ProfileOutFriendRequestsView
extends MvpView {
    @StateStrategyType(value=OneExecutionStateStrategy.class)
    void W3();

    void a();

    void b();

    @StateStrategyType(value=OneExecutionStateStrategy.class)
    void c();

    void d();

    void e();

    @StateStrategyType(value=OneExecutionStateStrategy.class)
    void f(long var1);

    @StateStrategyType(value=OneExecutionStateStrategy.class)
    void s0();
}

