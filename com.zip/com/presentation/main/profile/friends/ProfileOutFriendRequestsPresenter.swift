/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.database.entity.Profile
 *  com.swiftsoft.anixartd.network.api.ProfileFriendApi
 *  com.swiftsoft.anixartd.presentation.comments.a
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileOutFriendRequestsPresenter$listener
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileOutFriendRequestsPresenter$listener$1
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileOutFriendRequestsPresenter$onProfileFriends
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileOutFriendRequestsPresenter$onProfileFriends$1
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileOutFriendRequestsPresenter$onProfileFriends$3
 *  com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileOutFriendRequestsPresenter$onProfileFriends$4
 *  com.swiftsoft.anixartd.repository.ProfileRepository
 *  com.swiftsoft.anixartd.ui.controller.main.profile.friends.ProfileOutFriendRequestsUiController
 *  com.swiftsoft.anixartd.ui.controller.main.profile.friends.ProfileOutFriendRequestsUiController$Listener
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  io.reactivex.Observable
 *  io.reactivex.Scheduler
 *  io.reactivex.android.schedulers.AndroidSchedulers
 *  io.reactivex.disposables.Disposable
 *  io.reactivex.functions.Action
 *  io.reactivex.functions.Consumer
 *  io.reactivex.internal.functions.Functions
 *  io.reactivex.schedulers.Schedulers
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  javax.inject.Inject
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  moxy.InjectViewState
 *  moxy.MvpPresenter
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.presentation.main.profile.friends;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.database.entity.Profile;
import com.swiftsoft.anixartd.network.api.ProfileFriendApi;
import com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileOutFriendRequestsPresenter;
import com.swiftsoft.anixartd.presentation.main.profile.friends.ProfileOutFriendRequestsView;
import com.swiftsoft.anixartd.presentation.main.profile.friends.a;
import com.swiftsoft.anixartd.repository.ProfileRepository;
import com.swiftsoft.anixartd.ui.controller.main.profile.friends.ProfileOutFriendRequestsUiController;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import com.swiftsoft.anixartd.ui.logic.main.profile.friends.ProfileOutFriendRequestsUiLogic;
import io.reactivex.Observable;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.internal.functions.Functions;
import io.reactivex.schedulers.Schedulers;
import java.util.List;
import javax.inject.Inject;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import moxy.InjectViewState;
import moxy.MvpPresenter;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/presentation/main/profile/friends/ProfileOutFriendRequestsPresenter;", "Lmoxy/MvpPresenter;", "Lcom/swiftsoft/anixartd/presentation/main/profile/friends/ProfileOutFriendRequestsView;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@InjectViewState
final class ProfileOutFriendRequestsPresenter
extends MvpPresenter<ProfileOutFriendRequestsView> {
    @NotNull
    ProfileRepository a;
    @NotNull
    Listener b;
    @NotNull
    ProfileOutFriendRequestsUiLogic c;
    @NotNull
    ProfileOutFriendRequestsUiController d;

    @Inject
    init(@NotNull ProfileRepository profileRepository, @NotNull Prefs prefs) {
        Intrinsics.h((Object)profileRepository, (String)"profileRepository");
        Intrinsics.h((Object)prefs, (String)"prefs");
        this.a = profileRepository;
        this.b = new listener.1(this);
        this.c = new ProfileOutFriendRequestsUiLogic();
        this.d = new ProfileOutFriendRequestsUiController();
    }

    static void b(ProfileOutFriendRequestsPresenter profileOutFriendRequestsPresenter, Bool bl, Bool bl2, Int n) {
        if ((n & 1) != 0) {
            bl = profileOutFriendRequestsPresenter.d.isEmpty();
        }
        if ((n & 2) != 0) {
            bl2 = false;
        }
        profileOutFriendRequestsPresenter.a(bl, bl2);
    }

    final void a(Bool bl, Bool bl2) {
        ProfileRepository profileRepository = this.a;
        Int n = this.c.b;
        profileRepository.b.requestsOut(n, profileRepository.d.w()).n(Schedulers.c).k(AndroidSchedulers.a()).i((Consumer)new a((Function1)new onProfileFriends.1(bl, this, bl2), 14)).j((Action)new com.swiftsoft.anixartd.presentation.comments.a(bl, (MvpPresenter)this, bl2, 12)).l((Consumer)new a((Function1)new onProfileFriends.3(this), 15), (Consumer)new a((Function1)new onProfileFriends.4(this), 16), Functions.b, Functions.c);
    }

    final void c() {
        ProfileOutFriendRequestsUiLogic profileOutFriendRequestsUiLogic = this.c;
        if (profileOutFriendRequestsUiLogic.a) {
            profileOutFriendRequestsUiLogic.b = 0;
            profileOutFriendRequestsUiLogic.d = 0L;
            profileOutFriendRequestsUiLogic.c.clear();
            profileOutFriendRequestsUiLogic.e = false;
            ProfileOutFriendRequestsPresenter.b(this, false, false, 2);
        }
    }

}

