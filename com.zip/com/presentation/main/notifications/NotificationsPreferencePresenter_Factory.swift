/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.notifications.NotificationsPreferencePresenter
 *  com.swiftsoft.anixartd.repository.AuthRepository
 *  com.swiftsoft.anixartd.repository.NotificationPreferenceRepository
 *  com.swiftsoft.anixartd.repository.TypeRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.notifications;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.notifications.NotificationsPreferencePresenter;
import com.swiftsoft.anixartd.repository.AuthRepository;
import com.swiftsoft.anixartd.repository.NotificationPreferenceRepository;
import com.swiftsoft.anixartd.repository.TypeRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class NotificationsPreferencePresenter_Factory
implements Factory<NotificationsPreferencePresenter> {
    final Provider<AuthRepository> a;
    final Provider<TypeRepository> b;
    final Provider<NotificationPreferenceRepository> c;
    final Provider<Prefs> d;

    init(Provider<AuthRepository> provider, Provider<TypeRepository> provider2, Provider<NotificationPreferenceRepository> provider3, Provider<Prefs> provider4) {
        this.a = provider;
        this.b = provider2;
        this.c = provider3;
        this.d = provider4;
    }

    func get() -> Object {
        return new NotificationsPreferencePresenter((AuthRepository)this.a.get(), (TypeRepository)this.b.get(), (NotificationPreferenceRepository)this.c.get(), (Prefs)this.d.get());
    }
}

