/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.notifications.NotificationsView
 *  com.swiftsoft.anixartd.presentation.main.notifications.NotificationsView$$State$OnCollectionCommentCommand
 *  com.swiftsoft.anixartd.presentation.main.notifications.NotificationsView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.notifications.NotificationsView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.notifications.NotificationsView$$State$OnHideRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.notifications.NotificationsView$$State$OnLoadedCommand
 *  com.swiftsoft.anixartd.presentation.main.notifications.NotificationsView$$State$OnMoreCommand
 *  com.swiftsoft.anixartd.presentation.main.notifications.NotificationsView$$State$OnNotificationsPreferenceCommand
 *  com.swiftsoft.anixartd.presentation.main.notifications.NotificationsView$$State$OnProfileCommand
 *  com.swiftsoft.anixartd.presentation.main.notifications.NotificationsView$$State$OnRefreshAfterFilterCommand
 *  com.swiftsoft.anixartd.presentation.main.notifications.NotificationsView$$State$OnReleaseCommand
 *  com.swiftsoft.anixartd.presentation.main.notifications.NotificationsView$$State$OnReleaseCommentCommand
 *  com.swiftsoft.anixartd.presentation.main.notifications.NotificationsView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.notifications.NotificationsView$$State$OnShowRefreshViewCommand
 *  java.lang.Boolean
 *  java.lang.Long
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.notifications;

import com.swiftsoft.anixartd.presentation.main.notifications.NotificationsView;
import com.swiftsoft.anixartd.presentation.main.notifications.NotificationsView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class NotificationsView$$State
extends MvpViewState<NotificationsView>
implements NotificationsView {
    func M0() -> void {
        OnNotificationsPreferenceCommand onNotificationsPreferenceCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onNotificationsPreferenceCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((NotificationsView)iterator.next()).M0();
        }
        this.viewCommands.afterApply((ViewCommand)onNotificationsPreferenceCommand);
    }

    func N(long l, long l2, long l3) -> void {
        OnReleaseCommentCommand onReleaseCommentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReleaseCommentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((NotificationsView)iterator.next()).N(l, l2, l3);
        }
        this.viewCommands.afterApply((ViewCommand)onReleaseCommentCommand);
    }

    func O() -> void {
        OnLoadedCommand onLoadedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLoadedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((NotificationsView)iterator.next()).O();
        }
        this.viewCommands.afterApply((ViewCommand)onLoadedCommand);
    }

    func S0(long l, long l2, Long l3) -> void {
        OnCollectionCommentCommand onCollectionCommentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onCollectionCommentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((NotificationsView)iterator.next()).S0(l, l2, l3);
        }
        this.viewCommands.afterApply((ViewCommand)onCollectionCommentCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((NotificationsView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((NotificationsView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((NotificationsView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func d() -> void {
        OnShowRefreshViewCommand onShowRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((NotificationsView)iterator.next()).d();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRefreshViewCommand);
    }

    func e() -> void {
        OnHideRefreshViewCommand onHideRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((NotificationsView)iterator.next()).e();
        }
        this.viewCommands.afterApply((ViewCommand)onHideRefreshViewCommand);
    }

    func f(long l) -> void {
        OnProfileCommand onProfileCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onProfileCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((NotificationsView)iterator.next()).f(l);
        }
        this.viewCommands.afterApply((ViewCommand)onProfileCommand);
    }

    func g(long l) -> void {
        OnReleaseCommand onReleaseCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReleaseCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((NotificationsView)iterator.next()).g(l);
        }
        this.viewCommands.afterApply((ViewCommand)onReleaseCommand);
    }

    func h2() -> void {
        OnRefreshAfterFilterCommand onRefreshAfterFilterCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onRefreshAfterFilterCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((NotificationsView)iterator.next()).h2();
        }
        this.viewCommands.afterApply((ViewCommand)onRefreshAfterFilterCommand);
    }

    func k(long l) -> void {
        OnMoreCommand onMoreCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onMoreCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((NotificationsView)iterator.next()).k(l);
        }
        this.viewCommands.afterApply((ViewCommand)onMoreCommand);
    }
}

