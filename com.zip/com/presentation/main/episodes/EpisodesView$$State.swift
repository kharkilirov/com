/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.episode.Episode
 *  com.swiftsoft.anixartd.database.entity.episode.Source
 *  com.swiftsoft.anixartd.database.entity.episode.Type
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnAskWhichDownloaderToUseCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnAskWhichPlayerToUseCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnDownloadEpisode1Command
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnDownloadEpisodeCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnDownloadEpisodeDisclaimerCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnDownloadEpisodeFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnEpisodeDisclaimerCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnHideParsingProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnLastWatchedEpisodeCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnLoadedCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnParsingFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnReportSentCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnShowEpisodeReportFragmentCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnShowKodikAdCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnShowNeedAuthCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnShowParsingProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnShowTooltipEpisodeUpdatesCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnSourceCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnSwiftPlayerCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnThirdPartyPlayerCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnTorlookDisclaimerCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnTypeCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnTypesCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State$OnWebPlayerCommand
 *  java.lang.Boolean
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.episodes;

import com.swiftsoft.anixartd.database.entity.episode.Episode;
import com.swiftsoft.anixartd.database.entity.episode.Source;
import com.swiftsoft.anixartd.database.entity.episode.Type;
import com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView;
import com.swiftsoft.anixartd.presentation.main.episodes.EpisodesView$$State;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class EpisodesView$$State
extends MvpViewState<EpisodesView>
implements EpisodesView {
    func A1() -> void {
        OnShowTooltipEpisodeUpdatesCommand onShowTooltipEpisodeUpdatesCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowTooltipEpisodeUpdatesCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).A1();
        }
        this.viewCommands.afterApply((ViewCommand)onShowTooltipEpisodeUpdatesCommand);
    }

    func G3(Episode episode, Int n, Int n2) -> void {
        OnShowKodikAdCommand onShowKodikAdCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowKodikAdCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).G3(episode, n, n2);
        }
        this.viewCommands.afterApply((ViewCommand)onShowKodikAdCommand);
    }

    func H1(Type type) -> void {
        OnTypeCommand onTypeCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onTypeCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).H1(type);
        }
        this.viewCommands.afterApply((ViewCommand)onTypeCommand);
    }

    func L3(Episode episode, String string, List<String> list, Int n) -> void {
        OnThirdPartyPlayerCommand onThirdPartyPlayerCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onThirdPartyPlayerCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).L3(episode, string, list, n);
        }
        this.viewCommands.afterApply((ViewCommand)onThirdPartyPlayerCommand);
    }

    func N1(Episode episode, Int n, List<String> list) -> void {
        OnDownloadEpisode1Command onDownloadEpisode1Command = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onDownloadEpisode1Command);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).N1(episode, n, list);
        }
        this.viewCommands.afterApply((ViewCommand)onDownloadEpisode1Command);
    }

    func O() -> void {
        OnLoadedCommand onLoadedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLoadedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).O();
        }
        this.viewCommands.afterApply((ViewCommand)onLoadedCommand);
    }

    func O2(Int n, Int n2) -> void {
        OnLastWatchedEpisodeCommand onLastWatchedEpisodeCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLastWatchedEpisodeCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).O2(n, n2);
        }
        this.viewCommands.afterApply((ViewCommand)onLastWatchedEpisodeCommand);
    }

    func R1() -> void {
        OnTypesCommand onTypesCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onTypesCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).R1();
        }
        this.viewCommands.afterApply((ViewCommand)onTypesCommand);
    }

    func S3(List<String> list, String string, Long l) -> void {
        OnSwiftPlayerCommand onSwiftPlayerCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onSwiftPlayerCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).S3(list, string, l);
        }
        this.viewCommands.afterApply((ViewCommand)onSwiftPlayerCommand);
    }

    func U1() -> void {
        OnDownloadEpisodeFailedCommand onDownloadEpisodeFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onDownloadEpisodeFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).U1();
        }
        this.viewCommands.afterApply((ViewCommand)onDownloadEpisodeFailedCommand);
    }

    func Z3(Episode episode) -> void {
        OnEpisodeDisclaimerCommand onEpisodeDisclaimerCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onEpisodeDisclaimerCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).Z3(episode);
        }
        this.viewCommands.afterApply((ViewCommand)onEpisodeDisclaimerCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func c3(Episode episode) -> void {
        OnAskWhichDownloaderToUseCommand onAskWhichDownloaderToUseCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onAskWhichDownloaderToUseCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).c3(episode);
        }
        this.viewCommands.afterApply((ViewCommand)onAskWhichDownloaderToUseCommand);
    }

    func d3() -> void {
        OnHideParsingProgressViewCommand onHideParsingProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideParsingProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).d3();
        }
        this.viewCommands.afterApply((ViewCommand)onHideParsingProgressViewCommand);
    }

    func f4(Source source) -> void {
        OnSourceCommand onSourceCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onSourceCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).f4(source);
        }
        this.viewCommands.afterApply((ViewCommand)onSourceCommand);
    }

    func j4(List<Type> list) -> void {
        OnTorlookDisclaimerCommand onTorlookDisclaimerCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onTorlookDisclaimerCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).j4(list);
        }
        this.viewCommands.afterApply((ViewCommand)onTorlookDisclaimerCommand);
    }

    func m() -> void {
        OnShowNeedAuthCommand onShowNeedAuthCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowNeedAuthCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).m();
        }
        this.viewCommands.afterApply((ViewCommand)onShowNeedAuthCommand);
    }

    func n() -> void {
        OnReportSentCommand onReportSentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onReportSentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).n();
        }
        this.viewCommands.afterApply((ViewCommand)onReportSentCommand);
    }

    func onDownloadEpisode() -> void {
        OnDownloadEpisodeCommand onDownloadEpisodeCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onDownloadEpisodeCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).onDownloadEpisode();
        }
        this.viewCommands.afterApply((ViewCommand)onDownloadEpisodeCommand);
    }

    func p3() -> void {
        OnShowParsingProgressViewCommand onShowParsingProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowParsingProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).p3();
        }
        this.viewCommands.afterApply((ViewCommand)onShowParsingProgressViewCommand);
    }

    func r2(Episode episode) -> void {
        OnShowEpisodeReportFragmentCommand onShowEpisodeReportFragmentCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowEpisodeReportFragmentCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).r2(episode);
        }
        this.viewCommands.afterApply((ViewCommand)onShowEpisodeReportFragmentCommand);
    }

    func r3(String string) -> void {
        OnParsingFailedCommand onParsingFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onParsingFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).r3(string);
        }
        this.viewCommands.afterApply((ViewCommand)onParsingFailedCommand);
    }

    func s2(Episode episode, Int n, Bool bl) -> void {
        OnAskWhichPlayerToUseCommand onAskWhichPlayerToUseCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onAskWhichPlayerToUseCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).s2(episode, n, bl);
        }
        this.viewCommands.afterApply((ViewCommand)onAskWhichPlayerToUseCommand);
    }

    func u2(String string, Bool bl) -> void {
        OnWebPlayerCommand onWebPlayerCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onWebPlayerCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).u2(string, bl);
        }
        this.viewCommands.afterApply((ViewCommand)onWebPlayerCommand);
    }

    func x2(Episode episode) -> void {
        OnDownloadEpisodeDisclaimerCommand onDownloadEpisodeDisclaimerCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onDownloadEpisodeDisclaimerCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((EpisodesView)iterator.next()).x2(episode);
        }
        this.viewCommands.afterApply((ViewCommand)onDownloadEpisodeDisclaimerCommand);
    }
}

