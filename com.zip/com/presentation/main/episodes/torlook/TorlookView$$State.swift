/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.presentation.main.episodes.torlook.TorlookView
 *  com.swiftsoft.anixartd.presentation.main.episodes.torlook.TorlookView$$State$OnFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.torlook.TorlookView$$State$OnHideProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.torlook.TorlookView$$State$OnHideRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.torlook.TorlookView$$State$OnLinkCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.torlook.TorlookView$$State$OnMagnetLinkCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.torlook.TorlookView$$State$OnMagnetLinkFailedCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.torlook.TorlookView$$State$OnShowProgressViewCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.torlook.TorlookView$$State$OnShowRefreshViewCommand
 *  com.swiftsoft.anixartd.presentation.main.episodes.torlook.TorlookView$$State$OnUpdateSearchQueryTextCommand
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.Set
 *  moxy.viewstate.MvpViewState
 *  moxy.viewstate.ViewCommand
 *  moxy.viewstate.ViewCommands
 */
package com.swiftsoft.anixartd.presentation.main.episodes.torlook;

import com.swiftsoft.anixartd.presentation.main.episodes.torlook.TorlookView;
import com.swiftsoft.anixartd.presentation.main.episodes.torlook.TorlookView$$State;
import java.util.Iterator;
import java.util.Set;
import moxy.viewstate.MvpViewState;
import moxy.viewstate.ViewCommand;
import moxy.viewstate.ViewCommands;

/*
 * Exception performing whole class analysis.
 */
class TorlookView$$State
extends MvpViewState<TorlookView>
implements TorlookView {
    func N0(String string) -> void {
        OnLinkCommand onLinkCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onLinkCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((TorlookView)iterator.next()).N0(string);
        }
        this.viewCommands.afterApply((ViewCommand)onLinkCommand);
    }

    func a() -> void {
        OnHideProgressViewCommand onHideProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((TorlookView)iterator.next()).a();
        }
        this.viewCommands.afterApply((ViewCommand)onHideProgressViewCommand);
    }

    func b() -> void {
        OnShowProgressViewCommand onShowProgressViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowProgressViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((TorlookView)iterator.next()).b();
        }
        this.viewCommands.afterApply((ViewCommand)onShowProgressViewCommand);
    }

    func c() -> void {
        OnFailedCommand onFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((TorlookView)iterator.next()).c();
        }
        this.viewCommands.afterApply((ViewCommand)onFailedCommand);
    }

    func d() -> void {
        OnShowRefreshViewCommand onShowRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onShowRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((TorlookView)iterator.next()).d();
        }
        this.viewCommands.afterApply((ViewCommand)onShowRefreshViewCommand);
    }

    func e() -> void {
        OnHideRefreshViewCommand onHideRefreshViewCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onHideRefreshViewCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((TorlookView)iterator.next()).e();
        }
        this.viewCommands.afterApply((ViewCommand)onHideRefreshViewCommand);
    }

    func l2(String string) -> void {
        OnUpdateSearchQueryTextCommand onUpdateSearchQueryTextCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onUpdateSearchQueryTextCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((TorlookView)iterator.next()).l2(string);
        }
        this.viewCommands.afterApply((ViewCommand)onUpdateSearchQueryTextCommand);
    }

    func n0(String string) -> void {
        OnMagnetLinkCommand onMagnetLinkCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onMagnetLinkCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((TorlookView)iterator.next()).n0(string);
        }
        this.viewCommands.afterApply((ViewCommand)onMagnetLinkCommand);
    }

    func t1() -> void {
        OnMagnetLinkFailedCommand onMagnetLinkFailedCommand = new /* Unavailable Anonymous Inner Class!! */;
        this.viewCommands.beforeApply((ViewCommand)onMagnetLinkFailedCommand);
        if (this.hasNotView().booleanValue()) {
            return;
        }
        Iterator iterator = this.views.iterator();
        while (iterator.hasNext()) {
            ((TorlookView)iterator.next()).t1();
        }
        this.viewCommands.afterApply((ViewCommand)onMagnetLinkFailedCommand);
    }
}

