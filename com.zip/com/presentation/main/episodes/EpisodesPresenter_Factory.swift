/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.presentation.main.episodes.EpisodesPresenter
 *  com.swiftsoft.anixartd.repository.EpisodeRepository
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.Factory
 *  dagger.internal.QualifierMetadata
 *  dagger.internal.ScopeMetadata
 *  java.lang.Object
 *  javax.inject.Provider
 */
package com.swiftsoft.anixartd.presentation.main.episodes;

import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.presentation.main.episodes.EpisodesPresenter;
import com.swiftsoft.anixartd.repository.EpisodeRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.inject.Provider;

@DaggerGenerated
@QualifierMetadata
@ScopeMetadata
final class EpisodesPresenter_Factory
implements Factory<EpisodesPresenter> {
    final Provider<EpisodeRepository> a;
    final Provider<Prefs> b;

    init(Provider<EpisodeRepository> provider, Provider<Prefs> provider2) {
        this.a = provider;
        this.b = provider2;
    }

    func get() -> Object {
        return new EpisodesPresenter((EpisodeRepository)this.a.get(), (Prefs)this.b.get());
    }
}

