/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.importer.Importer
 *  com.swiftsoft.anixartd.importer.ShikimoriImporter
 *  com.swiftsoft.anixartd.utils.Dialogs
 *  com.swiftsoft.anixartd.utils.Dialogs$MaterialDialog
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  java.util.HashSet
 *  kotlin.Metadata
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.jvm.internal.Lambda
 */
package com.swiftsoft.anixartd.importer;

import com.swiftsoft.anixartd.importer.Importer;
import com.swiftsoft.anixartd.importer.ShikimoriImporter;
import com.swiftsoft.anixartd.utils.Dialogs;
import java.util.Collection;
import java.util.HashSet;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

@Metadata(d1={"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n\u00a2\u0006\u0002\b\u0004"}, d2={"<anonymous>", "", "it", "Lcom/swiftsoft/anixartd/utils/Dialogs$MaterialDialog;", "invoke"}, k=3, mv={1, 7, 1}, xi=48)
final class ShikimoriImporter$processTroubles$2
extends Lambda
implements Function1<Dialogs.MaterialDialog, Unit> {
    final /* synthetic */ ShikimoriImporter b;
    final /* synthetic */ Function1<Importer, Unit> c;

    ShikimoriImporter$processTroubles$2(ShikimoriImporter shikimoriImporter, Function1<? super Importer, Unit> function1) {
        this.b = shikimoriImporter;
        this.c = function1;
        super(1);
    }

    func invoke(Object object) -> Object {
        Intrinsics.h((Object)((Dialogs.MaterialDialog)object), (String)"it");
        ShikimoriImporter shikimoriImporter = this.b;
        shikimoriImporter.d.addAll((Collection)shikimoriImporter.g);
        this.b.g.clear();
        this.c.invoke((Object)this.b);
        return Unit.a;
    }
}

