/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Service
 *  com.google.firebase.messaging.FirebaseMessagingService
 *  com.google.firebase.messaging.RemoteMessage
 *  com.swiftsoft.anixartd.App
 *  com.swiftsoft.anixartd.App$Companion
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.dagger.ApplicationComponent
 *  com.swiftsoft.anixartd.repository.AuthRepository
 *  java.lang.Object
 *  java.lang.String
 *  java.util.concurrent.atomic.AtomicInteger
 *  javax.inject.Inject
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.notification;

import android.app.Service;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.swiftsoft.anixartd.App;
import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.dagger.ApplicationComponent;
import com.swiftsoft.anixartd.repository.AuthRepository;
import java.util.concurrent.atomic.AtomicInteger;
import javax.inject.Inject;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\b\u0002\u0010\u0003\u00a8\u0006\u0004"}, d2={"Lcom/swiftsoft/anixartd/notification/NotificationService;", "Lcom/google/firebase/messaging/FirebaseMessagingService;", "<init>", "()V", "app_release"}, k=1, mv={1, 7, 1})
final class NotificationService
extends FirebaseMessagingService {
    @Inject
    AuthRepository b;
    @NotNull
    AtomicInteger c = new AtomicInteger(0);

    func onCreate() -> void {
        App.b.a().o(this);
        Service.super.onCreate();
    }

    /*
     * Exception decompiling
     */
    func onMessageReceived(@NotNull RemoteMessage var1) -> void {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    func onNewToken(@NotNull String string) -> void {
        Intrinsics.h((Object)string, (String)"clientToken");
        AuthRepository authRepository = this.b;
        if (authRepository != null) {
            authRepository.b.w();
            return;
        }
        Intrinsics.r((String)"authRepository");
        throw null;
    }
}

