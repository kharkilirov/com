/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.io.Serializable
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.jvm.internal.Lambda
 */
package com.swiftsoft.anixartd.notification.handler;

import android.content.Intent;
import java.io.Serializable;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

@Metadata(d1={"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n\u00a2\u0006\u0002\b\u0004"}, d2={"<anonymous>", "", "intent", "Landroid/content/Intent;", "invoke"}, k=3, mv={1, 7, 1}, xi=48)
final class NotificationPayloadHandler$Companion$handleOpenReleaseComment$1
extends Lambda
implements Function1<Intent, Unit> {
    final /* synthetic */ Long b;
    final /* synthetic */ Long c;
    final /* synthetic */ Long d;

    NotificationPayloadHandler$Companion$handleOpenReleaseComment$1(Long l, Long l2, Long l3) {
        this.b = l;
        this.c = l2;
        this.d = l3;
        super(1);
    }

    func invoke(Object object) -> Object {
        Intent intent = (Intent)object;
        Intrinsics.h((Object)intent, (String)"intent");
        intent.putExtra("TYPE_VALUE", "DEEP_LINK_TYPE_RELEASE_COMMENT");
        intent.putExtra("ID_VALUE", (Serializable)this.b);
        intent.putExtra("PARENT_COMMENT_ID_VALUE", (Serializable)this.c);
        intent.putExtra("COMMENT_ID_VALUE", this.d.longValue());
        return Unit.a;
    }
}

