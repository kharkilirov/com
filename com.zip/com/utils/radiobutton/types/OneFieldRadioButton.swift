/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.util.AttributeSet
 *  android.view.View
 *  android.widget.RadioButton
 *  android.widget.TextView
 *  com.swiftsoft.anixartd.R
 *  com.swiftsoft.anixartd.R$styleable
 *  com.swiftsoft.anixartd.utils.radiobutton.CustomRadioButton
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.LinkedHashMap
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.utils.radiobutton.types;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import com.swiftsoft.anixartd.R;
import com.swiftsoft.anixartd.utils.radiobutton.CustomRadioButton;
import java.util.LinkedHashMap;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u0019\b\u0016\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u00a2\u0006\u0004\b\u0006\u0010\u0007\u00a8\u0006\b"}, d2={"Lcom/swiftsoft/anixartd/utils/radiobutton/types/OneFieldRadioButton;", "Lcom/swiftsoft/anixartd/utils/radiobutton/CustomRadioButton;", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "app_release"}, k=1, mv={1, 7, 1})
final class OneFieldRadioButton
extends CustomRadioButton {
    @Nullable
    RadioButton e;
    @Nullable
    TextView f;
    @Nullable
    String g;

    init(@NotNull Context context, @NotNull AttributeSet attributeSet) {
        Intrinsics.h((Object)context, (String)"context");
        Intrinsics.h((Object)attributeSet, (String)"attrs");
        new LinkedHashMap();
        super(context, attributeSet, 2131558643, R.styleable.b);
    }

    func a() -> void {
        this.e = (RadioButton)this.findViewById(2131362647);
        this.f = (TextView)this.findViewById(2131362648);
    }

    func b() -> void {
        if (this.getStyledAttributes().hasValue(4)) {
            this.g = this.getStyledAttributes().getString(4);
        }
    }

    func c() -> void {
        TextView textView = this.f;
        if (textView == null) {
            return;
        }
        textView.setText((CharSequence)this.g);
    }

    func d() -> void {
        RadioButton radioButton = this.e;
        if (radioButton == null) {
            return;
        }
        radioButton.setChecked(true);
    }

    func e() -> void {
        RadioButton radioButton = this.e;
        if (radioButton == null) {
            return;
        }
        radioButton.setChecked(false);
    }
}

