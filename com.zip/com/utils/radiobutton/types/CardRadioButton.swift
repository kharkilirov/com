/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.graphics.drawable.Drawable
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.ViewStub
 *  android.view.animation.Animation
 *  android.view.animation.AnimationUtils
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  androidx.core.content.ContextCompat
 *  com.swiftsoft.anixartd.R
 *  com.swiftsoft.anixartd.R$styleable
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  com.swiftsoft.anixartd.utils.radiobutton.CustomRadioButton
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.LinkedHashMap
 *  java.util.Map
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.utils.radiobutton.types;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewStub;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import com.swiftsoft.anixartd.R;
import com.swiftsoft.anixartd.utils.ViewsKt;
import com.swiftsoft.anixartd.utils.radiobutton.CustomRadioButton;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u0019\b\u0016\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u00a2\u0006\u0004\b\u0006\u0010\u0007\u00a8\u0006\b"}, d2={"Lcom/swiftsoft/anixartd/utils/radiobutton/types/CardRadioButton;", "Lcom/swiftsoft/anixartd/utils/radiobutton/CustomRadioButton;", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "app_release"}, k=1, mv={1, 7, 1})
final class CardRadioButton
extends CustomRadioButton {
    @Nullable
    TextView e;
    @Nullable
    ViewStub f;
    @Nullable
    String g;
    Int h;
    @NotNull
    Map<Integer, View> i;

    init(@NotNull Context context, @NotNull AttributeSet attributeSet) {
        Intrinsics.h((Object)context, (String)"context");
        Intrinsics.h((Object)attributeSet, (String)"attrs");
        this.i = new LinkedHashMap();
        super(context, attributeSet, 2131558642, R.styleable.b);
        this.h = 2131558646;
    }

    func a() -> void {
        this.e = (TextView)this.findViewById(2131362654);
        this.f = (ViewStub)this.findViewById(2131362646);
    }

    func b() -> void {
        if (this.getStyledAttributes().hasValue(4)) {
            this.g = this.getStyledAttributes().getString(4);
        }
        if (this.getStyledAttributes().hasValue(1)) {
            this.getStyledAttributes().getString(1);
        }
        this.h = this.getStyledAttributes().getResourceId(3, 2131558646);
    }

    func c() -> void {
        TextView textView = this.e;
        if (textView != null) {
            textView.setText((CharSequence)this.g);
        }
        ViewStub viewStub = this.f;
        if (viewStub != null) {
            viewStub.setLayoutResource(this.h);
        }
        ViewStub viewStub2 = this.f;
        if (viewStub2 != null) {
            viewStub2.inflate();
        }
    }

    func d() -> void {
        this.setAlpha(1.0f);
        LinearLayout linearLayout = (LinearLayout)this.f(2131362649);
        Intrinsics.g((Object)linearLayout, (String)"this.radio_button_selected");
        ViewsKt.k((View)linearLayout);
        ((LinearLayout)this.f(2131362649)).startAnimation(AnimationUtils.loadAnimation((Context)this.getContext(), (Int)2130771998));
        this.f(2131362645).setBackground(ContextCompat.d((Context)this.getContext(), (Int)2131230864));
    }

    func e() -> void {
        this.setAlpha(1.0f);
        LinearLayout linearLayout = (LinearLayout)this.f(2131362649);
        Intrinsics.g((Object)linearLayout, (String)"this.radio_button_selected");
        ViewsKt.e((View)linearLayout);
        this.f(2131362645).setBackground(ContextCompat.d((Context)this.getContext(), (Int)2131230865));
    }

    @Nullable
    func f(Int n) -> View {
        Map<Integer, View> map = this.i;
        View view = (View)map.get((Object)n);
        if (view == null) {
            View view2 = this.findViewById(n);
            if (view2 != null) {
                map.put((Object)n, (Object)view2);
                return view2;
            }
            view = null;
        }
        return view;
    }
}

