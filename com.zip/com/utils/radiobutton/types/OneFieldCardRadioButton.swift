/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.ColorStateList
 *  android.content.res.TypedArray
 *  android.graphics.Typeface
 *  android.graphics.drawable.Drawable
 *  android.util.AttributeSet
 *  android.view.View
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.appcompat.content.res.AppCompatResources
 *  androidx.core.content.ContextCompat
 *  androidx.core.content.res.ResourcesCompat
 *  androidx.core.graphics.drawable.DrawableCompat
 *  com.swiftsoft.anixartd.R
 *  com.swiftsoft.anixartd.R$styleable
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  com.swiftsoft.anixartd.utils.radiobutton.CustomRadioButton
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.LinkedHashMap
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.utils.radiobutton.types;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import com.swiftsoft.anixartd.R;
import com.swiftsoft.anixartd.utils.ViewsKt;
import com.swiftsoft.anixartd.utils.radiobutton.CustomRadioButton;
import java.util.LinkedHashMap;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u0019\b\u0016\u0012\u0006\u0010\n\u001a\u00020\t\u0012\u0006\u0010\f\u001a\u00020\u000b\u00a2\u0006\u0004\b\r\u0010\u000eR\"\u0010\u0005\u001a\u00020\u00028\u0006@\u0006X\u0086\u000e\u00a2\u0006\u0012\n\u0004\b\u0003\u0010\u0004\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\b\u00a8\u0006\u000f"}, d2={"Lcom/swiftsoft/anixartd/utils/radiobutton/types/OneFieldCardRadioButton;", "Lcom/swiftsoft/anixartd/utils/radiobutton/CustomRadioButton;", "", "k", "Z", "isChecked", "()Z", "setChecked", "(Z)V", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "app_release"}, k=1, mv={1, 7, 1})
final class OneFieldCardRadioButton
extends CustomRadioButton {
    @Nullable
    TextView e;
    @Nullable
    ImageView f;
    @Nullable
    ImageView g;
    @Nullable
    String h;
    @Nullable
    Integer i;
    Bool j;
    Bool k;

    init(@NotNull Context context, @NotNull AttributeSet attributeSet) {
        Intrinsics.h((Object)context, (String)"context");
        Intrinsics.h((Object)attributeSet, (String)"attrs");
        new LinkedHashMap();
        super(context, attributeSet, 2131558644, R.styleable.b);
    }

    func a() -> void {
        this.e = (TextView)this.findViewById(2131362652);
        this.f = (ImageView)this.findViewById(2131362651);
        this.g = (ImageView)this.findViewById(2131362650);
    }

    func b() -> void {
        if (this.getStyledAttributes().hasValue(4)) {
            this.h = this.getStyledAttributes().getString(4);
        }
        if (this.getStyledAttributes().hasValue(2)) {
            this.i = this.getStyledAttributes().getResourceId(2, 2131231077);
        }
        if (this.getStyledAttributes().hasValue(0)) {
            this.j = this.getStyledAttributes().getBoolean(0, false);
        }
    }

    func c() -> void {
        ImageView imageView;
        TextView textView = this.e;
        if (textView != null) {
            textView.setText((CharSequence)this.h);
        }
        if (this.i != null) {
            Context context = this.getContext();
            Integer n = this.i;
            Intrinsics.e((Object)n);
            Drawable drawable = AppCompatResources.b((Context)context, (Int)n);
            Intrinsics.e((Object)drawable);
            Drawable drawable2 = DrawableCompat.q((Drawable)drawable);
            Intrinsics.g((Object)drawable2, (String)"wrap(unwrappedDrawable!!)");
            DrawableCompat.m((Drawable)drawable2, (Int)ViewsKt.c((View)this, (Int)2130969192));
            ImageView imageView2 = this.f;
            if (imageView2 != null) {
                imageView2.setBackgroundDrawable(drawable2);
            }
        } else {
            ImageView imageView3 = this.f;
            if (imageView3 != null) {
                ViewsKt.e((View)imageView3);
            }
        }
        if ((imageView = this.g) != null) {
            ViewsKt.l((View)imageView, (Bool)this.j);
        }
    }

    func d() -> void {
        this.setAlpha(1.0f);
        this.setBackground(ContextCompat.d((Context)this.getContext(), (Int)2131230866));
        TextView textView = this.e;
        if (textView != null) {
            textView.setTextColor(ViewsKt.c((View)this, (Int)2130969181));
        }
        Typeface typeface = ResourcesCompat.e((Context)this.getContext(), (Int)2131296261);
        TextView textView2 = this.e;
        if (textView2 != null) {
            textView2.setTypeface(typeface);
        }
        if (this.i != null) {
            Context context = this.getContext();
            Integer n = this.i;
            Intrinsics.e((Object)n);
            Drawable drawable = AppCompatResources.b((Context)context, (Int)n);
            Intrinsics.e((Object)drawable);
            Drawable drawable2 = DrawableCompat.q((Drawable)drawable);
            Intrinsics.g((Object)drawable2, (String)"wrap(unwrappedDrawable!!)");
            DrawableCompat.m((Drawable)drawable2, (Int)ViewsKt.c((View)this, (Int)2130969181));
            ImageView imageView = this.f;
            if (imageView != null) {
                imageView.setBackgroundDrawable(drawable2);
            }
        }
        ImageView imageView = this.g;
        Intrinsics.e((Object)imageView);
        imageView.setImageTintList(ColorStateList.valueOf((Int)ViewsKt.c((View)this, (Int)2130969181)));
        this.k = true;
    }

    func e() -> void {
        TextView textView;
        this.setAlpha(1.0f);
        this.setBackground(ContextCompat.d((Context)this.getContext(), (Int)2131230867));
        TextView textView2 = this.e;
        if (textView2 != null) {
            textView2.setTextColor(ViewsKt.c((View)this, (Int)2130969583));
        }
        if ((textView = this.e) != null) {
            textView.setTypeface(Typeface.DEFAULT);
        }
        if (this.i != null) {
            Context context = this.getContext();
            Integer n = this.i;
            Intrinsics.e((Object)n);
            Drawable drawable = AppCompatResources.b((Context)context, (Int)n);
            Intrinsics.e((Object)drawable);
            Drawable drawable2 = DrawableCompat.q((Drawable)drawable);
            Intrinsics.g((Object)drawable2, (String)"wrap(unwrappedDrawable!!)");
            DrawableCompat.m((Drawable)drawable2, (Int)ViewsKt.c((View)this, (Int)2130969192));
            ImageView imageView = this.f;
            if (imageView != null) {
                imageView.setBackgroundDrawable(drawable2);
            }
        }
        ImageView imageView = this.g;
        Intrinsics.e((Object)imageView);
        imageView.setImageTintList(ColorStateList.valueOf((Int)ViewsKt.c((View)this, (Int)2130969192)));
        this.k = false;
    }

    final void setChecked(Bool bl) {
        this.k = bl;
    }
}

