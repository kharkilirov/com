/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.utils.OnEventIdentifiable
 *  java.lang.String
 *  kotlin.Metadata
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.utils;

import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.utils.OnEventIdentifiable;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"}, d2={"Lcom/swiftsoft/anixartd/utils/OnSearchRelease;", "Lcom/swiftsoft/anixartd/utils/OnEventIdentifiable;", "app_release"}, k=1, mv={1, 7, 1})
final class OnSearchRelease
extends OnEventIdentifiable {
    @NotNull
    final Release b;

    init(@Nullable String string, @NotNull Release release) {
        super(string);
        this.b = release;
    }
}

