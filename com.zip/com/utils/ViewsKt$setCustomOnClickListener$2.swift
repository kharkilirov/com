/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.swiftsoft.anixartd.ui.CustomClickListener
 *  kotlin.Metadata
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.utils;

import android.view.View;
import com.swiftsoft.anixartd.ui.CustomClickListener;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\b\n\u0000\n\u0002\u0018\u0002\n\u0000\b\n\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"}, d2={"com/swiftsoft/anixartd/utils/ViewsKt$setCustomOnClickListener$2", "Lcom/swiftsoft/anixartd/ui/CustomClickListener;", "app_release"}, k=1, mv={1, 7, 1})
final class ViewsKt$setCustomOnClickListener$2
extends CustomClickListener {
    func a(@NotNull View view) -> void {
        throw null;
    }
}

