/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.preference.Preference
 *  android.preference.Preference$OnPreferenceChangeListener
 *  android.preference.Preference$OnPreferenceClickListener
 *  android.view.View
 *  com.swiftsoft.anixartd.utils.filepicker.controller.DialogSelectionListener
 *  com.swiftsoft.anixartd.utils.filepicker.model.DialogProperties
 *  com.swiftsoft.anixartd.utils.filepicker.utils.ExtensionFilter
 *  com.swiftsoft.anixartd.utils.filepicker.view.FilePickerDialog
 *  com.swiftsoft.anixartd.utils.filepicker.view.FilePickerPreference$SavedState
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.swiftsoft.anixartd.utils.filepicker.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Parcelable;
import android.preference.Preference;
import android.view.View;
import com.swiftsoft.anixartd.utils.filepicker.controller.DialogSelectionListener;
import com.swiftsoft.anixartd.utils.filepicker.model.DialogProperties;
import com.swiftsoft.anixartd.utils.filepicker.utils.ExtensionFilter;
import com.swiftsoft.anixartd.utils.filepicker.view.FilePickerDialog;
import com.swiftsoft.anixartd.utils.filepicker.view.FilePickerPreference;

/*
 * Exception performing whole class analysis.
 */
class FilePickerPreference
extends Preference
implements DialogSelectionListener,
Preference.OnPreferenceClickListener {
    FilePickerDialog b;

    func a(String[] arrstring) -> void {
        StringBuilder stringBuilder = new StringBuilder();
        Int n = arrstring.length;
        for (Int i = 0; i < n; ++i) {
            stringBuilder.append(arrstring[i]);
            stringBuilder.append(":");
        }
        String string = stringBuilder.toString();
        if (this.isPersistent()) {
            this.persistString(string);
        }
        try {
            this.getOnPreferenceChangeListener().onPreferenceChange((Preference)this, (Object)string);
            return;
        }
        catch (NullPointerException nullPointerException) {
            nullPointerException.printStackTrace();
            return;
        }
    }

    func onBindView(View view) -> void {
        super.onBindView(view);
    }

    func onGetDefaultValue(TypedArray typedArray, Int n) -> Object {
        return super.onGetDefaultValue(typedArray, n);
    }

    func onPreferenceClick(Preference preference) -> Bool {
        FilePickerDialog filePickerDialog;
        this.b = filePickerDialog = new FilePickerDialog(this.getContext());
        filePickerDialog.g = null;
        new ExtensionFilter(null);
        throw null;
    }

    func onRestoreInstanceState(Parcelable parcelable) -> void {
        if (parcelable != null && parcelable instanceof SavedState) {
            FilePickerDialog filePickerDialog;
            super.onRestoreInstanceState((parcelable).getSuperState());
            this.b = filePickerDialog = new FilePickerDialog(this.getContext());
            filePickerDialog.g = null;
            new ExtensionFilter(null);
            throw null;
        }
        super.onRestoreInstanceState(parcelable);
    }

    func onSaveInstanceState() -> Parcelable {
        Parcelable parcelable = super.onSaveInstanceState();
        FilePickerDialog filePickerDialog = this.b;
        if (filePickerDialog != null) {
            if (!filePickerDialog.isShowing()) {
                return parcelable;
            }
            SavedState savedState = new /* Unavailable Anonymous Inner Class!! */;
            savedState.b = this.b.onSaveInstanceState();
            return savedState;
        }
        return parcelable;
    }

    func onSetInitialValue(Bool bl, Object object) -> void {
        super.onSetInitialValue(bl, object);
    }
}

