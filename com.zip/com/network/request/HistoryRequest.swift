/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.fasterxml.jackson.annotation.JsonProperty
 *  com.swiftsoft.anixartd.network.request.UserRequest
 *  kotlin.Metadata
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.network.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.swiftsoft.anixartd.network.request.UserRequest;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(d1={"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0006\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\t\u001a\u00020\u00002\u0006\u0010\u0003\u001a\u00020\u0004R\u001e\u0010\u0003\u001a\u00020\u00048\u0006@\u0006X\u0087\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\b\u00a8\u0006\n"}, d2={"Lcom/swiftsoft/anixartd/network/request/HistoryRequest;", "Lcom/swiftsoft/anixartd/network/request/UserRequest;", "()V", "episodeId", "", "getEpisodeId", "()J", "setEpisodeId", "(J)V", "fill", "app_release"}, k=1, mv={1, 7, 1}, xi=48)
final class HistoryRequest
extends UserRequest {
    @JsonProperty(value="episode_id")
    long episodeId;

    @NotNull
    final HistoryRequest fill(long l) {
        this.episodeId = l;
        return this;
    }

    final long getEpisodeId() {
        return this.episodeId;
    }

    final void setEpisodeId(long l) {
        this.episodeId = l;
    }
}

