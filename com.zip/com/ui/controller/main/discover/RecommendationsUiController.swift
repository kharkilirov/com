/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.epoxy.Carousel
 *  com.airbnb.epoxy.Carousel$Padding
 *  com.airbnb.epoxy.EpoxyControllerAdapter
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.Typed2EpoxyController
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.ui.controller.main.discover.RecommendationsUiController$Listener
 *  com.swiftsoft.anixartd.ui.model.main.discover.ReleaseCardModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.discover.ReleaseCardModel_
 *  com.swiftsoft.anixartd.ui.model.main.release.carousel.RecommendedCarouselModelBuilder
 *  java.lang.CharSequence
 *  java.lang.Double
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.BitSet
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.controller.main.discover;

import com.airbnb.epoxy.Carousel;
import com.airbnb.epoxy.EpoxyControllerAdapter;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.Typed2EpoxyController;
import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.ui.controller.main.discover.RecommendationsUiController;
import com.swiftsoft.anixartd.ui.model.main.discover.ReleaseCardModel;
import com.swiftsoft.anixartd.ui.model.main.discover.ReleaseCardModel_;
import com.swiftsoft.anixartd.ui.model.main.release.carousel.RecommendedCarouselModelBuilder;
import com.swiftsoft.anixartd.ui.model.main.release.carousel.RecommendedCarouselModel_;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(d1={"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\u0018\u00002\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00030\u0002\u0012\u0004\u0012\u00020\u00040\u0001:\u0001\fB\u0005\u00a2\u0006\u0002\u0010\u0005J\u001e\u0010\u0006\u001a\u00020\u00072\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00030\u00022\u0006\u0010\t\u001a\u00020\u0004H\u0014J\u0006\u0010\n\u001a\u00020\u000b\u00a8\u0006\r"}, d2={"Lcom/swiftsoft/anixartd/ui/controller/main/discover/RecommendationsUiController;", "Lcom/airbnb/epoxy/Typed2EpoxyController;", "", "Lcom/swiftsoft/anixartd/database/entity/Release;", "Lcom/swiftsoft/anixartd/ui/controller/main/discover/RecommendationsUiController$Listener;", "()V", "buildModels", "", "releases", "listener", "isEmpty", "", "Listener", "app_release"}, k=1, mv={1, 7, 1}, xi=48)
final class RecommendationsUiController
extends Typed2EpoxyController<List<? extends Release>, Listener> {
    init() {
        this.setDebugLoggingEnabled(true);
    }

    func buildModels(@NotNull List<Release> list, @NotNull Listener listener) -> void {
        Intrinsics.h(list, (String)"releases");
        Intrinsics.h((Object)listener, (String)"listener");
        RecommendedCarouselModel_ recommendedCarouselModel_ = new RecommendedCarouselModel_();
        recommendedCarouselModel_.h2((CharSequence)"carousel");
        recommendedCarouselModel_.s(Carousel.Padding.a((Int)16, (Int)8, (Int)16, (Int)0, (Int)16));
        ArrayList arrayList = new ArrayList(CollectionsKt.m(list, (Int)10));
        for (Release release : list) {
            ReleaseCardModel_ releaseCardModel_ = new ReleaseCardModel_();
            releaseCardModel_.w2(release.getId());
            String string = release.getTitleRu();
            releaseCardModel_.l2();
            releaseCardModel_.k = string;
            Integer n = release.getEpisodesReleased();
            releaseCardModel_.l2();
            releaseCardModel_.l = n;
            Integer n2 = release.getEpisodesTotal();
            releaseCardModel_.l2();
            releaseCardModel_.m = n2;
            Double d = release.getGrade();
            releaseCardModel_.l2();
            releaseCardModel_.n = d;
            String string2 = release.getDescription();
            releaseCardModel_.l2();
            releaseCardModel_.o = string2;
            String string3 = release.getImage();
            releaseCardModel_.l2();
            releaseCardModel_.p = string3;
            Bool bl = release.isFavorite();
            releaseCardModel_.l2();
            releaseCardModel_.q = bl;
            Int n3 = release.getProfileListStatus();
            releaseCardModel_.l2();
            releaseCardModel_.r = n3;
            Bool bl2 = release.getVoteCount() > 50;
            releaseCardModel_.l2();
            releaseCardModel_.s = bl2;
            releaseCardModel_.l2();
            releaseCardModel_.t = listener;
            arrayList.add((Object)releaseCardModel_);
        }
        recommendedCarouselModel_.k.set(6);
        recommendedCarouselModel_.l2();
        recommendedCarouselModel_.n = arrayList;
        this.add((EpoxyModel)recommendedCarouselModel_);
    }

    final Bool isEmpty() {
        return this.getAdapter().j == 0;
    }
}

