/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.epoxy.EpoxyControllerAdapter
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.Typed2EpoxyController
 *  com.swiftsoft.anixartd.database.entity.Interesting
 *  com.swiftsoft.anixartd.ui.controller.main.discover.InterestingUiController$Listener
 *  com.swiftsoft.anixartd.ui.model.main.discover.InterestingModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.discover.InterestingModelBuilder
 *  com.swiftsoft.anixartd.ui.model.main.discover.InterestingModel_
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.controller.main.discover;

import com.airbnb.epoxy.EpoxyControllerAdapter;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.Typed2EpoxyController;
import com.swiftsoft.anixartd.database.entity.Interesting;
import com.swiftsoft.anixartd.ui.controller.main.discover.InterestingUiController;
import com.swiftsoft.anixartd.ui.model.main.discover.InterestingModel;
import com.swiftsoft.anixartd.ui.model.main.discover.InterestingModelBuilder;
import com.swiftsoft.anixartd.ui.model.main.discover.InterestingModel_;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(d1={"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\u0018\u00002\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00030\u0002\u0012\u0004\u0012\u00020\u00040\u0001:\u0001\fB\u0005\u00a2\u0006\u0002\u0010\u0005J\u001e\u0010\u0006\u001a\u00020\u00072\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00030\u00022\u0006\u0010\t\u001a\u00020\u0004H\u0014J\u0006\u0010\n\u001a\u00020\u000b\u00a8\u0006\r"}, d2={"Lcom/swiftsoft/anixartd/ui/controller/main/discover/InterestingUiController;", "Lcom/airbnb/epoxy/Typed2EpoxyController;", "", "Lcom/swiftsoft/anixartd/database/entity/Interesting;", "Lcom/swiftsoft/anixartd/ui/controller/main/discover/InterestingUiController$Listener;", "()V", "buildModels", "", "interesting", "listener", "isEmpty", "", "Listener", "app_release"}, k=1, mv={1, 7, 1}, xi=48)
final class InterestingUiController
extends Typed2EpoxyController<List<? extends Interesting>, Listener> {
    init() {
        this.setDebugLoggingEnabled(true);
    }

    func buildModels(@NotNull List<Interesting> list, @NotNull Listener listener) -> void {
        Intrinsics.h(list, (String)"interesting");
        Intrinsics.h((Object)listener, (String)"listener");
        for (Interesting interesting : list) {
            InterestingModel_ interestingModel_ = new InterestingModel_();
            interestingModel_.b(interesting.getId());
            interestingModel_.j(interesting.getTitle());
            interestingModel_.g(interesting.getDescription());
            interestingModel_.c(interesting.getImage());
            interestingModel_.n1(interesting.getType());
            interestingModel_.r0(interesting.getAction());
            interestingModel_.R1(listener);
            this.add((EpoxyModel)interestingModel_);
        }
    }

    final Bool isEmpty() {
        return this.getAdapter().j == 0;
    }
}

