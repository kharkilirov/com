/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.epoxy.EpoxyControllerAdapter
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.Typed2EpoxyController
 *  com.swiftsoft.anixartd.database.entity.SuperMenu
 *  com.swiftsoft.anixartd.ui.controller.main.discover.SocialSuperMenuUiController$Listener
 *  com.swiftsoft.anixartd.ui.model.main.discover.SuperMenuModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.discover.SuperMenuModelBuilder
 *  com.swiftsoft.anixartd.ui.model.main.discover.SuperMenuModel_
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.controller.main.discover;

import com.airbnb.epoxy.EpoxyControllerAdapter;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.Typed2EpoxyController;
import com.swiftsoft.anixartd.database.entity.SuperMenu;
import com.swiftsoft.anixartd.ui.controller.main.discover.SocialSuperMenuUiController;
import com.swiftsoft.anixartd.ui.model.main.discover.SuperMenuModel;
import com.swiftsoft.anixartd.ui.model.main.discover.SuperMenuModelBuilder;
import com.swiftsoft.anixartd.ui.model.main.discover.SuperMenuModel_;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(d1={"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\u0018\u00002\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00030\u0002\u0012\u0004\u0012\u00020\u00040\u0001:\u0001\fB\u0005\u00a2\u0006\u0002\u0010\u0005J\u001e\u0010\u0006\u001a\u00020\u00072\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00030\u00022\u0006\u0010\t\u001a\u00020\u0004H\u0014J\u0006\u0010\n\u001a\u00020\u000b\u00a8\u0006\r"}, d2={"Lcom/swiftsoft/anixartd/ui/controller/main/discover/SocialSuperMenuUiController;", "Lcom/airbnb/epoxy/Typed2EpoxyController;", "", "Lcom/swiftsoft/anixartd/database/entity/SuperMenu;", "Lcom/swiftsoft/anixartd/ui/controller/main/discover/SocialSuperMenuUiController$Listener;", "()V", "buildModels", "", "releases", "listener", "isEmpty", "", "Listener", "app_release"}, k=1, mv={1, 7, 1}, xi=48)
final class SocialSuperMenuUiController
extends Typed2EpoxyController<List<? extends SuperMenu>, Listener> {
    init() {
        this.setDebugLoggingEnabled(true);
    }

    func buildModels(@NotNull List<SuperMenu> list, @NotNull Listener listener) -> void {
        Intrinsics.h(list, (String)"releases");
        Intrinsics.h((Object)listener, (String)"listener");
        for (SuperMenu superMenu : list) {
            SuperMenuModel_ superMenuModel_ = new SuperMenuModel_();
            superMenuModel_.u2(superMenu.getId());
            long l = superMenu.getId();
            superMenuModel_.l2();
            superMenuModel_.k = l;
            superMenuModel_.v2(superMenu.getTitle());
            Int n = superMenu.getColor();
            superMenuModel_.l2();
            superMenuModel_.m = n;
            Int n2 = superMenu.getBackgroundColor();
            superMenuModel_.l2();
            superMenuModel_.n = n2;
            Int n3 = superMenu.getIcon();
            superMenuModel_.l2();
            superMenuModel_.o = n3;
            Bool bl = superMenu.getNewDot();
            superMenuModel_.l2();
            superMenuModel_.p = bl;
            superMenuModel_.l2();
            superMenuModel_.q = listener;
            this.add((EpoxyModel)superMenuModel_);
        }
    }

    final Bool isEmpty() {
        return this.getAdapter().j == 0;
    }
}

