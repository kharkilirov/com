/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.widget.TextView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.model.common.SectionHeaderModel$Listener
 *  com.swiftsoft.anixartd.ui.model.common.SectionHeaderModel$bind
 *  com.swiftsoft.anixartd.ui.model.common.SectionHeaderModel$bind$3
 *  com.swiftsoft.anixartd.ui.model.common.SectionHeaderModel$bind$3$1
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.common;

import android.content.Context;
import android.view.View;
import android.widget.TextView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.model.common.SectionHeaderModel;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/common/SectionHeaderModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class SectionHeaderModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    Int k;
    @EpoxyAttribute
    @Nullable
    String l = "";
    @EpoxyAttribute
    @NotNull
    String m = "";
    @EpoxyAttribute
    Bool n;
    @EpoxyAttribute
    @Nullable
    Integer o = 0;
    @EpoxyAttribute
    Listener p;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        if (this.k != 0) {
            ((TextView)view.findViewById(2131363064)).setText((CharSequence)context.getString(this.k));
        }
        String string = this.l;
        Bool bl = true;
        Bool bl2 = string == null || string.length() == 0;
        if (!bl2) {
            ((TextView)view.findViewById(2131363064)).setText((CharSequence)this.l);
        }
        TextView textView = (TextView)view.findViewById(2131363040);
        Intrinsics.g((Object)textView, (String)"bind$lambda$1");
        if (this.m.length() <= 0) {
            bl = false;
        }
        ViewsKt.l((View)textView, (Bool)bl);
        textView.setText((CharSequence)this.m);
        TextView textView2 = (TextView)view.findViewById(2131361956);
        Intrinsics.g((Object)textView2, (String)"bind$lambda$2");
        ViewsKt.l((View)textView2, (Bool)this.n);
        ViewsKt.j((View)textView2, (Function1)new bind.3.1(this));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof SectionHeaderModel) {
            Int n = this.k;
            SectionHeaderModel sectionHeaderModel = (SectionHeaderModel)epoxyModel;
            if (n != sectionHeaderModel.k) {
                arrayList.add((Object)0);
            }
            if (!Intrinsics.c((Object)this.l, (Object)sectionHeaderModel.l)) {
                arrayList.add((Object)1);
            }
            if (!Intrinsics.c((Object)this.m, (Object)sectionHeaderModel.m)) {
                arrayList.add((Object)2);
            }
            if (this.n != sectionHeaderModel.n) {
                arrayList.add((Object)3);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        Context context = a.b((View)view, (String)"view", list, (String)"payloads");
        if (list.contains((Object)0) && this.k != 0) {
            ((TextView)view.findViewById(2131363064)).setText((CharSequence)context.getString(this.k));
        }
        if (list.contains((Object)1)) {
            String string = this.l;
            Bool bl = string == null || string.length() == 0;
            if (!bl) {
                ((TextView)view.findViewById(2131363064)).setText((CharSequence)this.l);
            }
        }
        if (list.contains((Object)2)) {
            TextView textView = (TextView)view.findViewById(2131363040);
            Intrinsics.g((Object)textView, (String)"bind$lambda$0");
            Int n = this.m.length();
            Bool bl = false;
            if (n > 0) {
                bl = true;
            }
            ViewsKt.l((View)textView, (Bool)bl);
            textView.setText((CharSequence)this.m);
        }
        if (list.contains((Object)3)) {
            TextView textView = (TextView)view.findViewById(2131361956);
            Intrinsics.g((Object)textView, (String)"view.btn");
            ViewsKt.l((View)textView, (Bool)this.n);
        }
    }
}

