/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.widget.TextView
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package com.swiftsoft.anixartd.ui.model.common;

import android.content.Context;
import android.view.View;
import android.widget.TextView;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv={}, d1={"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001\u00a8\u0006\u0003"}, d2={"Lcom/swiftsoft/anixartd/ui/model/common/ListCountModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class ListCountModel
extends EpoxyModel<View> {
    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        TextView textView = (TextView)view.findViewById(2131362075);
        String string = context.getString(2131951683);
        Intrinsics.g((Object)string, (String)"context.getString(R.string.bookmarks_count)");
        Object[] arrobject = new Object[]{0L};
        a.y((Object[])arrobject, (Int)1, (String)string, (String)"format(format, *args)", (TextView)textView);
    }
}

