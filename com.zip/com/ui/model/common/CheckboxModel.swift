/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.widget.CompoundButton
 *  android.widget.CompoundButton$OnCheckedChangeListener
 *  androidx.appcompat.widget.AppCompatCheckBox
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.model.common.CheckboxModel$Listener
 *  com.swiftsoft.anixartd.ui.model.common.a
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.model.common;

import android.view.View;
import android.widget.CompoundButton;
import androidx.appcompat.widget.AppCompatCheckBox;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.swiftsoft.anixartd.ui.model.common.CheckboxModel;
import com.swiftsoft.anixartd.ui.model.common.a;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/common/CheckboxModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class CheckboxModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    String k;
    @EpoxyAttribute
    Int l;
    @EpoxyAttribute
    Bool m;
    @EpoxyAttribute
    Listener n;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        AppCompatCheckBox appCompatCheckBox = (AppCompatCheckBox)view.findViewById(2131362020);
        appCompatCheckBox.setText((CharSequence)this.v2());
        appCompatCheckBox.setChecked(this.m);
        appCompatCheckBox.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new a(this, 1));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = com.google.protobuf.a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof CheckboxModel) {
            CheckboxModel checkboxModel;
            String string = this.v2();
            if (!Intrinsics.c((Object)string, (Object)(checkboxModel = (CheckboxModel)epoxyModel).v2())) {
                arrayList.add((Object)0);
            }
            if (this.m != checkboxModel.m) {
                arrayList.add((Object)1);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        if (com.google.protobuf.a.z((View)view, (String)"view", list, (String)"payloads", (Int)0)) {
            ((AppCompatCheckBox)view.findViewById(2131362020)).setText((CharSequence)this.v2());
        }
        if (list.contains((Object)1)) {
            AppCompatCheckBox appCompatCheckBox = (AppCompatCheckBox)view.findViewById(2131362020);
            appCompatCheckBox.setOnCheckedChangeListener(null);
            appCompatCheckBox.setChecked(this.m);
            appCompatCheckBox.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new a(this, 0));
        }
    }

    @NotNull
    final String v2() {
        String string = this.k;
        if (string != null) {
            return string;
        }
        Intrinsics.r((String)"title");
        throw null;
    }

    func w2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        ((AppCompatCheckBox)view.findViewById(2131362020)).setOnCheckedChangeListener(null);
    }
}

