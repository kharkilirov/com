/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  androidx.appcompat.widget.AppCompatButton
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModel$SpanSizeOverrideCallback
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.swiftsoft.anixartd.ui.model.common.ErrorModel$Listener
 *  com.swiftsoft.anixartd.ui.model.common.ErrorModel$bind
 *  com.swiftsoft.anixartd.ui.model.common.ErrorModel$bind$1
 *  com.swiftsoft.anixartd.ui.model.common.ErrorModel_
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  j.a
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 */
package com.swiftsoft.anixartd.ui.model.common;

import android.view.View;
import androidx.appcompat.widget.AppCompatButton;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.swiftsoft.anixartd.ui.model.common.ErrorModel;
import com.swiftsoft.anixartd.ui.model.common.ErrorModel_;
import com.swiftsoft.anixartd.utils.ViewsKt;
import j.a;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u0003\u00a8\u0006\u0004"}, d2={"Lcom/swiftsoft/anixartd/ui/model/common/ErrorModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class ErrorModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    Listener k;

    init() {
        a a2 = a.t;
        ((ErrorModel_)this).i = a2;
    }

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        AppCompatButton appCompatButton = (AppCompatButton)view.findViewById(2131362720);
        Intrinsics.g((Object)appCompatButton, (String)"view.repeat");
        ViewsKt.j((View)appCompatButton, (Function1)new bind.1(this));
    }
}

