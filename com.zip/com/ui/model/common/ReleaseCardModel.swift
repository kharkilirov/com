/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a.a
 *  android.content.Context
 *  android.view.View
 *  android.view.View$OnLongClickListener
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.fragment.main.profile.d
 *  com.swiftsoft.anixartd.ui.model.common.ReleaseCardModel$bind
 *  com.swiftsoft.anixartd.ui.model.common.ReleaseCardModel$bind$2
 *  com.swiftsoft.anixartd.ui.model.common.ReleaseModel$Listener
 *  com.swiftsoft.anixartd.utils.DigitsKt
 *  com.swiftsoft.anixartd.utils.Time
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Double
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.common;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.fragment.main.profile.d;
import com.swiftsoft.anixartd.ui.model.common.ReleaseCardModel;
import com.swiftsoft.anixartd.ui.model.common.ReleaseModel;
import com.swiftsoft.anixartd.utils.DigitsKt;
import com.swiftsoft.anixartd.utils.Time;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u0003\u00a8\u0006\u0004"}, d2={"Lcom/swiftsoft/anixartd/ui/model/common/ReleaseCardModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class ReleaseCardModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    @Nullable
    String k = "";
    @EpoxyAttribute
    @Nullable
    Integer l;
    @EpoxyAttribute
    @Nullable
    Integer m;
    @EpoxyAttribute
    @Nullable
    Double n;
    @EpoxyAttribute
    @Nullable
    String o;
    @EpoxyAttribute
    @Nullable
    String p;
    @EpoxyAttribute
    @Nullable
    String q;
    @EpoxyAttribute
    Int r;
    @EpoxyAttribute
    long s;
    @EpoxyAttribute
    @Nullable
    Long t;
    @EpoxyAttribute
    Bool u;
    @EpoxyAttribute
    Int v;
    @EpoxyAttribute
    Bool w;
    @EpoxyAttribute
    ReleaseModel.Listener x;

    init() {
        Integer n;
        this.l = n = Integer.valueOf((Int)0);
        this.m = n;
        this.n = 0.0;
        this.o = "";
        this.p = "";
        this.q = "";
        this.t = 0L;
    }

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        String string = this.k;
        Integer n = this.l;
        Integer n2 = this.m;
        Double d2 = this.n;
        Long l = this.t;
        Int n3 = this.r;
        String string2 = this.q;
        Bool bl = this.u;
        Int n4 = this.v;
        if (l != null && l == 3L && this.s != 0L) {
            ((TextView)view.findViewById(2131362200)).setText((CharSequence)Time.a.b(this.s, "d MMM yyyy \u0433."));
        } else if (l != null && l == 3L) {
            Bool bl2;
            Bool bl3 = 1 <= n3 && n3 < 5;
            String string3 = "";
            if (bl3) {
                String string4 = n3 != 1 ? (n3 != 2 ? (n3 != 3 ? (n3 != 4 ? string3 : "\u043e\u0441\u0435\u043d\u044c") : "\u043b\u0435\u0442\u043e") : "\u0432\u0435\u0441\u043d\u0430") : "\u0437\u0438\u043c\u0430";
                string3 = a.a.l((String)string3, (String)string4, (char)' ');
            }
            Bool bl4 = string2 == null || string2.length() == 0;
            if (!bl4) {
                string3 = a.a.m((String)string3, (String)string2, (String)" \u0433.");
            }
            if (bl2 = string3.length() > 0) {
                ((TextView)view.findViewById(2131362200)).setText((CharSequence)string3);
            } else {
                ((TextView)view.findViewById(2131362200)).setText((CharSequence)context.getString(2131951741));
            }
        }
        ImageView imageView = (ImageView)view.findViewById(2131362281);
        Int n5 = bl ? 0 : 8;
        imageView.setVisibility(n5);
        if (n4 != 0) {
            RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362918);
            Intrinsics.g((Object)relativeLayout, (String)"view.status_layout");
            ViewsKt.m((View)relativeLayout, (Bool)true);
            if (n4 != 1) {
                if (n4 != 2) {
                    if (n4 != 3) {
                        if (n4 != 4) {
                            if (n4 == 5) {
                                ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0431\u0440\u043e\u0448\u0435\u043d\u043e");
                                a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131100607, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                            }
                        } else {
                            ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u043e\u0442\u043b\u043e\u0436\u0435\u043d\u043e");
                            a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131100687, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                        }
                    } else {
                        ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u043f\u0440\u043e\u0441\u043c\u043e\u0442\u0440\u0435\u043d\u043e");
                        a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131099691, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                    }
                } else {
                    ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0432 \u043f\u043b\u0430\u043d\u0430\u0445");
                    a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131100604, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                }
            } else {
                ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0441\u043c\u043e\u0442\u0440\u044e");
                a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131099809, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
            }
        } else {
            RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362918);
            Intrinsics.g((Object)relativeLayout, (String)"view.status_layout");
            ViewsKt.m((View)relativeLayout, (Bool)false);
        }
        Bool bl5 = string == null || string.length() == 0;
        if (bl5) {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)"\u0411\u0435\u0437 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u044f");
        } else {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)string);
        }
        if (l == null || l != 3L) {
            if (n != null && n2 != null && Intrinsics.c((Object)n, (Object)n2)) {
                TextView textView = (TextView)a.g((Integer)n2, (String)" \u044d\u043f", (TextView)((TextView)view.findViewById(2131362200)), (View)view, (Int)2131362200);
                TextView textView2 = (TextView)a.C((TextView)textView, (String)"view.episodes", (TextView)textView, (View)view, (Int)2131362164);
                Intrinsics.g((Object)textView2, (String)"view.dot");
                ViewsKt.k((View)textView2);
            } else if (n != null && n2 != null) {
                a.t((Integer)n, (String)" \u0438\u0437 ", (Integer)n2, (String)" \u044d\u043f", (TextView)((TextView)view.findViewById(2131362200)));
                TextView textView = (TextView)view.findViewById(2131362200);
                TextView textView3 = (TextView)a.C((TextView)textView, (String)"view.episodes", (TextView)textView, (View)view, (Int)2131362164);
                Intrinsics.g((Object)textView3, (String)"view.dot");
                ViewsKt.k((View)textView3);
            } else if (n != null && n2 == null) {
                TextView textView = (TextView)a.g((Integer)n, (String)" \u0438\u0437 ? \u044d\u043f", (TextView)((TextView)view.findViewById(2131362200)), (View)view, (Int)2131362200);
                TextView textView4 = (TextView)a.C((TextView)textView, (String)"view.episodes", (TextView)textView, (View)view, (Int)2131362164);
                Intrinsics.g((Object)textView4, (String)"view.dot");
                ViewsKt.k((View)textView4);
            } else if (n == null && n2 != null) {
                a.u((String)"? \u0438\u0437 ", (Integer)n2, (String)" \u044d\u043f", (TextView)((TextView)view.findViewById(2131362200)));
                TextView textView = (TextView)view.findViewById(2131362200);
                TextView textView5 = (TextView)a.C((TextView)textView, (String)"view.episodes", (TextView)textView, (View)view, (Int)2131362164);
                Intrinsics.g((Object)textView5, (String)"view.dot");
                ViewsKt.k((View)textView5);
            } else {
                TextView textView = (TextView)view.findViewById(2131362200);
                TextView textView6 = (TextView)a.f((TextView)textView, (String)"view.episodes", (TextView)textView, (View)view, (Int)2131362164);
                Intrinsics.g((Object)textView6, (String)"view.dot");
                ViewsKt.e((View)textView6);
            }
        }
        LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362662);
        Intrinsics.g((Object)linearLayout, (String)"view.rating_layout");
        Bool bl6 = this.w && (l == null || l != 3L);
        ViewsKt.l((View)linearLayout, (Bool)bl6);
        if (d2 != null) {
            a.s((Double)d2, (Int)0, (Int)1, (TextView)((TextView)view.findViewById(2131362324)));
        }
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362613);
        Intrinsics.g((Object)appCompatImageView, (String)"view.poster");
        ViewsKt.h((ImageView)appCompatImageView, (String)this.p);
        ViewsKt.j((View)view, (Function1)new bind.2(this));
        view.setOnLongClickListener((View.OnLongClickListener)new d((Object)this, 1));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof ReleaseCardModel) {
            String string = this.k;
            ReleaseCardModel releaseCardModel = (ReleaseCardModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)releaseCardModel.k)) {
                arrayList.add((Object)0);
            }
            if (!Intrinsics.c((Object)this.l, (Object)releaseCardModel.l)) {
                arrayList.add((Object)1);
            }
            if (!Intrinsics.c((Object)this.m, (Object)releaseCardModel.m)) {
                arrayList.add((Object)2);
            }
            if (!Intrinsics.a((Double)this.n, (Double)releaseCardModel.n)) {
                arrayList.add((Object)3);
            }
            if (!Intrinsics.c((Object)this.o, (Object)releaseCardModel.o)) {
                arrayList.add((Object)4);
            }
            if (!Intrinsics.c((Object)this.p, (Object)releaseCardModel.p)) {
                arrayList.add((Object)5);
            }
            if (!Intrinsics.c((Object)this.q, (Object)releaseCardModel.q)) {
                arrayList.add((Object)6);
            }
            if (this.r != releaseCardModel.r) {
                arrayList.add((Object)7);
            }
            if (!Intrinsics.c((Object)this.t, (Object)releaseCardModel.t)) {
                arrayList.add((Object)8);
            }
            if (this.u != releaseCardModel.u) {
                arrayList.add((Object)9);
            }
            if (this.v != releaseCardModel.v) {
                arrayList.add((Object)10);
            }
            if (this.w != releaseCardModel.w) {
                arrayList.add((Object)11);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        block37 : {
            Long l;
            String string;
            Context context;
            String string2;
            block39 : {
                block38 : {
                    Double d2;
                    context = a.b((View)view, (String)"view", list, (String)"payloads");
                    if (list.contains((Object)0)) {
                        ((TextView)view.findViewById(2131363004)).setText((CharSequence)this.k);
                    }
                    if (list.contains((Object)1)) {
                        TextView textView = (TextView)view.findViewById(2131362200);
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append((Object)this.l);
                        stringBuilder.append(" \u0438\u0437 ");
                        a.w((StringBuilder)stringBuilder, (Integer)this.m, (TextView)textView);
                    }
                    if (list.contains((Object)2)) {
                        TextView textView = (TextView)view.findViewById(2131362200);
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append((Object)this.l);
                        stringBuilder.append(" \u0438\u0437 ");
                        a.w((StringBuilder)stringBuilder, (Integer)this.m, (TextView)textView);
                    }
                    if (list.contains((Object)3) && (d2 = this.n) != null) {
                        Double d3 = d2;
                        ((TextView)view.findViewById(2131362324)).setText((CharSequence)DigitsKt.d((Double)d3, (Int)0, (Int)1));
                    }
                    if (list.contains((Object)5)) {
                        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362613);
                        Intrinsics.g((Object)appCompatImageView, (String)"view.poster");
                        ViewsKt.h((ImageView)appCompatImageView, (String)this.p);
                    }
                    if (list.contains((Object)9)) {
                        ImageView imageView = (ImageView)view.findViewById(2131362281);
                        Int n = this.u ? 0 : 8;
                        imageView.setVisibility(n);
                    }
                    if (list.contains((Object)10)) {
                        if (this.v != 0) {
                            RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362918);
                            Intrinsics.g((Object)relativeLayout, (String)"view.status_layout");
                            ViewsKt.m((View)relativeLayout, (Bool)true);
                            Int n = this.v;
                            if (n != 1) {
                                if (n != 2) {
                                    if (n != 3) {
                                        if (n != 4) {
                                            if (n == 5) {
                                                ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0431\u0440\u043e\u0448\u0435\u043d\u043e");
                                                a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131100607, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                                            }
                                        } else {
                                            ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u043e\u0442\u043b\u043e\u0436\u0435\u043d\u043e");
                                            a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131100687, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                                        }
                                    } else {
                                        ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u043f\u0440\u043e\u0441\u043c\u043e\u0442\u0440\u0435\u043d\u043e");
                                        a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131099691, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                                    }
                                } else {
                                    ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0432 \u043f\u043b\u0430\u043d\u0430\u0445");
                                    a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131100604, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                                }
                            } else {
                                ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0441\u043c\u043e\u0442\u0440\u044e");
                                a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131099809, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                            }
                        } else {
                            RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362918);
                            Intrinsics.g((Object)relativeLayout, (String)"view.status_layout");
                            ViewsKt.m((View)relativeLayout, (Bool)false);
                        }
                    }
                    Bool bl = list.contains((Object)6);
                    string = "\u043e\u0441\u0435\u043d\u044c";
                    if (bl || list.contains((Object)7)) {
                        String string3;
                        Bool bl2;
                        Int n = this.r;
                        Bool bl3 = 1 <= n && n < 5;
                        if (bl3) {
                            String string4 = n != 1 ? (n != 2 ? (n != 3 ? (n != 4 ? "" : string) : "\u043b\u0435\u0442\u043e") : "\u0432\u0435\u0441\u043d\u0430") : "\u0437\u0438\u043c\u0430";
                            string3 = a.a.l((String)"", (String)string4, (char)' ');
                        } else {
                            string3 = "";
                        }
                        String string5 = this.q;
                        Bool bl4 = string5 == null || string5.length() == 0;
                        if (!bl4) {
                            string3 = a.a.q((StringBuilder)a.a.u((String)string3), (String)this.q, (String)" \u0433.");
                        }
                        if (bl2 = string3.length() > 0) {
                            ((TextView)view.findViewById(2131362200)).setText((CharSequence)string3);
                        }
                    }
                    if (!list.contains((Object)8)) break block37;
                    Long l2 = this.t;
                    if (l2 == null || l2 != 3L) break block38;
                    string2 = "";
                    if (this.s == 0L) break block39;
                    ((TextView)view.findViewById(2131362200)).setText((CharSequence)Time.a.b(this.s, "d MMM yyyy \u0433."));
                    break block37;
                }
                string2 = "";
            }
            if ((l = this.t) != null && l == 3L) {
                String string6;
                Bool bl;
                Int n = this.r;
                Bool bl5 = 1 <= n && n < 5;
                if (bl5) {
                    if (n != 1) {
                        if (n != 2) {
                            if (n != 3) {
                                if (n != 4) {
                                    string = string2;
                                }
                            } else {
                                string = "\u043b\u0435\u0442\u043e";
                            }
                        } else {
                            string = "\u0432\u0435\u0441\u043d\u0430";
                        }
                    } else {
                        string = "\u0437\u0438\u043c\u0430";
                    }
                    string6 = a.a.l((String)string2, (String)string, (char)' ');
                } else {
                    string6 = string2;
                }
                String string7 = this.q;
                Bool bl6 = string7 == null || string7.length() == 0;
                if (!bl6) {
                    string6 = a.a.q((StringBuilder)a.a.u((String)string6), (String)this.q, (String)" \u0433.");
                }
                if (bl = string6.length() > 0) {
                    ((TextView)view.findViewById(2131362200)).setText((CharSequence)string6);
                } else {
                    ((TextView)view.findViewById(2131362200)).setText((CharSequence)context.getString(2131951741));
                }
            }
        }
        if (list.contains((Object)11)) {
            Long l;
            LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362662);
            Intrinsics.g((Object)linearLayout, (String)"view.rating_layout");
            Bool bl = this.w && ((l = this.t) == null || l != 3L);
            ViewsKt.l((View)linearLayout, (Bool)bl);
        }
    }

    func v2(@NotNull View view) -> void {
        a.p((View)view, (String)"view", null, null);
    }
}

