/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a.a
 *  android.content.Context
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnLongClickListener
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.fragment.main.profile.d
 *  com.swiftsoft.anixartd.ui.model.common.ReleaseModel$Listener
 *  com.swiftsoft.anixartd.ui.model.common.ReleaseModel$bind
 *  com.swiftsoft.anixartd.ui.model.common.ReleaseModel$bind$2
 *  com.swiftsoft.anixartd.ui.model.common.ReleaseModel$bind$4
 *  com.swiftsoft.anixartd.utils.DigitsKt
 *  com.swiftsoft.anixartd.utils.Time
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Double
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.common;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.fragment.main.profile.d;
import com.swiftsoft.anixartd.ui.model.common.ReleaseModel;
import com.swiftsoft.anixartd.utils.DigitsKt;
import com.swiftsoft.anixartd.utils.Time;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/common/ReleaseModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class ReleaseModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    @Nullable
    String k = "";
    @EpoxyAttribute
    @Nullable
    Integer l;
    @EpoxyAttribute
    @Nullable
    Integer m;
    @EpoxyAttribute
    @Nullable
    Double n;
    @EpoxyAttribute
    @Nullable
    String o;
    @EpoxyAttribute
    @Nullable
    String p;
    @EpoxyAttribute
    @Nullable
    String q;
    @EpoxyAttribute
    Int r;
    @EpoxyAttribute
    long s;
    @EpoxyAttribute
    @Nullable
    Long t;
    @EpoxyAttribute
    Bool u;
    @EpoxyAttribute
    Int v;
    @EpoxyAttribute
    Bool w;
    @EpoxyAttribute
    Listener x;

    init() {
        Integer n;
        this.l = n = Integer.valueOf((Int)0);
        this.m = n;
        this.n = 0.0;
        this.o = "";
        this.p = "";
        this.q = "";
        this.t = 0L;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    func Z1(Object var1_1) -> void {
        block36 : {
            block35 : {
                block34 : {
                    block33 : {
                        block32 : {
                            var2_2 = (View)var1_1;
                            Intrinsics.h((Object)var2_2, (String)"view");
                            var3_3 = var2_2.getContext();
                            var4_4 = this.k;
                            var5_5 = this.l;
                            var6_6 = this.m;
                            var7_7 = this.n;
                            var8_8 = this.t;
                            var9_9 = this.r;
                            var10_10 = this.q;
                            var11_11 = this.o;
                            var12_12 = this.u;
                            var13_13 = this.v;
                            var14_14 = (ImageView)var2_2.findViewById(2131362281);
                            var15_15 = var12_12 != false ? 0 : 8;
                            var14_14.setVisibility(var15_15);
                            if (var8_8 == null || var8_8 != 3L) break block32;
                            var16_16 = var6_6;
                            var17_17 = var7_7;
                            if (this.s == 0L) break block33;
                            ((TextView)var2_2.findViewById(2131362123)).setMaxLines(3);
                            var52_18 = (TextView)var2_2.findViewById(2131361897);
                            var53_19 = (TextView)a.C((TextView)var52_18, (String)"view.announcement", (TextView)var52_18, (View)var2_2, (Int)2131362699);
                            ((TextView)a.C((TextView)var53_19, (String)"view.release_status", (TextView)var53_19, (View)var2_2, (Int)2131362699)).setText((CharSequence)"\u0410\u043d\u043e\u043d\u0441");
                            ((TextView)var2_2.findViewById(2131361897)).setText((CharSequence)Time.a.b(this.s, "d MMM yyyy \u0433."));
                            break block34;
                        }
                        var16_16 = var6_6;
                        var17_17 = var7_7;
                    }
                    if (var8_8 != null && var8_8 == 3L) {
                        ((TextView)var2_2.findViewById(2131362123)).setMaxLines(3);
                        var45_20 = (TextView)var2_2.findViewById(2131361897);
                        var46_21 = (TextView)a.C((TextView)var45_20, (String)"view.announcement", (TextView)var45_20, (View)var2_2, (Int)2131362699);
                        ((TextView)a.C((TextView)var46_21, (String)"view.release_status", (TextView)var46_21, (View)var2_2, (Int)2131362699)).setText((CharSequence)"\u0410\u043d\u043e\u043d\u0441");
                        var47_22 = 1 <= var9_9 && var9_9 < 5;
                        var48_23 = "";
                        if (var47_22) {
                            var51_24 = var9_9 != 1 ? (var9_9 != 2 ? (var9_9 != 3 ? (var9_9 != 4 ? var48_23 : "\u043e\u0441\u0435\u043d\u044c") : "\u043b\u0435\u0442\u043e") : "\u0432\u0435\u0441\u043d\u0430") : "\u0437\u0438\u043c\u0430";
                            var48_23 = a.a.l((String)var48_23, (String)var51_24, (char)' ');
                        }
                        var49_25 = var10_10 == null || var10_10.length() == 0;
                        if (!var49_25) {
                            var48_23 = a.a.m((String)var48_23, (String)var10_10, (String)" \u0433.");
                        }
                        if (var50_26 = var48_23.length() > 0) {
                            ((TextView)var2_2.findViewById(2131361897)).setText((CharSequence)var48_23);
                        } else {
                            ((TextView)var2_2.findViewById(2131361897)).setText((CharSequence)var3_3.getString(2131951741));
                        }
                    } else {
                        ((TextView)var2_2.findViewById(2131362123)).setMaxLines(4);
                        var18_27 = (TextView)var2_2.findViewById(2131362123);
                        var19_28 = (TextView)a.C((TextView)var18_27, (String)"view.description", (TextView)var18_27, (View)var2_2, (Int)2131361897);
                        var20_29 = (TextView)a.f((TextView)var19_28, (String)"view.announcement", (TextView)var19_28, (View)var2_2, (Int)2131362699);
                        Intrinsics.g((Object)var20_29, (String)"view.release_status");
                        ViewsKt.e((View)var20_29);
                    }
                }
                if (var13_13 != 0) {
                    var44_30 = (RelativeLayout)var2_2.findViewById(2131362918);
                    Intrinsics.g((Object)var44_30, (String)"view.status_layout");
                    ViewsKt.m((View)var44_30, (Bool)true);
                    if (var13_13 != 1) {
                        if (var13_13 != 2) {
                            if (var13_13 != 3) {
                                if (var13_13 != 4) {
                                    if (var13_13 == 5) {
                                        ((TextView)var2_2.findViewById(2131362909)).setText((CharSequence)"\u0431\u0440\u043e\u0448\u0435\u043d\u043e");
                                        a.n((View)var2_2, (Int)2131100657, (TextView)((TextView)a.d((View)var2_2, (Int)2131100607, (RelativeLayout)((RelativeLayout)var2_2.findViewById(2131362918)), (Int)2131362909)));
                                    }
                                } else {
                                    ((TextView)var2_2.findViewById(2131362909)).setText((CharSequence)"\u043e\u0442\u043b\u043e\u0436\u0435\u043d\u043e");
                                    a.n((View)var2_2, (Int)2131100657, (TextView)((TextView)a.d((View)var2_2, (Int)2131100687, (RelativeLayout)((RelativeLayout)var2_2.findViewById(2131362918)), (Int)2131362909)));
                                }
                            } else {
                                ((TextView)var2_2.findViewById(2131362909)).setText((CharSequence)"\u043f\u0440\u043e\u0441\u043c\u043e\u0442\u0440\u0435\u043d\u043e");
                                a.n((View)var2_2, (Int)2131100657, (TextView)((TextView)a.d((View)var2_2, (Int)2131099691, (RelativeLayout)((RelativeLayout)var2_2.findViewById(2131362918)), (Int)2131362909)));
                            }
                        } else {
                            ((TextView)var2_2.findViewById(2131362909)).setText((CharSequence)"\u0432 \u043f\u043b\u0430\u043d\u0430\u0445");
                            a.n((View)var2_2, (Int)2131100657, (TextView)((TextView)a.d((View)var2_2, (Int)2131100604, (RelativeLayout)((RelativeLayout)var2_2.findViewById(2131362918)), (Int)2131362909)));
                        }
                    } else {
                        ((TextView)var2_2.findViewById(2131362909)).setText((CharSequence)"\u0441\u043c\u043e\u0442\u0440\u044e");
                        a.n((View)var2_2, (Int)2131100657, (TextView)((TextView)a.d((View)var2_2, (Int)2131099809, (RelativeLayout)((RelativeLayout)var2_2.findViewById(2131362918)), (Int)2131362909)));
                    }
                } else {
                    var21_31 = (RelativeLayout)var2_2.findViewById(2131362918);
                    Intrinsics.g((Object)var21_31, (String)"view.status_layout");
                    ViewsKt.m((View)var21_31, (Bool)false);
                }
                var22_32 = var4_4 == null || var4_4.length() == 0;
                if (var22_32) {
                    ((TextView)var2_2.findViewById(2131363004)).setText((CharSequence)"\u0411\u0435\u0437 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u044f");
                } else {
                    ((TextView)var2_2.findViewById(2131363004)).setText((CharSequence)var4_4);
                }
                if (var5_5 == null || var16_16 == null) break block35;
                var23_33 = var16_16;
                if (Intrinsics.c((Object)var5_5, (Object)var23_33)) ** GOTO lbl-1000
                break block36;
            }
            var23_33 = var16_16;
        }
        if (var8_8 != null && var8_8 == 3L) lbl-1000: // 2 sources:
        {
            var37_34 = (TextView)var2_2.findViewById(2131362200);
            if (var23_33 != null) {
                var38_35 = new StringBuilder();
                var38_35.append((Object)var23_33);
                var38_35.append(" \u044d\u043f");
                var41_36 = var38_35.toString();
            } else {
                var41_36 = "? \u044d\u043f";
            }
            var37_34.setText((CharSequence)var41_36);
            var42_37 = (TextView)var2_2.findViewById(2131362200);
            var43_38 = (TextView)a.C((TextView)var42_37, (String)"view.episodes", (TextView)var42_37, (View)var2_2, (Int)2131362164);
            Intrinsics.g((Object)var43_38, (String)"view.dot");
            ViewsKt.k((View)var43_38);
        } else if (var5_5 != null && var23_33 != null) {
            a.t((Integer)var5_5, (String)" \u0438\u0437 ", (Integer)var23_33, (String)" \u044d\u043f", (TextView)((TextView)var2_2.findViewById(2131362200)));
            var35_39 = (TextView)var2_2.findViewById(2131362200);
            var36_40 = (TextView)a.C((TextView)var35_39, (String)"view.episodes", (TextView)var35_39, (View)var2_2, (Int)2131362164);
            Intrinsics.g((Object)var36_40, (String)"view.dot");
            ViewsKt.k((View)var36_40);
        } else if (var5_5 != null && var23_33 == null) {
            var33_41 = (TextView)a.g((Integer)var5_5, (String)" \u0438\u0437 ? \u044d\u043f", (TextView)((TextView)var2_2.findViewById(2131362200)), (View)var2_2, (Int)2131362200);
            var34_42 = (TextView)a.C((TextView)var33_41, (String)"view.episodes", (TextView)var33_41, (View)var2_2, (Int)2131362164);
            Intrinsics.g((Object)var34_42, (String)"view.dot");
            ViewsKt.k((View)var34_42);
        } else if (var5_5 == null && var23_33 != null) {
            a.u((String)"? \u0438\u0437 ", (Integer)var23_33, (String)" \u044d\u043f", (TextView)((TextView)var2_2.findViewById(2131362200)));
            var31_43 = (TextView)var2_2.findViewById(2131362200);
            var32_44 = (TextView)a.C((TextView)var31_43, (String)"view.episodes", (TextView)var31_43, (View)var2_2, (Int)2131362164);
            Intrinsics.g((Object)var32_44, (String)"view.dot");
            ViewsKt.k((View)var32_44);
        } else {
            var24_45 = (TextView)var2_2.findViewById(2131362200);
            var25_46 = (TextView)a.f((TextView)var24_45, (String)"view.episodes", (TextView)var24_45, (View)var2_2, (Int)2131362164);
            Intrinsics.g((Object)var25_46, (String)"view.dot");
            ViewsKt.e((View)var25_46);
        }
        var26_47 = (LinearLayout)var2_2.findViewById(2131362662);
        Intrinsics.g((Object)var26_47, (String)"view.rating_layout");
        ViewsKt.l((View)var26_47, (Bool)this.w);
        if (var17_17 != null) {
            var30_48 = (TextView)var2_2.findViewById(2131362324);
            a.s((Double)var17_17, (Int)0, (Int)1, (TextView)var30_48);
        }
        var27_49 = var11_11 == null || var11_11.length() == 0;
        if (var27_49 && (var8_8 == null || var8_8 != 3L)) {
            ((TextView)var2_2.findViewById(2131362123)).setText((CharSequence)var2_2.getContext().getString(2131951809));
        } else {
            ((TextView)var2_2.findViewById(2131362123)).setText((CharSequence)var11_11);
        }
        var28_50 = (AppCompatImageView)var2_2.findViewById(2131362613);
        Intrinsics.g((Object)var28_50, (String)"view.poster");
        ViewsKt.h((ImageView)var28_50, (String)this.p);
        ViewsKt.j((View)var2_2, (Function1)new bind.2(this));
        var2_2.setOnLongClickListener((View.OnLongClickListener)new d((Object)this, 3));
        var29_51 = (ImageView)var2_2.findViewById(2131362497);
        Intrinsics.g((Object)var29_51, (String)"view.more");
        ViewsKt.j((View)var29_51, (Function1)new bind.4(this));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof ReleaseModel) {
            String string = this.k;
            ReleaseModel releaseModel = (ReleaseModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)releaseModel.k)) {
                arrayList.add((Object)0);
            }
            if (!Intrinsics.c((Object)this.l, (Object)releaseModel.l)) {
                arrayList.add((Object)1);
            }
            if (!Intrinsics.c((Object)this.m, (Object)releaseModel.m)) {
                arrayList.add((Object)2);
            }
            if (!Intrinsics.a((Double)this.n, (Double)releaseModel.n)) {
                arrayList.add((Object)3);
            }
            if (!Intrinsics.c((Object)this.o, (Object)releaseModel.o)) {
                arrayList.add((Object)4);
            }
            if (!Intrinsics.c((Object)this.p, (Object)releaseModel.p)) {
                arrayList.add((Object)5);
            }
            if (!Intrinsics.c((Object)this.q, (Object)releaseModel.q)) {
                arrayList.add((Object)6);
            }
            if (this.r != releaseModel.r) {
                arrayList.add((Object)7);
            }
            if (!Intrinsics.c((Object)this.t, (Object)releaseModel.t)) {
                arrayList.add((Object)8);
            }
            if (this.u != releaseModel.u) {
                arrayList.add((Object)9);
            }
            if (this.v != releaseModel.v) {
                arrayList.add((Object)10);
            }
            if (this.w != releaseModel.w) {
                arrayList.add((Object)11);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        block38 : {
            String string;
            String string2;
            Context context;
            String string3;
            Long l;
            block40 : {
                block39 : {
                    Double d2;
                    context = a.b((View)view, (String)"view", list, (String)"payloads");
                    if (list.contains((Object)0)) {
                        ((TextView)view.findViewById(2131363004)).setText((CharSequence)this.k);
                    }
                    if (list.contains((Object)1)) {
                        TextView textView = (TextView)view.findViewById(2131362200);
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append((Object)this.l);
                        stringBuilder.append(" \u0438\u0437 ");
                        a.w((StringBuilder)stringBuilder, (Integer)this.m, (TextView)textView);
                    }
                    if (list.contains((Object)2)) {
                        TextView textView = (TextView)view.findViewById(2131362200);
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append((Object)this.l);
                        stringBuilder.append(" \u0438\u0437 ");
                        a.w((StringBuilder)stringBuilder, (Integer)this.m, (TextView)textView);
                    }
                    if (list.contains((Object)3) && (d2 = this.n) != null) {
                        Double d3 = d2;
                        ((TextView)view.findViewById(2131362324)).setText((CharSequence)DigitsKt.d((Double)d3, (Int)0, (Int)1));
                    }
                    if (list.contains((Object)4)) {
                        Long l2;
                        String string4 = this.o;
                        Bool bl = string4 == null || string4.length() == 0;
                        if (bl && ((l2 = this.t) == null || l2 != 3L)) {
                            ((TextView)view.findViewById(2131362123)).setText((CharSequence)view.getContext().getString(2131951809));
                        } else {
                            ((TextView)view.findViewById(2131362123)).setText((CharSequence)this.o);
                        }
                    }
                    if (list.contains((Object)5)) {
                        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362613);
                        Intrinsics.g((Object)appCompatImageView, (String)"view.poster");
                        ViewsKt.h((ImageView)appCompatImageView, (String)this.p);
                    }
                    Bool bl = list.contains((Object)6);
                    string = "\u043b\u0435\u0442\u043e";
                    string2 = "";
                    if (bl || list.contains((Object)7)) {
                        String string5;
                        Bool bl2;
                        Int n = this.r;
                        Bool bl3 = 1 <= n && n < 5;
                        if (bl3) {
                            String string6 = n != 1 ? (n != 2 ? (n != 3 ? (n != 4 ? string2 : "\u043e\u0441\u0435\u043d\u044c") : string) : "\u0432\u0435\u0441\u043d\u0430") : "\u0437\u0438\u043c\u0430";
                            string5 = a.a.l((String)string2, (String)string6, (char)' ');
                        } else {
                            string5 = string2;
                        }
                        String string7 = this.q;
                        Bool bl4 = string7 == null || string7.length() == 0;
                        if (!bl4) {
                            string5 = a.a.q((StringBuilder)a.a.u((String)string5), (String)this.q, (String)" \u0433.");
                        }
                        if (bl2 = string5.length() > 0) {
                            ((TextView)view.findViewById(2131361897)).setText((CharSequence)string5);
                        }
                    }
                    if (!list.contains((Object)8)) break block38;
                    Long l3 = this.t;
                    if (l3 == null || l3 != 3L) break block39;
                    string3 = "view.release_status";
                    if (this.s == 0L) break block40;
                    ((TextView)view.findViewById(2131362123)).setMaxLines(3);
                    TextView textView = (TextView)view.findViewById(2131361897);
                    TextView textView2 = (TextView)a.C((TextView)textView, (String)"view.announcement", (TextView)textView, (View)view, (Int)2131362699);
                    ((TextView)a.C((TextView)textView2, (String)string3, (TextView)textView2, (View)view, (Int)2131362699)).setText((CharSequence)"\u0410\u043d\u043e\u043d\u0441");
                    ((TextView)view.findViewById(2131361897)).setText((CharSequence)Time.a.b(this.s, "d MMM yyyy \u0433."));
                    break block38;
                }
                string3 = "view.release_status";
            }
            if ((l = this.t) != null && l == 3L) {
                String string8;
                Bool bl;
                ((TextView)view.findViewById(2131362123)).setMaxLines(3);
                TextView textView = (TextView)view.findViewById(2131361897);
                TextView textView3 = (TextView)a.C((TextView)textView, (String)"view.announcement", (TextView)textView, (View)view, (Int)2131362699);
                ((TextView)a.C((TextView)textView3, (String)string3, (TextView)textView3, (View)view, (Int)2131362699)).setText((CharSequence)"\u0410\u043d\u043e\u043d\u0441");
                Int n = this.r;
                Bool bl5 = 1 <= n && n < 5;
                if (bl5) {
                    if (n != 1) {
                        if (n != 2) {
                            if (n != 3) {
                                string = n != 4 ? string2 : "\u043e\u0441\u0435\u043d\u044c";
                            }
                        } else {
                            string = "\u0432\u0435\u0441\u043d\u0430";
                        }
                    } else {
                        string = "\u0437\u0438\u043c\u0430";
                    }
                    string2 = a.a.l((String)string2, (String)string, (char)' ');
                }
                Bool bl6 = (string8 = this.q) == null || string8.length() == 0;
                if (!bl6) {
                    string2 = a.a.q((StringBuilder)a.a.u((String)string2), (String)this.q, (String)" \u0433.");
                }
                if (bl = string2.length() > 0) {
                    ((TextView)view.findViewById(2131361897)).setText((CharSequence)string2);
                } else {
                    ((TextView)view.findViewById(2131361897)).setText((CharSequence)context.getString(2131951741));
                }
            } else {
                ((TextView)view.findViewById(2131362123)).setMaxLines(4);
                TextView textView = (TextView)view.findViewById(2131362123);
                TextView textView4 = (TextView)a.C((TextView)textView, (String)"view.description", (TextView)textView, (View)view, (Int)2131361897);
                TextView textView5 = (TextView)a.f((TextView)textView4, (String)"view.announcement", (TextView)textView4, (View)view, (Int)2131362699);
                Intrinsics.g((Object)textView5, (String)string3);
                ViewsKt.e((View)textView5);
            }
        }
        if (list.contains((Object)9)) {
            ImageView imageView = (ImageView)view.findViewById(2131362281);
            Int n = this.u ? 0 : 8;
            imageView.setVisibility(n);
        }
        if (list.contains((Object)10)) {
            if (this.v != 0) {
                RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362918);
                Intrinsics.g((Object)relativeLayout, (String)"view.status_layout");
                ViewsKt.m((View)relativeLayout, (Bool)true);
                Int n = this.v;
                if (n != 1) {
                    if (n != 2) {
                        if (n != 3) {
                            if (n != 4) {
                                if (n == 5) {
                                    ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0431\u0440\u043e\u0448\u0435\u043d\u043e");
                                    a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131100607, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                                }
                            } else {
                                ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u043e\u0442\u043b\u043e\u0436\u0435\u043d\u043e");
                                a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131100687, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                            }
                        } else {
                            ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u043f\u0440\u043e\u0441\u043c\u043e\u0442\u0440\u0435\u043d\u043e");
                            a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131099691, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                        }
                    } else {
                        ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0432 \u043f\u043b\u0430\u043d\u0430\u0445");
                        a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131100604, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                    }
                } else {
                    ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0441\u043c\u043e\u0442\u0440\u044e");
                    a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131099809, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                }
            } else {
                RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362918);
                Intrinsics.g((Object)relativeLayout, (String)"view.status_layout");
                ViewsKt.m((View)relativeLayout, (Bool)false);
            }
        }
        if (list.contains((Object)11)) {
            LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362662);
            Intrinsics.g((Object)linearLayout, (String)"view.rating_layout");
            ViewsKt.l((View)linearLayout, (Bool)this.w);
        }
    }

    @NotNull
    final Listener v2() {
        Listener listener = this.x;
        if (listener != null) {
            return listener;
        }
        Intrinsics.r((String)"listener");
        throw null;
    }

    func w2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        view.setOnClickListener(null);
        view.setOnLongClickListener(null);
        ((ImageView)view.findViewById(2131362497)).setOnClickListener(null);
    }
}

