/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.TextView
 *  androidx.annotation.StringRes
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.fragment.main.watching.a
 *  com.swiftsoft.anixartd.ui.model.main.profile.friends.FriendRecommendationModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.profile.friends.FriendRecommendationModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.profile.friends.FriendRecommendationModel$bind$7
 *  com.swiftsoft.anixartd.ui.model.main.profile.friends.FriendRecommendationModel$bind$8
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.profile.friends;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.StringRes;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.model.main.profile.friends.FriendRecommendationModel;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/profile/friends/FriendRecommendationModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class FriendRecommendationModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    @NotNull
    String k = "";
    @EpoxyAttribute
    @Nullable
    String l = "";
    @EpoxyAttribute
    Bool m;
    @StringRes
    @EpoxyAttribute
    Int n;
    @StringRes
    @EpoxyAttribute
    Int o;
    @EpoxyAttribute
    Int p;
    @EpoxyAttribute
    Int q;
    @EpoxyAttribute
    Bool r;
    @EpoxyAttribute
    Bool s;
    @EpoxyAttribute
    Listener t;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362872);
        Intrinsics.g((Object)appCompatImageView, (String)"view.sponsor");
        ViewsKt.l((View)appCompatImageView, (Bool)this.r);
        AppCompatImageView appCompatImageView2 = (AppCompatImageView)view.findViewById(2131363094);
        Intrinsics.g((Object)appCompatImageView2, (String)"view.verified");
        ViewsKt.l((View)appCompatImageView2, (Bool)this.s);
        ((TextView)view.findViewById(2131362548)).setText((CharSequence)this.k);
        String string = this.l;
        if (string != null) {
            AppCompatImageView appCompatImageView3 = (AppCompatImageView)view.findViewById(2131361916);
            Intrinsics.g((Object)appCompatImageView3, (String)"view.avatar");
            ViewsKt.a((AppCompatImageView)appCompatImageView3, (String)string);
        }
        AppCompatImageView appCompatImageView4 = (AppCompatImageView)view.findViewById(2131362389);
        Intrinsics.g((Object)appCompatImageView4, (String)"view.isOnline");
        ViewsKt.l((View)appCompatImageView4, (Bool)this.m);
        Button button = (Button)view.findViewById(2131361975);
        Intrinsics.g((Object)button, (String)"bind$lambda$4");
        Bool bl = this.n != 0;
        ViewsKt.l((View)button, (Bool)bl);
        if (this.n != 0) {
            ((Button)view.findViewById(2131361975)).setText((CharSequence)context.getString(this.n));
        }
        Button button2 = (Button)view.findViewById(2131361973);
        Intrinsics.g((Object)button2, (String)"bind$lambda$5");
        Int n = this.o;
        Bool bl2 = false;
        if (n != 0) {
            bl2 = true;
        }
        ViewsKt.l((View)button2, (Bool)bl2);
        if (this.o != 0) {
            ((Button)view.findViewById(2131361973)).setText((CharSequence)context.getString(this.o));
        }
        Button button3 = (Button)view.findViewById(2131361975);
        Intrinsics.g((Object)button3, (String)"view.btnPositive");
        ViewsKt.j((View)button3, (Function1)new bind.7(this));
        Button button4 = (Button)view.findViewById(2131361973);
        Intrinsics.g((Object)button4, (String)"view.btnNegative");
        ViewsKt.j((View)button4, (Function1)new bind.8(this));
        view.setOnClickListener((View.OnClickListener)new com.swiftsoft.anixartd.ui.fragment.main.watching.a((Object)this, 13));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof FriendRecommendationModel) {
            String string = this.k;
            FriendRecommendationModel friendRecommendationModel = (FriendRecommendationModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)friendRecommendationModel.k)) {
                arrayList.add((Object)0);
            }
            if (!Intrinsics.c((Object)this.l, (Object)friendRecommendationModel.l)) {
                arrayList.add((Object)1);
            }
            if (this.m != friendRecommendationModel.m) {
                arrayList.add((Object)2);
            }
            if (this.n != friendRecommendationModel.n) {
                arrayList.add((Object)3);
            }
            if (this.n != friendRecommendationModel.n) {
                arrayList.add((Object)4);
            }
            if (this.r != friendRecommendationModel.r) {
                arrayList.add((Object)5);
            }
            if (this.s != friendRecommendationModel.s) {
                arrayList.add((Object)6);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        String string;
        Context context = a.b((View)view, (String)"view", list, (String)"payloads");
        if (list.contains((Object)0)) {
            ((TextView)view.findViewById(2131362548)).setText((CharSequence)this.k);
        }
        if (list.contains((Object)1) && (string = this.l) != null) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131361916);
            Intrinsics.g((Object)appCompatImageView, (String)"view.avatar");
            ViewsKt.a((AppCompatImageView)appCompatImageView, (String)string);
        }
        if (list.contains((Object)2)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362389);
            Intrinsics.g((Object)appCompatImageView, (String)"view.isOnline");
            ViewsKt.l((View)appCompatImageView, (Bool)this.m);
        }
        if (list.contains((Object)3)) {
            Button button = (Button)view.findViewById(2131361975);
            Intrinsics.g((Object)button, (String)"bind$lambda$1");
            Bool bl = this.n != 0;
            ViewsKt.l((View)button, (Bool)bl);
            if (this.n != 0) {
                ((Button)view.findViewById(2131361975)).setText((CharSequence)context.getString(this.n));
            }
        }
        if (list.contains((Object)4)) {
            Button button = (Button)view.findViewById(2131361973);
            Intrinsics.g((Object)button, (String)"bind$lambda$2");
            Int n = this.o;
            Bool bl = false;
            if (n != 0) {
                bl = true;
            }
            ViewsKt.l((View)button, (Bool)bl);
            if (this.o != 0) {
                ((Button)view.findViewById(2131361973)).setText((CharSequence)context.getString(this.o));
            }
        }
        if (list.contains((Object)5)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362872);
            Intrinsics.g((Object)appCompatImageView, (String)"view.sponsor");
            ViewsKt.l((View)appCompatImageView, (Bool)this.r);
        }
        if (list.contains((Object)6)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131363094);
            Intrinsics.g((Object)appCompatImageView, (String)"view.verified");
            ViewsKt.l((View)appCompatImageView, (Bool)this.s);
        }
    }

    @NotNull
    final Listener v2() {
        Listener listener = this.t;
        if (listener != null) {
            return listener;
        }
        Intrinsics.r((String)"listener");
        throw null;
    }

    func w2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        view.setOnClickListener(null);
    }
}

