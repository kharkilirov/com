/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewGroup$MarginLayoutParams
 *  androidx.annotation.Dimension
 *  androidx.annotation.LayoutRes
 *  androidx.annotation.NonNull
 *  androidx.room.util.a
 *  com.airbnb.epoxy.Carousel
 *  com.airbnb.epoxy.Carousel$Padding
 *  com.airbnb.epoxy.EpoxyController
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyViewHolder
 *  com.airbnb.epoxy.GeneratedModel
 *  com.swiftsoft.anixartd.ui.model.main.profile.friends.carousel.RecommendationCarousel
 *  com.swiftsoft.anixartd.ui.model.main.profile.friends.carousel.RecommendationCarouselModelBuilder
 *  java.lang.Float
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.UnsupportedOperationException
 *  java.util.BitSet
 *  java.util.List
 *  java.util.Objects
 */
package com.swiftsoft.anixartd.ui.model.main.profile.friends.carousel;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.Dimension;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.room.util.a;
import com.airbnb.epoxy.Carousel;
import com.airbnb.epoxy.EpoxyController;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyViewHolder;
import com.airbnb.epoxy.GeneratedModel;
import com.swiftsoft.anixartd.ui.model.main.profile.friends.carousel.RecommendationCarousel;
import com.swiftsoft.anixartd.ui.model.main.profile.friends.carousel.RecommendationCarouselModelBuilder;
import java.util.BitSet;
import java.util.List;
import java.util.Objects;

class RecommendationCarouselModel_
extends EpoxyModel<RecommendationCarousel>
implements GeneratedModel<RecommendationCarousel>,
RecommendationCarouselModelBuilder {
    final BitSet k = new BitSet(7);
    @Dimension
    Int l = -1;
    @NonNull
    List<? extends EpoxyModel<?>> m;

    func N1(EpoxyViewHolder epoxyViewHolder, Object object, Int n) -> void {
        (RecommendationCarousel)object;
        this.t2("The model was changed between being added to the controller and being bound.", n);
    }

    func X1(EpoxyController epoxyController) -> void {
        epoxyController.addInternal((EpoxyModel)this);
        this.Y1(epoxyController);
        if (this.k.get(6)) {
            return;
        }
        throw new IllegalStateException("A value is required for setModels");
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        RecommendationCarousel recommendationCarousel = (RecommendationCarousel)object;
        if (!(epoxyModel instanceof RecommendationCarouselModel_)) {
            this.u2(recommendationCarousel);
            return;
        }
        RecommendationCarouselModel_ recommendationCarouselModel_ = (RecommendationCarouselModel_)epoxyModel;
        if (this.k.get(3)) {
            Objects.requireNonNull((Object)((Object)recommendationCarouselModel_));
        } else if (this.k.get(4)) {
            Int n = this.l;
            if (n != recommendationCarouselModel_.l) {
                recommendationCarousel.setPaddingDp(n);
            }
        } else if (this.k.get(5)) {
            if (!recommendationCarouselModel_.k.get(5)) {
                recommendationCarousel.setPadding(null);
            }
        } else if (recommendationCarouselModel_.k.get(3) || recommendationCarouselModel_.k.get(4) || recommendationCarouselModel_.k.get(5)) {
            recommendationCarousel.setPaddingDp(this.l);
        }
        Objects.requireNonNull((Object)((Object)recommendationCarouselModel_));
        if (this.k.get(1)) {
            if (Float.compare((Float)0.0f, (Float)0.0f) != 0) {
                recommendationCarousel.setNumViewsToShowOnScreen(0.0f);
            }
        } else if (!this.k.get(2) && (recommendationCarouselModel_.k.get(1) || recommendationCarouselModel_.k.get(2))) {
            recommendationCarousel.setNumViewsToShowOnScreen(0.0f);
        }
        List<? extends EpoxyModel<?>> list = this.m;
        List<? extends EpoxyModel<?>> list2 = recommendationCarouselModel_.m;
        if (list != null ? !list.equals(list2) : list2 != null) {
            recommendationCarousel.setModels(this.m);
        }
    }

    func c2(ViewGroup viewGroup) -> View {
        RecommendationCarousel recommendationCarousel = new RecommendationCarousel(viewGroup.getContext());
        recommendationCarousel.setLayoutParams((ViewGroup.LayoutParams)new ViewGroup.MarginLayoutParams(-2, -2));
        return recommendationCarousel;
    }

    @LayoutRes
    func d2() -> Int {
        throw new UnsupportedOperationException("Layout resources are unsupported for views created programmatically.");
    }

    func e2(Int n, Int n2, Int n3) -> Int {
        return n;
    }

    func equals(Object object) -> Bool {
        if (object == this) {
            return true;
        }
        if (!(object instanceof RecommendationCarouselModel_)) {
            return false;
        }
        if (!super.equals(object)) {
            return false;
        }
        RecommendationCarouselModel_ recommendationCarouselModel_ = (RecommendationCarouselModel_)((Object)object);
        Objects.requireNonNull((Object)((Object)recommendationCarouselModel_));
        if (Float.compare((Float)0.0f, (Float)0.0f) != 0) {
            return false;
        }
        if (this.l != recommendationCarouselModel_.l) {
            return false;
        }
        List<? extends EpoxyModel<?>> list = this.m;
        List<? extends EpoxyModel<?>> list2 = recommendationCarouselModel_.m;
        return !(list != null ? !list.equals(list2) : list2 != null);
    }

    func f0(Object object, Int n) -> void {
        (RecommendationCarousel)object;
        this.t2("The model was changed during the bind call.", n);
    }

    func f2() -> Int {
        return 0;
    }

    func g2(long l) -> EpoxyModel {
        super.g2(l);
        return this;
    }

    func hashCode() -> Int {
        Int n = 31 * (0 + 31 * (31 * (0 + 31 * (0 + 31 * (0 + 31 * (0 + 31 * (0 + 31 * (0 + 31 * (0 + 31 * (0 + 31 * super.hashCode())))))))) + this.l));
        List<? extends EpoxyModel<?>> list = this.m;
        Int n2 = 0;
        if (list != null) {
            n2 = list.hashCode();
        }
        return n + n2;
    }

    func q2() -> Bool {
        return true;
    }

    func s2(Object object) -> void {
        ((RecommendationCarousel)object).L0();
    }

    func toString() -> String {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("RecommendationCarouselModel_{hasFixedSize_Boolean=");
        stringBuilder.append(false);
        stringBuilder.append(", numViewsToShowOnScreen_Float=");
        stringBuilder.append(0.0f);
        stringBuilder.append(", initialPrefetchItemCount_Int=");
        a.A((StringBuilder)stringBuilder, (Int)0, (String)", paddingRes_Int=", (Int)0, (String)", paddingDp_Int=");
        stringBuilder.append(this.l);
        stringBuilder.append(", padding_Padding=");
        stringBuilder.append(null);
        stringBuilder.append(", models_List=");
        stringBuilder.append(this.m);
        stringBuilder.append("}");
        stringBuilder.append(super.toString());
        return stringBuilder.toString();
    }

    func u2(RecommendationCarousel recommendationCarousel) -> void {
        if (this.k.get(3)) {
            recommendationCarousel.setPaddingRes(0);
        } else if (this.k.get(4)) {
            recommendationCarousel.setPaddingDp(this.l);
        } else if (this.k.get(5)) {
            recommendationCarousel.setPadding(null);
        } else {
            recommendationCarousel.setPaddingDp(this.l);
        }
        recommendationCarousel.setHasFixedSize(false);
        if (this.k.get(1)) {
            recommendationCarousel.setNumViewsToShowOnScreen(0.0f);
        } else if (this.k.get(2)) {
            recommendationCarousel.setInitialPrefetchItemCount(0);
        } else {
            recommendationCarousel.setNumViewsToShowOnScreen(0.0f);
        }
        recommendationCarousel.setModels(this.m);
    }
}

