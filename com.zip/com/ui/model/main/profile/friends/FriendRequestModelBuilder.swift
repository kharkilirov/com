/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Nullable
 *  androidx.annotation.StringRes
 *  com.airbnb.epoxy.EpoxyBuildScope
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModel$SpanSizeOverrideCallback
 *  java.lang.Object
 *  java.lang.String
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.profile.friends;

import androidx.annotation.StringRes;
import com.airbnb.epoxy.EpoxyBuildScope;
import com.airbnb.epoxy.EpoxyModel;
import com.swiftsoft.anixartd.ui.model.main.profile.friends.FriendRequestModel;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@EpoxyBuildScope
interface FriendRequestModelBuilder {
    FriendRequestModelBuilder A0(long var1);

    FriendRequestModelBuilder B0(Int var1);

    FriendRequestModelBuilder I0(@StringRes Int var1);

    FriendRequestModelBuilder L1(Int var1);

    FriendRequestModelBuilder P0(FriendRequestModel.Listener var1);

    FriendRequestModelBuilder Q(Bool var1);

    FriendRequestModelBuilder b(long var1);

    FriendRequestModelBuilder d(@androidx.annotation.Nullable EpoxyModel.SpanSizeOverrideCallback var1);

    FriendRequestModelBuilder k(@NotNull String var1);

    FriendRequestModelBuilder k1(@StringRes Int var1);

    FriendRequestModelBuilder l(@Nullable String var1);

    FriendRequestModelBuilder o0(Int var1);

    FriendRequestModelBuilder p(Bool var1);

    FriendRequestModelBuilder r(Bool var1);
}

