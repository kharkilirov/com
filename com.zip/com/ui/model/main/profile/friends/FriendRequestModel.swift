/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.TextView
 *  androidx.annotation.StringRes
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.fragment.main.watching.a
 *  com.swiftsoft.anixartd.ui.model.main.profile.friends.FriendRequestModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.profile.friends.FriendRequestModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.profile.friends.FriendRequestModel$bind$10
 *  com.swiftsoft.anixartd.ui.model.main.profile.friends.FriendRequestModel$bind$9
 *  com.swiftsoft.anixartd.utils.Plurals
 *  com.swiftsoft.anixartd.utils.Time
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.profile.friends;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.StringRes;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.model.main.profile.friends.FriendRequestModel;
import com.swiftsoft.anixartd.utils.Plurals;
import com.swiftsoft.anixartd.utils.Time;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/profile/friends/FriendRequestModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class FriendRequestModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    @NotNull
    String k = "";
    @EpoxyAttribute
    @Nullable
    String l = "";
    @EpoxyAttribute
    Bool m;
    @EpoxyAttribute
    Int n;
    @EpoxyAttribute
    long o;
    @StringRes
    @EpoxyAttribute
    Int p;
    @StringRes
    @EpoxyAttribute
    Int q;
    @EpoxyAttribute
    Int r;
    @EpoxyAttribute
    Int s;
    @EpoxyAttribute
    Bool t;
    @EpoxyAttribute
    Bool u;
    @EpoxyAttribute
    Listener v;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362872);
        Intrinsics.g((Object)appCompatImageView, (String)"view.sponsor");
        ViewsKt.l((View)appCompatImageView, (Bool)this.t);
        AppCompatImageView appCompatImageView2 = (AppCompatImageView)view.findViewById(2131363094);
        Intrinsics.g((Object)appCompatImageView2, (String)"view.verified");
        ViewsKt.l((View)appCompatImageView2, (Bool)this.u);
        ((TextView)view.findViewById(2131362548)).setText((CharSequence)this.k);
        String string = this.l;
        if (string != null) {
            AppCompatImageView appCompatImageView3 = (AppCompatImageView)view.findViewById(2131361916);
            Intrinsics.g((Object)appCompatImageView3, (String)"view.avatar");
            ViewsKt.a((AppCompatImageView)appCompatImageView3, (String)string);
        }
        AppCompatImageView appCompatImageView4 = (AppCompatImageView)view.findViewById(2131362389);
        Intrinsics.g((Object)appCompatImageView4, (String)"view.isOnline");
        ViewsKt.l((View)appCompatImageView4, (Bool)this.m);
        Button button = (Button)view.findViewById(2131361975);
        Intrinsics.g((Object)button, (String)"bind$lambda$6");
        Bool bl = this.p != 0;
        ViewsKt.l((View)button, (Bool)bl);
        if (this.p != 0) {
            ((Button)view.findViewById(2131361975)).setText((CharSequence)context.getString(this.p));
        }
        Button button2 = (Button)view.findViewById(2131361973);
        Intrinsics.g((Object)button2, (String)"bind$lambda$7");
        Bool bl2 = this.q != 0;
        ViewsKt.l((View)button2, (Bool)bl2);
        if (this.q != 0) {
            ((Button)view.findViewById(2131361973)).setText((CharSequence)context.getString(this.q));
        }
        Button button3 = (Button)view.findViewById(2131361975);
        Intrinsics.g((Object)button3, (String)"view.btnPositive");
        ViewsKt.j((View)button3, (Function1)new bind.9(this));
        Button button4 = (Button)view.findViewById(2131361973);
        Intrinsics.g((Object)button4, (String)"view.btnNegative");
        ViewsKt.j((View)button4, (Function1)new bind.10(this));
        TextView textView = (TextView)view.findViewById(2131362924);
        Intrinsics.g((Object)textView, (String)"bind$lambda$8");
        Bool bl3 = this.n > 0;
        ViewsKt.l((View)textView, (Bool)bl3);
        Plurals plurals = Plurals.a;
        Context context2 = view.getContext();
        Intrinsics.g((Object)context2, (String)"view.context");
        textView.setText((CharSequence)plurals.b(context2, this.n, 2131820552, 2131952031));
        TextView textView2 = (TextView)view.findViewById(2131362925);
        Intrinsics.g((Object)textView2, (String)"bind$lambda$9");
        long l = this.o LCMP 0L;
        Bool bl4 = false;
        if (l > 0) {
            bl4 = true;
        }
        ViewsKt.l((View)textView2, (Bool)bl4);
        Time time = Time.a;
        Context context3 = view.getContext();
        Intrinsics.g((Object)context3, (String)"view.context");
        textView2.setText((CharSequence)time.g(context3, this.o));
        view.setOnClickListener((View.OnClickListener)new com.swiftsoft.anixartd.ui.fragment.main.watching.a((Object)this, 14));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof FriendRequestModel) {
            String string = this.k;
            FriendRequestModel friendRequestModel = (FriendRequestModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)friendRequestModel.k)) {
                arrayList.add((Object)0);
            }
            if (!Intrinsics.c((Object)this.l, (Object)friendRequestModel.l)) {
                arrayList.add((Object)1);
            }
            if (this.m != friendRequestModel.m) {
                arrayList.add((Object)2);
            }
            if (this.n != friendRequestModel.n) {
                arrayList.add((Object)3);
            }
            if (this.o != friendRequestModel.o) {
                arrayList.add((Object)4);
            }
            if (this.p != friendRequestModel.p) {
                arrayList.add((Object)5);
            }
            if (this.p != friendRequestModel.p) {
                arrayList.add((Object)6);
            }
            if (this.t != friendRequestModel.t) {
                arrayList.add((Object)7);
            }
            if (this.u != friendRequestModel.u) {
                arrayList.add((Object)8);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        String string;
        Context context = a.b((View)view, (String)"view", list, (String)"payloads");
        if (list.contains((Object)0)) {
            ((TextView)view.findViewById(2131362548)).setText((CharSequence)this.k);
        }
        if (list.contains((Object)1) && (string = this.l) != null) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131361916);
            Intrinsics.g((Object)appCompatImageView, (String)"view.avatar");
            ViewsKt.a((AppCompatImageView)appCompatImageView, (String)string);
        }
        if (list.contains((Object)2)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362389);
            Intrinsics.g((Object)appCompatImageView, (String)"view.isOnline");
            ViewsKt.l((View)appCompatImageView, (Bool)this.m);
        }
        if (list.contains((Object)3)) {
            TextView textView = (TextView)view.findViewById(2131362924);
            Intrinsics.g((Object)textView, (String)"bind$lambda$1");
            Bool bl = this.n > 0;
            ViewsKt.l((View)textView, (Bool)bl);
            Plurals plurals = Plurals.a;
            Context context2 = view.getContext();
            Intrinsics.g((Object)context2, (String)"view.context");
            textView.setText((CharSequence)plurals.b(context2, this.n, 2131820552, 2131952031));
        }
        if (list.contains((Object)4)) {
            TextView textView = (TextView)view.findViewById(2131362925);
            Intrinsics.g((Object)textView, (String)"bind$lambda$2");
            Bool bl = this.o > 0L;
            ViewsKt.l((View)textView, (Bool)bl);
            Time time = Time.a;
            Context context3 = view.getContext();
            Intrinsics.g((Object)context3, (String)"view.context");
            textView.setText((CharSequence)time.g(context3, this.o));
        }
        if (list.contains((Object)5)) {
            Button button = (Button)view.findViewById(2131361975);
            Intrinsics.g((Object)button, (String)"bind$lambda$3");
            Bool bl = this.p != 0;
            ViewsKt.l((View)button, (Bool)bl);
            if (this.p != 0) {
                ((Button)view.findViewById(2131361975)).setText((CharSequence)context.getString(this.p));
            }
        }
        if (list.contains((Object)6)) {
            Button button = (Button)view.findViewById(2131361973);
            Intrinsics.g((Object)button, (String)"bind$lambda$4");
            Int n = this.q;
            Bool bl = false;
            if (n != 0) {
                bl = true;
            }
            ViewsKt.l((View)button, (Bool)bl);
            if (this.q != 0) {
                ((Button)view.findViewById(2131361973)).setText((CharSequence)context.getString(this.q));
            }
        }
        if (list.contains((Object)7)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362872);
            Intrinsics.g((Object)appCompatImageView, (String)"view.sponsor");
            ViewsKt.l((View)appCompatImageView, (Bool)this.t);
        }
        if (list.contains((Object)8)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131363094);
            Intrinsics.g((Object)appCompatImageView, (String)"view.verified");
            ViewsKt.l((View)appCompatImageView, (Bool)this.u);
        }
    }

    @NotNull
    final Listener v2() {
        Listener listener = this.v;
        if (listener != null) {
            return listener;
        }
        Intrinsics.r((String)"listener");
        throw null;
    }

    func w2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        view.setOnClickListener(null);
    }
}

