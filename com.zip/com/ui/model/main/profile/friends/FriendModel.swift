/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.fragment.main.watching.a
 *  com.swiftsoft.anixartd.ui.model.main.profile.friends.FriendModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.profile.friends.FriendModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.profile.friends.FriendModel$bind$5
 *  com.swiftsoft.anixartd.utils.Plurals
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.NoWhenBranchMatchedException
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.profile.friends;

import android.content.Context;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.model.main.profile.friends.FriendModel;
import com.swiftsoft.anixartd.utils.Plurals;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/profile/friends/FriendModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class FriendModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    @NotNull
    String k = "";
    @EpoxyAttribute
    @Nullable
    String l = "";
    @EpoxyAttribute
    Bool m;
    @EpoxyAttribute
    Int n;
    @EpoxyAttribute
    Bool o;
    @EpoxyAttribute
    Bool p;
    @EpoxyAttribute
    Bool q;
    @EpoxyAttribute
    Listener r;

    func Z1(Object object) -> void {
        block7 : {
            Int n;
            AppCompatImageView appCompatImageView;
            View view;
            Bool bl;
            block6 : {
                Bool bl2;
                block5 : {
                    view = (View)object;
                    Intrinsics.h((Object)view, (String)"view");
                    ((TextView)view.findViewById(2131362548)).setText((CharSequence)this.k);
                    AppCompatImageView appCompatImageView2 = (AppCompatImageView)view.findViewById(2131362872);
                    Intrinsics.g((Object)appCompatImageView2, (String)"view.sponsor");
                    ViewsKt.l((View)appCompatImageView2, (Bool)this.o);
                    AppCompatImageView appCompatImageView3 = (AppCompatImageView)view.findViewById(2131363094);
                    Intrinsics.g((Object)appCompatImageView3, (String)"view.verified");
                    ViewsKt.l((View)appCompatImageView3, (Bool)this.p);
                    appCompatImageView = (AppCompatImageView)view.findViewById(2131362487);
                    bl2 = this.q;
                    bl = true;
                    if (bl2 != bl) break block5;
                    n = ViewsKt.c((View)view, (Int)2130968827);
                    break block6;
                }
                if (bl2) break block7;
                n = ViewsKt.c((View)view, (Int)2130969187);
            }
            appCompatImageView.setColorFilter(n);
            String string = this.l;
            if (string != null) {
                AppCompatImageView appCompatImageView4 = (AppCompatImageView)view.findViewById(2131361916);
                Intrinsics.g((Object)appCompatImageView4, (String)"view.avatar");
                ViewsKt.a((AppCompatImageView)appCompatImageView4, (String)string);
            }
            AppCompatImageView appCompatImageView5 = (AppCompatImageView)view.findViewById(2131362389);
            Intrinsics.g((Object)appCompatImageView5, (String)"view.isOnline");
            ViewsKt.l((View)appCompatImageView5, (Bool)this.m);
            TextView textView = (TextView)view.findViewById(2131362924);
            Intrinsics.g((Object)textView, (String)"bind$lambda$3");
            if (this.n <= 0) {
                bl = false;
            }
            ViewsKt.l((View)textView, (Bool)bl);
            Plurals plurals = Plurals.a;
            Context context = view.getContext();
            Intrinsics.g((Object)context, (String)"view.context");
            textView.setText((CharSequence)plurals.b(context, this.n, 2131820552, 2131952031));
            RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362486);
            Intrinsics.g((Object)relativeLayout, (String)"view.message");
            ViewsKt.j((View)relativeLayout, (Function1)new bind.5(this));
            view.setOnClickListener((View.OnClickListener)new com.swiftsoft.anixartd.ui.fragment.main.watching.a((Object)this, 12));
            return;
        }
        throw new NoWhenBranchMatchedException();
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof FriendModel) {
            String string = this.k;
            FriendModel friendModel = (FriendModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)friendModel.k)) {
                arrayList.add((Object)0);
            }
            if (!Intrinsics.c((Object)this.l, (Object)friendModel.l)) {
                arrayList.add((Object)1);
            }
            if (this.m != friendModel.m) {
                arrayList.add((Object)2);
            }
            if (this.n != friendModel.n) {
                arrayList.add((Object)3);
            }
            if (this.o != friendModel.o) {
                arrayList.add((Object)4);
            }
            if (this.p != friendModel.p) {
                arrayList.add((Object)5);
            }
            if (this.q != friendModel.q) {
                arrayList.add((Object)6);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        block10 : {
            block13 : {
                Int n;
                AppCompatImageView appCompatImageView;
                block12 : {
                    Bool bl;
                    block11 : {
                        String string;
                        if (a.z((View)view, (String)"view", list, (String)"payloads", (Int)0)) {
                            ((TextView)view.findViewById(2131362548)).setText((CharSequence)this.k);
                        }
                        if (list.contains((Object)1) && (string = this.l) != null) {
                            AppCompatImageView appCompatImageView2 = (AppCompatImageView)view.findViewById(2131361916);
                            Intrinsics.g((Object)appCompatImageView2, (String)"view.avatar");
                            ViewsKt.a((AppCompatImageView)appCompatImageView2, (String)string);
                        }
                        if (list.contains((Object)2)) {
                            AppCompatImageView appCompatImageView3 = (AppCompatImageView)view.findViewById(2131362389);
                            Intrinsics.g((Object)appCompatImageView3, (String)"view.isOnline");
                            ViewsKt.l((View)appCompatImageView3, (Bool)this.m);
                        }
                        if (list.contains((Object)3)) {
                            TextView textView = (TextView)view.findViewById(2131362924);
                            Intrinsics.g((Object)textView, (String)"bind$lambda$1");
                            Int n2 = this.n;
                            Bool bl2 = false;
                            if (n2 > 0) {
                                bl2 = true;
                            }
                            ViewsKt.l((View)textView, (Bool)bl2);
                            Plurals plurals = Plurals.a;
                            Context context = view.getContext();
                            Intrinsics.g((Object)context, (String)"view.context");
                            textView.setText((CharSequence)plurals.b(context, this.n, 2131820552, 2131952031));
                        }
                        if (list.contains((Object)4)) {
                            AppCompatImageView appCompatImageView4 = (AppCompatImageView)view.findViewById(2131362872);
                            Intrinsics.g((Object)appCompatImageView4, (String)"view.sponsor");
                            ViewsKt.l((View)appCompatImageView4, (Bool)this.o);
                        }
                        if (list.contains((Object)5)) {
                            AppCompatImageView appCompatImageView5 = (AppCompatImageView)view.findViewById(2131363094);
                            Intrinsics.g((Object)appCompatImageView5, (String)"view.verified");
                            ViewsKt.l((View)appCompatImageView5, (Bool)this.p);
                        }
                        if (!list.contains((Object)6)) break block10;
                        appCompatImageView = (AppCompatImageView)view.findViewById(2131362487);
                        bl = this.q;
                        if (!bl) break block11;
                        n = ViewsKt.c((View)view, (Int)2130968827);
                        break block12;
                    }
                    if (bl) break block13;
                    n = ViewsKt.c((View)view, (Int)2130969187);
                }
                appCompatImageView.setColorFilter(n);
                return;
            }
            throw new NoWhenBranchMatchedException();
        }
    }

    func v2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        view.setOnClickListener(null);
    }
}

