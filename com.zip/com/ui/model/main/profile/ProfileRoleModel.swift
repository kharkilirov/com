/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Color
 *  android.graphics.drawable.Drawable
 *  android.view.View
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.appcompat.content.res.AppCompatResources
 *  androidx.core.graphics.drawable.DrawableCompat
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.model.main.profile.ProfileRoleModel$Listener
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.model.main.profile;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.core.graphics.drawable.DrawableCompat;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.model.main.profile.ProfileRoleModel;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/profile/ProfileRoleModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class ProfileRoleModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    @NotNull
    String k = "";
    @EpoxyAttribute
    @NotNull
    String l = "";
    @EpoxyAttribute
    Listener m;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        ((TextView)view.findViewById(2131362525)).setText((CharSequence)this.k);
        try {
            Drawable drawable = AppCompatResources.b((Context)context, (Int)2131230920);
            Intrinsics.e((Object)drawable);
            Drawable drawable2 = DrawableCompat.q((Drawable)drawable);
            Intrinsics.g((Object)drawable2, (String)"wrap(unwrappedDrawable!!)");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append('#');
            stringBuilder.append(this.l);
            DrawableCompat.m((Drawable)drawable2, (Int)Color.parseColor((String)stringBuilder.toString()));
            view.setBackground(drawable2);
            ImageView imageView = (ImageView)view.findViewById(2131362164);
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append('#');
            stringBuilder2.append(this.l);
            imageView.setColorFilter(Color.parseColor((String)stringBuilder2.toString()));
            TextView textView = (TextView)view.findViewById(2131362525);
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append('#');
            stringBuilder3.append(this.l);
            textView.setTextColor(Color.parseColor((String)stringBuilder3.toString()));
        }
        catch (Exception exception) {}
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof ProfileRoleModel) {
            String string = this.k;
            ProfileRoleModel profileRoleModel = (ProfileRoleModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)profileRoleModel.k)) {
                arrayList.add((Object)0);
            }
            if (!Intrinsics.c((Object)this.l, (Object)profileRoleModel.l)) {
                arrayList.add((Object)1);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    /*
     * Exception decompiling
     */
    func u2(@NotNull View var1, @NotNull List<Object> var2) -> void {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1145)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:644)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }
}

