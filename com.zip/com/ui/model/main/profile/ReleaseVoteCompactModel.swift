/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.View
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.RatingBar
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.model.main.profile.ReleaseVoteCompactModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.profile.ReleaseVoteCompactModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.profile.ReleaseVoteCompactModel$bind$3
 *  com.swiftsoft.anixartd.utils.Time
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.profile;

import android.content.Context;
import android.os.Build;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.model.main.profile.ReleaseVoteCompactModel;
import com.swiftsoft.anixartd.utils.Time;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/profile/ReleaseVoteCompactModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class ReleaseVoteCompactModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    @Nullable
    String k;
    @EpoxyAttribute
    @Nullable
    Integer l = 0;
    @EpoxyAttribute
    long m;
    @EpoxyAttribute
    @Nullable
    String n = "";
    @EpoxyAttribute
    Listener o;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        ((TextView)view.findViewById(2131363004)).setText((CharSequence)this.k);
        TextView textView = (TextView)view.findViewById(2131363137);
        Time time = Time.a;
        Context context2 = view.getContext();
        Intrinsics.g((Object)context2, (String)"view.context");
        textView.setText((CharSequence)time.g(context2, this.m));
        Integer n = this.l;
        if (n != null) {
            Int n2 = n;
            if (Build.VERSION.SDK_INT == 28) {
                RatingBar ratingBar = (RatingBar)view.findViewById(2131362657);
                Intrinsics.g((Object)ratingBar, (String)"view.rating_bar");
                ViewsKt.e((View)ratingBar);
                LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362658);
                Intrinsics.g((Object)linearLayout, (String)"view.rating_bar_text");
                ViewsKt.k((View)linearLayout);
            }
            ((RatingBar)view.findViewById(2131362657)).setRating((Float)n2);
            TextView textView2 = (TextView)view.findViewById(2131362663);
            String string = context.getString(2131952377);
            Intrinsics.g((Object)string, (String)"context.getString(R.string.rating_text)");
            Object[] arrobject = new Object[]{n2};
            a.y((Object[])arrobject, (Int)1, (String)string, (String)"format(format, *args)", (TextView)textView2);
        }
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362613);
        Intrinsics.g((Object)appCompatImageView, (String)"view.poster");
        ViewsKt.h((ImageView)appCompatImageView, (String)this.n);
        ViewsKt.j((View)view, (Function1)new bind.3(this));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof ReleaseVoteCompactModel) {
            String string = this.k;
            ReleaseVoteCompactModel releaseVoteCompactModel = (ReleaseVoteCompactModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)releaseVoteCompactModel.k)) {
                arrayList.add((Object)0);
            }
            if (this.m != releaseVoteCompactModel.m) {
                arrayList.add((Object)1);
            }
            if (!Intrinsics.c((Object)this.l, (Object)releaseVoteCompactModel.l)) {
                arrayList.add((Object)2);
            }
            if (!Intrinsics.c((Object)this.n, (Object)releaseVoteCompactModel.n)) {
                arrayList.add((Object)5);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        Integer n;
        Context context = a.b((View)view, (String)"view", list, (String)"payloads");
        if (list.contains((Object)0)) {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)this.k);
        }
        if (list.contains((Object)1)) {
            TextView textView = (TextView)view.findViewById(2131363137);
            Time time = Time.a;
            Context context2 = view.getContext();
            Intrinsics.g((Object)context2, (String)"view.context");
            textView.setText((CharSequence)time.g(context2, this.m));
        }
        if (list.contains((Object)2) && (n = this.l) != null) {
            Int n2 = n;
            if (Build.VERSION.SDK_INT == 28) {
                RatingBar ratingBar = (RatingBar)view.findViewById(2131362657);
                Intrinsics.g((Object)ratingBar, (String)"view.rating_bar");
                ViewsKt.e((View)ratingBar);
                LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362658);
                Intrinsics.g((Object)linearLayout, (String)"view.rating_bar_text");
                ViewsKt.k((View)linearLayout);
            }
            ((RatingBar)view.findViewById(2131362657)).setRating((Float)n2);
            TextView textView = (TextView)view.findViewById(2131362663);
            String string = context.getString(2131952377);
            Intrinsics.g((Object)string, (String)"context.getString(R.string.rating_text)");
            Object[] arrobject = new Object[]{n2};
            a.y((Object[])arrobject, (Int)1, (String)string, (String)"format(format, *args)", (TextView)textView);
        }
        if (list.contains((Object)3)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362613);
            Intrinsics.g((Object)appCompatImageView, (String)"view.poster");
            ViewsKt.h((ImageView)appCompatImageView, (String)this.n);
        }
    }

    func v2(@NotNull View view) -> void {
        a.p((View)view, (String)"view", null, null);
    }
}

