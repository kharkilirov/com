/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.RelativeLayout
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.android.material.button.MaterialButton
 *  com.swiftsoft.anixartd.ui.model.main.profile.vote.ExtraReleaseUnvotedModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.profile.vote.a
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.model.main.profile.vote;

import android.view.View;
import android.widget.RelativeLayout;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.android.material.button.MaterialButton;
import com.swiftsoft.anixartd.ui.model.main.profile.vote.ExtraReleaseUnvotedModel;
import com.swiftsoft.anixartd.ui.model.main.profile.vote.a;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u0003\u00a8\u0006\u0004"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/profile/vote/ExtraReleaseUnvotedModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class ExtraReleaseUnvotedModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    Listener k;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        ((RelativeLayout)view.findViewById(2131363077)).setOnClickListener((View.OnClickListener)new a(this, 0));
        ((MaterialButton)view.findViewById(2131361982)).setOnClickListener((View.OnClickListener)new a(this, 1));
    }

    func u2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        ((MaterialButton)view.findViewById(2131361982)).setOnClickListener(null);
    }
}

