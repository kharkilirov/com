/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnLongClickListener
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.RatingBar
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.fragment.main.profile.d
 *  com.swiftsoft.anixartd.ui.model.main.profile.vote.ReleaseVoteModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.profile.vote.ReleaseVoteModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.profile.vote.ReleaseVoteModel$bind$10
 *  com.swiftsoft.anixartd.ui.model.main.profile.vote.ReleaseVoteModel$bind$12
 *  com.swiftsoft.anixartd.ui.model.main.profile.vote.ReleaseVoteModel$bind$4
 *  com.swiftsoft.anixartd.ui.model.main.profile.vote.ReleaseVoteModel$bind$5
 *  com.swiftsoft.anixartd.ui.model.main.profile.vote.ReleaseVoteModel$bind$6
 *  com.swiftsoft.anixartd.ui.model.main.profile.vote.ReleaseVoteModel$bind$7
 *  com.swiftsoft.anixartd.ui.model.main.profile.vote.ReleaseVoteModel$bind$8
 *  com.swiftsoft.anixartd.ui.model.main.profile.vote.ReleaseVoteModel$bind$9
 *  com.swiftsoft.anixartd.utils.DigitsKt
 *  com.swiftsoft.anixartd.utils.Time
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Double
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.profile.vote;

import android.content.Context;
import android.os.Build;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.fragment.main.profile.d;
import com.swiftsoft.anixartd.ui.model.main.profile.vote.ReleaseVoteModel;
import com.swiftsoft.anixartd.utils.DigitsKt;
import com.swiftsoft.anixartd.utils.Time;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/profile/vote/ReleaseVoteModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class ReleaseVoteModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    @Nullable
    String k = "";
    @EpoxyAttribute
    @Nullable
    Integer l;
    @EpoxyAttribute
    @Nullable
    Integer m;
    @EpoxyAttribute
    @Nullable
    Double n;
    @EpoxyAttribute
    @Nullable
    String o;
    @EpoxyAttribute
    Bool p;
    @EpoxyAttribute
    Int q;
    @EpoxyAttribute
    @Nullable
    Integer r;
    @EpoxyAttribute
    long s;
    @EpoxyAttribute
    Bool t;
    @EpoxyAttribute
    Bool u;
    @EpoxyAttribute
    Listener v;

    init() {
        Integer n;
        this.l = n = Integer.valueOf((Int)0);
        this.m = n;
        this.n = 0.0;
        this.o = "";
        this.r = n;
        this.t = true;
    }

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        String string = this.k;
        Integer n = this.l;
        Integer n2 = this.m;
        Double d2 = this.n;
        Bool bl = this.p;
        Int n3 = this.q;
        Integer n4 = this.r;
        long l = this.s;
        Bool bl2 = this.t;
        ImageView imageView = (ImageView)view.findViewById(2131362281);
        Int n5 = bl ? 0 : 8;
        imageView.setVisibility(n5);
        if (n3 != 0) {
            RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362918);
            Intrinsics.g((Object)relativeLayout, (String)"view.status_layout");
            ViewsKt.m((View)relativeLayout, (Bool)true);
            if (n3 != 1) {
                if (n3 != 2) {
                    if (n3 != 3) {
                        if (n3 != 4) {
                            if (n3 == 5) {
                                ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0431\u0440\u043e\u0448\u0435\u043d\u043e");
                                a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131100607, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                            }
                        } else {
                            ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u043e\u0442\u043b\u043e\u0436\u0435\u043d\u043e");
                            a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131100687, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                        }
                    } else {
                        ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u043f\u0440\u043e\u0441\u043c\u043e\u0442\u0440\u0435\u043d\u043e");
                        a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131099691, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                    }
                } else {
                    ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0432 \u043f\u043b\u0430\u043d\u0430\u0445");
                    a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131100604, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                }
            } else {
                ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0441\u043c\u043e\u0442\u0440\u044e");
                a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131099809, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
            }
        } else {
            RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362918);
            Intrinsics.g((Object)relativeLayout, (String)"view.status_layout");
            ViewsKt.m((View)relativeLayout, (Bool)false);
        }
        Bool bl3 = string == null || string.length() == 0;
        if (bl3) {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)"\u0411\u0435\u0437 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u044f");
        } else {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)string);
        }
        if (n != null && n2 != null && Intrinsics.c((Object)n, (Object)n2)) {
            TextView textView = (TextView)a.g((Integer)n2, (String)" \u044d\u043f", (TextView)((TextView)view.findViewById(2131362200)), (View)view, (Int)2131362200);
            TextView textView2 = (TextView)a.C((TextView)textView, (String)"view.episodes", (TextView)textView, (View)view, (Int)2131362164);
            Intrinsics.g((Object)textView2, (String)"view.dot");
            ViewsKt.k((View)textView2);
        } else if (n != null && n2 != null) {
            a.t((Integer)n, (String)" \u0438\u0437 ", (Integer)n2, (String)" \u044d\u043f", (TextView)((TextView)view.findViewById(2131362200)));
            TextView textView = (TextView)view.findViewById(2131362200);
            TextView textView3 = (TextView)a.C((TextView)textView, (String)"view.episodes", (TextView)textView, (View)view, (Int)2131362164);
            Intrinsics.g((Object)textView3, (String)"view.dot");
            ViewsKt.k((View)textView3);
        } else if (n != null && n2 == null) {
            TextView textView = (TextView)a.g((Integer)n, (String)" \u0438\u0437 ? \u044d\u043f", (TextView)((TextView)view.findViewById(2131362200)), (View)view, (Int)2131362200);
            TextView textView4 = (TextView)a.C((TextView)textView, (String)"view.episodes", (TextView)textView, (View)view, (Int)2131362164);
            Intrinsics.g((Object)textView4, (String)"view.dot");
            ViewsKt.k((View)textView4);
        } else if (n == null && n2 != null) {
            a.u((String)"? \u0438\u0437 ", (Integer)n2, (String)" \u044d\u043f", (TextView)((TextView)view.findViewById(2131362200)));
            TextView textView = (TextView)view.findViewById(2131362200);
            TextView textView5 = (TextView)a.C((TextView)textView, (String)"view.episodes", (TextView)textView, (View)view, (Int)2131362164);
            Intrinsics.g((Object)textView5, (String)"view.dot");
            ViewsKt.k((View)textView5);
        } else {
            TextView textView = (TextView)view.findViewById(2131362200);
            TextView textView6 = (TextView)a.f((TextView)textView, (String)"view.episodes", (TextView)textView, (View)view, (Int)2131362164);
            Intrinsics.g((Object)textView6, (String)"view.dot");
            ViewsKt.e((View)textView6);
        }
        LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362662);
        Intrinsics.g((Object)linearLayout, (String)"view.rating_layout");
        ViewsKt.l((View)linearLayout, (Bool)this.u);
        if (d2 != null) {
            a.s((Double)d2, (Int)0, (Int)1, (TextView)((TextView)view.findViewById(2131362324)));
        }
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362613);
        Intrinsics.g((Object)appCompatImageView, (String)"view.poster");
        ViewsKt.h((ImageView)appCompatImageView, (String)this.o);
        LinearLayout linearLayout2 = (LinearLayout)view.findViewById(2131362419);
        Intrinsics.g((Object)linearLayout2, (String)"view.layout_no_voted");
        Bool bl4 = n4 != null;
        ViewsKt.f((View)linearLayout2, (Bool)bl4, (Bool)false, null, (Int)6);
        LinearLayout linearLayout3 = (LinearLayout)view.findViewById(2131362420);
        Intrinsics.g((Object)linearLayout3, (String)"view.layout_voted");
        Bool bl5 = n4 != null;
        ViewsKt.l((View)linearLayout3, (Bool)bl5);
        LinearLayout linearLayout4 = (LinearLayout)view.findViewById(2131362117);
        Intrinsics.g((Object)linearLayout4, (String)"view.deleteVoteLayout");
        ViewsKt.l((View)linearLayout4, (Bool)bl2);
        if (n4 != null) {
            Int n6 = n4;
            if (Build.VERSION.SDK_INT == 28) {
                RatingBar ratingBar = (RatingBar)view.findViewById(2131362657);
                Intrinsics.g((Object)ratingBar, (String)"view.rating_bar");
                ViewsKt.e((View)ratingBar);
                LinearLayout linearLayout5 = (LinearLayout)view.findViewById(2131362658);
                Intrinsics.g((Object)linearLayout5, (String)"view.rating_bar_text");
                ViewsKt.k((View)linearLayout5);
            }
            ((RatingBar)view.findViewById(2131362657)).setRating((Float)n6);
            TextView textView = (TextView)view.findViewById(2131362663);
            String string2 = context.getString(2131952377);
            Intrinsics.g((Object)string2, (String)"context.getString(R.string.rating_text)");
            Object[] arrobject = new Object[]{n6};
            a.y((Object[])arrobject, (Int)1, (String)string2, (String)"format(format, *args)", (TextView)textView);
        }
        TextView textView = (TextView)view.findViewById(2131363068);
        Time time = Time.a;
        Intrinsics.g((Object)context, (String)"context");
        textView.setText((CharSequence)time.g(context, l));
        AppCompatImageView appCompatImageView2 = (AppCompatImageView)view.findViewById(2131362889);
        Intrinsics.g((Object)appCompatImageView2, (String)"view.star1");
        ViewsKt.j((View)appCompatImageView2, (Function1)new bind.4(view, this));
        AppCompatImageView appCompatImageView3 = (AppCompatImageView)view.findViewById(2131362890);
        Intrinsics.g((Object)appCompatImageView3, (String)"view.star2");
        ViewsKt.j((View)appCompatImageView3, (Function1)new bind.5(view, this));
        AppCompatImageView appCompatImageView4 = (AppCompatImageView)view.findViewById(2131362891);
        Intrinsics.g((Object)appCompatImageView4, (String)"view.star3");
        ViewsKt.j((View)appCompatImageView4, (Function1)new bind.6(view, this));
        AppCompatImageView appCompatImageView5 = (AppCompatImageView)view.findViewById(2131362892);
        Intrinsics.g((Object)appCompatImageView5, (String)"view.star4");
        ViewsKt.j((View)appCompatImageView5, (Function1)new bind.7(view, this));
        AppCompatImageView appCompatImageView6 = (AppCompatImageView)view.findViewById(2131362893);
        Intrinsics.g((Object)appCompatImageView6, (String)"view.star5");
        ViewsKt.j((View)appCompatImageView6, (Function1)new bind.8(view, this));
        LinearLayout linearLayout6 = (LinearLayout)view.findViewById(2131361965);
        Intrinsics.g((Object)linearLayout6, (String)"view.btnDeleteVote");
        ViewsKt.j((View)linearLayout6, (Function1)new bind.9(this));
        ViewsKt.j((View)view, (Function1)new bind.10(this));
        view.setOnLongClickListener((View.OnLongClickListener)new d((Object)this, 13));
        ImageView imageView2 = (ImageView)view.findViewById(2131362497);
        Intrinsics.g((Object)imageView2, (String)"view.more");
        ViewsKt.j((View)imageView2, (Function1)new bind.12(this));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof ReleaseVoteModel) {
            String string = this.k;
            ReleaseVoteModel releaseVoteModel = (ReleaseVoteModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)releaseVoteModel.k)) {
                arrayList.add((Object)0);
            }
            if (!Intrinsics.c((Object)this.l, (Object)releaseVoteModel.l)) {
                arrayList.add((Object)1);
            }
            if (!Intrinsics.c((Object)this.m, (Object)releaseVoteModel.m)) {
                arrayList.add((Object)2);
            }
            if (!Intrinsics.a((Double)this.n, (Double)releaseVoteModel.n)) {
                arrayList.add((Object)3);
            }
            if (!Intrinsics.c((Object)this.o, (Object)releaseVoteModel.o)) {
                arrayList.add((Object)4);
            }
            if (this.p != releaseVoteModel.p) {
                arrayList.add((Object)5);
            }
            if (this.q != releaseVoteModel.q) {
                arrayList.add((Object)6);
            }
            if (!Intrinsics.c((Object)this.r, (Object)releaseVoteModel.r)) {
                arrayList.add((Object)7);
            }
            if (this.s != releaseVoteModel.s) {
                arrayList.add((Object)8);
            }
            if (this.u != releaseVoteModel.u) {
                arrayList.add((Object)9);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        Integer n;
        Double d2;
        Context context = a.b((View)view, (String)"view", list, (String)"payloads");
        if (list.contains((Object)0)) {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)this.k);
        }
        if (list.contains((Object)1)) {
            TextView textView = (TextView)view.findViewById(2131362200);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append((Object)this.l);
            stringBuilder.append(" \u0438\u0437 ");
            a.w((StringBuilder)stringBuilder, (Integer)this.m, (TextView)textView);
        }
        if (list.contains((Object)2)) {
            TextView textView = (TextView)view.findViewById(2131362200);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append((Object)this.l);
            stringBuilder.append(" \u0438\u0437 ");
            a.w((StringBuilder)stringBuilder, (Integer)this.m, (TextView)textView);
        }
        if (list.contains((Object)3) && (d2 = this.n) != null) {
            Double d3 = d2;
            ((TextView)view.findViewById(2131362324)).setText((CharSequence)DigitsKt.d((Double)d3, (Int)0, (Int)1));
        }
        if (list.contains((Object)4)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362613);
            Intrinsics.g((Object)appCompatImageView, (String)"view.poster");
            ViewsKt.h((ImageView)appCompatImageView, (String)this.o);
        }
        if (list.contains((Object)5)) {
            ImageView imageView = (ImageView)view.findViewById(2131362281);
            Int n2 = this.p ? 0 : 8;
            imageView.setVisibility(n2);
        }
        if (list.contains((Object)6)) {
            if (this.q != 0) {
                RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362918);
                Intrinsics.g((Object)relativeLayout, (String)"view.status_layout");
                ViewsKt.m((View)relativeLayout, (Bool)true);
                Int n3 = this.q;
                if (n3 != 1) {
                    if (n3 != 2) {
                        if (n3 != 3) {
                            if (n3 != 4) {
                                if (n3 == 5) {
                                    ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0431\u0440\u043e\u0448\u0435\u043d\u043e");
                                    a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131100607, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                                }
                            } else {
                                ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u043e\u0442\u043b\u043e\u0436\u0435\u043d\u043e");
                                a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131100687, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                            }
                        } else {
                            ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u043f\u0440\u043e\u0441\u043c\u043e\u0442\u0440\u0435\u043d\u043e");
                            a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131099691, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                        }
                    } else {
                        ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0432 \u043f\u043b\u0430\u043d\u0430\u0445");
                        a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131100604, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                    }
                } else {
                    ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0441\u043c\u043e\u0442\u0440\u044e");
                    a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131099809, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                }
            } else {
                RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362918);
                Intrinsics.g((Object)relativeLayout, (String)"view.status_layout");
                ViewsKt.m((View)relativeLayout, (Bool)false);
            }
        }
        if (list.contains((Object)7) && ((n = this.r) == null || n != 0)) {
            LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362419);
            Intrinsics.g((Object)linearLayout, (String)"view.layout_no_voted");
            Bool bl = this.r != null;
            ViewsKt.f((View)linearLayout, (Bool)bl, (Bool)false, null, (Int)6);
            LinearLayout linearLayout2 = (LinearLayout)view.findViewById(2131362420);
            Intrinsics.g((Object)linearLayout2, (String)"view.layout_voted");
            Bool bl2 = this.r != null;
            ViewsKt.l((View)linearLayout2, (Bool)bl2);
            Integer n4 = this.r;
            if (n4 != null) {
                Int n5 = n4;
                if (Build.VERSION.SDK_INT == 28) {
                    RatingBar ratingBar = (RatingBar)view.findViewById(2131362657);
                    Intrinsics.g((Object)ratingBar, (String)"view.rating_bar");
                    ViewsKt.e((View)ratingBar);
                    LinearLayout linearLayout3 = (LinearLayout)view.findViewById(2131362658);
                    Intrinsics.g((Object)linearLayout3, (String)"view.rating_bar_text");
                    ViewsKt.k((View)linearLayout3);
                }
                ((RatingBar)view.findViewById(2131362657)).setRating((Float)n5);
                TextView textView = (TextView)view.findViewById(2131362663);
                String string = context.getString(2131952377);
                Intrinsics.g((Object)string, (String)"context.getString(R.string.rating_text)");
                Object[] arrobject = new Object[]{n5};
                a.y((Object[])arrobject, (Int)1, (String)string, (String)"format(format, *args)", (TextView)textView);
            }
        }
        if (list.contains((Object)8) && this.s != 0L) {
            TextView textView = (TextView)view.findViewById(2131363068);
            Time time = Time.a;
            Intrinsics.g((Object)context, (String)"context");
            textView.setText((CharSequence)time.g(context, this.s));
        }
        if (list.contains((Object)9)) {
            LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362662);
            Intrinsics.g((Object)linearLayout, (String)"view.rating_layout");
            ViewsKt.l((View)linearLayout, (Bool)this.u);
        }
    }

    @NotNull
    final Listener v2() {
        Listener listener = this.v;
        if (listener != null) {
            return listener;
        }
        Intrinsics.r((String)"listener");
        throw null;
    }

    func w2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        view.setOnClickListener(null);
        view.setOnLongClickListener(null);
        ((ImageView)view.findViewById(2131362497)).setOnClickListener(null);
    }
}

