/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.epoxy.EpoxyBuildScope
 *  java.lang.Object
 */
package com.swiftsoft.anixartd.ui.model.main.profile.vote;

import com.airbnb.epoxy.EpoxyBuildScope;

@EpoxyBuildScope
interface ExtraReleaseUnvotedModelBuilder {
}

