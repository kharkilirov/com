/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.MenuItem
 *  android.view.View
 *  android.widget.TextView
 *  androidx.appcompat.widget.PopupMenu
 *  androidx.appcompat.widget.PopupMenu$OnMenuItemClickListener
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.model.main.profile.vote.ExtraReleaseVoteModel$Listener
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.internal.Intrinsics
 */
package com.swiftsoft.anixartd.ui.model.main.profile.vote;

import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.widget.PopupMenu;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.model.main.profile.vote.ExtraReleaseVoteModel;
import kotlin.jvm.internal.Intrinsics;

final class b
implements PopupMenu.OnMenuItemClickListener {
    final /* synthetic */ ExtraReleaseVoteModel b;
    final /* synthetic */ View c;

    /* synthetic */ b(ExtraReleaseVoteModel extraReleaseVoteModel, View view) {
        this.b = extraReleaseVoteModel;
        this.c = view;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     */
    final Bool onMenuItemClick(MenuItem var1_1) {
        var2_2 = this.b;
        var3_3 = this.c;
        Intrinsics.h((Object)var2_2, (String)"this$0");
        Intrinsics.h((Object)var3_3, (String)"$view");
        var4_4 = var1_1.getItemId();
        if (var4_4 != 2131363131) {
            switch (var4_4) {
                default: {
                    switch (var4_4) {
                        default: {
                            ** break;
                        }
                        case 2131363136: {
                            var2_2.u2().a(6);
                            ** break;
                        }
                        case 2131363135: 
                    }
                    var2_2.u2().a(5);
                    ** break;
                }
                case 2131363126: {
                    var2_2.u2().a(4);
                    ** break;
                }
                case 2131363125: {
                    var2_2.u2().a(3);
                    ** break;
                }
                case 2131363124: {
                    var2_2.u2().a(1);
                    ** break;
                }
                case 2131363123: 
            }
            var2_2.u2().a(2);
            ** break;
lbl30: // 7 sources:
        } else {
            var2_2.u2().a(7);
        }
        a.m((MenuItem)var1_1, (TextView)((TextView)var3_3.findViewById(2131362799)));
        return true;
    }
}

