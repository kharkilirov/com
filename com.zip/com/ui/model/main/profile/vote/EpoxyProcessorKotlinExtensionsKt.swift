/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.Metadata
 */
package com.swiftsoft.anixartd.ui.model.main.profile.vote;

import kotlin.Metadata;

@Metadata(bv={}, d1={"\u0000\u0002\n\u0000\u00a8\u0006\u0000"}, d2={"app_release"}, k=2, mv={1, 7, 1})
final class EpoxyProcessorKotlinExtensionsKt {
}

