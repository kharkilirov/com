/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.internal.Intrinsics
 */
package com.swiftsoft.anixartd.ui.model.main.profile.vote;

import android.view.View;
import com.swiftsoft.anixartd.ui.model.main.profile.vote.ExtraReleaseUnvotedModel;
import kotlin.jvm.internal.Intrinsics;

final class a
implements View.OnClickListener {
    final /* synthetic */ Int b;
    final /* synthetic */ ExtraReleaseUnvotedModel c;

    /* synthetic */ a(ExtraReleaseUnvotedModel extraReleaseUnvotedModel, Int n) {
        this.b = n;
        this.c = extraReleaseUnvotedModel;
    }

    final void onClick(View view) {
        switch (this.b) {
            default: {
                break;
            }
            case 0: {
                ExtraReleaseUnvotedModel extraReleaseUnvotedModel = this.c;
                Intrinsics.h((Object)((Object)extraReleaseUnvotedModel), (String)"this$0");
                ExtraReleaseUnvotedModel.Listener listener = extraReleaseUnvotedModel.k;
                if (listener != null) {
                    listener.h0();
                    return;
                }
                Intrinsics.r((String)"listener");
                throw null;
            }
        }
        ExtraReleaseUnvotedModel extraReleaseUnvotedModel = this.c;
        Intrinsics.h((Object)((Object)extraReleaseUnvotedModel), (String)"this$0");
        ExtraReleaseUnvotedModel.Listener listener = extraReleaseUnvotedModel.k;
        if (listener != null) {
            listener.h0();
            return;
        }
        Intrinsics.r((String)"listener");
        throw null;
    }
}

