/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.utils.DigitsKt
 *  com.swiftsoft.anixartd.utils.Time
 *  java.lang.CharSequence
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Objects
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.model.main.profile;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.utils.DigitsKt;
import com.swiftsoft.anixartd.utils.Time;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u0003\u00a8\u0006\u0004"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/profile/WatchDynamicsModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class WatchDynamicsModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    Int k;
    @EpoxyAttribute
    Int l;
    @EpoxyAttribute
    long m;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        ((TextView)view.findViewById(2131362075)).setText((CharSequence)String.valueOf((Int)this.k));
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362630);
        Intrinsics.g((Object)appCompatImageView, (String)"view.progress");
        ViewGroup.LayoutParams layoutParams = appCompatImageView.getLayoutParams();
        Objects.requireNonNull((Object)layoutParams, (String)"null cannot be cast to non-null type android.view.ViewGroup.LayoutParams");
        layoutParams.height = Math.max((Int)((Int)((Double)(DigitsKt.c((Int)100, (View)view) * this.k) / (Double)this.l)), (Int)DigitsKt.c((Int)10, (View)view));
        appCompatImageView.setLayoutParams(layoutParams);
        ((TextView)view.findViewById(2131362110)).setText((CharSequence)Time.a.d(this.m));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof WatchDynamicsModel) {
            Int n = this.k;
            WatchDynamicsModel watchDynamicsModel = (WatchDynamicsModel)epoxyModel;
            if (n != watchDynamicsModel.k) {
                arrayList.add((Object)0);
            }
            if (this.l != watchDynamicsModel.l) {
                arrayList.add((Object)1);
            }
            if (this.m != watchDynamicsModel.m) {
                arrayList.add((Object)2);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        if (a.z((View)view, (String)"view", list, (String)"payloads", (Int)0)) {
            ((TextView)view.findViewById(2131362075)).setText((CharSequence)String.valueOf((Int)this.k));
        }
        if (list.contains((Object)1)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362630);
            Intrinsics.g((Object)appCompatImageView, (String)"view.progress");
            ViewGroup.LayoutParams layoutParams = appCompatImageView.getLayoutParams();
            Objects.requireNonNull((Object)layoutParams, (String)"null cannot be cast to non-null type android.view.ViewGroup.LayoutParams");
            layoutParams.height = Math.max((Int)((Int)((Double)(DigitsKt.c((Int)100, (View)view) * this.k) / (Double)this.l)), (Int)DigitsKt.c((Int)10, (View)view));
            appCompatImageView.setLayoutParams(layoutParams);
        }
        if (list.contains((Object)2)) {
            ((TextView)view.findViewById(2131362110)).setText((CharSequence)Time.a.d(this.m));
        }
    }
}

