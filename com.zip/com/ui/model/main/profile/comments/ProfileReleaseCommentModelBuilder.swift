/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.epoxy.EpoxyBuildScope
 *  java.lang.Object
 *  java.lang.String
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.profile.comments;

import com.airbnb.epoxy.EpoxyBuildScope;
import com.swiftsoft.anixartd.ui.model.main.profile.comments.ProfileReleaseCommentModel;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@EpoxyBuildScope
interface ProfileReleaseCommentModelBuilder {
    ProfileReleaseCommentModelBuilder B(long var1);

    ProfileReleaseCommentModelBuilder E(Bool var1);

    ProfileReleaseCommentModelBuilder K(long var1);

    ProfileReleaseCommentModelBuilder W(long var1);

    ProfileReleaseCommentModelBuilder b(long var1);

    ProfileReleaseCommentModelBuilder i1(ProfileReleaseCommentModel.Listener var1);

    ProfileReleaseCommentModelBuilder k(@NotNull String var1);

    ProfileReleaseCommentModelBuilder l(@Nullable String var1);

    ProfileReleaseCommentModelBuilder p(Bool var1);

    ProfileReleaseCommentModelBuilder r(Bool var1);

    ProfileReleaseCommentModelBuilder t(long var1);

    ProfileReleaseCommentModelBuilder u(Bool var1);

    ProfileReleaseCommentModelBuilder v(@NotNull String var1);

    ProfileReleaseCommentModelBuilder w(Bool var1);

    ProfileReleaseCommentModelBuilder w0(@Nullable String var1);

    ProfileReleaseCommentModelBuilder x(Int var1);

    ProfileReleaseCommentModelBuilder y(long var1);
}

