/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.epoxy.EpoxyBuildScope
 *  java.lang.Object
 *  java.lang.String
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.profile.comments;

import com.airbnb.epoxy.EpoxyBuildScope;
import com.swiftsoft.anixartd.ui.model.main.profile.comments.ProfileCollectionCommentModel;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@EpoxyBuildScope
interface ProfileCollectionCommentModelBuilder {
    ProfileCollectionCommentModelBuilder B(long var1);

    ProfileCollectionCommentModelBuilder E(Bool var1);

    ProfileCollectionCommentModelBuilder I1(long var1);

    ProfileCollectionCommentModelBuilder K(long var1);

    ProfileCollectionCommentModelBuilder W(long var1);

    ProfileCollectionCommentModelBuilder W0(@Nullable String var1);

    ProfileCollectionCommentModelBuilder a0(ProfileCollectionCommentModel.Listener var1);

    ProfileCollectionCommentModelBuilder b(long var1);

    ProfileCollectionCommentModelBuilder k(@NotNull String var1);

    ProfileCollectionCommentModelBuilder l(@Nullable String var1);

    ProfileCollectionCommentModelBuilder p(Bool var1);

    ProfileCollectionCommentModelBuilder r(Bool var1);

    ProfileCollectionCommentModelBuilder t(long var1);

    ProfileCollectionCommentModelBuilder u(Bool var1);

    ProfileCollectionCommentModelBuilder v(@NotNull String var1);

    ProfileCollectionCommentModelBuilder w(Bool var1);

    ProfileCollectionCommentModelBuilder x(Int var1);
}

