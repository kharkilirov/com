/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.model.main.profile.comments.ProfileCollectionCommentModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.profile.comments.ProfileCollectionCommentModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.profile.comments.ProfileCollectionCommentModel$bind$10
 *  com.swiftsoft.anixartd.ui.model.main.profile.comments.ProfileCollectionCommentModel$bind$9
 *  com.swiftsoft.anixartd.ui.model.main.profile.comments.b
 *  com.swiftsoft.anixartd.utils.Time
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.jvm.internal.Ref
 *  kotlin.jvm.internal.Ref$BooleanRef
 *  kotlin.text.StringsKt
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.profile.comments;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.model.main.profile.comments.ProfileCollectionCommentModel;
import com.swiftsoft.anixartd.ui.model.main.profile.comments.b;
import com.swiftsoft.anixartd.utils.Time;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/profile/comments/ProfileCollectionCommentModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class ProfileCollectionCommentModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    long k;
    @EpoxyAttribute
    long l;
    @EpoxyAttribute
    long m;
    @EpoxyAttribute
    long n;
    @EpoxyAttribute
    @Nullable
    String o = "";
    @EpoxyAttribute
    @NotNull
    String p = "";
    @EpoxyAttribute
    Bool q;
    @EpoxyAttribute
    Int r;
    @EpoxyAttribute
    long s;
    @EpoxyAttribute
    Bool t;
    @EpoxyAttribute
    Bool u;
    @EpoxyAttribute
    @NotNull
    String v = "";
    @EpoxyAttribute
    @Nullable
    String w = "";
    @EpoxyAttribute
    Bool x;
    @EpoxyAttribute
    Bool y;
    @EpoxyAttribute
    Listener z;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        ((TextView)view.findViewById(2131362486)).setText((CharSequence)this.p);
        ((TextView)view.findViewById(2131362548)).setText((CharSequence)this.v);
        ((TextView)view.findViewById(2131363004)).setText((CharSequence)this.o);
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362872);
        Intrinsics.g((Object)appCompatImageView, (String)"view.sponsor");
        ViewsKt.l((View)appCompatImageView, (Bool)this.x);
        AppCompatImageView appCompatImageView2 = (AppCompatImageView)view.findViewById(2131363094);
        Intrinsics.g((Object)appCompatImageView2, (String)"view.verified");
        ViewsKt.l((View)appCompatImageView2, (Bool)this.y);
        TextView textView = (TextView)view.findViewById(2131362106);
        Time time = Time.a;
        Context context = view.getContext();
        Intrinsics.g((Object)context, (String)"view.context");
        textView.setText((CharSequence)time.g(context, this.s));
        AppCompatImageView appCompatImageView3 = (AppCompatImageView)a.B((View)view, (Int)2131952323, (TextView)((TextView)view.findViewById(2131362065)), (Int)2131362186);
        Intrinsics.g((Object)appCompatImageView3, (String)"view.edited");
        ViewsKt.l((View)appCompatImageView3, (Bool)this.t);
        TextView textView2 = (TextView)view.findViewById(2131362486);
        Intrinsics.g((Object)textView2, (String)"view.message");
        ViewsKt.f((View)textView2, (Bool)this.u, (Bool)false, null, (Int)6);
        TextView textView3 = (TextView)view.findViewById(2131362119);
        Intrinsics.g((Object)textView3, (String)"view.deleted");
        ViewsKt.l((View)textView3, (Bool)this.u);
        if (!this.u) {
            if (!this.q && this.r > -5) {
                TextView textView4 = (TextView)a.e((View)view, (Int)2130969583, (TextView)((TextView)view.findViewById(2131362486)), (Int)2131362486);
                LinearLayout linearLayout = (LinearLayout)a.C((TextView)textView4, (String)"view.message", (TextView)textView4, (View)view, (Int)2131362870);
                Intrinsics.g((Object)linearLayout, (String)"view.spoilerHideShow");
                ViewsKt.e((View)linearLayout);
            } else {
                Ref.BooleanRef booleanRef = new Ref.BooleanRef();
                TextView textView5 = (TextView)a.e((View)view, (Int)2130969642, (TextView)((TextView)view.findViewById(2131362486)), (Int)2131362486);
                LinearLayout linearLayout = (LinearLayout)a.f((TextView)textView5, (String)"view.message", (TextView)textView5, (View)view, (Int)2131362870);
                Intrinsics.g((Object)linearLayout, (String)"view.spoilerHideShow");
                ViewsKt.k((View)linearLayout);
                TextView textView6 = (TextView)view.findViewById(2131363061);
                Int n = this.r;
                String string = n > -5 && this.q ? view.getContext().getString(2131951757) : (n <= -5 && this.q ? view.getContext().getString(2131951756) : (n <= -5 && !this.q ? view.getContext().getString(2131951758) : view.getContext().getString(2131951757)));
                textView6.setText((CharSequence)string);
                ((LinearLayout)view.findViewById(2131362870)).setOnClickListener((View.OnClickListener)new b(booleanRef, view, 1));
            }
        }
        ((TextView)view.findViewById(2131363138)).setText((CharSequence)StringsKt.Q((String)String.valueOf((Int)this.r), (String)"-", (String)"\u2013", (Bool)false, (Int)4, null));
        Int n = this.r;
        if (n == 0) {
            ((LinearLayout)view.findViewById(2131363140)).setBackgroundResource(2131230860);
            ((TextView)view.findViewById(2131363138)).setTextColor(ViewsKt.c((View)view, (Int)2130969821));
        } else if (n > 0) {
            ((LinearLayout)view.findViewById(2131363140)).setBackgroundResource(2131230859);
            a.n((View)view, (Int)2131099808, (TextView)((TextView)view.findViewById(2131363138)));
        } else {
            ((LinearLayout)view.findViewById(2131363140)).setBackgroundResource(2131230858);
            a.n((View)view, (Int)2131100606, (TextView)((TextView)view.findViewById(2131363138)));
        }
        AppCompatImageView appCompatImageView4 = (AppCompatImageView)view.findViewById(2131361916);
        Intrinsics.g((Object)appCompatImageView4, (String)"view.avatar");
        ViewsKt.a((AppCompatImageView)appCompatImageView4, (String)this.w);
        ViewsKt.j((View)view, (Function1)new bind.9(this));
        AppCompatImageView appCompatImageView5 = (AppCompatImageView)view.findViewById(2131361916);
        Intrinsics.g((Object)appCompatImageView5, (String)"view.avatar");
        ViewsKt.j((View)appCompatImageView5, (Function1)new bind.10(this));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof ProfileCollectionCommentModel) {
            String string = this.p;
            ProfileCollectionCommentModel profileCollectionCommentModel = (ProfileCollectionCommentModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)profileCollectionCommentModel.p)) {
                arrayList.add((Object)0);
            }
            if (this.q != profileCollectionCommentModel.q) {
                arrayList.add((Object)1);
            }
            if (this.r != profileCollectionCommentModel.r) {
                arrayList.add((Object)2);
            }
            if (this.s != profileCollectionCommentModel.s) {
                arrayList.add((Object)3);
            }
            if (this.t != profileCollectionCommentModel.t) {
                arrayList.add((Object)9);
            }
            if (this.u != profileCollectionCommentModel.u) {
                arrayList.add((Object)10);
            }
            if (!Intrinsics.c((Object)this.v, (Object)profileCollectionCommentModel.v)) {
                arrayList.add((Object)4);
            }
            if (!Intrinsics.c((Object)this.w, (Object)profileCollectionCommentModel.w)) {
                arrayList.add((Object)5);
            }
            if (this.x != profileCollectionCommentModel.x) {
                arrayList.add((Object)6);
            }
            if (this.y != profileCollectionCommentModel.y) {
                arrayList.add((Object)7);
            }
            if (!Intrinsics.c((Object)this.o, (Object)profileCollectionCommentModel.o)) {
                arrayList.add((Object)8);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        if (a.z((View)view, (String)"view", list, (String)"payloads", (Int)0)) {
            ((TextView)view.findViewById(2131362486)).setText((CharSequence)this.p);
        }
        if (list.contains((Object)1)) {
            if (!this.q && this.r > -5) {
                TextView textView = (TextView)a.e((View)view, (Int)2130969583, (TextView)((TextView)view.findViewById(2131362486)), (Int)2131362486);
                LinearLayout linearLayout = (LinearLayout)a.C((TextView)textView, (String)"view.message", (TextView)textView, (View)view, (Int)2131362870);
                Intrinsics.g((Object)linearLayout, (String)"view.spoilerHideShow");
                ViewsKt.e((View)linearLayout);
            } else {
                Ref.BooleanRef booleanRef = new Ref.BooleanRef();
                TextView textView = (TextView)a.e((View)view, (Int)2130969642, (TextView)((TextView)view.findViewById(2131362486)), (Int)2131362486);
                LinearLayout linearLayout = (LinearLayout)a.f((TextView)textView, (String)"view.message", (TextView)textView, (View)view, (Int)2131362870);
                Intrinsics.g((Object)linearLayout, (String)"view.spoilerHideShow");
                ViewsKt.k((View)linearLayout);
                TextView textView2 = (TextView)view.findViewById(2131363061);
                Int n = this.r;
                String string = n > -5 && this.q ? view.getContext().getString(2131951757) : (n <= -5 && this.q ? view.getContext().getString(2131951756) : (n <= -5 && !this.q ? view.getContext().getString(2131951758) : view.getContext().getString(2131951757)));
                textView2.setText((CharSequence)string);
                ((LinearLayout)view.findViewById(2131362870)).setOnClickListener((View.OnClickListener)new b(booleanRef, view, 0));
            }
        }
        if (list.contains((Object)2)) {
            ((TextView)view.findViewById(2131363138)).setText((CharSequence)StringsKt.Q((String)String.valueOf((Int)this.r), (String)"-", (String)"\u2013", (Bool)false, (Int)4, null));
            Int n = this.r;
            if (n == 0) {
                ((LinearLayout)view.findViewById(2131363140)).setBackgroundResource(2131230860);
                ((TextView)view.findViewById(2131363138)).setTextColor(ViewsKt.c((View)view, (Int)2130969821));
            } else if (n > 0) {
                ((LinearLayout)view.findViewById(2131363140)).setBackgroundResource(2131230859);
                a.n((View)view, (Int)2131099808, (TextView)((TextView)view.findViewById(2131363138)));
            } else {
                ((LinearLayout)view.findViewById(2131363140)).setBackgroundResource(2131230858);
                a.n((View)view, (Int)2131100606, (TextView)((TextView)view.findViewById(2131363138)));
            }
        }
        if (list.contains((Object)3)) {
            TextView textView = (TextView)view.findViewById(2131362106);
            Time time = Time.a;
            Context context = view.getContext();
            Intrinsics.g((Object)context, (String)"view.context");
            textView.setText((CharSequence)time.g(context, this.s));
        }
        if (list.contains((Object)9)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362186);
            Intrinsics.g((Object)appCompatImageView, (String)"view.edited");
            ViewsKt.l((View)appCompatImageView, (Bool)this.t);
        }
        if (list.contains((Object)10)) {
            TextView textView = (TextView)view.findViewById(2131362486);
            Intrinsics.g((Object)textView, (String)"view.message");
            ViewsKt.f((View)textView, (Bool)this.u, (Bool)false, null, (Int)6);
            TextView textView3 = (TextView)view.findViewById(2131362119);
            Intrinsics.g((Object)textView3, (String)"view.deleted");
            ViewsKt.l((View)textView3, (Bool)this.u);
        }
        if (list.contains((Object)4)) {
            ((TextView)view.findViewById(2131362548)).setText((CharSequence)this.v);
        }
        if (list.contains((Object)5)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131361916);
            Intrinsics.g((Object)appCompatImageView, (String)"view.avatar");
            ViewsKt.h((ImageView)appCompatImageView, (String)this.w);
        }
        if (list.contains((Object)6)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362872);
            Intrinsics.g((Object)appCompatImageView, (String)"view.sponsor");
            ViewsKt.l((View)appCompatImageView, (Bool)this.x);
        }
        if (list.contains((Object)7)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131363094);
            Intrinsics.g((Object)appCompatImageView, (String)"view.verified");
            ViewsKt.l((View)appCompatImageView, (Bool)this.y);
        }
        if (list.contains((Object)8)) {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)this.o);
        }
    }

    func v2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        view.setOnClickListener(null);
    }
}

