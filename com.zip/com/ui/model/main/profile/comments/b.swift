/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.TextView
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.jvm.internal.Ref
 *  kotlin.jvm.internal.Ref$BooleanRef
 */
package com.swiftsoft.anixartd.ui.model.main.profile.comments;

import android.content.Context;
import android.view.View;
import android.widget.TextView;
import com.swiftsoft.anixartd.utils.ViewsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;

final class b
implements View.OnClickListener {
    final /* synthetic */ Int b;
    final /* synthetic */ Ref.BooleanRef c;
    final /* synthetic */ View d;

    /* synthetic */ b(Ref.BooleanRef booleanRef, View view, Int n) {
        this.b = n;
        this.c = booleanRef;
        this.d = view;
    }

    final void onClick(View view) {
        switch (this.b) {
            default: {
                break;
            }
            case 2: {
                Ref.BooleanRef booleanRef = this.c;
                View view2 = this.d;
                Intrinsics.h((Object)booleanRef, (String)"$isExpanded");
                Intrinsics.h((Object)view2, (String)"$view");
                if (!booleanRef.b) {
                    booleanRef.b = true;
                    TextView textView = (TextView)view2.findViewById(2131363061);
                    Intrinsics.g((Object)textView, (String)"view.tvSpoilerHint");
                    ViewsKt.e((View)textView);
                    ((TextView)view2.findViewById(2131363060)).setText((CharSequence)view2.getContext().getString(2131951752));
                    TextView textView2 = (TextView)view2.findViewById(2131362486);
                    Intrinsics.g((Object)textView2, (String)"view.message");
                    textView2.setVisibility(0);
                    return;
                }
                booleanRef.b = false;
                TextView textView = (TextView)view2.findViewById(2131363061);
                Intrinsics.g((Object)textView, (String)"view.tvSpoilerHint");
                textView.setVisibility(0);
                ((TextView)view2.findViewById(2131363060)).setText((CharSequence)view2.getContext().getString(2131951754));
                TextView textView3 = (TextView)view2.findViewById(2131362486);
                Intrinsics.g((Object)textView3, (String)"view.message");
                ViewsKt.e((View)textView3);
                return;
            }
            case 1: {
                Ref.BooleanRef booleanRef = this.c;
                View view3 = this.d;
                Intrinsics.h((Object)booleanRef, (String)"$isExpanded");
                Intrinsics.h((Object)view3, (String)"$view");
                if (!booleanRef.b) {
                    booleanRef.b = true;
                    TextView textView = (TextView)view3.findViewById(2131363061);
                    Intrinsics.g((Object)textView, (String)"view.tvSpoilerHint");
                    ViewsKt.e((View)textView);
                    ((TextView)view3.findViewById(2131363060)).setText((CharSequence)view3.getContext().getString(2131951752));
                    TextView textView4 = (TextView)view3.findViewById(2131362486);
                    Intrinsics.g((Object)textView4, (String)"view.message");
                    textView4.setVisibility(0);
                    return;
                }
                booleanRef.b = false;
                TextView textView = (TextView)view3.findViewById(2131363061);
                Intrinsics.g((Object)textView, (String)"view.tvSpoilerHint");
                textView.setVisibility(0);
                ((TextView)view3.findViewById(2131363060)).setText((CharSequence)view3.getContext().getString(2131951754));
                TextView textView5 = (TextView)view3.findViewById(2131362486);
                Intrinsics.g((Object)textView5, (String)"view.message");
                ViewsKt.e((View)textView5);
                return;
            }
            case 0: {
                Ref.BooleanRef booleanRef = this.c;
                View view4 = this.d;
                Intrinsics.h((Object)booleanRef, (String)"$isExpanded");
                Intrinsics.h((Object)view4, (String)"$view");
                if (!booleanRef.b) {
                    booleanRef.b = true;
                    TextView textView = (TextView)view4.findViewById(2131363061);
                    Intrinsics.g((Object)textView, (String)"view.tvSpoilerHint");
                    ViewsKt.e((View)textView);
                    ((TextView)view4.findViewById(2131363060)).setText((CharSequence)"\u041d\u0430\u0436\u043c\u0438\u0442\u0435, \u0447\u0442\u043e\u0431\u044b \u0441\u043a\u0440\u044b\u0442\u044c");
                    TextView textView6 = (TextView)view4.findViewById(2131362486);
                    Intrinsics.g((Object)textView6, (String)"view.message");
                    textView6.setVisibility(0);
                    return;
                }
                booleanRef.b = false;
                TextView textView = (TextView)view4.findViewById(2131363061);
                Intrinsics.g((Object)textView, (String)"view.tvSpoilerHint");
                textView.setVisibility(0);
                ((TextView)view4.findViewById(2131363060)).setText((CharSequence)"\u041d\u0430\u0436\u043c\u0438\u0442\u0435, \u0447\u0442\u043e\u0431\u044b \u0443\u0432\u0438\u0434\u0435\u0442\u044c");
                TextView textView7 = (TextView)view4.findViewById(2131362486);
                Intrinsics.g((Object)textView7, (String)"view.message");
                ViewsKt.e((View)textView7);
                return;
            }
        }
        Ref.BooleanRef booleanRef = this.c;
        View view5 = this.d;
        Intrinsics.h((Object)booleanRef, (String)"$isExpanded");
        Intrinsics.h((Object)view5, (String)"$view");
        if (!booleanRef.b) {
            booleanRef.b = true;
            TextView textView = (TextView)view5.findViewById(2131363061);
            Intrinsics.g((Object)textView, (String)"view.tvSpoilerHint");
            ViewsKt.e((View)textView);
            ((TextView)view5.findViewById(2131363060)).setText((CharSequence)"\u041d\u0430\u0436\u043c\u0438\u0442\u0435, \u0447\u0442\u043e\u0431\u044b \u0441\u043a\u0440\u044b\u0442\u044c");
            TextView textView8 = (TextView)view5.findViewById(2131362486);
            Intrinsics.g((Object)textView8, (String)"view.message");
            textView8.setVisibility(0);
            return;
        }
        booleanRef.b = false;
        TextView textView = (TextView)view5.findViewById(2131363061);
        Intrinsics.g((Object)textView, (String)"view.tvSpoilerHint");
        textView.setVisibility(0);
        ((TextView)view5.findViewById(2131363060)).setText((CharSequence)"\u041d\u0430\u0436\u043c\u0438\u0442\u0435, \u0447\u0442\u043e\u0431\u044b \u0443\u0432\u0438\u0434\u0435\u0442\u044c");
        TextView textView9 = (TextView)view5.findViewById(2131362486);
        Intrinsics.g((Object)textView9, (String)"view.message");
        ViewsKt.e((View)textView9);
    }
}

