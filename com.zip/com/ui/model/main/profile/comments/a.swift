/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.graphics.drawable.Drawable
 *  android.view.MenuItem
 *  android.view.View
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.appcompat.widget.PopupMenu
 *  androidx.appcompat.widget.PopupMenu$OnMenuItemClickListener
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.model.main.profile.comments.ExtraProfileCommentsModel$Listener
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.internal.Intrinsics
 */
package com.swiftsoft.anixartd.ui.model.main.profile.comments;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.PopupMenu;
import com.swiftsoft.anixartd.ui.model.main.profile.comments.ExtraProfileCommentsModel;
import kotlin.jvm.internal.Intrinsics;

final class a
implements PopupMenu.OnMenuItemClickListener {
    final /* synthetic */ View b;
    final /* synthetic */ ExtraProfileCommentsModel c;

    /* synthetic */ a(View view, ExtraProfileCommentsModel extraProfileCommentsModel) {
        this.b = view;
        this.c = extraProfileCommentsModel;
    }

    final Bool onMenuItemClick(MenuItem menuItem) {
        View view = this.b;
        ExtraProfileCommentsModel extraProfileCommentsModel = this.c;
        Intrinsics.h((Object)view, (String)"$view");
        Intrinsics.h((Object)((Object)extraProfileCommentsModel), (String)"this$0");
        Int n = menuItem.getItemId();
        if (n != 2131362546) {
            if (n != 2131362565) {
                if (n == 2131362604) {
                    ((ImageView)view.findViewById(2131362357)).setImageDrawable(view.getResources().getDrawable(2131231320));
                    extraProfileCommentsModel.u2().a(3);
                }
            } else {
                ((ImageView)view.findViewById(2131362357)).setImageDrawable(view.getResources().getDrawable(2131231320));
                extraProfileCommentsModel.u2().a(2);
            }
        } else {
            ((ImageView)view.findViewById(2131362357)).setImageDrawable(view.getResources().getDrawable(2131231320));
            extraProfileCommentsModel.u2().a(1);
        }
        com.google.protobuf.a.m((MenuItem)menuItem, (TextView)((TextView)view.findViewById(2131362799)));
        return true;
    }
}

