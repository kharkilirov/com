/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.model.main.discover.CommentModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.discover.CommentModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.discover.CommentModel$bind$10
 *  com.swiftsoft.anixartd.ui.model.main.discover.CommentModel$bind$9
 *  com.swiftsoft.anixartd.ui.model.main.discover.a
 *  com.swiftsoft.anixartd.utils.DigitsKt
 *  com.swiftsoft.anixartd.utils.Time
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.jvm.internal.Ref
 *  kotlin.jvm.internal.Ref$BooleanRef
 *  kotlin.text.StringsKt
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.discover;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.swiftsoft.anixartd.ui.model.main.discover.CommentModel;
import com.swiftsoft.anixartd.ui.model.main.discover.a;
import com.swiftsoft.anixartd.utils.DigitsKt;
import com.swiftsoft.anixartd.utils.Time;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/discover/CommentModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class CommentModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    long k;
    @EpoxyAttribute
    long l;
    @EpoxyAttribute
    @Nullable
    String m = "";
    @EpoxyAttribute
    @NotNull
    String n = "";
    @EpoxyAttribute
    Bool o;
    @EpoxyAttribute
    Int p;
    @EpoxyAttribute
    long q;
    @EpoxyAttribute
    Bool r;
    @EpoxyAttribute
    @NotNull
    String s = "";
    @EpoxyAttribute
    @Nullable
    String t = "";
    @EpoxyAttribute
    Bool u;
    @EpoxyAttribute
    Bool v;
    @EpoxyAttribute
    Listener w;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        ((TextView)view.findViewById(2131362486)).setText((CharSequence)this.n);
        ((TextView)view.findViewById(2131362548)).setText((CharSequence)this.s);
        ((TextView)view.findViewById(2131363004)).setText((CharSequence)this.m);
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362872);
        Intrinsics.g((Object)appCompatImageView, (String)"view.sponsor");
        ViewsKt.l((View)appCompatImageView, (Bool)this.u);
        AppCompatImageView appCompatImageView2 = (AppCompatImageView)view.findViewById(2131363094);
        Intrinsics.g((Object)appCompatImageView2, (String)"view.verified");
        ViewsKt.l((View)appCompatImageView2, (Bool)this.v);
        TextView textView = (TextView)view.findViewById(2131362106);
        Time time = Time.a;
        Context context = view.getContext();
        Intrinsics.g((Object)context, (String)"view.context");
        textView.setText((CharSequence)time.g(context, this.q));
        AppCompatImageView appCompatImageView3 = (AppCompatImageView)view.findViewById(2131362186);
        Intrinsics.g((Object)appCompatImageView3, (String)"view.edited");
        ViewsKt.l((View)appCompatImageView3, (Bool)this.r);
        if (!this.o && this.p > -5) {
            TextView textView2 = (TextView)com.google.protobuf.a.e((View)view, (Int)2130969583, (TextView)((TextView)view.findViewById(2131362486)), (Int)2131362486);
            LinearLayout linearLayout = (LinearLayout)com.google.protobuf.a.C((TextView)textView2, (String)"view.message", (TextView)textView2, (View)view, (Int)2131362870);
            Intrinsics.g((Object)linearLayout, (String)"view.spoilerHideShow");
            ViewsKt.e((View)linearLayout);
        } else {
            Ref.BooleanRef booleanRef = new Ref.BooleanRef();
            TextView textView3 = (TextView)com.google.protobuf.a.e((View)view, (Int)2130969642, (TextView)((TextView)view.findViewById(2131362486)), (Int)2131362486);
            LinearLayout linearLayout = (LinearLayout)com.google.protobuf.a.f((TextView)textView3, (String)"view.message", (TextView)textView3, (View)view, (Int)2131362870);
            Intrinsics.g((Object)linearLayout, (String)"view.spoilerHideShow");
            ViewsKt.k((View)linearLayout);
            TextView textView4 = (TextView)view.findViewById(2131363061);
            Int n = this.p;
            String string = n > -5 && this.o ? view.getContext().getString(2131951757) : (n <= -5 && this.o ? view.getContext().getString(2131951756) : (n <= -5 && !this.o ? view.getContext().getString(2131951758) : view.getContext().getString(2131951757)));
            textView4.setText((CharSequence)string);
            ((LinearLayout)view.findViewById(2131362870)).setOnClickListener((View.OnClickListener)new a(booleanRef, view, 0));
        }
        ((TextView)view.findViewById(2131363138)).setText((CharSequence)StringsKt.Q((String)DigitsKt.e((Int)this.p), (String)"-", (String)"\u2013", (Bool)false, (Int)4, null));
        Int n = this.p;
        if (n == 0) {
            ((LinearLayout)view.findViewById(2131363140)).setBackgroundResource(2131230860);
            ((TextView)view.findViewById(2131363138)).setTextColor(ViewsKt.c((View)view, (Int)2130969821));
        } else if (n > 0) {
            ((LinearLayout)view.findViewById(2131363140)).setBackgroundResource(2131230859);
            com.google.protobuf.a.n((View)view, (Int)2131099808, (TextView)((TextView)view.findViewById(2131363138)));
        } else {
            ((LinearLayout)view.findViewById(2131363140)).setBackgroundResource(2131230858);
            com.google.protobuf.a.n((View)view, (Int)2131100606, (TextView)((TextView)view.findViewById(2131363138)));
        }
        AppCompatImageView appCompatImageView4 = (AppCompatImageView)view.findViewById(2131361916);
        Intrinsics.g((Object)appCompatImageView4, (String)"view.avatar");
        ViewsKt.a((AppCompatImageView)appCompatImageView4, (String)this.t);
        ViewsKt.j((View)view, (Function1)new bind.9(this));
        AppCompatImageView appCompatImageView5 = (AppCompatImageView)view.findViewById(2131361916);
        Intrinsics.g((Object)appCompatImageView5, (String)"view.avatar");
        ViewsKt.j((View)appCompatImageView5, (Function1)new bind.10(this));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = com.google.protobuf.a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof CommentModel) {
            String string = this.n;
            CommentModel commentModel = (CommentModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)commentModel.n)) {
                arrayList.add((Object)0);
            }
            if (this.o != commentModel.o) {
                arrayList.add((Object)1);
            }
            if (this.p != commentModel.p) {
                arrayList.add((Object)2);
            }
            if (this.q != commentModel.q) {
                arrayList.add((Object)3);
            }
            if (this.r != commentModel.r) {
                arrayList.add((Object)9);
            }
            if (!Intrinsics.c((Object)this.s, (Object)commentModel.s)) {
                arrayList.add((Object)4);
            }
            if (!Intrinsics.c((Object)this.t, (Object)commentModel.t)) {
                arrayList.add((Object)5);
            }
            if (this.u != commentModel.u) {
                arrayList.add((Object)6);
            }
            if (this.v != commentModel.v) {
                arrayList.add((Object)7);
            }
            if (!Intrinsics.c((Object)this.m, (Object)commentModel.m)) {
                arrayList.add((Object)8);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        if (com.google.protobuf.a.z((View)view, (String)"view", list, (String)"payloads", (Int)0)) {
            ((TextView)view.findViewById(2131362486)).setText((CharSequence)this.n);
        }
        if (list.contains((Object)1)) {
            if (!this.o && this.p > -5) {
                TextView textView = (TextView)com.google.protobuf.a.e((View)view, (Int)2130969583, (TextView)((TextView)view.findViewById(2131362486)), (Int)2131362486);
                Intrinsics.g((Object)textView, (String)"view.message");
                textView.setVisibility(0);
                LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362870);
                Intrinsics.g((Object)linearLayout, (String)"view.spoilerHideShow");
                ViewsKt.e((View)linearLayout);
            } else {
                Ref.BooleanRef booleanRef = new Ref.BooleanRef();
                TextView textView = (TextView)com.google.protobuf.a.e((View)view, (Int)2130969642, (TextView)((TextView)view.findViewById(2131362486)), (Int)2131362486);
                LinearLayout linearLayout = (LinearLayout)com.google.protobuf.a.f((TextView)textView, (String)"view.message", (TextView)textView, (View)view, (Int)2131362870);
                Intrinsics.g((Object)linearLayout, (String)"view.spoilerHideShow");
                linearLayout.setVisibility(0);
                TextView textView2 = (TextView)view.findViewById(2131363061);
                Int n = this.p;
                String string = n > -5 && this.o ? view.getContext().getString(2131951757) : (n <= -5 && this.o ? view.getContext().getString(2131951756) : (n <= -5 && !this.o ? view.getContext().getString(2131951758) : view.getContext().getString(2131951757)));
                textView2.setText((CharSequence)string);
                ((LinearLayout)view.findViewById(2131362870)).setOnClickListener((View.OnClickListener)new a(booleanRef, view, 1));
            }
        }
        if (list.contains((Object)2)) {
            ((TextView)view.findViewById(2131363138)).setText((CharSequence)StringsKt.Q((String)DigitsKt.e((Int)this.p), (String)"-", (String)"\u2013", (Bool)false, (Int)4, null));
            Int n = this.p;
            if (n == 0) {
                ((LinearLayout)view.findViewById(2131363140)).setBackgroundResource(2131230860);
                ((TextView)view.findViewById(2131363138)).setTextColor(ViewsKt.c((View)view, (Int)2130969821));
            } else if (n > 0) {
                ((LinearLayout)view.findViewById(2131363140)).setBackgroundResource(2131230859);
                com.google.protobuf.a.n((View)view, (Int)2131099808, (TextView)((TextView)view.findViewById(2131363138)));
            } else {
                ((LinearLayout)view.findViewById(2131363140)).setBackgroundResource(2131230858);
                com.google.protobuf.a.n((View)view, (Int)2131100606, (TextView)((TextView)view.findViewById(2131363138)));
            }
        }
        if (list.contains((Object)3)) {
            TextView textView = (TextView)view.findViewById(2131362106);
            Time time = Time.a;
            Context context = view.getContext();
            Intrinsics.g((Object)context, (String)"view.context");
            textView.setText((CharSequence)time.g(context, this.q));
        }
        if (list.contains((Object)9)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362186);
            Intrinsics.g((Object)appCompatImageView, (String)"view.edited");
            ViewsKt.l((View)appCompatImageView, (Bool)this.r);
        }
        if (list.contains((Object)4)) {
            ((TextView)view.findViewById(2131362548)).setText((CharSequence)this.s);
        }
        if (list.contains((Object)5)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131361916);
            Intrinsics.g((Object)appCompatImageView, (String)"view.avatar");
            ViewsKt.h((ImageView)appCompatImageView, (String)this.t);
        }
        if (list.contains((Object)6)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362872);
            Intrinsics.g((Object)appCompatImageView, (String)"view.sponsor");
            ViewsKt.l((View)appCompatImageView, (Bool)this.u);
        }
        if (list.contains((Object)7)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131363094);
            Intrinsics.g((Object)appCompatImageView, (String)"view.verified");
            ViewsKt.l((View)appCompatImageView, (Bool)this.v);
        }
        if (list.contains((Object)8)) {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)this.m);
        }
    }

    func v2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        view.setOnClickListener(null);
    }
}

