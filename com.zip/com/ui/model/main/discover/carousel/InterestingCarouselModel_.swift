/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewGroup$MarginLayoutParams
 *  androidx.annotation.Dimension
 *  androidx.annotation.LayoutRes
 *  androidx.room.util.a
 *  com.airbnb.epoxy.Carousel
 *  com.airbnb.epoxy.Carousel$Padding
 *  com.airbnb.epoxy.EpoxyController
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyViewHolder
 *  com.airbnb.epoxy.GeneratedModel
 *  com.swiftsoft.anixartd.ui.model.main.discover.carousel.InterestingCarousel
 *  com.swiftsoft.anixartd.ui.model.main.discover.carousel.InterestingCarouselModelBuilder
 *  java.lang.Float
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.UnsupportedOperationException
 *  java.util.BitSet
 *  java.util.List
 *  java.util.Objects
 */
package com.swiftsoft.anixartd.ui.model.main.discover.carousel;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.Dimension;
import androidx.annotation.LayoutRes;
import androidx.room.util.a;
import com.airbnb.epoxy.Carousel;
import com.airbnb.epoxy.EpoxyController;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyViewHolder;
import com.airbnb.epoxy.GeneratedModel;
import com.swiftsoft.anixartd.ui.model.main.discover.carousel.InterestingCarousel;
import com.swiftsoft.anixartd.ui.model.main.discover.carousel.InterestingCarouselModelBuilder;
import java.util.BitSet;
import java.util.List;
import java.util.Objects;

class InterestingCarouselModel_
extends EpoxyModel<InterestingCarousel>
implements GeneratedModel<InterestingCarousel>,
InterestingCarouselModelBuilder {
    final BitSet k = new BitSet(7);
    @Dimension
    Int l = -1;

    func N1(EpoxyViewHolder epoxyViewHolder, Object object, Int n) -> void {
        (InterestingCarousel)object;
        this.t2("The model was changed between being added to the controller and being bound.", n);
    }

    func X1(EpoxyController epoxyController) -> void {
        epoxyController.addInternal((EpoxyModel)this);
        this.Y1(epoxyController);
        if (this.k.get(6)) {
            return;
        }
        throw new IllegalStateException("A value is required for setModels");
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        InterestingCarousel interestingCarousel = (InterestingCarousel)object;
        if (!(epoxyModel instanceof InterestingCarouselModel_)) {
            this.u2(interestingCarousel);
            return;
        }
        InterestingCarouselModel_ interestingCarouselModel_ = (InterestingCarouselModel_)epoxyModel;
        if (this.k.get(3)) {
            Objects.requireNonNull((Object)((Object)interestingCarouselModel_));
        } else if (this.k.get(4)) {
            Int n = this.l;
            if (n != interestingCarouselModel_.l) {
                interestingCarousel.setPaddingDp(n);
            }
        } else if (this.k.get(5)) {
            if (!interestingCarouselModel_.k.get(5)) {
                interestingCarousel.setPadding(null);
            }
        } else if (interestingCarouselModel_.k.get(3) || interestingCarouselModel_.k.get(4) || interestingCarouselModel_.k.get(5)) {
            interestingCarousel.setPaddingDp(this.l);
        }
        Objects.requireNonNull((Object)((Object)interestingCarouselModel_));
        if (this.k.get(1)) {
            if (Float.compare((Float)0.0f, (Float)0.0f) != 0) {
                interestingCarousel.setNumViewsToShowOnScreen(0.0f);
                return;
            }
        } else {
            if (this.k.get(2)) {
                return;
            }
            if (interestingCarouselModel_.k.get(1) || interestingCarouselModel_.k.get(2)) {
                interestingCarousel.setNumViewsToShowOnScreen(0.0f);
            }
        }
    }

    func c2(ViewGroup viewGroup) -> View {
        InterestingCarousel interestingCarousel = new InterestingCarousel(viewGroup.getContext());
        interestingCarousel.setLayoutParams((ViewGroup.LayoutParams)new ViewGroup.MarginLayoutParams(-2, -2));
        return interestingCarousel;
    }

    @LayoutRes
    func d2() -> Int {
        throw new UnsupportedOperationException("Layout resources are unsupported for views created programmatically.");
    }

    func e2(Int n, Int n2, Int n3) -> Int {
        return n;
    }

    func equals(Object object) -> Bool {
        if (object == this) {
            return true;
        }
        if (!(object instanceof InterestingCarouselModel_)) {
            return false;
        }
        if (!super.equals(object)) {
            return false;
        }
        InterestingCarouselModel_ interestingCarouselModel_ = (InterestingCarouselModel_)((Object)object);
        Objects.requireNonNull((Object)((Object)interestingCarouselModel_));
        if (Float.compare((Float)0.0f, (Float)0.0f) != 0) {
            return false;
        }
        return this.l == interestingCarouselModel_.l;
    }

    func f0(Object object, Int n) -> void {
        (InterestingCarousel)object;
        this.t2("The model was changed during the bind call.", n);
    }

    func f2() -> Int {
        return 0;
    }

    func g2(long l) -> EpoxyModel {
        super.g2(l);
        return this;
    }

    func hashCode() -> Int {
        return 0 + 31 * (0 + 31 * (31 * (0 + 31 * (0 + 31 * (0 + 31 * (0 + 31 * (0 + 31 * (0 + 31 * (0 + 31 * (0 + 31 * super.hashCode())))))))) + this.l));
    }

    func q2() -> Bool {
        return true;
    }

    func s2(Object object) -> void {
        ((InterestingCarousel)object).L0();
    }

    func toString() -> String {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("InterestingCarouselModel_{hasFixedSize_Boolean=");
        stringBuilder.append(false);
        stringBuilder.append(", numViewsToShowOnScreen_Float=");
        stringBuilder.append(0.0f);
        stringBuilder.append(", initialPrefetchItemCount_Int=");
        a.A((StringBuilder)stringBuilder, (Int)0, (String)", paddingRes_Int=", (Int)0, (String)", paddingDp_Int=");
        stringBuilder.append(this.l);
        stringBuilder.append(", padding_Padding=");
        stringBuilder.append(null);
        stringBuilder.append(", models_List=");
        stringBuilder.append(null);
        stringBuilder.append("}");
        stringBuilder.append(super.toString());
        return stringBuilder.toString();
    }

    func u2(InterestingCarousel interestingCarousel) -> void {
        if (this.k.get(3)) {
            interestingCarousel.setPaddingRes(0);
        } else if (this.k.get(4)) {
            interestingCarousel.setPaddingDp(this.l);
        } else if (this.k.get(5)) {
            interestingCarousel.setPadding(null);
        } else {
            interestingCarousel.setPaddingDp(this.l);
        }
        interestingCarousel.setHasFixedSize(false);
        if (this.k.get(1)) {
            interestingCarousel.setNumViewsToShowOnScreen(0.0f);
        } else if (this.k.get(2)) {
            interestingCarousel.setInitialPrefetchItemCount(0);
        } else {
            interestingCarousel.setNumViewsToShowOnScreen(0.0f);
        }
        interestingCarousel.setModels(null);
    }
}

