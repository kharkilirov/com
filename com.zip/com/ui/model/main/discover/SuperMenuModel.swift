/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.ColorStateList
 *  android.content.res.Resources
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ImageView
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.swiftsoft.anixartd.ui.fragment.main.watching.a
 *  com.swiftsoft.anixartd.ui.model.main.discover.SuperMenuModel$Listener
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.model.main.discover;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.swiftsoft.anixartd.ui.fragment.main.watching.a;
import com.swiftsoft.anixartd.ui.model.main.discover.SuperMenuModel;
import com.swiftsoft.anixartd.utils.ViewsKt;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u0003\u00a8\u0006\u0004"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/discover/SuperMenuModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class SuperMenuModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    long k;
    @EpoxyAttribute
    @NotNull
    String l = "";
    @EpoxyAttribute
    Int m;
    @EpoxyAttribute
    Int n;
    @EpoxyAttribute
    Int o;
    @EpoxyAttribute
    Bool p;
    @EpoxyAttribute
    Listener q;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        ((TextView)view.findViewById(2131363004)).setText((CharSequence)this.l);
        ((TextView)view.findViewById(2131363004)).setTextColor(context.getResources().getColor(this.m));
        ((ImageView)view.findViewById(2131362349)).setImageResource(this.o);
        ((ImageView)view.findViewById(2131362349)).setImageTintList(ColorStateList.valueOf((Int)context.getResources().getColor(this.m)));
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362543);
        Intrinsics.g((Object)appCompatImageView, (String)"view.new_dot");
        ViewsKt.l((View)appCompatImageView, (Bool)this.p);
        ((RelativeLayout)view.findViewById(2131362417)).setBackgroundColor(context.getResources().getColor(this.n));
        view.setOnClickListener((View.OnClickListener)new a((Object)this, 7));
    }
}

