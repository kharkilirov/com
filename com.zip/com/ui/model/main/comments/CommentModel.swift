/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.model.main.comments.CommentModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.comments.CommentModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.comments.CommentModel$bind$10
 *  com.swiftsoft.anixartd.ui.model.main.comments.CommentModel$bind$11
 *  com.swiftsoft.anixartd.ui.model.main.comments.CommentModel$bind$6
 *  com.swiftsoft.anixartd.ui.model.main.comments.CommentModel$bind$7
 *  com.swiftsoft.anixartd.ui.model.main.comments.CommentModel$bind$8
 *  com.swiftsoft.anixartd.ui.model.main.comments.CommentModel$bind$9
 *  com.swiftsoft.anixartd.ui.model.main.comments.a
 *  com.swiftsoft.anixartd.utils.DigitsKt
 *  com.swiftsoft.anixartd.utils.Plurals
 *  com.swiftsoft.anixartd.utils.Time
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.jvm.internal.Ref
 *  kotlin.jvm.internal.Ref$BooleanRef
 *  kotlin.text.StringsKt
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.comments;

import android.content.Context;
import android.content.res.Resources;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.swiftsoft.anixartd.ui.model.main.comments.CommentModel;
import com.swiftsoft.anixartd.ui.model.main.comments.a;
import com.swiftsoft.anixartd.utils.DigitsKt;
import com.swiftsoft.anixartd.utils.Plurals;
import com.swiftsoft.anixartd.utils.Time;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/comments/CommentModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class CommentModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    long k;
    @EpoxyAttribute
    @NotNull
    String l = "";
    @EpoxyAttribute
    Bool m;
    @EpoxyAttribute
    Int n;
    @EpoxyAttribute
    Int o;
    @EpoxyAttribute
    long p;
    @EpoxyAttribute
    long q;
    @EpoxyAttribute
    Bool r;
    @EpoxyAttribute
    Bool s;
    @EpoxyAttribute
    @NotNull
    String t = "";
    @EpoxyAttribute
    @Nullable
    String u = "";
    @EpoxyAttribute
    Bool v;
    @EpoxyAttribute
    Bool w;
    @EpoxyAttribute
    Bool x;
    @EpoxyAttribute
    Listener y;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        ((TextView)view.findViewById(2131362486)).setText((CharSequence)this.l);
        ((TextView)view.findViewById(2131362548)).setText((CharSequence)this.t);
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362872);
        Intrinsics.g((Object)appCompatImageView, (String)"view.sponsor");
        ViewsKt.l((View)appCompatImageView, (Bool)this.v);
        AppCompatImageView appCompatImageView2 = (AppCompatImageView)view.findViewById(2131363094);
        Intrinsics.g((Object)appCompatImageView2, (String)"view.verified");
        ViewsKt.l((View)appCompatImageView2, (Bool)this.w);
        TextView textView = (TextView)view.findViewById(2131362106);
        Time time = Time.a;
        Context context = view.getContext();
        Intrinsics.g((Object)context, (String)"view.context");
        textView.setText((CharSequence)time.g(context, this.p));
        AppCompatImageView appCompatImageView3 = (AppCompatImageView)view.findViewById(2131362186);
        Intrinsics.g((Object)appCompatImageView3, (String)"view.edited");
        ViewsKt.l((View)appCompatImageView3, (Bool)this.r);
        TextView textView2 = (TextView)view.findViewById(2131362486);
        Intrinsics.g((Object)textView2, (String)"view.message");
        ViewsKt.f((View)textView2, (Bool)this.s, (Bool)false, null, (Int)6);
        TextView textView3 = (TextView)view.findViewById(2131362119);
        Intrinsics.g((Object)textView3, (String)"view.deleted");
        ViewsKt.l((View)textView3, (Bool)this.s);
        if (!this.s) {
            if (!this.m && this.n > -5) {
                TextView textView4 = (TextView)com.google.protobuf.a.e((View)view, (Int)2130969583, (TextView)((TextView)view.findViewById(2131362486)), (Int)2131362486);
                LinearLayout linearLayout = (LinearLayout)com.google.protobuf.a.C((TextView)textView4, (String)"view.message", (TextView)textView4, (View)view, (Int)2131362870);
                Intrinsics.g((Object)linearLayout, (String)"view.spoilerHideShow");
                ViewsKt.e((View)linearLayout);
            } else {
                Ref.BooleanRef booleanRef = new Ref.BooleanRef();
                TextView textView5 = (TextView)com.google.protobuf.a.e((View)view, (Int)2130969642, (TextView)((TextView)view.findViewById(2131362486)), (Int)2131362486);
                LinearLayout linearLayout = (LinearLayout)com.google.protobuf.a.f((TextView)textView5, (String)"view.message", (TextView)textView5, (View)view, (Int)2131362870);
                Intrinsics.g((Object)linearLayout, (String)"view.spoilerHideShow");
                ViewsKt.k((View)linearLayout);
                TextView textView6 = (TextView)view.findViewById(2131363061);
                Int n = this.n;
                String string = n > -5 && this.m ? view.getContext().getString(2131951757) : (n <= -5 && this.m ? view.getContext().getString(2131951756) : (n <= -5 && !this.m ? view.getContext().getString(2131951758) : view.getContext().getString(2131951757)));
                textView6.setText((CharSequence)string);
                ((LinearLayout)view.findViewById(2131362870)).setOnClickListener((View.OnClickListener)new a(booleanRef, view, 1));
            }
        }
        ((TextView)view.findViewById(2131363138)).setText((CharSequence)StringsKt.Q((String)DigitsKt.e((Int)this.n), (String)"-", (String)"\u2013", (Bool)false, (Int)4, null));
        TextView textView7 = (TextView)view.findViewById(2131363138);
        Int n = this.n;
        Int n2 = n == 0 ? ViewsKt.c((View)view, (Int)2130969821) : (n > 0 ? view.getResources().getColor(2131099808) : view.getResources().getColor(2131100606));
        textView7.setTextColor(n2);
        RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131363130);
        Intrinsics.g((Object)relativeLayout, (String)"view.vote_minus_inactive");
        Int n3 = this.o;
        Bool bl = n3 == 2 || n3 == 0;
        ViewsKt.l((View)relativeLayout, (Bool)bl);
        RelativeLayout relativeLayout2 = (RelativeLayout)view.findViewById(2131363129);
        Intrinsics.g((Object)relativeLayout2, (String)"view.vote_minus_active");
        Bool bl2 = this.o == 1;
        ViewsKt.l((View)relativeLayout2, (Bool)bl2);
        RelativeLayout relativeLayout3 = (RelativeLayout)view.findViewById(2131363134);
        Intrinsics.g((Object)relativeLayout3, (String)"view.vote_plus_inactive");
        Int n4 = this.o;
        Bool bl3 = n4 == 1 || n4 == 0;
        ViewsKt.l((View)relativeLayout3, (Bool)bl3);
        RelativeLayout relativeLayout4 = (RelativeLayout)view.findViewById(2131363133);
        Intrinsics.g((Object)relativeLayout4, (String)"view.vote_plus_active");
        Bool bl4 = this.o == 2;
        ViewsKt.l((View)relativeLayout4, (Bool)bl4);
        TextView textView8 = (TextView)view.findViewById(2131362820);
        Plurals plurals = Plurals.a;
        Context context2 = view.getContext();
        Intrinsics.g((Object)context2, (String)"view.context");
        textView8.setText((CharSequence)plurals.c(context2, this.q, 2131820561, 2131952419));
        LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362819);
        Intrinsics.g((Object)linearLayout, (String)"view.show_replies");
        long l = this.q LCMP 0L;
        Bool bl5 = false;
        if (l > 0) {
            bl5 = true;
        }
        ViewsKt.l((View)linearLayout, (Bool)bl5);
        AppCompatImageView appCompatImageView4 = (AppCompatImageView)view.findViewById(2131361916);
        Intrinsics.g((Object)appCompatImageView4, (String)"view.avatar");
        ViewsKt.a((AppCompatImageView)appCompatImageView4, (String)this.u);
        Int n5 = DigitsKt.c((Int)16, (View)view);
        Int n6 = DigitsKt.c((Int)8, (View)view);
        Int n7 = DigitsKt.c((Int)16, (View)view);
        Int n8 = DigitsKt.c((Int)8, (View)view);
        Int n9 = DigitsKt.c((Int)42, (View)view);
        Int n10 = DigitsKt.c((Int)42, (View)view);
        if (this.x) {
            n5 = DigitsKt.c((Int)48, (View)view);
            n9 = DigitsKt.c((Int)36, (View)view);
            n10 = DigitsKt.c((Int)36, (View)view);
        }
        view.setPadding(n5, n6, n7, n8);
        ViewGroup.LayoutParams layoutParams = ((AppCompatImageView)view.findViewById(2131361916)).getLayoutParams();
        layoutParams.width = n9;
        layoutParams.height = n10;
        ViewsKt.j((View)view, (Function1)new bind.6(this));
        AppCompatImageView appCompatImageView5 = (AppCompatImageView)view.findViewById(2131361916);
        Intrinsics.g((Object)appCompatImageView5, (String)"view.avatar");
        ViewsKt.j((View)appCompatImageView5, (Function1)new bind.7(this));
        RelativeLayout relativeLayout5 = (RelativeLayout)view.findViewById(2131363128);
        Intrinsics.g((Object)relativeLayout5, (String)"view.vote_minus");
        ViewsKt.j((View)relativeLayout5, (Function1)new bind.8(view, this));
        RelativeLayout relativeLayout6 = (RelativeLayout)view.findViewById(2131363132);
        Intrinsics.g((Object)relativeLayout6, (String)"view.vote_plus");
        ViewsKt.j((View)relativeLayout6, (Function1)new bind.9(view, this));
        TextView textView9 = (TextView)view.findViewById(2131362725);
        Intrinsics.g((Object)textView9, (String)"view.reply");
        ViewsKt.j((View)textView9, (Function1)new bind.10(this));
        LinearLayout linearLayout2 = (LinearLayout)view.findViewById(2131362819);
        Intrinsics.g((Object)linearLayout2, (String)"view.show_replies");
        ViewsKt.j((View)linearLayout2, (Function1)new bind.11(this));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = com.google.protobuf.a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof CommentModel) {
            String string = this.l;
            CommentModel commentModel = (CommentModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)commentModel.l)) {
                arrayList.add((Object)0);
            }
            if (this.m != commentModel.m) {
                arrayList.add((Object)1);
            }
            if (this.n != commentModel.n) {
                arrayList.add((Object)2);
            }
            if (this.p != commentModel.p) {
                arrayList.add((Object)5);
            }
            if (this.q != commentModel.q) {
                arrayList.add((Object)3);
            }
            if (this.o != commentModel.o) {
                arrayList.add((Object)4);
            }
            if (this.r != commentModel.r) {
                arrayList.add((Object)10);
            }
            if (this.s != commentModel.s) {
                arrayList.add((Object)11);
            }
            if (!Intrinsics.c((Object)this.t, (Object)commentModel.t)) {
                arrayList.add((Object)6);
            }
            if (!Intrinsics.c((Object)this.u, (Object)commentModel.u)) {
                arrayList.add((Object)7);
            }
            if (this.v != commentModel.v) {
                arrayList.add((Object)8);
            }
            if (this.w != commentModel.w) {
                arrayList.add((Object)9);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        if (com.google.protobuf.a.z((View)view, (String)"view", list, (String)"payloads", (Int)0)) {
            ((TextView)view.findViewById(2131362486)).setText((CharSequence)this.l);
        }
        if (list.contains((Object)1) || list.contains((Object)11)) {
            TextView textView = (TextView)view.findViewById(2131362486);
            Intrinsics.g((Object)textView, (String)"view.message");
            ViewsKt.f((View)textView, (Bool)this.s, (Bool)false, null, (Int)6);
            TextView textView2 = (TextView)view.findViewById(2131362119);
            Intrinsics.g((Object)textView2, (String)"view.deleted");
            ViewsKt.l((View)textView2, (Bool)this.s);
            if (!this.s) {
                if (!this.m && this.n > -5) {
                    TextView textView3 = (TextView)com.google.protobuf.a.e((View)view, (Int)2130969583, (TextView)((TextView)view.findViewById(2131362486)), (Int)2131362486);
                    Intrinsics.g((Object)textView3, (String)"view.message");
                    textView3.setVisibility(0);
                    LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362870);
                    Intrinsics.g((Object)linearLayout, (String)"view.spoilerHideShow");
                    ViewsKt.e((View)linearLayout);
                } else {
                    Ref.BooleanRef booleanRef = new Ref.BooleanRef();
                    TextView textView4 = (TextView)com.google.protobuf.a.e((View)view, (Int)2130969642, (TextView)((TextView)view.findViewById(2131362486)), (Int)2131362486);
                    LinearLayout linearLayout = (LinearLayout)com.google.protobuf.a.f((TextView)textView4, (String)"view.message", (TextView)textView4, (View)view, (Int)2131362870);
                    Intrinsics.g((Object)linearLayout, (String)"view.spoilerHideShow");
                    linearLayout.setVisibility(0);
                    TextView textView5 = (TextView)view.findViewById(2131363061);
                    Int n = this.n;
                    String string = n > -5 && this.m ? view.getContext().getString(2131951757) : (n <= -5 && this.m ? view.getContext().getString(2131951756) : (n <= -5 && !this.m ? view.getContext().getString(2131951758) : view.getContext().getString(2131951757)));
                    textView5.setText((CharSequence)string);
                    ((LinearLayout)view.findViewById(2131362870)).setOnClickListener((View.OnClickListener)new a(booleanRef, view, 0));
                }
            }
        }
        if (list.contains((Object)2)) {
            ((TextView)view.findViewById(2131363138)).setText((CharSequence)StringsKt.Q((String)DigitsKt.e((Int)this.n), (String)"-", (String)"\u2013", (Bool)false, (Int)4, null));
            TextView textView = (TextView)view.findViewById(2131363138);
            Int n = this.n;
            Int n2 = n == 0 ? ViewsKt.c((View)view, (Int)2130969821) : (n > 0 ? view.getResources().getColor(2131099808) : view.getResources().getColor(2131100606));
            textView.setTextColor(n2);
        }
        if (list.contains((Object)4)) {
            RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131363130);
            Intrinsics.g((Object)relativeLayout, (String)"view.vote_minus_inactive");
            Int n = this.o;
            Bool bl = n == 2 || n == 0;
            ViewsKt.l((View)relativeLayout, (Bool)bl);
            RelativeLayout relativeLayout2 = (RelativeLayout)view.findViewById(2131363129);
            Intrinsics.g((Object)relativeLayout2, (String)"view.vote_minus_active");
            Bool bl2 = this.o == 1;
            ViewsKt.l((View)relativeLayout2, (Bool)bl2);
            RelativeLayout relativeLayout3 = (RelativeLayout)view.findViewById(2131363134);
            Intrinsics.g((Object)relativeLayout3, (String)"view.vote_plus_inactive");
            Int n3 = this.o;
            Bool bl3 = n3 == 1 || n3 == 0;
            ViewsKt.l((View)relativeLayout3, (Bool)bl3);
            RelativeLayout relativeLayout4 = (RelativeLayout)view.findViewById(2131363133);
            Intrinsics.g((Object)relativeLayout4, (String)"view.vote_plus_active");
            Bool bl4 = this.o == 2;
            ViewsKt.l((View)relativeLayout4, (Bool)bl4);
        }
        if (list.contains((Object)5)) {
            TextView textView = (TextView)view.findViewById(2131362106);
            Time time = Time.a;
            Context context = view.getContext();
            Intrinsics.g((Object)context, (String)"view.context");
            textView.setText((CharSequence)time.g(context, this.p));
        }
        if (list.contains((Object)3)) {
            TextView textView = (TextView)view.findViewById(2131362820);
            Plurals plurals = Plurals.a;
            Context context = view.getContext();
            Intrinsics.g((Object)context, (String)"view.context");
            textView.setText((CharSequence)plurals.b(context, (Int)this.q, 2131820561, 2131952419));
            Bool bl = this.q > 0L;
            ViewsKt.l((View)textView, (Bool)bl);
            LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362819);
            Intrinsics.g((Object)linearLayout, (String)"view.show_replies");
            long l = this.q LCMP 0L;
            Bool bl5 = false;
            if (l > 0) {
                bl5 = true;
            }
            ViewsKt.l((View)linearLayout, (Bool)bl5);
        }
        if (list.contains((Object)10)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362186);
            Intrinsics.g((Object)appCompatImageView, (String)"view.edited");
            ViewsKt.l((View)appCompatImageView, (Bool)this.r);
        }
        if (list.contains((Object)6)) {
            ((TextView)view.findViewById(2131362548)).setText((CharSequence)this.t);
        }
        if (list.contains((Object)7)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131361916);
            Intrinsics.g((Object)appCompatImageView, (String)"view.avatar");
            ViewsKt.h((ImageView)appCompatImageView, (String)this.u);
        }
        if (list.contains((Object)8)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362872);
            Intrinsics.g((Object)appCompatImageView, (String)"view.sponsor");
            ViewsKt.l((View)appCompatImageView, (Bool)this.v);
        }
        if (list.contains((Object)9)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131363094);
            Intrinsics.g((Object)appCompatImageView, (String)"view.verified");
            ViewsKt.l((View)appCompatImageView, (Bool)this.w);
        }
    }

    @NotNull
    final Listener v2() {
        Listener listener = this.y;
        if (listener != null) {
            return listener;
        }
        Intrinsics.r((String)"listener");
        throw null;
    }

    func w2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        view.setOnClickListener(null);
    }
}

