/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  kotlin.Metadata
 */
package com.swiftsoft.anixartd.ui.model.main.comments;

import android.view.View;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import kotlin.Metadata;

@Metadata(bv={}, d1={"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001\u00a8\u0006\u0003"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/comments/NoCommentsModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class NoCommentsModel
extends EpoxyModel<View> {
}

