/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.MenuItem
 *  android.view.View
 *  android.widget.TextView
 *  androidx.appcompat.widget.PopupMenu
 *  androidx.appcompat.widget.PopupMenu$OnMenuItemClickListener
 *  com.airbnb.epoxy.EpoxyModel
 *  com.swiftsoft.anixartd.ui.model.main.comments.ExtraCommentVotesModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.comments.ExtraCommentsModel$Listener
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.internal.Intrinsics
 */
package com.swiftsoft.anixartd.ui.model.main.comments;

import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.widget.PopupMenu;
import com.airbnb.epoxy.EpoxyModel;
import com.swiftsoft.anixartd.ui.model.main.comments.ExtraCommentVotesModel;
import com.swiftsoft.anixartd.ui.model.main.comments.ExtraCommentsModel;
import kotlin.jvm.internal.Intrinsics;

final class b
implements PopupMenu.OnMenuItemClickListener {
    final /* synthetic */ Int b;
    final /* synthetic */ View c;
    final /* synthetic */ Object d;

    /* synthetic */ b(EpoxyModel epoxyModel, View view, Int n) {
        this.b = n;
        this.d = epoxyModel;
        this.c = view;
    }

    final Bool onMenuItemClick(MenuItem menuItem) {
        switch (this.b) {
            default: {
                break;
            }
            case 0: {
                ExtraCommentVotesModel extraCommentVotesModel = (ExtraCommentVotesModel)((Object)this.d);
                View view = this.c;
                Intrinsics.h((Object)((Object)extraCommentVotesModel), (String)"this$0");
                Intrinsics.h((Object)view, (String)"$view");
                Int n = menuItem.getItemId();
                if (n != 2131361889) {
                    if (n != 2131362535) {
                        if (n == 2131362610) {
                            extraCommentVotesModel.u2().a(2);
                        }
                    } else {
                        extraCommentVotesModel.u2().a(1);
                    }
                } else {
                    extraCommentVotesModel.u2().a(0);
                }
                ((TextView)view.findViewById(2131362799)).setText((CharSequence)String.valueOf((Object)menuItem.getTitle()));
                return true;
            }
        }
        ExtraCommentsModel extraCommentsModel = (ExtraCommentsModel)((Object)this.d);
        View view = this.c;
        Intrinsics.h((Object)((Object)extraCommentsModel), (String)"this$0");
        Intrinsics.h((Object)view, (String)"$view");
        Int n = menuItem.getItemId();
        if (n != 2131362546) {
            if (n != 2131362565) {
                if (n == 2131362604) {
                    extraCommentsModel.u2().a(3);
                }
            } else {
                extraCommentsModel.u2().a(2);
            }
        } else {
            extraCommentsModel.u2().a(1);
        }
        ((TextView)view.findViewById(2131362799)).setText((CharSequence)String.valueOf((Object)menuItem.getTitle()));
        return true;
    }
}

