/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.swiftsoft.anixartd.ui.fragment.main.watching.a
 *  com.swiftsoft.anixartd.ui.model.main.streaming.ReleaseThirdPartyPlatformModel$Listener
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.model.main.streaming;

import android.view.View;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.swiftsoft.anixartd.ui.fragment.main.watching.a;
import com.swiftsoft.anixartd.ui.model.main.streaming.ReleaseThirdPartyPlatformModel;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u0003\u00a8\u0006\u0004"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/streaming/ReleaseThirdPartyPlatformModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class ReleaseThirdPartyPlatformModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    Listener k;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        view.setOnClickListener((View.OnClickListener)new a((Object)this, 16));
    }

    func u2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        view.setOnClickListener(null);
    }
}

