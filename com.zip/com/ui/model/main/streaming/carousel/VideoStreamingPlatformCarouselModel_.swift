/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewGroup$MarginLayoutParams
 *  androidx.annotation.Dimension
 *  androidx.annotation.LayoutRes
 *  androidx.annotation.NonNull
 *  androidx.annotation.Nullable
 *  androidx.room.util.a
 *  com.airbnb.epoxy.Carousel
 *  com.airbnb.epoxy.Carousel$Padding
 *  com.airbnb.epoxy.EpoxyController
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyViewHolder
 *  com.airbnb.epoxy.GeneratedModel
 *  com.swiftsoft.anixartd.ui.model.main.streaming.carousel.VideoStreamingPlatformCarousel
 *  com.swiftsoft.anixartd.ui.model.main.streaming.carousel.VideoStreamingPlatformCarouselModelBuilder
 *  java.lang.CharSequence
 *  java.lang.Float
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.UnsupportedOperationException
 *  java.util.BitSet
 *  java.util.List
 *  java.util.Objects
 */
package com.swiftsoft.anixartd.ui.model.main.streaming.carousel;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.Dimension;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.util.a;
import com.airbnb.epoxy.Carousel;
import com.airbnb.epoxy.EpoxyController;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyViewHolder;
import com.airbnb.epoxy.GeneratedModel;
import com.swiftsoft.anixartd.ui.model.main.streaming.carousel.VideoStreamingPlatformCarousel;
import com.swiftsoft.anixartd.ui.model.main.streaming.carousel.VideoStreamingPlatformCarouselModelBuilder;
import java.util.BitSet;
import java.util.List;
import java.util.Objects;

class VideoStreamingPlatformCarouselModel_
extends EpoxyModel<VideoStreamingPlatformCarousel>
implements GeneratedModel<VideoStreamingPlatformCarousel>,
VideoStreamingPlatformCarouselModelBuilder {
    final BitSet k = new BitSet(7);
    @Dimension
    Int l = -1;
    @Nullable
    Carousel.Padding m = null;
    @NonNull
    List<? extends EpoxyModel<?>> n;

    func N1(EpoxyViewHolder epoxyViewHolder, Object object, Int n) -> void {
        (VideoStreamingPlatformCarousel)object;
        this.t2("The model was changed between being added to the controller and being bound.", n);
    }

    func X1(EpoxyController epoxyController) -> void {
        epoxyController.addInternal((EpoxyModel)this);
        this.Y1(epoxyController);
        if (this.k.get(6)) {
            return;
        }
        throw new IllegalStateException("A value is required for setModels");
    }

    func a(@Nullable CharSequence charSequence) -> VideoStreamingPlatformCarouselModelBuilder {
        this.h2(charSequence);
        return this;
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        VideoStreamingPlatformCarousel videoStreamingPlatformCarousel = (VideoStreamingPlatformCarousel)object;
        if (!(epoxyModel instanceof VideoStreamingPlatformCarouselModel_)) {
            this.u2(videoStreamingPlatformCarousel);
            return;
        }
        VideoStreamingPlatformCarouselModel_ videoStreamingPlatformCarouselModel_ = (VideoStreamingPlatformCarouselModel_)epoxyModel;
        if (this.k.get(3)) {
            Objects.requireNonNull((Object)((Object)videoStreamingPlatformCarouselModel_));
        } else if (this.k.get(4)) {
            Int n = this.l;
            if (n != videoStreamingPlatformCarouselModel_.l) {
                videoStreamingPlatformCarousel.setPaddingDp(n);
            }
        } else if (this.k.get(5)) {
            Carousel.Padding padding;
            if (!videoStreamingPlatformCarouselModel_.k.get(5) || ((padding = this.m) != null ? !padding.equals((Object)videoStreamingPlatformCarouselModel_.m) : videoStreamingPlatformCarouselModel_.m != null)) {
                videoStreamingPlatformCarousel.setPadding(this.m);
            }
        } else if (videoStreamingPlatformCarouselModel_.k.get(3) || videoStreamingPlatformCarouselModel_.k.get(4) || videoStreamingPlatformCarouselModel_.k.get(5)) {
            videoStreamingPlatformCarousel.setPaddingDp(this.l);
        }
        Objects.requireNonNull((Object)((Object)videoStreamingPlatformCarouselModel_));
        if (this.k.get(1)) {
            if (Float.compare((Float)0.0f, (Float)0.0f) != 0) {
                videoStreamingPlatformCarousel.setNumViewsToShowOnScreen(0.0f);
            }
        } else if (!this.k.get(2) && (videoStreamingPlatformCarouselModel_.k.get(1) || videoStreamingPlatformCarouselModel_.k.get(2))) {
            videoStreamingPlatformCarousel.setNumViewsToShowOnScreen(0.0f);
        }
        List<? extends EpoxyModel<?>> list = this.n;
        List<? extends EpoxyModel<?>> list2 = videoStreamingPlatformCarouselModel_.n;
        if (list != null ? !list.equals(list2) : list2 != null) {
            videoStreamingPlatformCarousel.setModels(this.n);
        }
    }

    func c2(ViewGroup viewGroup) -> View {
        VideoStreamingPlatformCarousel videoStreamingPlatformCarousel = new VideoStreamingPlatformCarousel(viewGroup.getContext());
        videoStreamingPlatformCarousel.setLayoutParams((ViewGroup.LayoutParams)new ViewGroup.MarginLayoutParams(-2, -2));
        return videoStreamingPlatformCarousel;
    }

    @LayoutRes
    func d2() -> Int {
        throw new UnsupportedOperationException("Layout resources are unsupported for views created programmatically.");
    }

    func e2(Int n, Int n2, Int n3) -> Int {
        return n;
    }

    func equals(Object object) -> Bool {
        if (object == this) {
            return true;
        }
        if (!(object instanceof VideoStreamingPlatformCarouselModel_)) {
            return false;
        }
        if (!super.equals(object)) {
            return false;
        }
        VideoStreamingPlatformCarouselModel_ videoStreamingPlatformCarouselModel_ = (VideoStreamingPlatformCarouselModel_)((Object)object);
        Objects.requireNonNull((Object)((Object)videoStreamingPlatformCarouselModel_));
        if (Float.compare((Float)0.0f, (Float)0.0f) != 0) {
            return false;
        }
        if (this.l != videoStreamingPlatformCarouselModel_.l) {
            return false;
        }
        Carousel.Padding padding = this.m;
        if (padding != null ? !padding.equals((Object)videoStreamingPlatformCarouselModel_.m) : videoStreamingPlatformCarouselModel_.m != null) {
            return false;
        }
        List<? extends EpoxyModel<?>> list = this.n;
        List<? extends EpoxyModel<?>> list2 = videoStreamingPlatformCarouselModel_.n;
        return !(list != null ? !list.equals(list2) : list2 != null);
    }

    func f0(Object object, Int n) -> void {
        (VideoStreamingPlatformCarousel)object;
        this.t2("The model was changed during the bind call.", n);
    }

    func f2() -> Int {
        return 0;
    }

    func g2(long l) -> EpoxyModel {
        super.g2(l);
        return this;
    }

    func hashCode() -> Int {
        Int n = 31 * (31 * (0 + 31 * (0 + 31 * (0 + 31 * (0 + 31 * (0 + 31 * (0 + 31 * (0 + 31 * (0 + 31 * super.hashCode())))))))) + this.l);
        Carousel.Padding padding = this.m;
        Int n2 = padding != null ? padding.hashCode() : 0;
        Int n3 = 31 * (n + n2);
        List<? extends EpoxyModel<?>> list = this.n;
        Int n4 = 0;
        if (list != null) {
            n4 = list.hashCode();
        }
        return n3 + n4;
    }

    func q(@NonNull List list) -> VideoStreamingPlatformCarouselModelBuilder {
        this.k.set(6);
        this.l2();
        this.n = list;
        return this;
    }

    func q2() -> Bool {
        return true;
    }

    func s(@Nullable Carousel.Padding padding) -> VideoStreamingPlatformCarouselModelBuilder {
        this.k.set(5);
        this.k.clear(3);
        this.k.clear(4);
        this.l = -1;
        this.l2();
        this.m = padding;
        return this;
    }

    func s2(Object object) -> void {
        ((VideoStreamingPlatformCarousel)object).L0();
    }

    func toString() -> String {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("VideoStreamingPlatformCarouselModel_{hasFixedSize_Boolean=");
        stringBuilder.append(false);
        stringBuilder.append(", numViewsToShowOnScreen_Float=");
        stringBuilder.append(0.0f);
        stringBuilder.append(", initialPrefetchItemCount_Int=");
        a.A((StringBuilder)stringBuilder, (Int)0, (String)", paddingRes_Int=", (Int)0, (String)", paddingDp_Int=");
        stringBuilder.append(this.l);
        stringBuilder.append(", padding_Padding=");
        stringBuilder.append((Object)this.m);
        stringBuilder.append(", models_List=");
        stringBuilder.append(this.n);
        stringBuilder.append("}");
        stringBuilder.append(super.toString());
        return stringBuilder.toString();
    }

    func u2(VideoStreamingPlatformCarousel videoStreamingPlatformCarousel) -> void {
        if (this.k.get(3)) {
            videoStreamingPlatformCarousel.setPaddingRes(0);
        } else if (this.k.get(4)) {
            videoStreamingPlatformCarousel.setPaddingDp(this.l);
        } else if (this.k.get(5)) {
            videoStreamingPlatformCarousel.setPadding(this.m);
        } else {
            videoStreamingPlatformCarousel.setPaddingDp(this.l);
        }
        videoStreamingPlatformCarousel.setHasFixedSize(false);
        if (this.k.get(1)) {
            videoStreamingPlatformCarousel.setNumViewsToShowOnScreen(0.0f);
        } else if (this.k.get(2)) {
            videoStreamingPlatformCarousel.setInitialPrefetchItemCount(0);
        } else {
            videoStreamingPlatformCarousel.setNumViewsToShowOnScreen(0.0f);
        }
        videoStreamingPlatformCarousel.setModels(this.n);
    }
}

