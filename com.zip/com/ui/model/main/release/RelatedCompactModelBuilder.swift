/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.epoxy.EpoxyBuildScope
 *  com.swiftsoft.anixartd.database.entity.Category
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.release;

import com.airbnb.epoxy.EpoxyBuildScope;
import com.swiftsoft.anixartd.database.entity.Category;
import com.swiftsoft.anixartd.ui.model.main.release.RelatedCompactModel;
import org.jetbrains.annotations.Nullable;

@EpoxyBuildScope
interface RelatedCompactModelBuilder {
    RelatedCompactModelBuilder A(@Nullable String var1);

    RelatedCompactModelBuilder T(@Nullable Category var1);

    RelatedCompactModelBuilder b(long var1);

    RelatedCompactModelBuilder c(@Nullable String var1);

    RelatedCompactModelBuilder d1(RelatedCompactModel.Listener var1);

    RelatedCompactModelBuilder e(@Nullable String var1);

    RelatedCompactModelBuilder h(@Nullable Double var1);

    RelatedCompactModelBuilder i(Bool var1);

    RelatedCompactModelBuilder y(long var1);
}

