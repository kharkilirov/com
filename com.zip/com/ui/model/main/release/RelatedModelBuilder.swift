/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.airbnb.epoxy.EpoxyBuildScope
 *  com.swiftsoft.anixartd.database.entity.Category
 *  java.lang.Double
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.release;

import com.airbnb.epoxy.EpoxyBuildScope;
import com.swiftsoft.anixartd.database.entity.Category;
import com.swiftsoft.anixartd.ui.model.main.release.RelatedModel;
import org.jetbrains.annotations.Nullable;

@EpoxyBuildScope
interface RelatedModelBuilder {
    RelatedModelBuilder A(@Nullable String var1);

    RelatedModelBuilder C(@Nullable Long var1);

    RelatedModelBuilder E1(Bool var1);

    RelatedModelBuilder I(Int var1);

    RelatedModelBuilder J(long var1);

    RelatedModelBuilder T(@Nullable Category var1);

    RelatedModelBuilder b(long var1);

    RelatedModelBuilder c(@Nullable String var1);

    RelatedModelBuilder d0(@Nullable Long var1);

    RelatedModelBuilder e(@Nullable String var1);

    RelatedModelBuilder f(Bool var1);

    RelatedModelBuilder f1(RelatedModel.Listener var1);

    RelatedModelBuilder g(@Nullable String var1);

    RelatedModelBuilder h(@Nullable Double var1);

    RelatedModelBuilder h0(Bool var1);

    RelatedModelBuilder i(Bool var1);

    RelatedModelBuilder m(@Nullable Integer var1);

    RelatedModelBuilder n(@Nullable Integer var1);

    RelatedModelBuilder o(Int var1);
}

