/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a.a
 *  android.content.Context
 *  android.content.res.ColorStateList
 *  android.content.res.Resources
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnLongClickListener
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.database.entity.Category
 *  com.swiftsoft.anixartd.ui.fragment.main.profile.d
 *  com.swiftsoft.anixartd.ui.model.main.release.RelatedModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.release.RelatedModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.release.RelatedModel$bind$4
 *  com.swiftsoft.anixartd.ui.model.main.release.RelatedModel$bind$6
 *  com.swiftsoft.anixartd.utils.DigitsKt
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Double
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.release;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.database.entity.Category;
import com.swiftsoft.anixartd.ui.fragment.main.profile.d;
import com.swiftsoft.anixartd.ui.model.main.release.RelatedModel;
import com.swiftsoft.anixartd.utils.DigitsKt;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/release/RelatedModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class RelatedModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    Bool A;
    @EpoxyAttribute
    Listener B;
    @EpoxyAttribute
    @Nullable
    Long k;
    @EpoxyAttribute
    @Nullable
    String l;
    @EpoxyAttribute
    @Nullable
    Integer m;
    @EpoxyAttribute
    @Nullable
    Integer n;
    @EpoxyAttribute
    @Nullable
    Double o;
    @EpoxyAttribute
    @Nullable
    String p;
    @EpoxyAttribute
    @Nullable
    String q;
    @EpoxyAttribute
    @Nullable
    Category r;
    @EpoxyAttribute
    @Nullable
    String s;
    @EpoxyAttribute
    Int t;
    @EpoxyAttribute
    long u;
    @EpoxyAttribute
    @Nullable
    Long v;
    @EpoxyAttribute
    Bool w;
    @EpoxyAttribute
    Int x;
    @EpoxyAttribute
    Bool y;
    @EpoxyAttribute
    Bool z;

    init() {
        Integer n;
        Long l;
        this.k = l = Long.valueOf((long)0L);
        this.l = "";
        this.m = n = Integer.valueOf((Int)0);
        this.n = n;
        this.o = 0.0;
        this.p = "";
        this.q = "";
        this.s = "";
        this.v = l;
    }

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Long l = this.k;
        String string = this.l;
        Integer n = this.m;
        Integer n2 = this.n;
        Double d2 = this.o;
        Long l2 = this.v;
        Int n3 = this.t;
        String string2 = this.s;
        String string3 = this.p;
        Bool bl = this.w;
        Int n4 = this.x;
        long l3 = this.b;
        Bool bl2 = l == null || l != l3;
        view.setEnabled(bl2);
        LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362370);
        long l4 = this.b;
        Int n5 = l != null && l == l4 ? 2131099673 : 0;
        linearLayout.setBackgroundResource(n5);
        TextView textView = (TextView)view.findViewById(2131363181);
        long l5 = this.b;
        Int n6 = l != null && l == l5 ? 2131230886 : 2131230885;
        textView.setBackgroundResource(n6);
        TextView textView2 = (TextView)view.findViewById(2131361999);
        long l6 = this.b;
        Int n7 = l != null && l == l6 ? 2131230886 : 2131230885;
        textView2.setBackgroundResource(n7);
        ImageView imageView = (ImageView)view.findViewById(2131362281);
        Int n8 = bl ? 0 : 8;
        imageView.setVisibility(n8);
        if (n4 != 0) {
            RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362918);
            Intrinsics.g((Object)relativeLayout, (String)"view.status_layout");
            ViewsKt.m((View)relativeLayout, (Bool)true);
            if (n4 != 1) {
                if (n4 != 2) {
                    if (n4 != 3) {
                        if (n4 != 4) {
                            if (n4 == 5) {
                                ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0431\u0440\u043e\u0448\u0435\u043d\u043e");
                                ((RelativeLayout)view.findViewById(2131362918)).setBackgroundTintList(ColorStateList.valueOf((Int)view.getResources().getColor(2131100607)));
                                a.n((View)view, (Int)2131100657, (TextView)((TextView)view.findViewById(2131362909)));
                            }
                        } else {
                            ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u043e\u0442\u043b\u043e\u0436\u0435\u043d\u043e");
                            ((RelativeLayout)view.findViewById(2131362918)).setBackgroundTintList(ColorStateList.valueOf((Int)view.getResources().getColor(2131100687)));
                            a.n((View)view, (Int)2131100657, (TextView)((TextView)view.findViewById(2131362909)));
                        }
                    } else {
                        ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u043f\u0440\u043e\u0441\u043c\u043e\u0442\u0440\u0435\u043d\u043e");
                        ((RelativeLayout)view.findViewById(2131362918)).setBackgroundTintList(ColorStateList.valueOf((Int)view.getResources().getColor(2131099691)));
                        a.n((View)view, (Int)2131100657, (TextView)((TextView)view.findViewById(2131362909)));
                    }
                } else {
                    ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0432 \u043f\u043b\u0430\u043d\u0430\u0445");
                    ((RelativeLayout)view.findViewById(2131362918)).setBackgroundTintList(ColorStateList.valueOf((Int)view.getResources().getColor(2131100604)));
                    a.n((View)view, (Int)2131100657, (TextView)((TextView)view.findViewById(2131362909)));
                }
            } else {
                ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0441\u043c\u043e\u0442\u0440\u044e");
                ((RelativeLayout)view.findViewById(2131362918)).setBackgroundTintList(ColorStateList.valueOf((Int)view.getResources().getColor(2131099809)));
                a.n((View)view, (Int)2131100657, (TextView)((TextView)view.findViewById(2131362909)));
            }
        } else {
            RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362918);
            Intrinsics.g((Object)relativeLayout, (String)"view.status_layout");
            ViewsKt.m((View)relativeLayout, (Bool)false);
        }
        Bool bl3 = string == null || string.length() == 0;
        if (bl3) {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)"\u0411\u0435\u0437 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u044f");
        } else {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)string);
        }
        if (n != null && n2 != null && Intrinsics.c((Object)n, (Object)n2) || l2 != null && l2 == 3L) {
            String string4;
            TextView textView3 = (TextView)view.findViewById(2131362200);
            if (n2 != null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append((Object)n2);
                stringBuilder.append(" \u044d\u043f");
                string4 = stringBuilder.toString();
            } else {
                string4 = "? \u044d\u043f";
            }
            textView3.setText((CharSequence)string4);
            TextView textView4 = (TextView)view.findViewById(2131362200);
            TextView textView5 = (TextView)a.C((TextView)textView4, (String)"view.episodes", (TextView)textView4, (View)view, (Int)2131362164);
            Intrinsics.g((Object)textView5, (String)"view.dot");
            ViewsKt.k((View)textView5);
        } else if (n != null && n2 != null) {
            a.t((Integer)n, (String)" \u0438\u0437 ", (Integer)n2, (String)" \u044d\u043f", (TextView)((TextView)view.findViewById(2131362200)));
            TextView textView6 = (TextView)view.findViewById(2131362200);
            TextView textView7 = (TextView)a.C((TextView)textView6, (String)"view.episodes", (TextView)textView6, (View)view, (Int)2131362164);
            Intrinsics.g((Object)textView7, (String)"view.dot");
            ViewsKt.k((View)textView7);
        } else if (n != null && n2 == null) {
            TextView textView8 = (TextView)a.g((Integer)n, (String)" \u0438\u0437 ? \u044d\u043f", (TextView)((TextView)view.findViewById(2131362200)), (View)view, (Int)2131362200);
            TextView textView9 = (TextView)a.C((TextView)textView8, (String)"view.episodes", (TextView)textView8, (View)view, (Int)2131362164);
            Intrinsics.g((Object)textView9, (String)"view.dot");
            ViewsKt.k((View)textView9);
        } else if (n == null && n2 != null) {
            a.u((String)"? \u0438\u0437 ", (Integer)n2, (String)" \u044d\u043f", (TextView)((TextView)view.findViewById(2131362200)));
            TextView textView10 = (TextView)view.findViewById(2131362200);
            TextView textView11 = (TextView)a.C((TextView)textView10, (String)"view.episodes", (TextView)textView10, (View)view, (Int)2131362164);
            Intrinsics.g((Object)textView11, (String)"view.dot");
            ViewsKt.k((View)textView11);
        } else {
            TextView textView12 = (TextView)view.findViewById(2131362200);
            TextView textView13 = (TextView)a.f((TextView)textView12, (String)"view.episodes", (TextView)textView12, (View)view, (Int)2131362164);
            Intrinsics.g((Object)textView13, (String)"view.dot");
            ViewsKt.e((View)textView13);
        }
        LinearLayout linearLayout2 = (LinearLayout)view.findViewById(2131362662);
        Intrinsics.g((Object)linearLayout2, (String)"view.rating_layout");
        ViewsKt.l((View)linearLayout2, (Bool)this.y);
        TextView textView14 = (TextView)view.findViewById(2131361999);
        Intrinsics.g((Object)textView14, (String)"view.category");
        Bool bl4 = this.r != null;
        ViewsKt.l((View)textView14, (Bool)bl4);
        Category category = this.r;
        if (category != null) {
            ((TextView)view.findViewById(2131361999)).setText((CharSequence)category.getName());
        }
        if (d2 != null) {
            a.s((Double)d2, (Int)0, (Int)1, (TextView)((TextView)view.findViewById(2131362324)));
        }
        Bool bl5 = string3 == null || string3.length() == 0;
        if (bl5 && (l2 == null || l2 != 3L)) {
            ((TextView)view.findViewById(2131362123)).setText((CharSequence)view.getContext().getString(2131951809));
        } else {
            ((TextView)view.findViewById(2131362123)).setText((CharSequence)string3);
        }
        Bool bl6 = 1 <= n3 && n3 < 5;
        String string5 = "";
        if (bl6) {
            String string6 = n3 != 1 ? (n3 != 2 ? (n3 != 3 ? (n3 != 4 ? string5 : "\u043e\u0441\u0435\u043d\u044c") : "\u043b\u0435\u0442\u043e") : "\u0432\u0435\u0441\u043d\u0430") : "\u0437\u0438\u043c\u0430";
            string5 = a.a.l((String)string5, (String)string6, (char)' ');
        }
        Bool bl7 = string2 == null || string2.length() == 0;
        if (!bl7) {
            string5 = a.a.m((String)string5, (String)string2, (String)" \u0433.");
        }
        TextView textView15 = (TextView)view.findViewById(2131363181);
        Intrinsics.g((Object)textView15, (String)"view.year");
        Bool bl8 = string5.length() == 0;
        ViewsKt.f((View)textView15, (Bool)bl8, (Bool)false, null, (Int)6);
        ((TextView)view.findViewById(2131363181)).setText((CharSequence)string5);
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362613);
        Intrinsics.g((Object)appCompatImageView, (String)"view.poster");
        ViewsKt.h((ImageView)appCompatImageView, (String)this.q);
        View view2 = view.findViewById(2131362432);
        Intrinsics.g((Object)view2, (String)"view.lineTop");
        ViewsKt.f((View)view2, (Bool)this.z, (Bool)false, null, (Int)6);
        View view3 = view.findViewById(2131362431);
        Intrinsics.g((Object)view3, (String)"view.lineBottom");
        ViewsKt.f((View)view3, (Bool)this.A, (Bool)false, null, (Int)6);
        ViewsKt.j((View)view, (Function1)new bind.4(this));
        view.setOnLongClickListener((View.OnLongClickListener)new d((Object)this, 14));
        ImageView imageView2 = (ImageView)view.findViewById(2131362497);
        Intrinsics.g((Object)imageView2, (String)"view.more");
        ViewsKt.j((View)imageView2, (Function1)new bind.6(this));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof RelatedModel) {
            String string = this.l;
            RelatedModel relatedModel = (RelatedModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)relatedModel.l)) {
                arrayList.add((Object)0);
            }
            if (!Intrinsics.c((Object)this.m, (Object)relatedModel.m)) {
                arrayList.add((Object)1);
            }
            if (!Intrinsics.c((Object)this.n, (Object)relatedModel.n)) {
                arrayList.add((Object)2);
            }
            if (!Intrinsics.a((Double)this.o, (Double)relatedModel.o)) {
                arrayList.add((Object)3);
            }
            if (!Intrinsics.c((Object)this.p, (Object)relatedModel.p)) {
                arrayList.add((Object)4);
            }
            if (!Intrinsics.c((Object)this.q, (Object)relatedModel.q)) {
                arrayList.add((Object)5);
            }
            if (!Intrinsics.c((Object)this.r, (Object)relatedModel.r)) {
                arrayList.add((Object)6);
            }
            if (!Intrinsics.c((Object)this.s, (Object)relatedModel.s)) {
                arrayList.add((Object)7);
            }
            if (this.t != relatedModel.t) {
                arrayList.add((Object)8);
            }
            if (!Intrinsics.c((Object)this.v, (Object)relatedModel.v)) {
                arrayList.add((Object)9);
            }
            if (this.w != relatedModel.w) {
                arrayList.add((Object)10);
            }
            if (this.x != relatedModel.x) {
                arrayList.add((Object)11);
            }
            if (this.y != relatedModel.y) {
                arrayList.add((Object)12);
            }
            if (this.A != relatedModel.A) {
                arrayList.add((Object)13);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func d2() -> Int {
        return 2131558652;
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        Double d2;
        if (a.z((View)view, (String)"view", list, (String)"payloads", (Int)0)) {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)this.l);
        }
        if (list.contains((Object)1)) {
            TextView textView = (TextView)view.findViewById(2131362200);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append((Object)this.m);
            stringBuilder.append(" \u0438\u0437 ");
            a.w((StringBuilder)stringBuilder, (Integer)this.n, (TextView)textView);
        }
        if (list.contains((Object)2)) {
            TextView textView = (TextView)view.findViewById(2131362200);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append((Object)this.m);
            stringBuilder.append(" \u0438\u0437 ");
            a.w((StringBuilder)stringBuilder, (Integer)this.n, (TextView)textView);
        }
        if (list.contains((Object)3) && (d2 = this.o) != null) {
            Double d3 = d2;
            ((TextView)view.findViewById(2131362324)).setText((CharSequence)DigitsKt.d((Double)d3, (Int)0, (Int)1));
        }
        if (list.contains((Object)4)) {
            Long l;
            String string = this.p;
            Bool bl = string == null || string.length() == 0;
            if (bl && ((l = this.v) == null || l != 3L)) {
                ((TextView)view.findViewById(2131362123)).setText((CharSequence)view.getContext().getString(2131951809));
            } else {
                ((TextView)view.findViewById(2131362123)).setText((CharSequence)this.p);
            }
        }
        if (list.contains((Object)5)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362613);
            Intrinsics.g((Object)appCompatImageView, (String)"view.poster");
            ViewsKt.h((ImageView)appCompatImageView, (String)this.q);
        }
        if (list.contains((Object)6)) {
            TextView textView = (TextView)view.findViewById(2131361999);
            Intrinsics.g((Object)textView, (String)"view.category");
            Bool bl = this.r != null;
            ViewsKt.l((View)textView, (Bool)bl);
            Category category = this.r;
            if (category != null) {
                ((TextView)view.findViewById(2131361999)).setText((CharSequence)category.getName());
            }
        }
        Bool bl = list.contains((Object)7);
        Int n = 8;
        if (bl || list.contains((Object)n)) {
            String string;
            Int n2 = this.t;
            Bool bl2 = 1 <= n2 && n2 < 5;
            String string2 = "";
            if (bl2) {
                String string3 = n2 != 1 ? (n2 != 2 ? (n2 != 3 ? (n2 != 4 ? string2 : "\u043e\u0441\u0435\u043d\u044c") : "\u043b\u0435\u0442\u043e") : "\u0432\u0435\u0441\u043d\u0430") : "\u0437\u0438\u043c\u0430";
                string2 = a.a.l((String)string2, (String)string3, (char)' ');
            }
            Bool bl3 = (string = this.s) == null || string.length() == 0;
            if (!bl3) {
                string2 = a.a.q((StringBuilder)a.a.u((String)string2), (String)this.s, (String)" \u0433.");
            }
            TextView textView = (TextView)view.findViewById(2131363181);
            Intrinsics.g((Object)textView, (String)"view.year");
            Bool bl4 = string2.length() == 0;
            ViewsKt.f((View)textView, (Bool)bl4, (Bool)false, null, (Int)6);
            ((TextView)view.findViewById(2131363181)).setText((CharSequence)string2);
        }
        if (list.contains((Object)10)) {
            ImageView imageView = (ImageView)view.findViewById(2131362281);
            if (this.w) {
                n = 0;
            }
            imageView.setVisibility(n);
        }
        if (list.contains((Object)11)) {
            if (this.x != 0) {
                RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362918);
                Intrinsics.g((Object)relativeLayout, (String)"view.status_layout");
                ViewsKt.m((View)relativeLayout, (Bool)true);
                Int n3 = this.x;
                if (n3 != 1) {
                    if (n3 != 2) {
                        if (n3 != 3) {
                            if (n3 != 4) {
                                if (n3 == 5) {
                                    ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0431\u0440\u043e\u0448\u0435\u043d\u043e");
                                    ((RelativeLayout)view.findViewById(2131362918)).setBackgroundTintList(ColorStateList.valueOf((Int)view.getResources().getColor(2131100607)));
                                    a.n((View)view, (Int)2131100657, (TextView)((TextView)view.findViewById(2131362909)));
                                }
                            } else {
                                ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u043e\u0442\u043b\u043e\u0436\u0435\u043d\u043e");
                                ((RelativeLayout)view.findViewById(2131362918)).setBackgroundTintList(ColorStateList.valueOf((Int)view.getResources().getColor(2131100687)));
                                a.n((View)view, (Int)2131100657, (TextView)((TextView)view.findViewById(2131362909)));
                            }
                        } else {
                            ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u043f\u0440\u043e\u0441\u043c\u043e\u0442\u0440\u0435\u043d\u043e");
                            ((RelativeLayout)view.findViewById(2131362918)).setBackgroundTintList(ColorStateList.valueOf((Int)view.getResources().getColor(2131099691)));
                            a.n((View)view, (Int)2131100657, (TextView)((TextView)view.findViewById(2131362909)));
                        }
                    } else {
                        ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0432 \u043f\u043b\u0430\u043d\u0430\u0445");
                        ((RelativeLayout)view.findViewById(2131362918)).setBackgroundTintList(ColorStateList.valueOf((Int)view.getResources().getColor(2131100604)));
                        a.n((View)view, (Int)2131100657, (TextView)((TextView)view.findViewById(2131362909)));
                    }
                } else {
                    ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0441\u043c\u043e\u0442\u0440\u044e");
                    ((RelativeLayout)view.findViewById(2131362918)).setBackgroundTintList(ColorStateList.valueOf((Int)view.getResources().getColor(2131099809)));
                    a.n((View)view, (Int)2131100657, (TextView)((TextView)view.findViewById(2131362909)));
                }
            } else {
                RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362918);
                Intrinsics.g((Object)relativeLayout, (String)"view.status_layout");
                ViewsKt.m((View)relativeLayout, (Bool)false);
            }
        }
        if (list.contains((Object)12)) {
            LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362662);
            Intrinsics.g((Object)linearLayout, (String)"view.rating_layout");
            ViewsKt.l((View)linearLayout, (Bool)this.y);
        }
        if (list.contains((Object)13)) {
            View view2 = view.findViewById(2131362431);
            Intrinsics.g((Object)view2, (String)"view.lineBottom");
            ViewsKt.f((View)view2, (Bool)this.A, (Bool)false, null, (Int)6);
        }
    }

    @NotNull
    final Listener v2() {
        Listener listener = this.B;
        if (listener != null) {
            return listener;
        }
        Intrinsics.r((String)"listener");
        throw null;
    }

    func w2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        view.setOnClickListener(null);
        view.setOnLongClickListener(null);
        ((ImageView)view.findViewById(2131362497)).setOnClickListener(null);
    }
}

