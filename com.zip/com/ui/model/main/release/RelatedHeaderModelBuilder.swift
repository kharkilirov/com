/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Nullable
 *  com.airbnb.epoxy.EpoxyBuildScope
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModel$SpanSizeOverrideCallback
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.release;

import com.airbnb.epoxy.EpoxyBuildScope;
import com.airbnb.epoxy.EpoxyModel;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@EpoxyBuildScope
interface RelatedHeaderModelBuilder {
    RelatedHeaderModelBuilder a(@androidx.annotation.Nullable CharSequence var1);

    RelatedHeaderModelBuilder c(@NotNull String var1);

    RelatedHeaderModelBuilder d(@androidx.annotation.Nullable EpoxyModel.SpanSizeOverrideCallback var1);

    RelatedHeaderModelBuilder g(@Nullable String var1);

    RelatedHeaderModelBuilder l0(@NotNull String var1);
}

