/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.release;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.swiftsoft.anixartd.utils.ViewsKt;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001\u00a8\u0006\u0003"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/release/VideoHeader;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class VideoHeader
extends EpoxyModel<View> {
    @EpoxyAttribute
    @Nullable
    String k = "";
    @EpoxyAttribute
    @Nullable
    String l = "";

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        ((TextView)view.findViewById(2131363004)).setText((CharSequence)this.k);
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362613);
        Intrinsics.g((Object)appCompatImageView, (String)"view.poster");
        ViewsKt.h((ImageView)appCompatImageView, (String)this.l);
    }
}

