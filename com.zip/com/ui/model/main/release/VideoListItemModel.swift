/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnLongClickListener
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.fragment.main.profile.d
 *  com.swiftsoft.anixartd.ui.model.main.release.VideoListItemModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.release.VideoListItemModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.release.VideoListItemModel$bind$1
 *  com.swiftsoft.anixartd.ui.model.main.release.VideoListItemModel$bind$3
 *  com.swiftsoft.anixartd.utils.Time
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.release;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.fragment.main.profile.d;
import com.swiftsoft.anixartd.ui.model.main.release.VideoListItemModel;
import com.swiftsoft.anixartd.utils.Time;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/release/VideoListItemModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class VideoListItemModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    long k;
    @EpoxyAttribute
    @NotNull
    String l = "";
    @EpoxyAttribute
    @Nullable
    String m = "";
    @EpoxyAttribute
    @NotNull
    String n = "";
    @EpoxyAttribute
    long o;
    @EpoxyAttribute
    @Nullable
    String p = "";
    @EpoxyAttribute
    @NotNull
    String q = "";
    @EpoxyAttribute
    @Nullable
    String r = "";
    @EpoxyAttribute
    Listener s;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        TextView textView = (TextView)view.findViewById(2131362525);
        Int n = this.l.length();
        Bool bl = true;
        Bool bl2 = n > 0;
        String string = bl2 ? this.l : view.getContext().getString(2131952628);
        textView.setText((CharSequence)string);
        ((TextView)view.findViewById(2131361999)).setText((CharSequence)this.m);
        ((TextView)view.findViewById(2131362548)).setText((CharSequence)this.n);
        TextView textView2 = (TextView)view.findViewById(2131363003);
        Time time = Time.a;
        Context context = view.getContext();
        Intrinsics.g((Object)context, (String)"view.context");
        textView2.setText((CharSequence)time.g(context, this.o));
        TextView textView3 = (TextView)view.findViewById(2131363003);
        Intrinsics.g((Object)textView3, (String)"view.timestamp");
        Bool bl3 = this.o > 0L;
        ViewsKt.l((View)textView3, (Bool)bl3);
        TextView textView4 = (TextView)view.findViewById(2131362164);
        Intrinsics.g((Object)textView4, (String)"view.dot");
        Bool bl4 = this.o > 0L;
        ViewsKt.l((View)textView4, (Bool)bl4);
        ((TextView)view.findViewById(2131362700)).setText((CharSequence)this.p);
        TextView textView5 = (TextView)view.findViewById(2131362700);
        Intrinsics.g((Object)textView5, (String)"view.release_title");
        String string2 = this.p;
        if (string2 != null && string2.length() != 0) {
            bl = false;
        }
        ViewsKt.f((View)textView5, (Bool)bl, (Bool)false, null, (Int)6);
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362361);
        Intrinsics.g((Object)appCompatImageView, (String)"view.image");
        ViewsKt.h((ImageView)appCompatImageView, (String)this.q);
        ImageView imageView = (ImageView)view.findViewById(2131362348);
        Intrinsics.g((Object)imageView, (String)"view.hostingIcon");
        ViewsKt.h((ImageView)imageView, (String)this.r);
        ViewsKt.j((View)view, (Function1)new bind.1(this));
        view.setOnLongClickListener((View.OnLongClickListener)new d((Object)this, 16));
        ImageView imageView2 = (ImageView)view.findViewById(2131362497);
        Intrinsics.g((Object)imageView2, (String)"view.more");
        ViewsKt.j((View)imageView2, (Function1)new bind.3(this));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof VideoListItemModel) {
            String string = this.l;
            VideoListItemModel videoListItemModel = (VideoListItemModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)videoListItemModel.l)) {
                arrayList.add((Object)1);
            }
            if (!Intrinsics.c((Object)this.m, (Object)videoListItemModel.m)) {
                arrayList.add((Object)2);
            }
            if (!Intrinsics.c((Object)this.n, (Object)videoListItemModel.n)) {
                arrayList.add((Object)3);
            }
            if (this.o != videoListItemModel.o) {
                arrayList.add((Object)4);
            }
            if (!Intrinsics.c((Object)this.p, (Object)videoListItemModel.p)) {
                arrayList.add((Object)5);
            }
            if (!Intrinsics.c((Object)this.q, (Object)videoListItemModel.q)) {
                arrayList.add((Object)6);
            }
            if (!Intrinsics.c((Object)this.r, (Object)videoListItemModel.r)) {
                arrayList.add((Object)7);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        Bool bl = true;
        if (a.z((View)view, (String)"view", list, (String)"payloads", (Int)bl)) {
            TextView textView = (TextView)view.findViewById(2131362525);
            Bool bl2 = this.l.length() > 0;
            String string = bl2 ? this.l : view.getContext().getString(2131952628);
            textView.setText((CharSequence)string);
        }
        if (list.contains((Object)2)) {
            ((TextView)view.findViewById(2131361999)).setText((CharSequence)this.m);
        }
        if (list.contains((Object)3)) {
            ((TextView)view.findViewById(2131362548)).setText((CharSequence)this.n);
        }
        if (list.contains((Object)4)) {
            TextView textView = (TextView)view.findViewById(2131363003);
            Time time = Time.a;
            Context context = view.getContext();
            Intrinsics.g((Object)context, (String)"view.context");
            textView.setText((CharSequence)time.g(context, this.o));
            TextView textView2 = (TextView)view.findViewById(2131363003);
            Intrinsics.g((Object)textView2, (String)"view.timestamp");
            Bool bl3 = this.o > 0L;
            ViewsKt.l((View)textView2, (Bool)bl3);
        }
        if (list.contains((Object)5)) {
            ((TextView)view.findViewById(2131362700)).setText((CharSequence)this.p);
            TextView textView = (TextView)view.findViewById(2131362700);
            Intrinsics.g((Object)textView, (String)"view.release_title");
            String string = this.p;
            if (string != null && string.length() != 0) {
                bl = false;
            }
            ViewsKt.f((View)textView, (Bool)bl, (Bool)false, null, (Int)6);
        }
        if (list.contains((Object)6)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362361);
            Intrinsics.g((Object)appCompatImageView, (String)"view.image");
            ViewsKt.h((ImageView)appCompatImageView, (String)this.q);
        }
        if (list.contains((Object)7)) {
            ImageView imageView = (ImageView)view.findViewById(2131362348);
            Intrinsics.g((Object)imageView, (String)"view.hostingIcon");
            ViewsKt.h((ImageView)imageView, (String)this.r);
        }
    }

    @NotNull
    final Listener v2() {
        Listener listener = this.s;
        if (listener != null) {
            return listener;
        }
        Intrinsics.r((String)"listener");
        throw null;
    }

    func w2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        view.setOnClickListener(null);
        view.setOnLongClickListener(null);
        ((ImageView)view.findViewById(2131362497)).setOnClickListener(null);
    }
}

