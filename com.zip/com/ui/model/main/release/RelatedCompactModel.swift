/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.database.entity.Category
 *  com.swiftsoft.anixartd.ui.model.main.release.RelatedCompactModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.release.RelatedCompactModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.release.RelatedCompactModel$bind$4
 *  com.swiftsoft.anixartd.utils.DigitsKt
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.release;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.database.entity.Category;
import com.swiftsoft.anixartd.ui.model.main.release.RelatedCompactModel;
import com.swiftsoft.anixartd.ui.model.main.release.RelatedModel;
import com.swiftsoft.anixartd.utils.DigitsKt;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/release/RelatedCompactModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class RelatedCompactModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    long k;
    @EpoxyAttribute
    @Nullable
    String l = "";
    @EpoxyAttribute
    @Nullable
    String m = "";
    @EpoxyAttribute
    @Nullable
    Double n = 0.0;
    @EpoxyAttribute
    @Nullable
    String o = "";
    @EpoxyAttribute
    @Nullable
    Category p;
    @EpoxyAttribute
    Bool q;
    @EpoxyAttribute
    Listener r;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        long l = this.k;
        String string = this.l;
        String string2 = this.m;
        Double d2 = this.n;
        long l2 = this.b;
        Bool bl = true;
        Bool bl2 = l != l2;
        view.setEnabled(bl2);
        LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362370);
        Intrinsics.g((Object)linearLayout, (String)"view.inactive");
        Bool bl3 = l == this.b;
        ViewsKt.m((View)linearLayout, (Bool)bl3);
        if (string != null) {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)string);
        }
        Bool bl4 = string2 == null || string2.length() == 0;
        if (bl4) {
            TextView textView = (TextView)view.findViewById(2131363181);
            TextView textView2 = (TextView)a.f((TextView)textView, (String)"view.year", (TextView)textView, (View)view, (Int)2131362164);
            Intrinsics.g((Object)textView2, (String)"view.dot");
            ViewsKt.e((View)textView2);
        } else {
            TextView textView = (TextView)view.findViewById(2131363181);
            TextView textView3 = (TextView)a.C((TextView)textView, (String)"view.year", (TextView)textView, (View)view, (Int)2131362164);
            TextView textView4 = (TextView)a.C((TextView)textView3, (String)"view.dot", (TextView)textView3, (View)view, (Int)2131363181);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string2);
            stringBuilder.append(" \u0433\u043e\u0434");
            textView4.setText((CharSequence)stringBuilder.toString());
        }
        LinearLayout linearLayout2 = (LinearLayout)view.findViewById(2131362662);
        Intrinsics.g((Object)linearLayout2, (String)"view.rating_layout");
        ViewsKt.l((View)linearLayout2, (Bool)this.q);
        if (d2 != null) {
            a.s((Double)d2, (Int)0, (Int)bl, (TextView)((TextView)view.findViewById(2131362324)));
        }
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362613);
        Intrinsics.g((Object)appCompatImageView, (String)"view.poster");
        ViewsKt.h((ImageView)appCompatImageView, (String)this.o);
        TextView textView = (TextView)view.findViewById(2131361999);
        Intrinsics.g((Object)textView, (String)"view.category");
        if (this.p == null) {
            bl = false;
        }
        ViewsKt.l((View)textView, (Bool)bl);
        Category category = this.p;
        if (category != null) {
            ((TextView)view.findViewById(2131361999)).setText((CharSequence)category.getName());
        }
        ViewsKt.j((View)view, (Function1)new bind.4(this));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof RelatedModel) {
            String string = this.l;
            RelatedModel relatedModel = (RelatedModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)relatedModel.l)) {
                arrayList.add((Object)0);
            }
            if (!Intrinsics.c((Object)this.m, (Object)relatedModel.s)) {
                arrayList.add((Object)1);
            }
            if (!Intrinsics.a((Double)this.n, (Double)relatedModel.o)) {
                arrayList.add((Object)2);
            }
            if (!Intrinsics.c((Object)this.o, (Object)relatedModel.q)) {
                arrayList.add((Object)3);
            }
            if (!Intrinsics.c((Object)this.p, (Object)relatedModel.r)) {
                arrayList.add((Object)4);
            }
            if (this.q != relatedModel.y) {
                arrayList.add((Object)5);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func d2() -> Int {
        return 2131558653;
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        Double d2;
        if (a.z((View)view, (String)"view", list, (String)"payloads", (Int)0)) {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)this.l);
        }
        if (list.contains((Object)1)) {
            String string = this.m;
            Bool bl = string == null || string.length() == 0;
            if (bl) {
                TextView textView = (TextView)view.findViewById(2131363181);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(this.m);
                stringBuilder.append(" \u0433\u043e\u0434");
                textView.setText((CharSequence)stringBuilder.toString());
            }
        }
        if (list.contains((Object)2) && (d2 = this.n) != null) {
            Double d3 = d2;
            ((TextView)view.findViewById(2131362324)).setText((CharSequence)DigitsKt.d((Double)d3, (Int)0, (Int)1));
        }
        if (list.contains((Object)3)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362613);
            Intrinsics.g((Object)appCompatImageView, (String)"view.poster");
            ViewsKt.h((ImageView)appCompatImageView, (String)this.o);
        }
        if (list.contains((Object)4)) {
            TextView textView = (TextView)view.findViewById(2131361999);
            Intrinsics.g((Object)textView, (String)"view.category");
            Category category = this.p;
            Bool bl = false;
            if (category != null) {
                bl = true;
            }
            ViewsKt.l((View)textView, (Bool)bl);
            Category category2 = this.p;
            if (category2 != null) {
                ((TextView)view.findViewById(2131361999)).setText((CharSequence)category2.getName());
            }
        }
        if (list.contains((Object)5)) {
            LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362662);
            Intrinsics.g((Object)linearLayout, (String)"view.rating_layout");
            ViewsKt.l((View)linearLayout, (Bool)this.q);
        }
    }

    func v2(@NotNull View view) -> void {
        a.p((View)view, (String)"view", null, null);
    }
}

