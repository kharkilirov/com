/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  androidx.constraintlayout.widget.ConstraintLayout
 *  at.blogc.android.views.ExpandableTextView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.android.material.button.MaterialButton
 *  com.swiftsoft.anixartd.ui.model.main.collections.b
 *  com.swiftsoft.anixartd.ui.model.main.release.RelatedHeaderModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.release.RelatedHeaderModel$bind$2
 *  com.swiftsoft.anixartd.ui.model.main.release.RelatedHeaderModel$bind$3
 *  com.swiftsoft.anixartd.utils.DigitsKt
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.release;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import at.blogc.android.views.ExpandableTextView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.android.material.button.MaterialButton;
import com.swiftsoft.anixartd.ui.model.main.collections.b;
import com.swiftsoft.anixartd.ui.model.main.release.RelatedHeaderModel;
import com.swiftsoft.anixartd.utils.DigitsKt;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001\u00a8\u0006\u0003"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/release/RelatedHeaderModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class RelatedHeaderModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    @NotNull
    String k = "";
    @EpoxyAttribute
    @Nullable
    String l = "";
    @EpoxyAttribute
    @NotNull
    String m = "";

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    func Z1(Object var1_1) -> void {
        block8 : {
            block9 : {
                var2_2 = (View)var1_1;
                Intrinsics.h((Object)var2_2, (String)"view");
                var3_3 = var2_2.getContext();
                var4_4 = StringsKt.E((CharSequence)this.m);
                var5_5 = StringsKt.E((CharSequence)this.k);
                var6_6 = 1;
                if (var5_5) ** GOTO lbl-1000
                var20_7 = this.l;
                var21_8 = var20_7 == null || StringsKt.E((CharSequence)var20_7);
                if (!var21_8) {
                    var7_9 = false;
                } else lbl-1000: // 2 sources:
                {
                    var7_9 = true;
                }
                var8_10 = (ConstraintLayout)var2_2.findViewById(2131362334);
                if (var4_4) {
                    Intrinsics.g((Object)var8_10, (String)"bind$lambda$0");
                    ViewsKt.e((View)var8_10);
                } else {
                    Intrinsics.g((Object)var8_10, (String)"bind$lambda$0");
                    ViewsKt.k((View)var8_10);
                    var9_11 = (ImageView)var2_2.findViewById(2131362335);
                    Intrinsics.g((Object)var9_11, (String)"view.headerImageView");
                    ViewsKt.h((ImageView)var9_11, (String)this.m);
                }
                var10_12 = (TextView)var2_2.findViewById(2131362337);
                Intrinsics.g((Object)var10_12, (String)"view.headerNameRu");
                ViewsKt.f((View)var10_12, (Bool)var7_9, (Bool)false, null, (Int)6);
                var11_13 = (ExpandableTextView)var2_2.findViewById(2131362332);
                Intrinsics.g((Object)var11_13, (String)"view.headerDescription");
                ViewsKt.f((View)var11_13, (Bool)var7_9, (Bool)false, null, (Int)6);
                var12_14 = (MaterialButton)var2_2.findViewById(2131362333);
                Intrinsics.g((Object)var12_14, (String)"view.headerExpand");
                ViewsKt.f((View)var12_14, (Bool)var7_9, (Bool)false, null, (Int)6);
                ((TextView)var2_2.findViewById(2131362337)).setText((CharSequence)this.k);
                ((ExpandableTextView)var2_2.findViewById(2131362332)).setText((CharSequence)this.l);
                var13_15 = (ExpandableTextView)var2_2.findViewById(2131362332);
                var14_16 = new bind.2(var2_2);
                var13_15.b.add((Object)var14_16);
                var16_17 = (MaterialButton)var2_2.findViewById(2131362333);
                Intrinsics.g((Object)var16_17, (String)"view.headerExpand");
                ViewsKt.j((View)var16_17, (Function1)new bind.3(var2_2));
                ((ExpandableTextView)var2_2.findViewById(2131362332)).post((Runnable)new b(var2_2, var6_6));
                if (!StringsKt.E((CharSequence)this.m)) break block8;
                if (StringsKt.E((CharSequence)this.k)) break block9;
                var19_18 = this.l;
                if (var19_18 != null && !StringsKt.E((CharSequence)var19_18)) {
                    var6_6 = 0;
                }
                if (var6_6 == 0) break block8;
            }
            ((LinearLayout)var2_2.findViewById(2131362336)).setPadding(0, 0, 0, 0);
            return;
        }
        var18_19 = (LinearLayout)var2_2.findViewById(2131362336);
        Intrinsics.g((Object)var3_3, (String)"context");
        var18_19.setPadding(0, DigitsKt.b((Int)16, (Context)var3_3), 0, DigitsKt.b((Int)24, (Context)var3_3));
    }

    func d2() -> Int {
        return 2131558654;
    }
}

