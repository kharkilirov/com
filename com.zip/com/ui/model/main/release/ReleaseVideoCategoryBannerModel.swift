/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.model.main.release.ReleaseVideoCategoryBannerModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.release.ReleaseVideoCategoryBannerModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.release.ReleaseVideoCategoryBannerModel$bind$1
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.model.main.release;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.model.main.release.ReleaseVideoCategoryBannerModel;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/release/ReleaseVideoCategoryBannerModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class ReleaseVideoCategoryBannerModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    long k;
    @EpoxyAttribute
    @NotNull
    String l = "";
    @EpoxyAttribute
    @NotNull
    String m = "";
    @EpoxyAttribute
    long n;
    @EpoxyAttribute
    @NotNull
    String o = "";
    @EpoxyAttribute
    Bool p;
    @EpoxyAttribute
    Listener q;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        ((TextView)view.findViewById(2131362525)).setText((CharSequence)this.l);
        TextView textView = (TextView)view.findViewById(2131362387);
        Intrinsics.g((Object)textView, (String)"view.isNew");
        ViewsKt.l((View)textView, (Bool)this.p);
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362361);
        Intrinsics.g((Object)appCompatImageView, (String)"view.image");
        ViewsKt.h((ImageView)appCompatImageView, (String)this.m);
        ViewsKt.j((View)view, (Function1)new bind.1(this));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof ReleaseVideoCategoryBannerModel) {
            String string = this.l;
            ReleaseVideoCategoryBannerModel releaseVideoCategoryBannerModel = (ReleaseVideoCategoryBannerModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)releaseVideoCategoryBannerModel.l)) {
                arrayList.add((Object)0);
            }
            if (!Intrinsics.c((Object)this.m, (Object)releaseVideoCategoryBannerModel.m)) {
                arrayList.add((Object)1);
            }
            if (this.n != releaseVideoCategoryBannerModel.n) {
                arrayList.add((Object)2);
            }
            if (!Intrinsics.c((Object)this.o, (Object)releaseVideoCategoryBannerModel.o)) {
                arrayList.add((Object)3);
            }
            if (this.p != releaseVideoCategoryBannerModel.p) {
                arrayList.add((Object)4);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        if (a.z((View)view, (String)"view", list, (String)"payloads", (Int)0)) {
            ((TextView)view.findViewById(2131362525)).setText((CharSequence)this.l);
        }
        if (list.contains((Object)1)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362361);
            Intrinsics.g((Object)appCompatImageView, (String)"view.image");
            ViewsKt.h((ImageView)appCompatImageView, (String)this.m);
        }
        if (list.contains((Object)4)) {
            TextView textView = (TextView)view.findViewById(2131362387);
            Intrinsics.g((Object)textView, (String)"view.isNew");
            ViewsKt.l((View)textView, (Bool)this.p);
        }
    }

    func v2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        view.setOnClickListener(null);
    }
}

