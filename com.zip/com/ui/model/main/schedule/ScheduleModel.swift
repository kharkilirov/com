/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.model.main.schedule.ScheduleModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.schedule.ScheduleModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.schedule.ScheduleModel$bind$1
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.schedule;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.model.common.ReleaseModel;
import com.swiftsoft.anixartd.ui.model.main.schedule.ScheduleModel;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/schedule/ScheduleModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class ScheduleModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    @Nullable
    String k = "";
    @EpoxyAttribute
    @Nullable
    String l = "";
    @EpoxyAttribute
    @Nullable
    Integer m;
    @EpoxyAttribute
    @Nullable
    Integer n;
    @EpoxyAttribute
    Listener o;

    init() {
        Integer n;
        this.m = n = Integer.valueOf((Int)0);
        this.n = n;
    }

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        String string = this.k;
        Integer n = this.m;
        Integer n2 = this.n;
        Bool bl = string == null || string.length() == 0;
        if (bl) {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)"\u0411\u0435\u0437 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u044f");
        } else {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)string);
        }
        if (n != null && n2 != null && Intrinsics.c((Object)n, (Object)n2)) {
            TextView textView = (TextView)a.g((Integer)n2, (String)" \u044d\u043f", (TextView)((TextView)view.findViewById(2131362200)), (View)view, (Int)2131362200);
            Intrinsics.g((Object)textView, (String)"view.episodes");
            ViewsKt.k((View)textView);
        } else if (n != null && n2 != null) {
            a.t((Integer)n, (String)" \u0438\u0437 ", (Integer)n2, (String)" \u044d\u043f", (TextView)((TextView)view.findViewById(2131362200)));
            TextView textView = (TextView)view.findViewById(2131362200);
            Intrinsics.g((Object)textView, (String)"view.episodes");
            ViewsKt.k((View)textView);
        } else if (n != null && n2 == null) {
            TextView textView = (TextView)a.g((Integer)n, (String)" \u0438\u0437 ? \u044d\u043f", (TextView)((TextView)view.findViewById(2131362200)), (View)view, (Int)2131362200);
            Intrinsics.g((Object)textView, (String)"view.episodes");
            ViewsKt.k((View)textView);
        } else if (n == null && n2 != null) {
            a.u((String)"? \u0438\u0437 ", (Integer)n2, (String)" \u044d\u043f", (TextView)((TextView)view.findViewById(2131362200)));
            TextView textView = (TextView)view.findViewById(2131362200);
            Intrinsics.g((Object)textView, (String)"view.episodes");
            ViewsKt.k((View)textView);
        } else {
            TextView textView = (TextView)view.findViewById(2131362200);
            Intrinsics.g((Object)textView, (String)"view.episodes");
            ViewsKt.e((View)textView);
        }
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362613);
        Intrinsics.g((Object)appCompatImageView, (String)"view.poster");
        ViewsKt.h((ImageView)appCompatImageView, (String)this.l);
        ViewsKt.j((View)view, (Function1)new bind.1(this));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof ScheduleModel) {
            String string = this.k;
            ScheduleModel scheduleModel = (ScheduleModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)scheduleModel.k)) {
                arrayList.add((Object)0);
            }
            if (!Intrinsics.c((Object)this.m, (Object)scheduleModel.m)) {
                arrayList.add((Object)1);
            }
            if (!Intrinsics.c((Object)this.n, (Object)scheduleModel.n)) {
                arrayList.add((Object)2);
            }
            if (epoxyModel instanceof ReleaseModel && !Intrinsics.c((Object)this.l, (Object)scheduleModel.l)) {
                arrayList.add((Object)3);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        if (a.z((View)view, (String)"view", list, (String)"payloads", (Int)0)) {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)this.k);
        }
        if (list.contains((Object)1)) {
            TextView textView = (TextView)view.findViewById(2131362200);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append((Object)this.m);
            stringBuilder.append(" \u0438\u0437 ");
            a.w((StringBuilder)stringBuilder, (Integer)this.n, (TextView)textView);
        }
        if (list.contains((Object)2)) {
            TextView textView = (TextView)view.findViewById(2131362200);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append((Object)this.m);
            stringBuilder.append(" \u0438\u0437 ");
            a.w((StringBuilder)stringBuilder, (Integer)this.n, (TextView)textView);
        }
        if (list.contains((Object)3)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362613);
            Intrinsics.g((Object)appCompatImageView, (String)"view.poster");
            ViewsKt.h((ImageView)appCompatImageView, (String)this.l);
        }
    }

    func v2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        view.setOnClickListener(null);
    }
}

