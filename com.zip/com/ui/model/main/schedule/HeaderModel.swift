/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.widget.TextView
 *  androidx.annotation.StringRes
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.airbnb.lottie.LottieAnimationView
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Calendar
 *  java.util.Locale
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.schedule;

import android.content.Context;
import android.view.View;
import android.widget.TextView;
import androidx.annotation.StringRes;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.airbnb.lottie.LottieAnimationView;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.Calendar;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001\u00a8\u0006\u0003"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/schedule/HeaderModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class HeaderModel
extends EpoxyModel<View> {
    @StringRes
    @EpoxyAttribute
    @Nullable
    Integer k = 0;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        Int n = Calendar.getInstance((Locale)Locale.getDefault()).get(7) - 1;
        if (n == 0) {
            n = 7;
        }
        LottieAnimationView lottieAnimationView = (LottieAnimationView)view.findViewById(2131362392);
        Intrinsics.g((Object)lottieAnimationView, (String)"view.isToday");
        Integer n2 = this.k;
        Bool bl = n2 != null && n2 == n;
        ViewsKt.m((View)lottieAnimationView, (Bool)bl);
        TextView textView = (TextView)view.findViewById(2131362331);
        Integer n3 = this.k;
        Int n4 = n3 != null && n3 == 1 ? 2131952157 : (n3 != null && n3 == 2 ? 2131952623 : (n3 != null && n3 == 3 ? 2131952664 : (n3 != null && n3 == 4 ? 2131952575 : (n3 != null && n3 == 5 ? 2131952026 : (n3 != null && n3 == 6 ? 2131952450 : (n3 != null && n3 == 7 ? 2131952550 : 2131951857))))));
        textView.setText((CharSequence)context.getString(n4));
    }
}

