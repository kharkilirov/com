/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.widget.Button
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.swiftsoft.anixartd.ui.model.main.notifications.NotificationsPushDisabledModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.notifications.NotificationsPushDisabledModel$bind$1
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 */
package com.swiftsoft.anixartd.ui.model.main.notifications;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.swiftsoft.anixartd.ui.model.main.notifications.NotificationsPushDisabledModel;
import com.swiftsoft.anixartd.utils.ViewsKt;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv={}, d1={"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001\u00a8\u0006\u0003"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/notifications/NotificationsPushDisabledModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class NotificationsPushDisabledModel
extends EpoxyModel<View> {
    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        Button button = (Button)view.findViewById(2131362807);
        Intrinsics.g((Object)button, (String)"view.settings");
        ViewsKt.j((View)button, (Function1)new bind.1(context));
    }
}

