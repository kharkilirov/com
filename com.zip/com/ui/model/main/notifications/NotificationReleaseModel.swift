/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.Html
 *  android.view.View
 *  android.view.View$OnLongClickListener
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.fragment.main.profile.d
 *  com.swiftsoft.anixartd.ui.model.main.notifications.NotificationReleaseModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.notifications.NotificationReleaseModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.notifications.NotificationReleaseModel$bind$1
 *  com.swiftsoft.anixartd.utils.Time
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.notifications;

import android.content.Context;
import android.text.Html;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.fragment.main.profile.d;
import com.swiftsoft.anixartd.ui.model.main.notifications.NotificationReleaseModel;
import com.swiftsoft.anixartd.utils.Time;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/notifications/NotificationReleaseModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class NotificationReleaseModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    long k;
    @EpoxyAttribute
    @Nullable
    String l;
    @EpoxyAttribute
    @Nullable
    String m;
    @EpoxyAttribute
    long n;
    @EpoxyAttribute
    Bool o;
    @EpoxyAttribute
    Listener p;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362361);
        Intrinsics.g((Object)appCompatImageView, (String)"view.image");
        ViewsKt.a((AppCompatImageView)appCompatImageView, (String)this.m);
        TextView textView = (TextView)view.findViewById(2131362486);
        String string = context.getString(2131952382);
        Intrinsics.g((Object)string, (String)"context.getString(R.stri\u2026elease_notification_text)");
        Object[] arrobject = new Object[]{this.l};
        String string2 = String.format((String)string, (Object[])Arrays.copyOf((Object[])arrobject, (Int)1));
        Intrinsics.g((Object)string2, (String)"format(format, *args)");
        textView.setText((CharSequence)Html.fromHtml((String)string2));
        TextView textView2 = (TextView)view.findViewById(2131362106);
        long l = this.n;
        String string3 = l != 0L ? Time.a.g(context, l) : "\u0432\u0440\u0435\u043c\u044f \u043d\u0435 \u0443\u043a\u0430\u0437\u0430\u043d\u043e";
        textView2.setText((CharSequence)string3);
        AppCompatImageView appCompatImageView2 = (AppCompatImageView)view.findViewById(2131362393);
        Intrinsics.g((Object)appCompatImageView2, (String)"view.is_new");
        ViewsKt.l((View)appCompatImageView2, (Bool)this.o);
        ViewsKt.j((View)view, (Function1)new bind.1(this));
        view.setOnLongClickListener((View.OnLongClickListener)new d((Object)this, 11));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof NotificationReleaseModel) {
            String string = this.m;
            NotificationReleaseModel notificationReleaseModel = (NotificationReleaseModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)notificationReleaseModel.m)) {
                arrayList.add((Object)0);
            }
            if (this.n != notificationReleaseModel.n) {
                arrayList.add((Object)1);
            }
            if (this.o != notificationReleaseModel.o) {
                arrayList.add((Object)2);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        Context context = a.b((View)view, (String)"view", list, (String)"payloads");
        if (list.contains((Object)0)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362361);
            Intrinsics.g((Object)appCompatImageView, (String)"view.image");
            ViewsKt.a((AppCompatImageView)appCompatImageView, (String)this.m);
        }
        if (list.contains((Object)1)) {
            String string;
            TextView textView = (TextView)view.findViewById(2131362106);
            if (this.n != 0L) {
                Time time = Time.a;
                Intrinsics.g((Object)context, (String)"context");
                string = time.g(context, this.n);
            } else {
                string = "\u0432\u0440\u0435\u043c\u044f \u043d\u0435 \u0443\u043a\u0430\u0437\u0430\u043d\u043e";
            }
            textView.setText((CharSequence)string);
        }
        if (list.contains((Object)2)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362393);
            Intrinsics.g((Object)appCompatImageView, (String)"view.is_new");
            ViewsKt.l((View)appCompatImageView, (Bool)this.o);
        }
    }

    func v2(@NotNull View view) -> void {
        a.p((View)view, (String)"view", null, null);
    }
}

