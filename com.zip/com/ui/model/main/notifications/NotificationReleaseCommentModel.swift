/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.Html
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnLongClickListener
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.fragment.main.profile.d
 *  com.swiftsoft.anixartd.ui.model.main.notifications.NotificationReleaseCommentModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.notifications.NotificationReleaseCommentModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.notifications.NotificationReleaseCommentModel$bind$3
 *  com.swiftsoft.anixartd.ui.model.main.notifications.b
 *  com.swiftsoft.anixartd.utils.Time
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.jvm.internal.Ref
 *  kotlin.jvm.internal.Ref$BooleanRef
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.model.main.notifications;

import android.content.Context;
import android.text.Html;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.fragment.main.profile.d;
import com.swiftsoft.anixartd.ui.model.main.notifications.NotificationReleaseCommentModel;
import com.swiftsoft.anixartd.ui.model.main.notifications.b;
import com.swiftsoft.anixartd.utils.Time;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/notifications/NotificationReleaseCommentModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class NotificationReleaseCommentModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    long k;
    @EpoxyAttribute
    long l;
    @EpoxyAttribute
    long m;
    @EpoxyAttribute
    @NotNull
    String n = "";
    @EpoxyAttribute
    Bool o;
    @EpoxyAttribute
    @NotNull
    String p = "";
    @EpoxyAttribute
    @NotNull
    String q = "";
    @EpoxyAttribute
    long r;
    @EpoxyAttribute
    Bool s;
    @EpoxyAttribute
    Listener t;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362361);
        Intrinsics.g((Object)appCompatImageView, (String)"view.image");
        ViewsKt.a((AppCompatImageView)appCompatImageView, (String)this.q);
        TextView textView = (TextView)view.findViewById(2131362486);
        String string = context.getString(2131951747);
        Intrinsics.g((Object)string, (String)"context.getString(R.stri\u2026omment_notification_text)");
        Object[] arrobject = new Object[]{this.p, this.n};
        String string2 = String.format((String)string, (Object[])Arrays.copyOf((Object[])arrobject, (Int)2));
        Intrinsics.g((Object)string2, (String)"format(format, *args)");
        textView.setText((CharSequence)Html.fromHtml((String)string2));
        if (this.o) {
            Ref.BooleanRef booleanRef = new Ref.BooleanRef();
            TextView textView2 = (TextView)a.e((View)view, (Int)2130969642, (TextView)((TextView)view.findViewById(2131362486)), (Int)2131362486);
            LinearLayout linearLayout = (LinearLayout)a.f((TextView)textView2, (String)"view.message", (TextView)textView2, (View)view, (Int)2131362870);
            Intrinsics.g((Object)linearLayout, (String)"view.spoilerHideShow");
            ViewsKt.k((View)linearLayout);
            ((LinearLayout)view.findViewById(2131362870)).setOnClickListener((View.OnClickListener)new b(booleanRef, view, 2));
        } else {
            TextView textView3 = (TextView)a.e((View)view, (Int)2130969583, (TextView)((TextView)view.findViewById(2131362486)), (Int)2131362486);
            LinearLayout linearLayout = (LinearLayout)a.C((TextView)textView3, (String)"view.message", (TextView)textView3, (View)view, (Int)2131362870);
            Intrinsics.g((Object)linearLayout, (String)"view.spoilerHideShow");
            ViewsKt.e((View)linearLayout);
        }
        TextView textView4 = (TextView)view.findViewById(2131362106);
        long l = this.r;
        String string3 = l != 0L ? Time.a.g(context, l) : "\u0432\u0440\u0435\u043c\u044f \u043d\u0435 \u0443\u043a\u0430\u0437\u0430\u043d\u043e";
        textView4.setText((CharSequence)string3);
        AppCompatImageView appCompatImageView2 = (AppCompatImageView)view.findViewById(2131362393);
        Intrinsics.g((Object)appCompatImageView2, (String)"view.is_new");
        ViewsKt.l((View)appCompatImageView2, (Bool)this.s);
        ViewsKt.j((View)view, (Function1)new bind.3(this));
        view.setOnLongClickListener((View.OnLongClickListener)new d((Object)this, 10));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof NotificationReleaseCommentModel) {
            String string = this.n;
            NotificationReleaseCommentModel notificationReleaseCommentModel = (NotificationReleaseCommentModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)notificationReleaseCommentModel.n)) {
                arrayList.add((Object)0);
            }
            if (this.o != notificationReleaseCommentModel.o) {
                arrayList.add((Object)5);
            }
            if (!Intrinsics.c((Object)this.p, (Object)notificationReleaseCommentModel.p)) {
                arrayList.add((Object)1);
            }
            if (!Intrinsics.c((Object)this.q, (Object)notificationReleaseCommentModel.q)) {
                arrayList.add((Object)2);
            }
            if (this.r != notificationReleaseCommentModel.r) {
                arrayList.add((Object)3);
            }
            if (this.s != notificationReleaseCommentModel.s) {
                arrayList.add((Object)4);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        Context context = a.b((View)view, (String)"view", list, (String)"payloads");
        if (list.contains((Object)0) || list.contains((Object)1)) {
            TextView textView = (TextView)view.findViewById(2131362486);
            String string = view.getContext().getString(2131952241);
            Intrinsics.g((Object)string, (String)"view.context.getString(R\u2026_comment_spoiler_warning)");
            Object[] arrobject = new Object[]{this.p, this.n};
            String string2 = String.format((String)string, (Object[])Arrays.copyOf((Object[])arrobject, (Int)2));
            Intrinsics.g((Object)string2, (String)"format(format, *args)");
            textView.setText((CharSequence)Html.fromHtml((String)string2));
        }
        if (list.contains((Object)5)) {
            if (this.o) {
                Ref.BooleanRef booleanRef = new Ref.BooleanRef();
                TextView textView = (TextView)a.e((View)view, (Int)2130969642, (TextView)((TextView)view.findViewById(2131362486)), (Int)2131362486);
                LinearLayout linearLayout = (LinearLayout)a.f((TextView)textView, (String)"view.message", (TextView)textView, (View)view, (Int)2131362870);
                Intrinsics.g((Object)linearLayout, (String)"view.spoilerHideShow");
                ViewsKt.k((View)linearLayout);
                ((LinearLayout)view.findViewById(2131362870)).setOnClickListener((View.OnClickListener)new b(booleanRef, view, 3));
            } else {
                TextView textView = (TextView)a.e((View)view, (Int)2130969583, (TextView)((TextView)view.findViewById(2131362486)), (Int)2131362486);
                LinearLayout linearLayout = (LinearLayout)a.C((TextView)textView, (String)"view.message", (TextView)textView, (View)view, (Int)2131362870);
                Intrinsics.g((Object)linearLayout, (String)"view.spoilerHideShow");
                ViewsKt.e((View)linearLayout);
            }
        }
        if (list.contains((Object)2)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362361);
            Intrinsics.g((Object)appCompatImageView, (String)"view.image");
            ViewsKt.a((AppCompatImageView)appCompatImageView, (String)this.q);
        }
        if (list.contains((Object)3)) {
            String string;
            TextView textView = (TextView)view.findViewById(2131362106);
            if (this.r != 0L) {
                Time time = Time.a;
                Intrinsics.g((Object)context, (String)"context");
                string = time.g(context, this.r);
            } else {
                string = "\u0432\u0440\u0435\u043c\u044f \u043d\u0435 \u0443\u043a\u0430\u0437\u0430\u043d\u043e";
            }
            textView.setText((CharSequence)string);
        }
        if (list.contains((Object)4)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362393);
            Intrinsics.g((Object)appCompatImageView, (String)"view.is_new");
            ViewsKt.l((View)appCompatImageView, (Bool)this.s);
        }
    }

    func v2(@NotNull View view) -> void {
        a.p((View)view, (String)"view", null, null);
    }
}

