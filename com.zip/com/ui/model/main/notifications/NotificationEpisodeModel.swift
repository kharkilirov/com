/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.Html
 *  android.view.View
 *  android.view.View$OnLongClickListener
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.fragment.main.profile.d
 *  com.swiftsoft.anixartd.ui.model.main.notifications.NotificationEpisodeModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.notifications.NotificationEpisodeModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.notifications.NotificationEpisodeModel$bind$1
 *  com.swiftsoft.anixartd.utils.Time
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.notifications;

import android.content.Context;
import android.text.Html;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.fragment.main.profile.d;
import com.swiftsoft.anixartd.ui.model.main.notifications.NotificationEpisodeModel;
import com.swiftsoft.anixartd.utils.Time;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/notifications/NotificationEpisodeModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class NotificationEpisodeModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    long k;
    @EpoxyAttribute
    @Nullable
    String l;
    @EpoxyAttribute
    @Nullable
    String m;
    @EpoxyAttribute
    @Nullable
    String n;
    @EpoxyAttribute
    String o;
    @EpoxyAttribute
    String p;
    @EpoxyAttribute
    long q;
    @EpoxyAttribute
    Bool r;
    @EpoxyAttribute
    Listener s;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362361);
        Intrinsics.g((Object)appCompatImageView, (String)"view.image");
        ViewsKt.a((AppCompatImageView)appCompatImageView, (String)this.m);
        TextView textView = (TextView)view.findViewById(2131362486);
        String string = context.getString(2131951850);
        Intrinsics.g((Object)string, (String)"context.getString(R.stri\u2026pisode_notification_text)");
        Object[] arrobject = new Object[4];
        String string2 = this.n;
        if (string2 == null) {
            string2 = "\u043d\u0435\u0442 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u044f";
        }
        arrobject[0] = string2;
        arrobject[1] = this.l;
        String string3 = this.o;
        if (string3 != null) {
            arrobject[2] = string3;
            String string4 = this.p;
            if (string4 != null) {
                arrobject[3] = string4;
                String string5 = String.format((String)string, (Object[])Arrays.copyOf((Object[])arrobject, (Int)4));
                Intrinsics.g((Object)string5, (String)"format(format, *args)");
                textView.setText((CharSequence)Html.fromHtml((String)string5));
                TextView textView2 = (TextView)view.findViewById(2131362106);
                long l = this.q;
                String string6 = l != 0L ? Time.a.g(context, l) : "\u0432\u0440\u0435\u043c\u044f \u043d\u0435 \u0443\u043a\u0430\u0437\u0430\u043d\u043e";
                textView2.setText((CharSequence)string6);
                AppCompatImageView appCompatImageView2 = (AppCompatImageView)view.findViewById(2131362393);
                Intrinsics.g((Object)appCompatImageView2, (String)"view.is_new");
                ViewsKt.l((View)appCompatImageView2, (Bool)this.r);
                ViewsKt.j((View)view, (Function1)new bind.1(this));
                view.setOnLongClickListener((View.OnLongClickListener)new d((Object)this, 8));
                return;
            }
            Intrinsics.r((String)"sourceName");
            throw null;
        }
        Intrinsics.r((String)"typeName");
        throw null;
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof NotificationEpisodeModel) {
            String string = this.m;
            NotificationEpisodeModel notificationEpisodeModel = (NotificationEpisodeModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)notificationEpisodeModel.m)) {
                arrayList.add((Object)0);
            }
            if (this.q != notificationEpisodeModel.q) {
                arrayList.add((Object)1);
            }
            if (this.r != notificationEpisodeModel.r) {
                arrayList.add((Object)2);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        Context context = a.b((View)view, (String)"view", list, (String)"payloads");
        if (list.contains((Object)0)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362361);
            Intrinsics.g((Object)appCompatImageView, (String)"view.image");
            ViewsKt.a((AppCompatImageView)appCompatImageView, (String)this.m);
        }
        if (list.contains((Object)1)) {
            String string;
            TextView textView = (TextView)view.findViewById(2131362106);
            if (this.q != 0L) {
                Time time = Time.a;
                Intrinsics.g((Object)context, (String)"context");
                string = time.g(context, this.q);
            } else {
                string = "\u0432\u0440\u0435\u043c\u044f \u043d\u0435 \u0443\u043a\u0430\u0437\u0430\u043d\u043e";
            }
            textView.setText((CharSequence)string);
        }
        if (list.contains((Object)2)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362393);
            Intrinsics.g((Object)appCompatImageView, (String)"view.is_new");
            ViewsKt.l((View)appCompatImageView, (Bool)this.r);
        }
    }

    func v2(@NotNull View view) -> void {
        a.p((View)view, (String)"view", null, null);
    }
}

