/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a.a
 *  android.text.Html
 *  android.view.View
 *  android.widget.ImageView
 *  android.widget.TextView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.android.material.button.MaterialButton
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.model.main.episodes.torlook.TorlookModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.episodes.torlook.TorlookModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.episodes.torlook.TorlookModel$bind$1
 *  com.swiftsoft.anixartd.ui.model.main.episodes.torlook.TorlookModel$bind$2
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.Regex
 *  kotlin.text.StringsKt
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.model.main.episodes.torlook;

import android.text.Html;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.android.material.button.MaterialButton;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.model.main.episodes.torlook.TorlookModel;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/episodes/torlook/TorlookModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class TorlookModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    @NotNull
    String k = "";
    @EpoxyAttribute
    @NotNull
    String l = "";
    @EpoxyAttribute
    @NotNull
    String m = "";
    @EpoxyAttribute
    @NotNull
    String n = "";
    @EpoxyAttribute
    @NotNull
    String o = "";
    @EpoxyAttribute
    @NotNull
    String p = "";
    @EpoxyAttribute
    @NotNull
    String q = "";
    @EpoxyAttribute
    @NotNull
    String r = "";
    @EpoxyAttribute
    @NotNull
    String s = "";
    @EpoxyAttribute
    @NotNull
    String t = "";
    @EpoxyAttribute
    Listener u;

    func Z1(Object object) -> void {
        Bool bl;
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        ((TextView)view.findViewById(2131363004)).setText((CharSequence)Html.fromHtml((String)this.v2(this.k, this.l)));
        ((TextView)view.findViewById(2131362827)).setText((CharSequence)this.m);
        ((TextView)view.findViewById(2131362106)).setText((CharSequence)this.n);
        ((TextView)view.findViewById(2131363024)).setText((CharSequence)this.o);
        ImageView imageView = (ImageView)view.findViewById(2131363025);
        Intrinsics.g((Object)imageView, (String)"view.tracker_icon");
        ViewsKt.h((ImageView)imageView, (String)this.p);
        ((TextView)view.findViewById(2131362792)).setText((CharSequence)this.q);
        ((TextView)view.findViewById(2131362422)).setText((CharSequence)this.r);
        TextView textView = (TextView)view.findViewById(2131362164);
        Intrinsics.g((Object)textView, (String)"view.dot");
        Int n = this.m.length();
        Bool bl2 = true;
        Bool bl3 = n == 0;
        Bool bl4 = bl3 || (bl = this.n.length() == 0);
        ViewsKt.f((View)textView, (Bool)bl4, (Bool)false, null, (Int)6);
        MaterialButton materialButton = (MaterialButton)view.findViewById(2131362454);
        Intrinsics.g((Object)materialButton, (String)"view.magnet_link");
        if (this.t.length() != 0) {
            bl2 = false;
        }
        ViewsKt.f((View)materialButton, (Bool)bl2, (Bool)false, null, (Int)6);
        MaterialButton materialButton2 = (MaterialButton)view.findViewById(2131362436);
        Intrinsics.g((Object)materialButton2, (String)"view.link");
        ViewsKt.j((View)materialButton2, (Function1)new bind.1(this));
        MaterialButton materialButton3 = (MaterialButton)view.findViewById(2131362454);
        Intrinsics.g((Object)materialButton3, (String)"view.magnet_link");
        ViewsKt.j((View)materialButton3, (Function1)new bind.2(this));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof TorlookModel) {
            String string = this.k;
            TorlookModel torlookModel = (TorlookModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)torlookModel.k)) {
                arrayList.add((Object)1);
            }
            if (!Intrinsics.c((Object)this.l, (Object)torlookModel.l)) {
                arrayList.add((Object)2);
            }
            if (!Intrinsics.c((Object)this.m, (Object)torlookModel.m)) {
                arrayList.add((Object)3);
            }
            if (!Intrinsics.c((Object)this.n, (Object)torlookModel.n)) {
                arrayList.add((Object)4);
            }
            if (!Intrinsics.c((Object)this.o, (Object)torlookModel.o)) {
                arrayList.add((Object)5);
            }
            if (!Intrinsics.c((Object)this.p, (Object)torlookModel.p)) {
                arrayList.add((Object)6);
            }
            if (!Intrinsics.c((Object)this.q, (Object)torlookModel.q)) {
                arrayList.add((Object)7);
            }
            if (!Intrinsics.c((Object)this.r, (Object)torlookModel.r)) {
                arrayList.add((Object)8);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        Bool bl = true;
        if (a.z((View)view, (String)"view", list, (String)"payloads", (Int)bl) || list.contains((Object)2)) {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)Html.fromHtml((String)this.v2(this.k, this.l)));
        }
        if (list.contains((Object)3)) {
            ((TextView)view.findViewById(2131362827)).setText((CharSequence)this.m);
            TextView textView = (TextView)view.findViewById(2131362164);
            Intrinsics.g((Object)textView, (String)"view.dot");
            Bool bl2 = this.m.length() == 0;
            ViewsKt.f((View)textView, (Bool)bl2, (Bool)false, null, (Int)6);
        }
        if (list.contains((Object)4)) {
            ((TextView)view.findViewById(2131362106)).setText((CharSequence)this.n);
            TextView textView = (TextView)view.findViewById(2131362164);
            Intrinsics.g((Object)textView, (String)"view.dot");
            if (this.n.length() != 0) {
                bl = false;
            }
            ViewsKt.f((View)textView, (Bool)bl, (Bool)false, null, (Int)6);
        }
        if (list.contains((Object)5)) {
            ((TextView)view.findViewById(2131363024)).setText((CharSequence)this.o);
        }
        if (list.contains((Object)6)) {
            ImageView imageView = (ImageView)view.findViewById(2131363025);
            Intrinsics.g((Object)imageView, (String)"view.tracker_icon");
            ViewsKt.h((ImageView)imageView, (String)this.p);
        }
        if (list.contains((Object)7)) {
            ((TextView)view.findViewById(2131362792)).setText((CharSequence)this.q);
        }
        if (list.contains((Object)8)) {
            ((TextView)view.findViewById(2131362422)).setText((CharSequence)this.r);
        }
    }

    final String v2(String string, String string2) {
        List list = StringsKt.S((CharSequence)string, (String[])new String[]{" "}, (Bool)false, (Int)0, (Int)6, null);
        Object[] arrobject = list.toArray((Object[])new String[0]);
        Intrinsics.f((Object)arrobject, (String)"null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
        for (String string3 : (String[])arrobject) {
            String string4 = new Regex("[<>{}\"\\/|;:.,~!?@#$%^=&*']").e((CharSequence)string3, "");
            Regex regex = new Regex(a.a.k((String)"(?i)", (String)string4));
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("<b>");
            stringBuilder.append(string4);
            stringBuilder.append("</b>");
            string2 = regex.e((CharSequence)string2, stringBuilder.toString());
        }
        return string2;
    }

    func w2(@NotNull View view) -> void {
        a.p((View)view, (String)"view", null, null);
    }
}

