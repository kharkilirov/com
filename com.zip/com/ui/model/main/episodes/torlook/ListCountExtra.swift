/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a.a
 *  android.content.Context
 *  android.view.View
 *  android.widget.TextView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.model.main.episodes.torlook;

import a.a;
import android.content.Context;
import android.view.View;
import android.widget.TextView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001\u00a8\u0006\u0003"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/episodes/torlook/ListCountExtra;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class ListCountExtra
extends EpoxyModel<View> {
    @EpoxyAttribute
    long k;
    @EpoxyAttribute
    @NotNull
    String l = "";

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        TextView textView = (TextView)view.findViewById(2131362075);
        String string = context.getString(2131951683);
        Intrinsics.g((Object)string, (String)"context.getString(R.string.bookmarks_count)");
        Int n = 1;
        Object[] arrobject = new Object[n];
        arrobject[0] = this.k;
        com.google.protobuf.a.y((Object[])arrobject, (Int)n, (String)string, (String)"format(format, *args)", (TextView)textView);
        if (this.l.length() <= 0) {
            n = 0;
        }
        if (n != 0) {
            TextView textView2 = (TextView)view.findViewById(2131362274);
            StringBuilder stringBuilder = a.u((String)"\u043e\u0442 ");
            stringBuilder.append(this.l);
            textView2.setText((CharSequence)stringBuilder.toString());
        }
    }
}

