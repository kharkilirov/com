/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.fragment.main.watching.a
 *  com.swiftsoft.anixartd.ui.model.main.episodes.TypeModel$Listener
 *  com.swiftsoft.anixartd.utils.Counters
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.episodes;

import android.content.Context;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.model.main.episodes.TypeModel;
import com.swiftsoft.anixartd.utils.Counters;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/episodes/TypeModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class TypeModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    long k;
    @EpoxyAttribute
    @NotNull
    String l = "";
    @EpoxyAttribute
    @Nullable
    String m = "";
    @EpoxyAttribute
    long n;
    @EpoxyAttribute
    long o;
    @EpoxyAttribute
    @Nullable
    Long p = 0L;
    @EpoxyAttribute
    Listener q;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        ((TextView)view.findViewById(2131362622)).setText((CharSequence)this.l);
        if (this.m == null) {
            TextView textView = (TextView)view.findViewById(2131362790);
            Intrinsics.g((Object)textView, (String)"view.secondaryText");
            ViewsKt.e((View)textView);
        } else {
            TextView textView = (TextView)view.findViewById(2131362790);
            ((TextView)a.C((TextView)textView, (String)"view.secondaryText", (TextView)textView, (View)view, (Int)2131362790)).setText((CharSequence)this.m);
        }
        TextView textView = (TextView)view.findViewById(2131362201);
        String string = context.getString(2131951856);
        Intrinsics.g((Object)string, (String)"context.getString(R.string.episodes_count_shorten)");
        Bool bl = true;
        Object[] arrobject = new Object[bl];
        arrobject[0] = this.n;
        a.y((Object[])arrobject, (Int)bl, (String)string, (String)"format(format, *args)", (TextView)textView);
        Bool bl2 = this.n > 0L;
        ViewsKt.l((View)textView, (Bool)bl2);
        TextView textView2 = (TextView)view.findViewById(2131362164);
        Intrinsics.g((Object)textView2, (String)"view.dot");
        Bool bl3 = this.n > 0L;
        ViewsKt.l((View)textView2, (Bool)bl3);
        TextView textView3 = (TextView)view.findViewById(2131363109);
        textView3.setText((CharSequence)Counters.a((Counters)Counters.a, (Context)context, (long)this.o, (Int)0, (Int)0, (Int)12));
        Bool bl4 = this.o > 0L;
        ViewsKt.l((View)textView3, (Bool)bl4);
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131363108);
        Intrinsics.g((Object)appCompatImageView, (String)"view.viewCountIcon");
        Bool bl5 = this.o > 0L;
        ViewsKt.l((View)appCompatImageView, (Bool)bl5);
        RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362456);
        Intrinsics.g((Object)relativeLayout, (String)"view.mark_new");
        long l = this.k;
        Long l2 = this.p;
        if (l2 == null || l != l2) {
            bl = false;
        }
        ViewsKt.l((View)relativeLayout, (Bool)bl);
        view.setOnClickListener((View.OnClickListener)new com.swiftsoft.anixartd.ui.fragment.main.watching.a((Object)this, 10));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof TypeModel) {
            String string = this.l;
            TypeModel typeModel = (TypeModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)typeModel.l)) {
                arrayList.add((Object)0);
            }
            if (!Intrinsics.c((Object)this.m, (Object)typeModel.m)) {
                arrayList.add((Object)1);
            }
            if (this.n != typeModel.n) {
                arrayList.add((Object)2);
            }
            if (this.o != typeModel.o) {
                arrayList.add((Object)3);
            }
            if (!Intrinsics.c((Object)this.p, (Object)typeModel.p)) {
                arrayList.add((Object)4);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        Context context = a.b((View)view, (String)"view", list, (String)"payloads");
        if (list.contains((Object)0)) {
            ((TextView)view.findViewById(2131362622)).setText((CharSequence)this.l);
        }
        if (list.contains((Object)1)) {
            ((TextView)view.findViewById(2131362790)).setText((CharSequence)this.m);
        }
        if (list.contains((Object)2)) {
            TextView textView = (TextView)view.findViewById(2131362201);
            String string = context.getString(2131951856);
            Intrinsics.g((Object)string, (String)"context.getString(R.string.episodes_count_shorten)");
            Object[] arrobject = new Object[]{this.n};
            a.y((Object[])arrobject, (Int)1, (String)string, (String)"format(format, *args)", (TextView)textView);
            Bool bl = this.n > 0L;
            ViewsKt.l((View)textView, (Bool)bl);
            TextView textView2 = (TextView)view.findViewById(2131362164);
            Intrinsics.g((Object)textView2, (String)"view.dot");
            Bool bl2 = this.n > 0L;
            ViewsKt.l((View)textView2, (Bool)bl2);
        }
        if (list.contains((Object)3)) {
            TextView textView = (TextView)view.findViewById(2131363109);
            Counters counters = Counters.a;
            Intrinsics.g((Object)context, (String)"context");
            textView.setText((CharSequence)Counters.a((Counters)counters, (Context)context, (long)this.o, (Int)0, (Int)0, (Int)12));
            Bool bl = this.o > 0L;
            ViewsKt.l((View)textView, (Bool)bl);
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131363108);
            Intrinsics.g((Object)appCompatImageView, (String)"view.viewCountIcon");
            Bool bl3 = this.o > 0L;
            ViewsKt.l((View)appCompatImageView, (Bool)bl3);
        }
        if (list.contains((Object)4)) {
            Bool bl;
            RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362456);
            Intrinsics.g((Object)relativeLayout, (String)"view.mark_new");
            long l = this.k;
            Long l2 = this.p;
            if (l2 == null) {
                bl = false;
            } else {
                long l3 = l LCMP l2;
                bl = false;
                if (l3 == false) {
                    bl = true;
                }
            }
            ViewsKt.l((View)relativeLayout, (Bool)bl);
        }
    }

    func v2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        view.setOnClickListener(null);
    }
}

