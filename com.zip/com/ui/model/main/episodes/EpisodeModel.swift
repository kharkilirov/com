/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.Menu
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnLongClickListener
 *  android.widget.PopupMenu
 *  android.widget.PopupMenu$OnMenuItemClickListener
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.fragment.main.watching.a
 *  com.swiftsoft.anixartd.ui.model.main.episodes.EpisodeModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.episodes.EpisodeModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.episodes.EpisodeModel$bind$3
 *  com.swiftsoft.anixartd.ui.model.main.episodes.EpisodeModel$bind$6
 *  com.swiftsoft.anixartd.ui.model.main.episodes.EpisodeModel$bind$6$1
 *  com.swiftsoft.anixartd.ui.model.main.episodes.EpisodeModel$bind$7
 *  com.swiftsoft.anixartd.ui.model.main.episodes.a
 *  com.swiftsoft.anixartd.ui.model.main.episodes.b
 *  com.swiftsoft.anixartd.utils.Time
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  com.yandex.div2.a
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.episodes;

import android.content.Context;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.swiftsoft.anixartd.ui.model.main.episodes.EpisodeModel;
import com.swiftsoft.anixartd.ui.model.main.episodes.a;
import com.swiftsoft.anixartd.ui.model.main.episodes.b;
import com.swiftsoft.anixartd.utils.Time;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/episodes/EpisodeModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class EpisodeModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    @Nullable
    String k;
    @EpoxyAttribute
    long l;
    @EpoxyAttribute
    @NotNull
    String m = "";
    @EpoxyAttribute
    Bool n;
    @EpoxyAttribute
    Bool o;
    @EpoxyAttribute
    Bool p;
    @EpoxyAttribute
    Int q;
    @EpoxyAttribute
    Listener r;
    @Nullable
    PopupMenu s;

    func Z1(Object object) -> void {
        TextView textView;
        View view;
        Bool bl;
        block9 : {
            block8 : {
                String string;
                view = (View)object;
                Intrinsics.h((Object)view, (String)"view");
                Context context = view.getContext();
                PopupMenu popupMenu = this.s;
                if (popupMenu != null) {
                    popupMenu.dismiss();
                }
                PopupMenu popupMenu2 = new PopupMenu(context, (View)((RelativeLayout)view.findViewById(2131362497)), 0, 2130969563, 2132017465);
                if (!this.o) {
                    popupMenu2.getMenu().add((CharSequence)context.getString(2131952655));
                } else {
                    popupMenu2.getMenu().add((CharSequence)context.getString(2131952656));
                }
                popupMenu2.getMenu().add((CharSequence)context.getString(2131952421));
                popupMenu2.setOnMenuItemClickListener((PopupMenu.OnMenuItemClickListener)new b(context, this, 1));
                this.s = popupMenu2;
                RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362166);
                Intrinsics.g((Object)relativeLayout, (String)"bind$lambda$6");
                ViewsKt.j((View)relativeLayout, (Function1)new bind.6.1(this));
                ViewsKt.l((View)relativeLayout, (Bool)this.p);
                RelativeLayout relativeLayout2 = (RelativeLayout)view.findViewById(2131362497);
                Intrinsics.g((Object)relativeLayout2, (String)"view.more");
                ViewsKt.j((View)relativeLayout2, (Function1)new bind.7(this));
                TextView textView2 = (TextView)view.findViewById(2131362622);
                String string2 = this.k;
                Bool bl2 = string2 == null || string2.length() == 0;
                String string3 = !bl2 ? this.k : context.getString(2131952626);
                textView2.setText((CharSequence)string3);
                textView = (TextView)view.findViewById(2131362790);
                if (this.l == -1L) {
                    string = context.getString(2131952663);
                } else {
                    String string4 = context.getString(2131952662);
                    Intrinsics.g((Object)string4, (String)"context.getString(R.string.watching_time)");
                    Object[] arrobject = new Object[]{Time.a.c(this.l / (long)1000)};
                    string = com.yandex.div2.a.g((Object[])arrobject, (Int)1, (String)string4, (String)"format(format, *args)");
                }
                Intrinsics.g((Object)string, (String)"if (playbackPosition == \u2026/ 1000)\n                )");
                textView.setText((CharSequence)string);
                long l = this.l;
                if (l == -1L) break block8;
                long l2 = l LCMP 1000L;
                bl = false;
                if (l2 <= 0) break block9;
            }
            bl = true;
        }
        ViewsKt.l((View)textView, (Bool)bl);
        RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362291);
        Intrinsics.g((Object)relativeLayout, (String)"view.filler_layout");
        ViewsKt.l((View)relativeLayout, (Bool)this.n);
        RelativeLayout relativeLayout3 = (RelativeLayout)view.findViewById(2131363157);
        Intrinsics.g((Object)relativeLayout3, (String)"view.watched_layout");
        ViewsKt.l((View)relativeLayout3, (Bool)this.o);
        view.setOnLongClickListener((View.OnLongClickListener)new a(this, 1));
        view.setOnClickListener((View.OnClickListener)new com.swiftsoft.anixartd.ui.fragment.main.watching.a((Object)this, 8));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = com.google.protobuf.a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof EpisodeModel) {
            String string = this.k;
            EpisodeModel episodeModel = (EpisodeModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)episodeModel.k)) {
                arrayList.add((Object)0);
            }
            if (this.l != episodeModel.l) {
                arrayList.add((Object)1);
            }
            if (this.n != episodeModel.n) {
                arrayList.add((Object)2);
            }
            if (this.o != episodeModel.o) {
                arrayList.add((Object)3);
            }
            if (this.p != episodeModel.p) {
                arrayList.add((Object)4);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        Context context = com.google.protobuf.a.b((View)view, (String)"view", list, (String)"payloads");
        Bool bl = list.contains((Object)0);
        Int n = 1;
        if (bl) {
            TextView textView = (TextView)view.findViewById(2131362622);
            String string = this.k;
            Bool bl2 = string == null || string.length() == 0;
            String string2 = !bl2 ? this.k : context.getString(2131952626);
            textView.setText((CharSequence)string2);
        }
        if (list.contains((Object)n)) {
            String string;
            TextView textView = (TextView)view.findViewById(2131362790);
            if (this.l == -1L) {
                string = context.getString(2131952663);
            } else {
                String string3 = context.getString(2131952662);
                Intrinsics.g((Object)string3, (String)"context.getString(R.string.watching_time)");
                Object[] arrobject = new Object[n];
                arrobject[0] = Time.a.c(this.l / (long)1000);
                string = com.yandex.div2.a.g((Object[])arrobject, (Int)n, (String)string3, (String)"format(format, *args)");
            }
            Intrinsics.g((Object)string, (String)"if (playbackPosition == \u202600)\n                    )");
            textView.setText((CharSequence)string);
            long l = this.l;
            if (l != -1L && l <= 1000L) {
                n = 0;
            }
            ViewsKt.l((View)textView, (Bool)n);
        }
        if (list.contains((Object)2)) {
            RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362291);
            Intrinsics.g((Object)relativeLayout, (String)"view.filler_layout");
            ViewsKt.l((View)relativeLayout, (Bool)this.n);
        }
        if (list.contains((Object)3)) {
            PopupMenu popupMenu = this.s;
            if (popupMenu != null) {
                popupMenu.dismiss();
            }
            PopupMenu popupMenu2 = new PopupMenu(context, (View)((RelativeLayout)view.findViewById(2131362497)), 0, 2130969563, 2132017465);
            if (!this.o) {
                popupMenu2.getMenu().add((CharSequence)context.getString(2131952655));
            } else {
                popupMenu2.getMenu().add((CharSequence)context.getString(2131952656));
            }
            popupMenu2.getMenu().add((CharSequence)context.getString(2131952421));
            popupMenu2.setOnMenuItemClickListener((PopupMenu.OnMenuItemClickListener)new b(context, this, 0));
            this.s = popupMenu2;
            RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362497);
            Intrinsics.g((Object)relativeLayout, (String)"view.more");
            ViewsKt.j((View)relativeLayout, (Function1)new bind.3(this));
            view.setOnLongClickListener((View.OnLongClickListener)new a(this, 0));
            RelativeLayout relativeLayout2 = (RelativeLayout)view.findViewById(2131363157);
            Intrinsics.g((Object)relativeLayout2, (String)"view.watched_layout");
            ViewsKt.l((View)relativeLayout2, (Bool)this.o);
        }
        if (list.contains((Object)4)) {
            RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362166);
            Intrinsics.g((Object)relativeLayout, (String)"view.download");
            ViewsKt.l((View)relativeLayout, (Bool)this.p);
        }
    }

    @NotNull
    final Listener v2() {
        Listener listener = this.r;
        if (listener != null) {
            return listener;
        }
        Intrinsics.r((String)"listener");
        throw null;
    }

    func w2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        PopupMenu popupMenu = this.s;
        if (popupMenu != null) {
            popupMenu.dismiss();
        }
        ((RelativeLayout)view.findViewById(2131362497)).setOnClickListener(null);
        ((RelativeLayout)view.findViewById(2131362166)).setOnClickListener(null);
        view.setOnClickListener(null);
    }
}

