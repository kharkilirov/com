/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a.a
 *  android.text.Html
 *  android.view.View
 *  android.widget.TextView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.utils.Time
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.episodes;

import a.a;
import android.text.Html;
import android.view.View;
import android.widget.TextView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.swiftsoft.anixartd.utils.Time;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u0003\u00a8\u0006\u0004"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/episodes/EpisodeUpdateModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class EpisodeUpdateModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    @Nullable
    String k = "";
    @EpoxyAttribute
    @NotNull
    String l = "";
    @EpoxyAttribute
    @NotNull
    String m = "";
    @EpoxyAttribute
    long n;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        String string = this.k;
        Bool bl = string == null || string.length() == 0;
        String string2 = !bl ? this.k : "\u043d\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043d\u0430\u044f \u0441\u0435\u0440\u0438\u044f";
        String string3 = this.l;
        String string4 = this.m;
        long l = this.n;
        TextView textView = (TextView)view.findViewById(2131362486);
        StringBuilder stringBuilder = a.z((String)"<b>", (String)string2, (String)"</b>, \u0432\u0430\u0440\u0438\u0430\u043d\u0442 <b>", (String)string3, (String)"</b>, \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a <b>");
        stringBuilder.append(string4);
        stringBuilder.append("<b>");
        textView.setText((CharSequence)Html.fromHtml((String)stringBuilder.toString()));
        TextView textView2 = (TextView)view.findViewById(2131362106);
        String string5 = l != 0L ? Time.a.a(l) : "\u0432\u0440\u0435\u043c\u044f \u043d\u0435 \u0443\u043a\u0430\u0437\u0430\u043d\u043e";
        textView2.setText((CharSequence)string5);
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = com.google.protobuf.a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof EpisodeUpdateModel) {
            String string = this.k;
            EpisodeUpdateModel episodeUpdateModel = (EpisodeUpdateModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)episodeUpdateModel.k)) {
                arrayList.add((Object)0);
            }
            if (!Intrinsics.c((Object)this.l, (Object)episodeUpdateModel.l)) {
                arrayList.add((Object)1);
            }
            if (!Intrinsics.c((Object)this.m, (Object)episodeUpdateModel.m)) {
                arrayList.add((Object)2);
            }
            if (this.n != episodeUpdateModel.n) {
                arrayList.add((Object)3);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        Intrinsics.h((Object)view, (String)"view");
        Intrinsics.h(list, (String)"payloads");
        String string = this.k;
        Bool bl = string == null || string.length() == 0;
        String string2 = !bl ? this.k : "\u043d\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043d\u0430\u044f \u0441\u0435\u0440\u0438\u044f";
        if (list.contains((Object)0)) {
            TextView textView = (TextView)view.findViewById(2131362486);
            StringBuilder stringBuilder = a.y((String)"<b>", (String)string2, (String)"</b>, \u0432\u0430\u0440\u0438\u0430\u043d\u0442 <b>");
            stringBuilder.append(this.l);
            stringBuilder.append("</b>, \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a <b>");
            stringBuilder.append(this.m);
            stringBuilder.append("<b>");
            textView.setText((CharSequence)Html.fromHtml((String)stringBuilder.toString()));
        }
        if (list.contains((Object)1)) {
            TextView textView = (TextView)view.findViewById(2131362486);
            StringBuilder stringBuilder = a.y((String)"<b>", (String)string2, (String)"</b>, \u0432\u0430\u0440\u0438\u0430\u043d\u0442 <b>");
            stringBuilder.append(this.l);
            stringBuilder.append("</b>, \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a <b>");
            stringBuilder.append(this.m);
            stringBuilder.append("<b>");
            textView.setText((CharSequence)Html.fromHtml((String)stringBuilder.toString()));
        }
        if (list.contains((Object)2)) {
            TextView textView = (TextView)view.findViewById(2131362486);
            StringBuilder stringBuilder = a.y((String)"<b>", (String)string2, (String)"</b>, \u0432\u0430\u0440\u0438\u0430\u043d\u0442 <b>");
            stringBuilder.append(this.l);
            stringBuilder.append("</b>, \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a <b>");
            stringBuilder.append(this.m);
            stringBuilder.append("<b>");
            textView.setText((CharSequence)Html.fromHtml((String)stringBuilder.toString()));
        }
        if (list.contains((Object)3)) {
            TextView textView = (TextView)view.findViewById(2131362106);
            long l = this.n;
            String string3 = l != 0L ? Time.a.a(l) : "\u0432\u0440\u0435\u043c\u044f \u043d\u0435 \u0443\u043a\u0430\u0437\u0430\u043d\u043e";
            textView.setText((CharSequence)string3);
        }
    }

    func v2(@NotNull View view) -> void {
        com.google.protobuf.a.p((View)view, (String)"view", null, null);
    }
}

