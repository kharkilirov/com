/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.fragment.main.watching.a
 *  com.swiftsoft.anixartd.ui.model.main.episodes.SourceModel$Listener
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.episodes;

import android.content.Context;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.swiftsoft.anixartd.ui.fragment.main.watching.a;
import com.swiftsoft.anixartd.ui.model.main.episodes.SourceModel;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/episodes/SourceModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class SourceModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    long k;
    @EpoxyAttribute
    @NotNull
    String l = "";
    @EpoxyAttribute
    long m;
    @EpoxyAttribute
    @Nullable
    Long n = 0L;
    @EpoxyAttribute
    Listener o;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        ((TextView)view.findViewById(2131362622)).setText((CharSequence)this.l);
        RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362456);
        Intrinsics.g((Object)relativeLayout, (String)"view.mark_new");
        long l = this.k;
        Long l2 = this.n;
        Bool bl = true;
        Bool bl2 = l2 != null && l == l2;
        ViewsKt.l((View)relativeLayout, (Bool)bl2);
        TextView textView = (TextView)view.findViewById(2131362201);
        String string = context.getString(2131951856);
        Intrinsics.g((Object)string, (String)"context.getString(R.string.episodes_count_shorten)");
        Object[] arrobject = new Object[bl];
        arrobject[0] = this.m;
        com.google.protobuf.a.y((Object[])arrobject, (Int)bl, (String)string, (String)"format(format, *args)", (TextView)textView);
        Bool bl3 = this.m > 0L;
        ViewsKt.l((View)textView, (Bool)bl3);
        TextView textView2 = (TextView)view.findViewById(2131362164);
        Intrinsics.g((Object)textView2, (String)"view.dot");
        if (this.m <= 0L) {
            bl = false;
        }
        ViewsKt.l((View)textView2, (Bool)bl);
        view.setOnClickListener((View.OnClickListener)new a((Object)this, 9));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = com.google.protobuf.a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof SourceModel) {
            String string = this.l;
            SourceModel sourceModel = (SourceModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)sourceModel.l)) {
                arrayList.add((Object)0);
            }
            if (this.m != sourceModel.m) {
                arrayList.add((Object)1);
            }
            if (!Intrinsics.c((Object)this.n, (Object)sourceModel.n)) {
                arrayList.add((Object)2);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        Context context = com.google.protobuf.a.b((View)view, (String)"view", list, (String)"payloads");
        if (list.contains((Object)0)) {
            ((TextView)view.findViewById(2131362622)).setText((CharSequence)this.l);
        }
        if (list.contains((Object)1)) {
            TextView textView = (TextView)view.findViewById(2131362201);
            String string = context.getString(2131951856);
            Intrinsics.g((Object)string, (String)"context.getString(R.string.episodes_count_shorten)");
            Object[] arrobject = new Object[]{this.m};
            com.google.protobuf.a.y((Object[])arrobject, (Int)1, (String)string, (String)"format(format, *args)", (TextView)textView);
            Bool bl = this.m > 0L;
            ViewsKt.l((View)textView, (Bool)bl);
            TextView textView2 = (TextView)view.findViewById(2131362164);
            Intrinsics.g((Object)textView2, (String)"view.dot");
            Bool bl2 = this.m > 0L;
            ViewsKt.l((View)textView2, (Bool)bl2);
        }
        if (list.contains((Object)2)) {
            Bool bl;
            RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362456);
            Intrinsics.g((Object)relativeLayout, (String)"view.mark_new");
            long l = this.k;
            Long l2 = this.n;
            if (l2 == null) {
                bl = false;
            } else {
                long l3 = l LCMP l2;
                bl = false;
                if (l3 == false) {
                    bl = true;
                }
            }
            ViewsKt.l((View)relativeLayout, (Bool)bl);
        }
    }

    func v2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        view.setOnClickListener(null);
    }
}

