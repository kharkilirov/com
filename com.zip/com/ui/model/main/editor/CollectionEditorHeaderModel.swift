/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.Html
 *  android.text.TextWatcher
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.CompoundButton
 *  android.widget.CompoundButton$OnCheckedChangeListener
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  androidx.constraintlayout.widget.ConstraintLayout
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.android.material.materialswitch.MaterialSwitch
 *  com.google.android.material.textfield.TextInputEditText
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.model.main.editor.CollectionEditorHeaderModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.editor.CollectionEditorHeaderModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.editor.CollectionEditorHeaderModel$bind$1
 *  com.swiftsoft.anixartd.ui.model.main.editor.CollectionEditorHeaderModel$bind$2
 *  com.swiftsoft.anixartd.ui.model.main.editor.CollectionEditorHeaderModel$bind$3
 *  com.swiftsoft.anixartd.ui.model.main.editor.CollectionEditorHeaderModel$bind$4
 *  com.swiftsoft.anixartd.ui.model.main.editor.CollectionEditorHeaderModel$descriptionTextWatcher
 *  com.swiftsoft.anixartd.ui.model.main.editor.CollectionEditorHeaderModel$descriptionTextWatcher$2
 *  com.swiftsoft.anixartd.ui.model.main.editor.CollectionEditorHeaderModel$privateOnCheckedChangeListener
 *  com.swiftsoft.anixartd.ui.model.main.editor.CollectionEditorHeaderModel$privateOnCheckedChangeListener$2
 *  com.swiftsoft.anixartd.ui.model.main.editor.CollectionEditorHeaderModel$titleTextWatcher
 *  com.swiftsoft.anixartd.ui.model.main.editor.CollectionEditorHeaderModel$titleTextWatcher$2
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.io.File
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.List
 *  kotlin.Lazy
 *  kotlin.LazyKt
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.editor;

import android.content.Context;
import android.text.Html;
import android.text.TextWatcher;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.textfield.TextInputEditText;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.model.main.editor.CollectionEditorHeaderModel;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/editor/CollectionEditorHeaderModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class CollectionEditorHeaderModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    @Nullable
    String k;
    @EpoxyAttribute
    @Nullable
    String l;
    @EpoxyAttribute
    @Nullable
    String m;
    @EpoxyAttribute
    @Nullable
    File n;
    @EpoxyAttribute
    Bool o;
    @EpoxyAttribute
    long p;
    @EpoxyAttribute
    Listener q;
    @NotNull
    final Lazy r = LazyKt.b((Function0)new titleTextWatcher.2(this));
    @NotNull
    final Lazy s = LazyKt.b((Function0)new descriptionTextWatcher.2(this));
    @NotNull
    final Lazy t = LazyKt.b((Function0)new privateOnCheckedChangeListener.2(this));

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        ((TextInputEditText)view.findViewById(2131363010)).setText((CharSequence)this.k);
        ((TextInputEditText)view.findViewById(2131362124)).setText((CharSequence)this.l);
        ((TextView)view.findViewById(2131362754)).setText((CharSequence)Html.fromHtml((String)context.getString(2131952448)));
        String string = this.m;
        File file = this.n;
        if (string == null && file == null) {
            RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131363086);
            Intrinsics.g((Object)relativeLayout, (String)"view.upload_image_layout");
            ViewsKt.k((View)relativeLayout);
            ConstraintLayout constraintLayout = (ConstraintLayout)view.findViewById(2131362724);
            Intrinsics.g((Object)constraintLayout, (String)"view.replace_image_layout");
            ViewsKt.e((View)constraintLayout);
        } else {
            RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131363086);
            Intrinsics.g((Object)relativeLayout, (String)"view.upload_image_layout");
            ViewsKt.e((View)relativeLayout);
            ConstraintLayout constraintLayout = (ConstraintLayout)view.findViewById(2131362724);
            Intrinsics.g((Object)constraintLayout, (String)"view.replace_image_layout");
            ViewsKt.k((View)constraintLayout);
            if (file != null) {
                AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362361);
                Intrinsics.g((Object)appCompatImageView, (String)"view.image");
                ViewsKt.g((ImageView)appCompatImageView, (File)file, (Int)2131231303);
            } else if (string != null) {
                AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362361);
                Intrinsics.g((Object)appCompatImageView, (String)"view.image");
                ViewsKt.i((ImageView)appCompatImageView, (String)string, (Int)2131231303);
            }
        }
        ((MaterialSwitch)view.findViewById(2131362931)).setChecked(this.o);
        TextView textView = (TextView)view.findViewById(2131362037);
        String string2 = context.getString(2131952282);
        Intrinsics.g((Object)string2, (String)"context.getString(R.string.out_count)");
        Object[] arrobject = new Object[]{this.p, 100};
        String string3 = String.format((String)string2, (Object[])Arrays.copyOf((Object[])arrobject, (Int)2));
        Intrinsics.g((Object)string3, (String)"format(format, *args)");
        textView.setText((CharSequence)string3);
        ((TextInputEditText)view.findViewById(2131363010)).addTextChangedListener((TextWatcher)this.r.getValue());
        ((TextInputEditText)view.findViewById(2131362124)).addTextChangedListener((TextWatcher)this.s.getValue());
        ((MaterialSwitch)view.findViewById(2131362931)).setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)this.t.getValue());
        TextView textView2 = (TextView)view.findViewById(2131362754);
        Intrinsics.g((Object)textView2, (String)"view.rules");
        ViewsKt.j((View)textView2, (Function1)new bind.1(this));
        View view2 = view.findViewById(2131363085);
        Intrinsics.g((Object)view2, (String)"view.upload_image");
        ViewsKt.j((View)view2, (Function1)new bind.2(this));
        LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362723);
        Intrinsics.g((Object)linearLayout, (String)"view.replace_image");
        ViewsKt.j((View)linearLayout, (Function1)new bind.3(this));
        LinearLayout linearLayout2 = (LinearLayout)view.findViewById(2131361985);
        Intrinsics.g((Object)linearLayout2, (String)"view.btn_add_release");
        ViewsKt.j((View)linearLayout2, (Function1)new bind.4(this));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof CollectionEditorHeaderModel) {
            String string = this.k;
            CollectionEditorHeaderModel collectionEditorHeaderModel = (CollectionEditorHeaderModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)collectionEditorHeaderModel.k)) {
                arrayList.add((Object)0);
            }
            if (!Intrinsics.c((Object)this.l, (Object)collectionEditorHeaderModel.l)) {
                arrayList.add((Object)1);
            }
            if (!Intrinsics.c((Object)this.m, (Object)collectionEditorHeaderModel.m) || !Intrinsics.c((Object)this.n, (Object)collectionEditorHeaderModel.n)) {
                arrayList.add((Object)2);
            }
            if (this.o != collectionEditorHeaderModel.o) {
                arrayList.add((Object)3);
            }
            if (this.p != collectionEditorHeaderModel.p) {
                arrayList.add((Object)4);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        Context context = a.b((View)view, (String)"view", list, (String)"payloads");
        list.contains((Object)0);
        list.contains((Object)1);
        if (list.contains((Object)2)) {
            String string = this.m;
            File file = this.n;
            if (string == null && file == null) {
                RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131363086);
                Intrinsics.g((Object)relativeLayout, (String)"view.upload_image_layout");
                ViewsKt.k((View)relativeLayout);
                ConstraintLayout constraintLayout = (ConstraintLayout)view.findViewById(2131362724);
                Intrinsics.g((Object)constraintLayout, (String)"view.replace_image_layout");
                ViewsKt.e((View)constraintLayout);
            } else {
                RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131363086);
                Intrinsics.g((Object)relativeLayout, (String)"view.upload_image_layout");
                ViewsKt.e((View)relativeLayout);
                ConstraintLayout constraintLayout = (ConstraintLayout)view.findViewById(2131362724);
                Intrinsics.g((Object)constraintLayout, (String)"view.replace_image_layout");
                ViewsKt.k((View)constraintLayout);
                if (file != null) {
                    AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362361);
                    Intrinsics.g((Object)appCompatImageView, (String)"view.image");
                    ViewsKt.g((ImageView)appCompatImageView, (File)file, (Int)2131231303);
                } else if (string != null) {
                    AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362361);
                    Intrinsics.g((Object)appCompatImageView, (String)"view.image");
                    ViewsKt.i((ImageView)appCompatImageView, (String)string, (Int)2131231303);
                }
            }
        }
        if (list.contains((Object)4)) {
            TextView textView = (TextView)view.findViewById(2131362037);
            String string = context.getString(2131952282);
            Intrinsics.g((Object)string, (String)"context.getString(R.string.out_count)");
            Object[] arrobject = new Object[]{this.p, 100};
            a.y((Object[])arrobject, (Int)2, (String)string, (String)"format(format, *args)", (TextView)textView);
        }
    }

    @NotNull
    final Listener v2() {
        Listener listener = this.q;
        if (listener != null) {
            return listener;
        }
        Intrinsics.r((String)"listener");
        throw null;
    }

    func w2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        ((TextInputEditText)view.findViewById(2131363010)).removeTextChangedListener((TextWatcher)this.r.getValue());
        ((TextInputEditText)view.findViewById(2131362124)).removeTextChangedListener((TextWatcher)this.s.getValue());
        ((MaterialSwitch)view.findViewById(2131362931)).setOnCheckedChangeListener(null);
        view.findViewById(2131363085).setOnClickListener(null);
        ((LinearLayout)view.findViewById(2131362723)).setOnClickListener(null);
        ((LinearLayout)view.findViewById(2131361985)).setOnClickListener(null);
    }
}

