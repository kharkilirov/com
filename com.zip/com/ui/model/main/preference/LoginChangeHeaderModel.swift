/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.android.material.button.MaterialButton
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.model.main.preference.LoginChangeHeaderModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.preference.LoginChangeHeaderModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.preference.LoginChangeHeaderModel$bind$1
 *  com.swiftsoft.anixartd.utils.Time
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.io.PrintStream
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.model.main.preference;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.android.material.button.MaterialButton;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.model.main.preference.LoginChangeHeaderModel;
import com.swiftsoft.anixartd.utils.Time;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/preference/LoginChangeHeaderModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class LoginChangeHeaderModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    @NotNull
    String k = "";
    @EpoxyAttribute
    Bool l;
    @EpoxyAttribute
    long m;
    @EpoxyAttribute
    Listener n;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("changeAvailable 2 ");
        stringBuilder.append(this.l);
        String string = stringBuilder.toString();
        print((Object)string);
        ((TextView)view.findViewById(2131363053)).setText((CharSequence)this.k);
        LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362418);
        Intrinsics.g((Object)linearLayout, (String)"view.layoutNextChangeAvailableAt");
        ViewsKt.l((View)linearLayout, (Bool)(true ^ this.l));
        MaterialButton materialButton = (MaterialButton)view.findViewById(2131361960);
        Intrinsics.g((Object)materialButton, (String)"view.btnChange");
        ViewsKt.l((View)materialButton, (Bool)this.l);
        ((TextView)view.findViewById(2131363054)).setText((CharSequence)Time.a.a(this.m));
        MaterialButton materialButton2 = (MaterialButton)view.findViewById(2131361960);
        Intrinsics.g((Object)materialButton2, (String)"view.btnChange");
        ViewsKt.j((View)materialButton2, (Function1)new bind.1(this));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof LoginChangeHeaderModel) {
            String string = this.k;
            LoginChangeHeaderModel loginChangeHeaderModel = (LoginChangeHeaderModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)loginChangeHeaderModel.k)) {
                arrayList.add((Object)0);
            }
            if (this.l != loginChangeHeaderModel.l) {
                arrayList.add((Object)1);
            }
            if (this.m != loginChangeHeaderModel.m) {
                arrayList.add((Object)2);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        Intrinsics.h((Object)view, (String)"view");
        Intrinsics.h(list, (String)"payloads");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("changeAvailable 1 ");
        stringBuilder.append(this.l);
        String string = stringBuilder.toString();
        print((Object)string);
        if (list.contains((Object)0)) {
            ((TextView)view.findViewById(2131363053)).setText((CharSequence)this.k);
        }
        if (list.contains((Object)1)) {
            LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362418);
            Intrinsics.g((Object)linearLayout, (String)"view.layoutNextChangeAvailableAt");
            ViewsKt.l((View)linearLayout, (Bool)(true ^ this.l));
            MaterialButton materialButton = (MaterialButton)view.findViewById(2131361960);
            Intrinsics.g((Object)materialButton, (String)"view.btnChange");
            ViewsKt.l((View)materialButton, (Bool)this.l);
        }
        if (list.contains((Object)2)) {
            ((TextView)view.findViewById(2131363054)).setText((CharSequence)Time.a.a(this.m));
        }
    }

    func v2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        ((MaterialButton)view.findViewById(2131361960)).setOnClickListener(null);
    }
}

