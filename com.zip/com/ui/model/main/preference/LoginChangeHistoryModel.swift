/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.widget.TextView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.utils.Time
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.preference;

import android.content.Context;
import android.view.View;
import android.widget.TextView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.utils.Time;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u0003\u00a8\u0006\u0004"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/preference/LoginChangeHistoryModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class LoginChangeHistoryModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    @Nullable
    String k;
    @EpoxyAttribute
    long l;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        ((TextView)view.findViewById(2131363053)).setText((CharSequence)this.k);
        if (this.l != 0L) {
            TextView textView = (TextView)view.findViewById(2131363063);
            Time time = Time.a;
            Context context = view.getContext();
            Intrinsics.g((Object)context, (String)"view.context");
            textView.setText((CharSequence)time.g(context, this.l));
            return;
        }
        ((TextView)view.findViewById(2131363063)).setText((CharSequence)"\u043f\u0440\u0438 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438");
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof LoginChangeHistoryModel) {
            String string = this.k;
            LoginChangeHistoryModel loginChangeHistoryModel = (LoginChangeHistoryModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)loginChangeHistoryModel.k)) {
                arrayList.add((Object)0);
            }
            if (this.l != loginChangeHistoryModel.l) {
                arrayList.add((Object)1);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        if (a.z((View)view, (String)"view", list, (String)"payloads", (Int)0)) {
            ((TextView)view.findViewById(2131363053)).setText((CharSequence)this.k);
        }
        if (list.contains((Object)1)) {
            if (this.l != 0L) {
                TextView textView = (TextView)view.findViewById(2131363063);
                Time time = Time.a;
                Context context = view.getContext();
                Intrinsics.g((Object)context, (String)"view.context");
                textView.setText((CharSequence)time.g(context, this.l));
                return;
            }
            ((TextView)view.findViewById(2131363063)).setText((CharSequence)"\u043f\u0440\u0438 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438");
        }
    }
}

