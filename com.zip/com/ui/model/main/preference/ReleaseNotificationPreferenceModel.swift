/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnLongClickListener
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.android.material.button.MaterialButton
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.fragment.main.profile.d
 *  com.swiftsoft.anixartd.ui.model.main.preference.ReleaseNotificationPreferenceModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.preference.ReleaseNotificationPreferenceModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.preference.ReleaseNotificationPreferenceModel$bind$2
 *  com.swiftsoft.anixartd.ui.model.main.preference.ReleaseNotificationPreferenceModel$bind$3
 *  com.swiftsoft.anixartd.ui.model.main.preference.ReleaseNotificationPreferenceModel$bind$5
 *  com.swiftsoft.anixartd.utils.DigitsKt
 *  com.swiftsoft.anixartd.utils.Plurals
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Double
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.preference;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.android.material.button.MaterialButton;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.fragment.main.profile.d;
import com.swiftsoft.anixartd.ui.model.main.preference.ReleaseNotificationPreferenceModel;
import com.swiftsoft.anixartd.utils.DigitsKt;
import com.swiftsoft.anixartd.utils.Plurals;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/preference/ReleaseNotificationPreferenceModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class ReleaseNotificationPreferenceModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    @Nullable
    String k = "";
    @EpoxyAttribute
    @Nullable
    Integer l;
    @EpoxyAttribute
    @Nullable
    Integer m;
    @EpoxyAttribute
    @Nullable
    Double n;
    @EpoxyAttribute
    @Nullable
    String o;
    @EpoxyAttribute
    Bool p;
    @EpoxyAttribute
    Int q;
    @EpoxyAttribute
    Bool r;
    @EpoxyAttribute
    Int s;
    @EpoxyAttribute
    Int t;
    @EpoxyAttribute
    Listener u;

    init() {
        Integer n;
        this.l = n = Integer.valueOf((Int)0);
        this.m = n;
        this.n = 0.0;
        this.o = "";
    }

    func Z1(Object object) -> void {
        String string;
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        String string2 = this.k;
        Integer n = this.l;
        Integer n2 = this.m;
        Double d2 = this.n;
        Bool bl = this.p;
        Int n3 = this.q;
        ImageView imageView = (ImageView)view.findViewById(2131362281);
        Int n4 = bl ? 0 : 8;
        imageView.setVisibility(n4);
        if (n3 != 0) {
            RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362918);
            Intrinsics.g((Object)relativeLayout, (String)"view.status_layout");
            ViewsKt.m((View)relativeLayout, (Bool)true);
            if (n3 != 1) {
                if (n3 != 2) {
                    if (n3 != 3) {
                        if (n3 != 4) {
                            if (n3 == 5) {
                                ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0431\u0440\u043e\u0448\u0435\u043d\u043e");
                                a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131100607, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                            }
                        } else {
                            ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u043e\u0442\u043b\u043e\u0436\u0435\u043d\u043e");
                            a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131100687, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                        }
                    } else {
                        ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u043f\u0440\u043e\u0441\u043c\u043e\u0442\u0440\u0435\u043d\u043e");
                        a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131099691, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                    }
                } else {
                    ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0432 \u043f\u043b\u0430\u043d\u0430\u0445");
                    a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131100604, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                }
            } else {
                ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0441\u043c\u043e\u0442\u0440\u044e");
                a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131099809, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
            }
        } else {
            RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362918);
            Intrinsics.g((Object)relativeLayout, (String)"view.status_layout");
            ViewsKt.m((View)relativeLayout, (Bool)false);
        }
        Bool bl2 = string2 == null || string2.length() == 0;
        if (bl2) {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)"\u0411\u0435\u0437 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u044f");
        } else {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)string2);
        }
        if (n != null && n2 != null && Intrinsics.c((Object)n, (Object)n2)) {
            TextView textView = (TextView)a.g((Integer)n2, (String)" \u044d\u043f", (TextView)((TextView)view.findViewById(2131362200)), (View)view, (Int)2131362200);
            TextView textView2 = (TextView)a.C((TextView)textView, (String)"view.episodes", (TextView)textView, (View)view, (Int)2131362164);
            Intrinsics.g((Object)textView2, (String)"view.dot");
            ViewsKt.k((View)textView2);
        } else if (n != null && n2 != null) {
            a.t((Integer)n, (String)" \u0438\u0437 ", (Integer)n2, (String)" \u044d\u043f", (TextView)((TextView)view.findViewById(2131362200)));
            TextView textView = (TextView)view.findViewById(2131362200);
            TextView textView3 = (TextView)a.C((TextView)textView, (String)"view.episodes", (TextView)textView, (View)view, (Int)2131362164);
            Intrinsics.g((Object)textView3, (String)"view.dot");
            ViewsKt.k((View)textView3);
        } else if (n != null && n2 == null) {
            TextView textView = (TextView)a.g((Integer)n, (String)" \u0438\u0437 ? \u044d\u043f", (TextView)((TextView)view.findViewById(2131362200)), (View)view, (Int)2131362200);
            TextView textView4 = (TextView)a.C((TextView)textView, (String)"view.episodes", (TextView)textView, (View)view, (Int)2131362164);
            Intrinsics.g((Object)textView4, (String)"view.dot");
            ViewsKt.k((View)textView4);
        } else if (n == null && n2 != null) {
            a.u((String)"? \u0438\u0437 ", (Integer)n2, (String)" \u044d\u043f", (TextView)((TextView)view.findViewById(2131362200)));
            TextView textView = (TextView)view.findViewById(2131362200);
            TextView textView5 = (TextView)a.C((TextView)textView, (String)"view.episodes", (TextView)textView, (View)view, (Int)2131362164);
            Intrinsics.g((Object)textView5, (String)"view.dot");
            ViewsKt.k((View)textView5);
        } else {
            TextView textView = (TextView)view.findViewById(2131362200);
            TextView textView6 = (TextView)a.f((TextView)textView, (String)"view.episodes", (TextView)textView, (View)view, (Int)2131362164);
            Intrinsics.g((Object)textView6, (String)"view.dot");
            ViewsKt.e((View)textView6);
        }
        if (d2 != null) {
            a.s((Double)d2, (Int)0, (Int)1, (TextView)((TextView)view.findViewById(2131362324)));
        }
        LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362662);
        Intrinsics.g((Object)linearLayout, (String)"view.rating_layout");
        ViewsKt.l((View)linearLayout, (Bool)this.r);
        TextView textView = (TextView)view.findViewById(2131363071);
        if (this.s == this.t) {
            string = context.getString(2131952391);
        } else {
            Plurals plurals = Plurals.a;
            Intrinsics.g((Object)context, (String)"context");
            string = plurals.b(context, this.s, 2131820558, 2131952392);
        }
        textView.setText((CharSequence)string);
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362613);
        Intrinsics.g((Object)appCompatImageView, (String)"view.poster");
        ViewsKt.h((ImageView)appCompatImageView, (String)this.o);
        MaterialButton materialButton = (MaterialButton)view.findViewById(2131362701);
        Intrinsics.g((Object)materialButton, (String)"view.release_type_notification_preferences");
        ViewsKt.j((View)materialButton, (Function1)new bind.2(this));
        ViewsKt.j((View)view, (Function1)new bind.3(this));
        view.setOnLongClickListener((View.OnLongClickListener)new d((Object)this, 12));
        ImageView imageView2 = (ImageView)view.findViewById(2131362497);
        Intrinsics.g((Object)imageView2, (String)"view.more");
        ViewsKt.j((View)imageView2, (Function1)new bind.5(this));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof ReleaseNotificationPreferenceModel) {
            String string = this.k;
            ReleaseNotificationPreferenceModel releaseNotificationPreferenceModel = (ReleaseNotificationPreferenceModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)releaseNotificationPreferenceModel.k)) {
                arrayList.add((Object)0);
            }
            if (!Intrinsics.c((Object)this.l, (Object)releaseNotificationPreferenceModel.l)) {
                arrayList.add((Object)1);
            }
            if (!Intrinsics.c((Object)this.m, (Object)releaseNotificationPreferenceModel.m)) {
                arrayList.add((Object)2);
            }
            if (!Intrinsics.a((Double)this.n, (Double)releaseNotificationPreferenceModel.n)) {
                arrayList.add((Object)3);
            }
            if (!Intrinsics.c((Object)this.o, (Object)releaseNotificationPreferenceModel.o)) {
                arrayList.add((Object)4);
            }
            if (this.p != releaseNotificationPreferenceModel.p) {
                arrayList.add((Object)5);
            }
            if (this.q != releaseNotificationPreferenceModel.q) {
                arrayList.add((Object)6);
            }
            if (this.r != releaseNotificationPreferenceModel.r) {
                arrayList.add((Object)7);
            }
            if (this.s != releaseNotificationPreferenceModel.s) {
                arrayList.add((Object)8);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        Double d2;
        Context context = a.b((View)view, (String)"view", list, (String)"payloads");
        if (list.contains((Object)0)) {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)this.k);
        }
        if (list.contains((Object)1)) {
            TextView textView = (TextView)view.findViewById(2131362200);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append((Object)this.l);
            stringBuilder.append(" \u0438\u0437 ");
            a.w((StringBuilder)stringBuilder, (Integer)this.m, (TextView)textView);
        }
        if (list.contains((Object)2)) {
            TextView textView = (TextView)view.findViewById(2131362200);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append((Object)this.l);
            stringBuilder.append(" \u0438\u0437 ");
            a.w((StringBuilder)stringBuilder, (Integer)this.m, (TextView)textView);
        }
        if (list.contains((Object)3) && (d2 = this.n) != null) {
            Double d3 = d2;
            ((TextView)view.findViewById(2131362324)).setText((CharSequence)DigitsKt.d((Double)d3, (Int)0, (Int)1));
        }
        if (list.contains((Object)4)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362613);
            Intrinsics.g((Object)appCompatImageView, (String)"view.poster");
            ViewsKt.h((ImageView)appCompatImageView, (String)this.o);
        }
        if (list.contains((Object)5)) {
            ImageView imageView = (ImageView)view.findViewById(2131362281);
            Int n = this.p ? 0 : 8;
            imageView.setVisibility(n);
        }
        if (list.contains((Object)6)) {
            if (this.q != 0) {
                RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362918);
                Intrinsics.g((Object)relativeLayout, (String)"view.status_layout");
                ViewsKt.m((View)relativeLayout, (Bool)true);
                Int n = this.q;
                if (n != 1) {
                    if (n != 2) {
                        if (n != 3) {
                            if (n != 4) {
                                if (n == 5) {
                                    ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0431\u0440\u043e\u0448\u0435\u043d\u043e");
                                    a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131100607, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                                }
                            } else {
                                ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u043e\u0442\u043b\u043e\u0436\u0435\u043d\u043e");
                                a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131100687, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                            }
                        } else {
                            ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u043f\u0440\u043e\u0441\u043c\u043e\u0442\u0440\u0435\u043d\u043e");
                            a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131099691, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                        }
                    } else {
                        ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0432 \u043f\u043b\u0430\u043d\u0430\u0445");
                        a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131100604, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                    }
                } else {
                    ((TextView)view.findViewById(2131362909)).setText((CharSequence)"\u0441\u043c\u043e\u0442\u0440\u044e");
                    a.n((View)view, (Int)2131100657, (TextView)((TextView)a.d((View)view, (Int)2131099809, (RelativeLayout)((RelativeLayout)view.findViewById(2131362918)), (Int)2131362909)));
                }
            } else {
                RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362918);
                Intrinsics.g((Object)relativeLayout, (String)"view.status_layout");
                ViewsKt.m((View)relativeLayout, (Bool)false);
            }
        }
        if (list.contains((Object)7)) {
            LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362662);
            Intrinsics.g((Object)linearLayout, (String)"view.rating_layout");
            ViewsKt.l((View)linearLayout, (Bool)this.r);
        }
        if (list.contains((Object)8)) {
            String string;
            TextView textView = (TextView)view.findViewById(2131363071);
            if (this.s == this.t) {
                string = context.getString(2131952391);
            } else {
                Plurals plurals = Plurals.a;
                Intrinsics.g((Object)context, (String)"context");
                string = plurals.b(context, this.s, 2131820558, 2131952392);
            }
            textView.setText((CharSequence)string);
        }
    }

    @NotNull
    final Listener v2() {
        Listener listener = this.u;
        if (listener != null) {
            return listener;
        }
        Intrinsics.r((String)"listener");
        throw null;
    }

    func w2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        view.setOnClickListener(null);
        view.setOnLongClickListener(null);
        ((ImageView)view.findViewById(2131362497)).setOnClickListener(null);
    }
}

