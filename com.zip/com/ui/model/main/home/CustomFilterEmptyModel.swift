/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModel$SpanSizeOverrideCallback
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.android.material.button.MaterialButton
 *  com.swiftsoft.anixartd.ui.model.main.home.CustomFilterEmptyModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.home.CustomFilterEmptyModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.home.CustomFilterEmptyModel$bind$1
 *  com.swiftsoft.anixartd.ui.model.main.home.CustomFilterEmptyModel_
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  j.a
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 */
package com.swiftsoft.anixartd.ui.model.main.home;

import android.view.View;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.android.material.button.MaterialButton;
import com.swiftsoft.anixartd.ui.model.main.home.CustomFilterEmptyModel;
import com.swiftsoft.anixartd.ui.model.main.home.CustomFilterEmptyModel_;
import com.swiftsoft.anixartd.utils.ViewsKt;
import j.a;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u0003\u00a8\u0006\u0004"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/home/CustomFilterEmptyModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class CustomFilterEmptyModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    Listener k;

    init() {
        a a2 = a.v;
        ((CustomFilterEmptyModel_)this).i = a2;
    }

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        MaterialButton materialButton = (MaterialButton)view.findViewById(2131361987);
        Intrinsics.g((Object)materialButton, (String)"view.button");
        ViewsKt.j((View)materialButton, (Function1)new bind.1(this));
    }
}

