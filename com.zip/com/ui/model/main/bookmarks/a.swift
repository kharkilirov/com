/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.graphics.drawable.Drawable
 *  android.view.MenuItem
 *  android.view.View
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.appcompat.widget.PopupMenu
 *  androidx.appcompat.widget.PopupMenu$OnMenuItemClickListener
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.model.main.bookmarks.ExtraBookmarksModel$Listener
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.internal.Intrinsics
 */
package com.swiftsoft.anixartd.ui.model.main.bookmarks;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.PopupMenu;
import com.swiftsoft.anixartd.ui.model.main.bookmarks.ExtraBookmarksModel;
import kotlin.jvm.internal.Intrinsics;

final class a
implements PopupMenu.OnMenuItemClickListener {
    final /* synthetic */ View b;
    final /* synthetic */ ExtraBookmarksModel c;

    /* synthetic */ a(View view, ExtraBookmarksModel extraBookmarksModel) {
        this.b = view;
        this.c = extraBookmarksModel;
    }

    final Bool onMenuItemClick(MenuItem menuItem) {
        View view = this.b;
        ExtraBookmarksModel extraBookmarksModel = this.c;
        Intrinsics.h((Object)view, (String)"$view");
        Intrinsics.h((Object)((Object)extraBookmarksModel), (String)"this$0");
        switch (menuItem.getItemId()) {
            default: {
                break;
            }
            case 2131363009: {
                ((ImageView)view.findViewById(2131362357)).setImageDrawable(view.getResources().getDrawable(2131231320));
                extraBookmarksModel.u2().a(5);
                break;
            }
            case 2131363008: {
                ((ImageView)view.findViewById(2131362357)).setImageDrawable(view.getResources().getDrawable(2131231319));
                extraBookmarksModel.u2().a(6);
                break;
            }
            case 2131362698: {
                ((ImageView)view.findViewById(2131362357)).setImageDrawable(view.getResources().getDrawable(2131231320));
                extraBookmarksModel.u2().a(3);
                break;
            }
            case 2131362697: {
                ((ImageView)view.findViewById(2131362357)).setImageDrawable(view.getResources().getDrawable(2131231319));
                extraBookmarksModel.u2().a(4);
                break;
            }
            case 2131362629: {
                ((ImageView)view.findViewById(2131362357)).setImageDrawable(view.getResources().getDrawable(2131231320));
                extraBookmarksModel.u2().a(1);
                break;
            }
            case 2131362628: {
                ((ImageView)view.findViewById(2131362357)).setImageDrawable(view.getResources().getDrawable(2131231319));
                extraBookmarksModel.u2().a(2);
            }
        }
        com.google.protobuf.a.m((MenuItem)menuItem, (TextView)((TextView)view.findViewById(2131362799)));
        return true;
    }
}

