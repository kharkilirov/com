/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.ImageView
 *  android.widget.TextView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.model.main.search.SearchRelatedModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.search.SearchRelatedModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.search.SearchRelatedModel$bind$1
 *  com.swiftsoft.anixartd.ui.model.main.search.a
 *  com.swiftsoft.anixartd.utils.Plurals
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.search;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.swiftsoft.anixartd.ui.model.main.search.SearchRelatedModel;
import com.swiftsoft.anixartd.ui.model.main.search.a;
import com.swiftsoft.anixartd.utils.Plurals;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/search/SearchRelatedModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class SearchRelatedModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    long k;
    @EpoxyAttribute
    @NotNull
    String l = "";
    @EpoxyAttribute
    @Nullable
    String m = "";
    @EpoxyAttribute
    @NotNull
    String n = "";
    @EpoxyAttribute
    long o;
    @EpoxyAttribute
    @Nullable
    String p = "";
    @EpoxyAttribute
    @Nullable
    String q = "";
    @EpoxyAttribute
    @Nullable
    String r = "";
    @EpoxyAttribute
    Listener s;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        ((TextView)view.findViewById(2131362525)).setText((CharSequence)this.l);
        TextView textView = (TextView)view.findViewById(2131362695);
        String string = context.getString(2131952380);
        Intrinsics.g((Object)string, (String)"context.getString(R.string.related_release_count)");
        Object[] arrobject = new Object[]{Plurals.a.a(context, (Int)this.o, 2131820559)};
        String string2 = String.format((String)string, (Object[])Arrays.copyOf((Object[])arrobject, (Int)1));
        Intrinsics.g((Object)string2, (String)"format(format, *args)");
        textView.setText((CharSequence)string2);
        ImageView imageView = (ImageView)view.findViewById(2131362621);
        Intrinsics.g((Object)imageView, (String)"view.primaryImage");
        ViewsKt.i((ImageView)imageView, (String)this.p, (Int)2131231301);
        ImageView imageView2 = (ImageView)view.findViewById(2131362789);
        Intrinsics.g((Object)imageView2, (String)"view.secondaryImage");
        ViewsKt.i((ImageView)imageView2, (String)this.q, (Int)2131231301);
        ImageView imageView3 = (ImageView)view.findViewById(2131362970);
        Intrinsics.g((Object)imageView3, (String)"view.tertiaryImage");
        ViewsKt.i((ImageView)imageView3, (String)this.r, (Int)2131231301);
        view.setOnClickListener((View.OnClickListener)new a(this, 0));
        ((Button)view.findViewById(2131361987)).setOnClickListener((View.OnClickListener)new a(this, 1));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = com.google.protobuf.a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof SearchRelatedModel) {
            long l = this.k;
            SearchRelatedModel searchRelatedModel = (SearchRelatedModel)epoxyModel;
            if (l != searchRelatedModel.k) {
                arrayList.add((Object)0);
            }
            if (!Intrinsics.c((Object)this.l, (Object)searchRelatedModel.l)) {
                arrayList.add((Object)1);
            }
            if (this.o != searchRelatedModel.o) {
                arrayList.add((Object)2);
            }
            if (!Intrinsics.c((Object)this.p, (Object)searchRelatedModel.p)) {
                arrayList.add((Object)3);
            }
            if (!Intrinsics.c((Object)this.q, (Object)searchRelatedModel.q)) {
                arrayList.add((Object)3);
            }
            if (!Intrinsics.c((Object)this.r, (Object)searchRelatedModel.r)) {
                arrayList.add((Object)3);
            }
            if (!Intrinsics.c((Object)this.m, (Object)searchRelatedModel.m)) {
                arrayList.add((Object)4);
            }
            if (!Intrinsics.c((Object)this.n, (Object)searchRelatedModel.n)) {
                arrayList.add((Object)3);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func d2() -> Int {
        return 2131558675;
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        Context context = com.google.protobuf.a.b((View)view, (String)"view", list, (String)"payloads");
        if (list.contains((Object)0) || list.contains((Object)4) || list.contains((Object)5)) {
            ViewsKt.j((View)view, (Function1)new bind.1(this));
            ((Button)view.findViewById(2131361987)).setOnClickListener((View.OnClickListener)new a(this, 2));
        }
        if (list.contains((Object)2)) {
            TextView textView = (TextView)view.findViewById(2131362695);
            String string = context.getString(2131952380);
            Intrinsics.g((Object)string, (String)"context.getString(R.string.related_release_count)");
            Object[] arrobject = new Object[]{Plurals.a.a(context, (Int)this.o, 2131820559)};
            com.google.protobuf.a.y((Object[])arrobject, (Int)1, (String)string, (String)"format(format, *args)", (TextView)textView);
        }
        if (list.contains((Object)1)) {
            ((TextView)view.findViewById(2131362525)).setText((CharSequence)this.l);
        }
        if (list.contains((Object)3)) {
            ImageView imageView = (ImageView)view.findViewById(2131362621);
            Intrinsics.g((Object)imageView, (String)"view.primaryImage");
            ViewsKt.i((ImageView)imageView, (String)this.p, (Int)2131231301);
            ImageView imageView2 = (ImageView)view.findViewById(2131362789);
            Intrinsics.g((Object)imageView2, (String)"view.secondaryImage");
            ViewsKt.i((ImageView)imageView2, (String)this.q, (Int)2131231301);
            ImageView imageView3 = (ImageView)view.findViewById(2131362970);
            Intrinsics.g((Object)imageView3, (String)"view.tertiaryImage");
            ViewsKt.i((ImageView)imageView3, (String)this.r, (Int)2131231301);
        }
    }

    @NotNull
    final Listener v2() {
        Listener listener = this.s;
        if (listener != null) {
            return listener;
        }
        Intrinsics.r((String)"listener");
        throw null;
    }

    func w2(@NotNull View view) -> void {
        com.google.protobuf.a.p((View)view, (String)"view", null, null);
    }
}

