/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.ColorStateList
 *  android.content.res.Resources
 *  android.graphics.drawable.Drawable
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ImageView
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.model.main.collections.CollectionCompactModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.collections.CollectionCompactModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.collections.CollectionCompactModel$bind$5
 *  com.swiftsoft.anixartd.utils.DigitsKt
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.model.main.collections;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.model.main.collections.CollectionCompactModel;
import com.swiftsoft.anixartd.utils.DigitsKt;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/collections/CollectionCompactModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class CollectionCompactModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    @NotNull
    String k = "";
    @EpoxyAttribute
    @NotNull
    String l = "";
    @EpoxyAttribute
    @NotNull
    String m = "";
    @EpoxyAttribute
    long n;
    @EpoxyAttribute
    Int o;
    @EpoxyAttribute
    Bool p;
    @EpoxyAttribute
    Bool q;
    @EpoxyAttribute
    Listener r;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        ((TextView)view.findViewById(2131363004)).setText((CharSequence)this.k);
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362361);
        Intrinsics.g((Object)appCompatImageView, (String)"view.image");
        ViewsKt.h((ImageView)appCompatImageView, (String)this.m);
        ((TextView)view.findViewById(2131362046)).setText((CharSequence)DigitsKt.f((long)this.n));
        ((TextView)view.findViewById(2131362277)).setText((CharSequence)DigitsKt.e((Int)this.o));
        Bool bl = this.q;
        if (bl) {
            ((TextView)view.findViewById(2131362277)).setTextColor(view.getResources().getColor(2131100686));
            AppCompatImageView appCompatImageView2 = (AppCompatImageView)view.findViewById(2131362278);
            appCompatImageView2.setImageDrawable(appCompatImageView2.getResources().getDrawable(2131231116));
            appCompatImageView2.setImageTintList(ColorStateList.valueOf((Int)appCompatImageView2.getResources().getColor(2131100686)));
        } else if (!bl) {
            Int n = ViewsKt.c((View)view, (Int)2130969642);
            ((TextView)view.findViewById(2131362277)).setTextColor(n);
            AppCompatImageView appCompatImageView3 = (AppCompatImageView)view.findViewById(2131362278);
            appCompatImageView3.setImageDrawable(appCompatImageView3.getResources().getDrawable(2131231117));
            appCompatImageView3.setImageTintList(ColorStateList.valueOf((Int)n));
        }
        RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362624);
        Intrinsics.g((Object)relativeLayout, (String)"view.privateCollection");
        ViewsKt.l((View)relativeLayout, (Bool)this.p);
        ViewsKt.j((View)view, (Function1)new bind.5(this));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof CollectionCompactModel) {
            String string = this.k;
            CollectionCompactModel collectionCompactModel = (CollectionCompactModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)collectionCompactModel.k)) {
                arrayList.add((Object)0);
            }
            if (!Intrinsics.c((Object)this.m, (Object)collectionCompactModel.m)) {
                arrayList.add((Object)1);
            }
            if (this.n != collectionCompactModel.n) {
                arrayList.add((Object)2);
            }
            if (this.o != collectionCompactModel.o) {
                arrayList.add((Object)3);
            }
            if (this.p != collectionCompactModel.q) {
                arrayList.add((Object)4);
            }
            if (this.q != collectionCompactModel.q) {
                arrayList.add((Object)5);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        if (a.z((View)view, (String)"view", list, (String)"payloads", (Int)0)) {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)this.k);
        }
        if (list.contains((Object)1)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362361);
            Intrinsics.g((Object)appCompatImageView, (String)"view.image");
            ViewsKt.h((ImageView)appCompatImageView, (String)this.m);
        }
        if (list.contains((Object)2)) {
            ((TextView)view.findViewById(2131362046)).setText((CharSequence)DigitsKt.f((long)this.n));
        }
        if (list.contains((Object)3)) {
            ((TextView)view.findViewById(2131362277)).setText((CharSequence)DigitsKt.e((Int)this.o));
        }
        if (list.contains((Object)4)) {
            RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362624);
            Intrinsics.g((Object)relativeLayout, (String)"view.privateCollection");
            ViewsKt.l((View)relativeLayout, (Bool)this.p);
        }
        if (list.contains((Object)5)) {
            Bool bl = this.q;
            if (bl) {
                ((TextView)view.findViewById(2131362277)).setTextColor(view.getResources().getColor(2131100686));
                AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362278);
                appCompatImageView.setImageDrawable(appCompatImageView.getResources().getDrawable(2131231116));
                appCompatImageView.setImageTintList(ColorStateList.valueOf((Int)appCompatImageView.getResources().getColor(2131100686)));
                return;
            }
            if (!bl) {
                Int n = ViewsKt.c((View)view, (Int)2130969642);
                ((TextView)view.findViewById(2131362277)).setTextColor(n);
                AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362278);
                appCompatImageView.setImageDrawable(appCompatImageView.getResources().getDrawable(2131231117));
                appCompatImageView.setImageTintList(ColorStateList.valueOf((Int)n));
            }
        }
    }

    func v2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        view.setOnClickListener(null);
    }
}

