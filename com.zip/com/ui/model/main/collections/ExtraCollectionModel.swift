/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.View
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  androidx.appcompat.view.menu.MenuBuilder
 *  androidx.appcompat.widget.PopupMenu
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.swiftsoft.anixartd.ui.model.main.collections.ExtraCollectionModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.collections.ExtraCollectionModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.collections.ExtraCollectionModel$bind$1
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.model.main.collections;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.widget.PopupMenu;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.swiftsoft.anixartd.ui.model.main.collections.ExtraCollectionModel;
import com.swiftsoft.anixartd.utils.ViewsKt;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u0003\u00a8\u0006\u0004"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/collections/ExtraCollectionModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class ExtraCollectionModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    Listener k;
    @EpoxyAttribute
    Int l = 1;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        PopupMenu popupMenu = new PopupMenu(view.getContext(), (View)((LinearLayout)view.findViewById(2131362863)));
        popupMenu.a().inflate(2131689476, (Menu)popupMenu.b);
        ((TextView)view.findViewById(2131362799)).setText((CharSequence)String.valueOf((Object)popupMenu.b.getItem(-1 + this.l)));
        LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362864);
        Intrinsics.g((Object)linearLayout, (String)"view.spinnerView");
        ViewsKt.j((View)linearLayout, (Function1)new bind.1(popupMenu, context, view, this));
    }

    @NotNull
    final Listener u2() {
        Listener listener = this.k;
        if (listener != null) {
            return listener;
        }
        Intrinsics.r((String)"listener");
        throw null;
    }
}

