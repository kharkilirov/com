/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a.a
 *  android.content.Context
 *  android.content.res.ColorStateList
 *  android.content.res.Resources
 *  android.graphics.drawable.Drawable
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.fragment.main.search.a
 *  com.swiftsoft.anixartd.ui.model.main.collections.CollectionHeaderModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.collections.CollectionHeaderModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.collections.CollectionHeaderModel$bind$4
 *  com.swiftsoft.anixartd.ui.model.main.collections.CollectionHeaderModel$bind$5
 *  com.swiftsoft.anixartd.ui.model.main.collections.CollectionHeaderModel$bind$7
 *  com.swiftsoft.anixartd.ui.model.main.collections.a
 *  com.swiftsoft.anixartd.ui.model.main.collections.b
 *  com.swiftsoft.anixartd.utils.DigitsKt
 *  com.swiftsoft.anixartd.utils.Time
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.model.main.collections;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.swiftsoft.anixartd.ui.model.main.collections.CollectionHeaderModel;
import com.swiftsoft.anixartd.ui.model.main.collections.a;
import com.swiftsoft.anixartd.ui.model.main.collections.b;
import com.swiftsoft.anixartd.utils.DigitsKt;
import com.swiftsoft.anixartd.utils.Time;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/collections/CollectionHeaderModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class CollectionHeaderModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    @NotNull
    String k = "";
    @EpoxyAttribute
    @NotNull
    String l = "";
    @EpoxyAttribute
    @NotNull
    String m = "";
    @EpoxyAttribute
    long n;
    @EpoxyAttribute
    long o;
    @EpoxyAttribute
    long p;
    @EpoxyAttribute
    Int q;
    @EpoxyAttribute
    Bool r;
    @EpoxyAttribute
    Bool s;
    @EpoxyAttribute
    @NotNull
    String t = "";
    @EpoxyAttribute
    Bool u;
    @EpoxyAttribute
    Listener v;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        ((TextView)view.findViewById(2131363004)).setText((CharSequence)this.k);
        ((TextView)view.findViewById(2131362123)).setText((CharSequence)this.l);
        TextView textView = (TextView)view.findViewById(2131362123);
        Intrinsics.g((Object)textView, (String)"view.description");
        Bool bl = this.l.length() > 0;
        ViewsKt.l((View)textView, (Bool)bl);
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362108);
        Intrinsics.g((Object)appCompatImageView, (String)"view.date_more");
        Bool bl2 = this.o <= this.n;
        ViewsKt.f((View)appCompatImageView, (Bool)bl2, (Bool)false, null, (Int)6);
        TextView textView2 = (TextView)view.findViewById(2131362416);
        AppCompatImageView appCompatImageView2 = (AppCompatImageView)com.google.protobuf.a.f((TextView)textView2, (String)"view.last_update_date", (TextView)textView2, (View)view, (Int)2131362108);
        Intrinsics.g((Object)appCompatImageView2, (String)"view.date_more");
        ViewsKt.k((View)appCompatImageView2);
        ((LinearLayout)view.findViewById(2131362107)).setOnClickListener((View.OnClickListener)new com.swiftsoft.anixartd.ui.fragment.main.search.a(view, 1));
        ((TextView)view.findViewById(2131362123)).setTextIsSelectable(false);
        ((TextView)view.findViewById(2131362123)).post((Runnable)new b(view, 0));
        AppCompatImageView appCompatImageView3 = (AppCompatImageView)view.findViewById(2131362361);
        Intrinsics.g((Object)appCompatImageView3, (String)"view.image");
        ViewsKt.i((ImageView)appCompatImageView3, (String)this.m, (Int)2131231303);
        TextView textView3 = (TextView)view.findViewById(2131362080);
        Time time = Time.a;
        Context context = view.getContext();
        Intrinsics.g((Object)context, (String)"view.context");
        textView3.setText((CharSequence)time.g(context, this.n));
        TextView textView4 = (TextView)view.findViewById(2131362416);
        StringBuilder stringBuilder = a.a.u((String)"\u0420\u0435\u0434. ");
        Context context2 = view.getContext();
        Intrinsics.g((Object)context2, (String)"view.context");
        stringBuilder.append(time.g(context2, this.o));
        textView4.setText((CharSequence)stringBuilder.toString());
        ((TextView)view.findViewById(2131362046)).setText((CharSequence)DigitsKt.f((long)this.p));
        ((TextView)view.findViewById(2131362277)).setText((CharSequence)DigitsKt.e((Int)this.q));
        if (this.r) {
            this.x2(view);
        } else {
            this.w2(view);
        }
        LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362625);
        Intrinsics.g((Object)linearLayout, (String)"view.private_collection");
        Bool bl3 = this.s && this.u;
        ViewsKt.l((View)linearLayout, (Bool)bl3);
        LinearLayout linearLayout2 = (LinearLayout)view.findViewById(2131362455);
        Intrinsics.g((Object)linearLayout2, (String)"view.management_actions");
        ViewsKt.l((View)linearLayout2, (Bool)this.u);
        LinearLayout linearLayout3 = (LinearLayout)view.findViewById(2131362050);
        Intrinsics.g((Object)linearLayout3, (String)"view.comments_show_all");
        ViewsKt.f((View)linearLayout3, (Bool)this.s, (Bool)false, null, (Int)6);
        AppCompatImageView appCompatImageView4 = (AppCompatImageView)view.findViewById(2131361916);
        Intrinsics.g((Object)appCompatImageView4, (String)"view.avatar");
        ViewsKt.a((AppCompatImageView)appCompatImageView4, (String)this.t);
        ((AppCompatImageView)view.findViewById(2131362361)).setOnClickListener((View.OnClickListener)new a(this, 0));
        RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131361872);
        Intrinsics.g((Object)relativeLayout, (String)"view.addToFav");
        ViewsKt.j((View)relativeLayout, (Function1)new bind.4(this));
        LinearLayout linearLayout4 = (LinearLayout)view.findViewById(2131362050);
        Intrinsics.g((Object)linearLayout4, (String)"view.comments_show_all");
        ViewsKt.j((View)linearLayout4, (Function1)new bind.5(this));
        ((AppCompatImageView)view.findViewById(2131362497)).setOnClickListener((View.OnClickListener)new a(this, 1));
        RelativeLayout relativeLayout2 = (RelativeLayout)view.findViewById(2131362183);
        Intrinsics.g((Object)relativeLayout2, (String)"view.edit");
        ViewsKt.j((View)relativeLayout2, (Function1)new bind.7(this));
        ((RelativeLayout)view.findViewById(2131362116)).setOnClickListener((View.OnClickListener)new a(this, 2));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = com.google.protobuf.a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof CollectionHeaderModel) {
            String string = this.k;
            CollectionHeaderModel collectionHeaderModel = (CollectionHeaderModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)collectionHeaderModel.k)) {
                arrayList.add((Object)0);
            }
            if (!Intrinsics.c((Object)this.l, (Object)collectionHeaderModel.l)) {
                arrayList.add((Object)1);
            }
            if (!Intrinsics.c((Object)this.m, (Object)collectionHeaderModel.m)) {
                arrayList.add((Object)3);
            }
            if (this.n != collectionHeaderModel.n) {
                arrayList.add((Object)4);
            }
            if (this.o != collectionHeaderModel.o) {
                arrayList.add((Object)5);
            }
            if (this.p != collectionHeaderModel.p) {
                arrayList.add((Object)6);
            }
            if (this.q != collectionHeaderModel.q) {
                arrayList.add((Object)7);
            }
            if (this.r != collectionHeaderModel.r) {
                arrayList.add((Object)8);
            }
            if (this.s != collectionHeaderModel.s) {
                arrayList.add((Object)9);
            }
            if (!Intrinsics.c((Object)this.t, (Object)collectionHeaderModel.t)) {
                arrayList.add((Object)10);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        Bool bl;
        if (com.google.protobuf.a.z((View)view, (String)"view", list, (String)"payloads", (Int)0)) {
            ((TextView)view.findViewById(2131363004)).setText((CharSequence)this.k);
        }
        if (list.contains((Object)((Int)(bl = true)))) {
            ((TextView)view.findViewById(2131362123)).setText((CharSequence)this.l);
            TextView textView = (TextView)view.findViewById(2131362123);
            Intrinsics.g((Object)textView, (String)"view.description");
            Bool bl2 = this.l.length() > 0;
            ViewsKt.l((View)textView, (Bool)bl2);
        }
        if (list.contains((Object)3)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362361);
            Intrinsics.g((Object)appCompatImageView, (String)"view.image");
            ViewsKt.i((ImageView)appCompatImageView, (String)this.m, (Int)2131231303);
        }
        if (list.contains((Object)4)) {
            TextView textView = (TextView)view.findViewById(2131362080);
            Time time = Time.a;
            Context context = view.getContext();
            Intrinsics.g((Object)context, (String)"view.context");
            textView.setText((CharSequence)time.g(context, this.n));
        }
        if (list.contains((Object)5)) {
            TextView textView = (TextView)view.findViewById(2131362416);
            AppCompatImageView appCompatImageView = (AppCompatImageView)com.google.protobuf.a.f((TextView)textView, (String)"view.last_update_date", (TextView)textView, (View)view, (Int)2131362108);
            Intrinsics.g((Object)appCompatImageView, (String)"view.date_more");
            ViewsKt.k((View)appCompatImageView);
            TextView textView2 = (TextView)view.findViewById(2131362416);
            TextView textView3 = (TextView)com.google.protobuf.a.f((TextView)textView2, (String)"view.last_update_date", (TextView)textView2, (View)view, (Int)2131362416);
            StringBuilder stringBuilder = a.a.u((String)"\u0420\u0435\u0434. ");
            Time time = Time.a;
            Context context = view.getContext();
            Intrinsics.g((Object)context, (String)"view.context");
            stringBuilder.append(time.g(context, this.o));
            textView3.setText((CharSequence)stringBuilder.toString());
        }
        if (list.contains((Object)6)) {
            ((TextView)view.findViewById(2131362046)).setText((CharSequence)DigitsKt.f((long)this.p));
        }
        if (list.contains((Object)7)) {
            ((TextView)view.findViewById(2131362277)).setText((CharSequence)DigitsKt.e((Int)this.q));
        }
        if (list.contains((Object)8)) {
            if (this.r) {
                this.x2(view);
            } else {
                this.w2(view);
            }
        }
        if (list.contains((Object)9)) {
            LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362625);
            Intrinsics.g((Object)linearLayout, (String)"view.private_collection");
            if (!this.s || !this.u) {
                bl = false;
            }
            ViewsKt.l((View)linearLayout, (Bool)bl);
            LinearLayout linearLayout2 = (LinearLayout)view.findViewById(2131362050);
            Intrinsics.g((Object)linearLayout2, (String)"view.comments_show_all");
            ViewsKt.f((View)linearLayout2, (Bool)this.s, (Bool)false, null, (Int)6);
        }
        if (list.contains((Object)10)) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131361916);
            Intrinsics.g((Object)appCompatImageView, (String)"view.avatar");
            ViewsKt.a((AppCompatImageView)appCompatImageView, (String)this.t);
        }
    }

    @NotNull
    final Listener v2() {
        Listener listener = this.v;
        if (listener != null) {
            return listener;
        }
        Intrinsics.r((String)"listener");
        throw null;
    }

    final void w2(View view) {
        Context context = view.getContext();
        Intrinsics.g((Object)context, (String)"context");
        Int n = ViewsKt.b((Context)context, (Int)2130969642);
        ((TextView)view.findViewById(2131362277)).setText((CharSequence)DigitsKt.e((Int)this.q));
        ((TextView)view.findViewById(2131362279)).setText((CharSequence)"\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0432 \u0437\u0430\u043a\u043b\u0430\u0434\u043a\u0438");
        ((TextView)view.findViewById(2131362277)).setTextColor(n);
        ((TextView)view.findViewById(2131362279)).setTextColor(n);
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362278);
        appCompatImageView.setImageDrawable(appCompatImageView.getResources().getDrawable(2131231117));
        appCompatImageView.setImageTintList(ColorStateList.valueOf((Int)n));
        RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131361872);
        relativeLayout.setBackground(relativeLayout.getResources().getDrawable(2131230926));
    }

    final void x2(View view) {
        Resources resources = view.getContext().getResources();
        ((TextView)view.findViewById(2131362277)).setText((CharSequence)DigitsKt.e((Int)this.q));
        ((TextView)view.findViewById(2131362279)).setText((CharSequence)"\u0423\u0434\u0430\u043b\u0438\u0442\u044c \u0438\u0437 \u0437\u0430\u043a\u043b\u0430\u0434\u043e\u043a");
        ((TextView)view.findViewById(2131362277)).setTextColor(resources.getColor(2131100686));
        ((TextView)view.findViewById(2131362279)).setTextColor(resources.getColor(2131100686));
        AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362278);
        appCompatImageView.setImageDrawable(resources.getDrawable(2131231116));
        appCompatImageView.setImageTintList(ColorStateList.valueOf((Int)resources.getColor(2131100686)));
        ((RelativeLayout)view.findViewById(2131361872)).setBackground(resources.getDrawable(2131230927));
    }

    func y2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        ((RelativeLayout)view.findViewById(2131361872)).setOnClickListener(null);
        ((LinearLayout)view.findViewById(2131362050)).setOnClickListener(null);
        ((AppCompatImageView)view.findViewById(2131362497)).setOnClickListener(null);
        ((RelativeLayout)view.findViewById(2131362183)).setOnClickListener(null);
        ((RelativeLayout)view.findViewById(2131362116)).setOnClickListener(null);
        ((TextView)view.findViewById(2131362123)).setText((CharSequence)"");
    }
}

