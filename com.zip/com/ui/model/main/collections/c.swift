/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.MenuItem
 *  android.view.View
 *  android.widget.TextView
 *  androidx.appcompat.widget.PopupMenu
 *  androidx.appcompat.widget.PopupMenu$OnMenuItemClickListener
 *  com.airbnb.epoxy.EpoxyModel
 *  com.swiftsoft.anixartd.ui.model.main.collections.ExtraCollectionModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.collections.ExtraReleaseCollectionModel$Listener
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.internal.Intrinsics
 */
package com.swiftsoft.anixartd.ui.model.main.collections;

import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.widget.PopupMenu;
import com.airbnb.epoxy.EpoxyModel;
import com.swiftsoft.anixartd.ui.model.main.collections.ExtraCollectionModel;
import com.swiftsoft.anixartd.ui.model.main.collections.ExtraReleaseCollectionModel;
import kotlin.jvm.internal.Intrinsics;

final class c
implements PopupMenu.OnMenuItemClickListener {
    final /* synthetic */ Int b;
    final /* synthetic */ View c;
    final /* synthetic */ Object d;

    /* synthetic */ c(EpoxyModel epoxyModel, View view, Int n) {
        this.b = n;
        this.d = epoxyModel;
        this.c = view;
    }

    final Bool onMenuItemClick(MenuItem menuItem) {
        block16 : {
            View view;
            block14 : {
                ExtraReleaseCollectionModel extraReleaseCollectionModel;
                block13 : {
                    block15 : {
                        switch (this.b) {
                            default: {
                                break;
                            }
                            case 0: {
                                ExtraCollectionModel extraCollectionModel = (ExtraCollectionModel)((Object)this.d);
                                View view2 = this.c;
                                Intrinsics.h((Object)((Object)extraCollectionModel), (String)"this$0");
                                Intrinsics.h((Object)view2, (String)"$view");
                                switch (menuItem.getItemId()) {
                                    default: {
                                        break;
                                    }
                                    case 2131362675: {
                                        extraCollectionModel.u2().a(5);
                                        break;
                                    }
                                    case 2131362655: {
                                        extraCollectionModel.u2().a(6);
                                        break;
                                    }
                                    case 2131362608: {
                                        extraCollectionModel.u2().a(2);
                                        break;
                                    }
                                    case 2131362607: {
                                        extraCollectionModel.u2().a(4);
                                        break;
                                    }
                                    case 2131362606: {
                                        extraCollectionModel.u2().a(3);
                                        break;
                                    }
                                    case 2131362421: {
                                        extraCollectionModel.u2().a(1);
                                    }
                                }
                                ((TextView)view2.findViewById(2131362799)).setText((CharSequence)String.valueOf((Object)menuItem.getTitle()));
                                return true;
                            }
                        }
                        extraReleaseCollectionModel = (ExtraReleaseCollectionModel)((Object)this.d);
                        view = this.c;
                        Intrinsics.h((Object)((Object)extraReleaseCollectionModel), (String)"this$0");
                        Intrinsics.h((Object)view, (String)"$view");
                        Int n = menuItem.getItemId();
                        if (n == 2131362605) break block13;
                        if (n != 2131362675) break block14;
                        ExtraReleaseCollectionModel.Listener listener = extraReleaseCollectionModel.k;
                        if (listener == null) break block15;
                        listener.a(5);
                        break block14;
                    }
                    Intrinsics.r((String)"listener");
                    throw null;
                }
                ExtraReleaseCollectionModel.Listener listener = extraReleaseCollectionModel.k;
                if (listener == null) break block16;
                listener.a(1);
            }
            ((TextView)view.findViewById(2131362799)).setText((CharSequence)String.valueOf((Object)menuItem.getTitle()));
            return true;
        }
        Intrinsics.r((String)"listener");
        throw null;
    }
}

