/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 *  android.widget.TextView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.android.material.button.MaterialButton
 *  com.swiftsoft.anixartd.App
 *  com.swiftsoft.anixartd.App$Companion
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.ui.fragment.main.watching.a
 *  com.swiftsoft.anixartd.ui.model.main.collections.CollectionCountReleaseModel$Listener
 *  com.swiftsoft.anixartd.utils.DigitsKt
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Arrays
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package com.swiftsoft.anixartd.ui.model.main.collections;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.android.material.button.MaterialButton;
import com.swiftsoft.anixartd.App;
import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.ui.fragment.main.watching.a;
import com.swiftsoft.anixartd.ui.model.main.collections.CollectionCountReleaseModel;
import com.swiftsoft.anixartd.utils.DigitsKt;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.Arrays;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u0003\u00a8\u0006\u0004"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/collections/CollectionCountReleaseModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class CollectionCountReleaseModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    long k;
    @EpoxyAttribute
    long l;
    @EpoxyAttribute
    long m;
    @EpoxyAttribute
    long n;
    @EpoxyAttribute
    long o;
    @EpoxyAttribute
    long p;
    @EpoxyAttribute
    Listener q;

    func Z1(Object object) -> void {
        Float f;
        Float f2;
        Float f3;
        Float f4;
        Float f5;
        Float f6;
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        MaterialButton materialButton = (MaterialButton)view.findViewById(2131362655);
        Intrinsics.g((Object)materialButton, (String)"view.random");
        Bool bl = this.k <= 1L;
        ViewsKt.f((View)materialButton, (Bool)bl, (Bool)false, null, (Int)6);
        LinearLayout linearLayout = (LinearLayout)view.findViewById(2131362903);
        Intrinsics.g((Object)linearLayout, (String)"view.statsRegularLayout");
        ViewsKt.f((View)linearLayout, (Bool)App.b.b().z(), (Bool)false, null, (Int)6);
        long l = this.l + this.m + this.n + this.o + this.p;
        TextView textView = (TextView)view.findViewById(2131362075);
        String string = context.getString(2131951737);
        Intrinsics.g((Object)string, (String)"context.getString(R.stri\u2026collection_release_count)");
        Object[] arrobject = new Object[]{this.k};
        String string2 = String.format((String)string, (Object[])Arrays.copyOf((Object[])arrobject, (Int)1));
        Intrinsics.g((Object)string2, (String)"format(format, *args)");
        textView.setText((CharSequence)string2);
        ((TextView)view.findViewById(2131363158)).setText((CharSequence)DigitsKt.f((long)this.l));
        ((TextView)view.findViewById(2131362602)).setText((CharSequence)DigitsKt.f((long)this.m));
        ((TextView)view.findViewById(2131362053)).setText((CharSequence)DigitsKt.f((long)this.n));
        ((TextView)view.findViewById(2131362342)).setText((CharSequence)DigitsKt.f((long)this.o));
        ((TextView)view.findViewById(2131362177)).setText((CharSequence)DigitsKt.f((long)this.p));
        long l2 = this.k;
        long l3 = this.l;
        long l4 = this.m;
        long l5 = l3 + l4;
        long l6 = this.n;
        long l7 = l5 + l6;
        long l8 = this.o;
        long l9 = l7 + l8;
        long l10 = this.p;
        long l11 = l2 - (l9 + l10);
        long l12 = 0L;
        if (l > l12) {
            long l13;
            if (l11 > l12) {
                f6 = l11 * (long)100 / l;
                l12 = 0L;
            } else {
                f6 = 0.0f;
            }
            if (l3 > l12) {
                f2 = l3 * (long)100 / l;
                l13 = 0L;
            } else {
                l13 = l12;
                f2 = 0.0f;
            }
            f3 = l4 > l13 ? (Float)(l4 * (long)100 / l) : 0.0f;
            f5 = l6 > l13 ? (Float)(l6 * (long)100 / l) : 0.0f;
            f4 = l8 > l13 ? (Float)(l8 * (long)100 / l) : 0.0f;
            long l14 = l10 LCMP l13;
            Float f7 = 0.0f;
            if (l14 > 0) {
                f7 = l10 * (long)100 / l;
            }
            f = f7;
        } else {
            f6 = 1.0f;
            f = 0.0f;
            f4 = 0.0f;
            f2 = 0.0f;
            f3 = 0.0f;
            f5 = 0.0f;
        }
        ViewGroup.LayoutParams layoutParams = view.findViewById(2131362193).getLayoutParams();
        Intrinsics.f((Object)layoutParams, (String)"null cannot be cast to non-null type android.widget.LinearLayout.LayoutParams");
        ((LinearLayout.LayoutParams)layoutParams).weight = f6;
        ViewGroup.LayoutParams layoutParams2 = view.findViewById(2131363160).getLayoutParams();
        Intrinsics.f((Object)layoutParams2, (String)"null cannot be cast to non-null type android.widget.LinearLayout.LayoutParams");
        ((LinearLayout.LayoutParams)layoutParams2).weight = f2;
        ViewGroup.LayoutParams layoutParams3 = view.findViewById(2131362603).getLayoutParams();
        Intrinsics.f((Object)layoutParams3, (String)"null cannot be cast to non-null type android.widget.LinearLayout.LayoutParams");
        ((LinearLayout.LayoutParams)layoutParams3).weight = f3;
        ViewGroup.LayoutParams layoutParams4 = view.findViewById(2131362055).getLayoutParams();
        Intrinsics.f((Object)layoutParams4, (String)"null cannot be cast to non-null type android.widget.LinearLayout.LayoutParams");
        ((LinearLayout.LayoutParams)layoutParams4).weight = f5;
        ViewGroup.LayoutParams layoutParams5 = view.findViewById(2131362343).getLayoutParams();
        Intrinsics.f((Object)layoutParams5, (String)"null cannot be cast to non-null type android.widget.LinearLayout.LayoutParams");
        ((LinearLayout.LayoutParams)layoutParams5).weight = f4;
        ViewGroup.LayoutParams layoutParams6 = view.findViewById(2131362178).getLayoutParams();
        Intrinsics.f((Object)layoutParams6, (String)"null cannot be cast to non-null type android.widget.LinearLayout.LayoutParams");
        ((LinearLayout.LayoutParams)layoutParams6).weight = f;
        ((MaterialButton)view.findViewById(2131362655)).setOnClickListener((View.OnClickListener)new a((Object)this, 4));
        ((LinearLayout)view.findViewById(2131362902)).requestLayout();
    }
}

