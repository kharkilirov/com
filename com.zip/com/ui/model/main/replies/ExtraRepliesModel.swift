/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.Html
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.annotation.StringRes
 *  androidx.appcompat.widget.AppCompatImageView
 *  com.airbnb.epoxy.EpoxyAttribute
 *  com.airbnb.epoxy.EpoxyModel
 *  com.airbnb.epoxy.EpoxyModelClass
 *  com.google.protobuf.a
 *  com.swiftsoft.anixartd.ui.model.main.replies.ExtraRepliesModel$Listener
 *  com.swiftsoft.anixartd.ui.model.main.replies.ExtraRepliesModel$bind
 *  com.swiftsoft.anixartd.ui.model.main.replies.ExtraRepliesModel$bind$3
 *  com.swiftsoft.anixartd.utils.ViewsKt
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.model.main.replies;

import android.content.Context;
import android.text.Html;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.StringRes;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.epoxy.EpoxyAttribute;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelClass;
import com.google.protobuf.a;
import com.swiftsoft.anixartd.ui.model.main.replies.ExtraRepliesModel;
import com.swiftsoft.anixartd.utils.ViewsKt;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b'\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0002\u0003\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/ui/model/main/replies/ExtraRepliesModel;", "Lcom/airbnb/epoxy/EpoxyModel;", "Landroid/view/View;", "Companion", "Listener", "app_release"}, k=1, mv={1, 7, 1})
@EpoxyModelClass
abstract class ExtraRepliesModel
extends EpoxyModel<View> {
    @EpoxyAttribute
    long k;
    @StringRes
    @EpoxyAttribute
    Int l;
    @EpoxyAttribute
    @Nullable
    String m = "";
    @EpoxyAttribute
    @Nullable
    String n = "";
    @EpoxyAttribute
    Listener o;

    func Z1(Object object) -> void {
        View view = (View)object;
        Intrinsics.h((Object)view, (String)"view");
        Context context = view.getContext();
        TextView textView = (TextView)view.findViewById(2131362373);
        String string = context.getString(this.l);
        Intrinsics.g((Object)string, (String)"context.getString(extraResourceId)");
        Object[] arrobject = new Object[1];
        String string2 = this.m;
        if (string2 == null) {
            string2 = "\u0411\u0435\u0437 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u044f";
        }
        arrobject[0] = string2;
        String string3 = String.format((String)string, (Object[])Arrays.copyOf((Object[])arrobject, (Int)1));
        Intrinsics.g((Object)string3, (String)"format(format, *args)");
        textView.setText((CharSequence)Html.fromHtml((String)string3));
        String string4 = this.n;
        if (string4 != null) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362361);
            Intrinsics.g((Object)appCompatImageView, (String)"view.image");
            ViewsKt.a((AppCompatImageView)appCompatImageView, (String)string4);
        }
        ViewsKt.j((View)view, (Function1)new bind.3(this));
    }

    func a2(Object object, EpoxyModel epoxyModel) -> void {
        View view = (View)object;
        ArrayList arrayList = a.k((View)view, (String)"view", (EpoxyModel)epoxyModel, (String)"previouslyBoundModel");
        if (epoxyModel instanceof ExtraRepliesModel) {
            String string = this.m;
            ExtraRepliesModel extraRepliesModel = (ExtraRepliesModel)epoxyModel;
            if (!Intrinsics.c((Object)string, (Object)extraRepliesModel.m)) {
                arrayList.add((Object)0);
            }
            if (!Intrinsics.c((Object)this.n, (Object)extraRepliesModel.n)) {
                arrayList.add((Object)1);
            }
            if (true ^ arrayList.isEmpty()) {
                this.u2(view, (List<Object>)arrayList);
                return;
            }
        }
        this.Z1((Object)view);
    }

    func u2(@NotNull View view, @NotNull List<Object> list) -> void {
        String string;
        Context context = a.b((View)view, (String)"view", list, (String)"payloads");
        if (list.contains((Object)0)) {
            TextView textView = (TextView)view.findViewById(2131362373);
            String string2 = context.getString(this.l);
            Intrinsics.g((Object)string2, (String)"context.getString(extraResourceId)");
            Object[] arrobject = new Object[]{this.m};
            String string3 = String.format((String)string2, (Object[])Arrays.copyOf((Object[])arrobject, (Int)1));
            Intrinsics.g((Object)string3, (String)"format(format, *args)");
            textView.setText((CharSequence)Html.fromHtml((String)string3));
        }
        if (list.contains((Object)1) && (string = this.n) != null) {
            AppCompatImageView appCompatImageView = (AppCompatImageView)view.findViewById(2131362361);
            Intrinsics.g((Object)appCompatImageView, (String)"view.image");
            ViewsKt.h((ImageView)appCompatImageView, (String)string);
        }
    }

    func v2(@NotNull View view) -> void {
        Intrinsics.h((Object)view, (String)"view");
        view.setOnClickListener(null);
    }
}

