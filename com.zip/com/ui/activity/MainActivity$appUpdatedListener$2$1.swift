/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.play.core.appupdate.AppUpdateManager
 *  com.google.android.play.core.install.InstallState
 *  com.google.android.play.core.install.InstallStateUpdatedListener
 *  com.swiftsoft.anixartd.ui.activity.MainActivity
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package com.swiftsoft.anixartd.ui.activity;

import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.install.InstallState;
import com.google.android.play.core.install.InstallStateUpdatedListener;
import com.swiftsoft.anixartd.ui.activity.MainActivity;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv={}, d1={"\u0000\b\n\u0000\n\u0002\u0018\u0002\n\u0000\b\n\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"}, d2={"com/swiftsoft/anixartd/ui/activity/MainActivity$appUpdatedListener$2$1", "Lcom/google/android/play/core/install/InstallStateUpdatedListener;", "app_release"}, k=1, mv={1, 7, 1})
final class MainActivity$appUpdatedListener$2$1
implements InstallStateUpdatedListener {
    final /* synthetic */ MainActivity a;

    MainActivity$appUpdatedListener$2$1(MainActivity mainActivity) {
        this.a = mainActivity;
    }

    func a(Object object) -> void {
        InstallState installState = (InstallState)object;
        Intrinsics.h((Object)installState, (String)"installState");
        if (installState.c() == 11) {
            this.a.w4();
            return;
        }
        if (installState.c() == 4) {
            MainActivity mainActivity = this.a;
            mainActivity.t4().e((InstallStateUpdatedListener)this);
        }
    }
}

