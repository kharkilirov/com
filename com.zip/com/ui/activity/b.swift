/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.MenuItem
 *  android.view.View
 *  com.google.android.material.bottomnavigation.BottomNavigationView
 *  com.google.android.material.bottomnavigation.BottomNavigationView$OnNavigationItemReselectedListener
 *  com.google.android.material.bottomnavigation.BottomNavigationView$OnNavigationItemSelectedListener
 *  com.ncapdevi.fragnav.FragNavController
 *  com.ncapdevi.fragnav.FragNavTransactionOptions
 *  com.swiftsoft.anixartd.presentation.main.MainPresenter
 *  com.swiftsoft.anixartd.ui.activity.MainActivity
 *  com.swiftsoft.anixartd.ui.logic.main.MainUiLogic
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 *  kotlin.jvm.internal.Intrinsics
 */
package com.swiftsoft.anixartd.ui.activity;

import android.view.MenuItem;
import android.view.View;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.ncapdevi.fragnav.FragNavController;
import com.ncapdevi.fragnav.FragNavTransactionOptions;
import com.swiftsoft.anixartd.presentation.main.MainPresenter;
import com.swiftsoft.anixartd.ui.activity.MainActivity;
import com.swiftsoft.anixartd.ui.logic.main.MainUiLogic;
import java.util.Objects;
import kotlin.jvm.internal.Intrinsics;

final class b
implements BottomNavigationView.OnNavigationItemSelectedListener,
BottomNavigationView.OnNavigationItemReselectedListener {
    final /* synthetic */ MainActivity a;

    /* synthetic */ b(MainActivity mainActivity) {
        this.a = mainActivity;
    }

    func a(MenuItem menuItem) -> Bool {
        MainActivity mainActivity = this.a;
        Intrinsics.h((Object)mainActivity, (String)"this$0");
        Intrinsics.h((Object)menuItem, (String)"menuItem");
        ((BottomNavigationView)mainActivity.s4(2131362527)).setOnNavigationItemReselectedListener((BottomNavigationView.OnNavigationItemReselectedListener)new b(mainActivity));
        switch (menuItem.getItemId()) {
            default: {
                return true;
            }
            case 2131362953: {
                if (!mainActivity.u4().a()) {
                    FragNavController.s((FragNavController)mainActivity.g, (Int)3, null, (Int)2);
                } else {
                    FragNavController.s((FragNavController)mainActivity.g, (Int)4, null, (Int)2);
                }
                mainActivity.u4().j.a("TAB_PROFILE");
                return true;
            }
            case 2131362950: {
                FragNavController.s((FragNavController)mainActivity.g, (Int)0, null, (Int)2);
                mainActivity.u4().j.a("TAB_HOME");
                return true;
            }
            case 2131362948: {
                FragNavController.s((FragNavController)mainActivity.g, (Int)1, null, (Int)2);
                mainActivity.u4().j.a("TAB_DISCOVER");
                return true;
            }
            case 2131362947: 
        }
        if (!mainActivity.u4().a()) {
            FragNavController.s((FragNavController)mainActivity.g, (Int)2, null, (Int)2);
        } else {
            FragNavController.s((FragNavController)mainActivity.g, (Int)4, null, (Int)2);
        }
        mainActivity.u4().j.a("TAB_BOOKMARKS");
        return true;
    }

    func b(MenuItem menuItem) -> void {
        MainActivity mainActivity = this.a;
        Intrinsics.h((Object)mainActivity, (String)"this$0");
        FragNavController fragNavController = mainActivity.g;
        Objects.requireNonNull((Object)fragNavController);
        fragNavController.b(null);
    }
}

