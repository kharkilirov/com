/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.ReportReason
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  java.io.Serializable
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.logic.main.report;

import com.swiftsoft.anixartd.database.entity.ReportReason;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001:\u0001\u0002\u00a8\u0006\u0003"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/report/ReportUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "Companion", "app_release"}, k=1, mv={1, 7, 1})
final class ReportUiLogic
extends UiLogic {
    Serializable b;
    Int c = -1;
    @NotNull
    List<ReportReason> d = new ArrayList();
    Bool e;

    @NotNull
    final Serializable a() {
        Serializable serializable = this.b;
        if (serializable != null) {
            return serializable;
        }
        Intrinsics.r((String)"targetEntity");
        throw null;
    }
}

