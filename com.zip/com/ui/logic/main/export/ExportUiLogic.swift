/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  java.lang.Integer
 *  java.lang.String
 *  kotlin.Metadata
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.logic.main.export;

import com.swiftsoft.anixartd.ui.logic.UiLogic;
import kotlin.Metadata;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/export/ExportUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "app_release"}, k=1, mv={1, 7, 1})
final class ExportUiLogic
extends UiLogic {
    @Nullable
    Integer b;
    @Nullable
    String c;
}

