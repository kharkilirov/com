/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.database.entity.episode.Episode
 *  com.swiftsoft.anixartd.database.entity.episode.LastWatchedEpisode
 *  com.swiftsoft.anixartd.database.entity.episode.Source
 *  com.swiftsoft.anixartd.database.entity.episode.Type
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.logic.main.episodes;

import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.database.entity.episode.Episode;
import com.swiftsoft.anixartd.database.entity.episode.LastWatchedEpisode;
import com.swiftsoft.anixartd.database.entity.episode.Source;
import com.swiftsoft.anixartd.database.entity.episode.Type;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001:\u0001\u0002\u00a8\u0006\u0003"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/episodes/EpisodesUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "Companion", "app_release"}, k=1, mv={1, 7, 1})
final class EpisodesUiLogic
extends UiLogic {
    long b;
    Release c;
    @NotNull
    String d = "STATE_TYPES";
    @NotNull
    String e = "";
    Int f = 1;
    @NotNull
    List<Type> g = new ArrayList();
    @NotNull
    List<Source> h = new ArrayList();
    @NotNull
    List<Episode> i = new ArrayList();
    Bool j;
    Bool k;
    Bool l;
    Bool m;
    Bool n;
    @Nullable
    Type o;
    @Nullable
    Source p;
    @Nullable
    Episode q;
    @Nullable
    Episode r;
    @Nullable
    LastWatchedEpisode s;
    Bool t;

    final void a() {
        this.g.clear();
        this.h.clear();
        this.i.clear();
    }

    @NotNull
    final Release b() {
        Release release = this.c;
        if (release != null) {
            return release;
        }
        Intrinsics.r((String)"release");
        throw null;
    }

    final void c(@NotNull String string) {
        this.d = string;
    }
}

