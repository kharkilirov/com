/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a.a
 *  com.swiftsoft.anixartd.database.entity.Collection
 *  com.swiftsoft.anixartd.database.entity.Profile
 *  com.swiftsoft.anixartd.database.entity.Related
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.database.entity.Search
 *  com.swiftsoft.anixartd.network.request.SearchRequest
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  java.lang.Exception
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.logic.main.search;

import a.a;
import com.swiftsoft.anixartd.database.entity.Profile;
import com.swiftsoft.anixartd.database.entity.Related;
import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.database.entity.Search;
import com.swiftsoft.anixartd.network.request.SearchRequest;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001:\u0001\u0002\u00a8\u0006\u0003"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/search/SearchUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "Companion", "app_release"}, k=1, mv={1, 7, 1})
final class SearchUiLogic
extends UiLogic {
    Int b;
    @NotNull
    String c = "TAB_HOME";
    @NotNull
    String d = "INNER_TAB_NONE";
    @Nullable
    Long e;
    @Nullable
    Long f;
    @NotNull
    String g = "";
    @NotNull
    String h = "";
    Int i;
    @NotNull
    String j = "";
    @NotNull
    List<Search> k = new ArrayList();
    @NotNull
    List<Release> l = new ArrayList();
    @NotNull
    List<com.swiftsoft.anixartd.database.entity.Collection> m = new ArrayList();
    @NotNull
    List<Profile> n = new ArrayList();
    @Nullable
    Related o;
    Bool p;
    Bool q;
    Bool r;
    Bool s;
    Bool t;

    final void a() {
        this.i = 0;
        this.j = "";
        this.k.clear();
        this.l.clear();
        this.m.clear();
        this.n.clear();
        this.o = null;
        this.p = false;
        this.q = false;
        this.s = false;
        this.t = false;
    }

    final void b(@NotNull List<Release> list) {
        Intrinsics.h(list, (String)"releases");
        this.j = "ACTION_RELEASES";
        if (!this.q) {
            if (this.q) {
                this.a();
            }
            this.l.addAll(list);
            this.q = true;
            return;
        }
        this.l.addAll(list);
    }

    @NotNull
    final SearchRequest c() {
        return new SearchRequest(this.g, this.b);
    }

    @NotNull
    final String d() {
        block25 : {
            String string = this.c;
            block0 : switch (string.hashCode()) {
                default: {
                    break block25;
                }
                case 1624588691: {
                    if (string.equals((Object)"TAB_BOOKMARKS")) {
                        String string2 = this.d;
                        switch (string2.hashCode()) {
                            default: {
                                break;
                            }
                            case 2121300245: {
                                if (!string2.equals((Object)"INNER_TAB_BOOKMARKS_PLANS")) break;
                                return "TYPE_RELEASE";
                            }
                            case 879690667: {
                                if (!string2.equals((Object)"INNER_TAB_BOOKMARKS_DROPPED")) break;
                                return "TYPE_RELEASE";
                            }
                            case 45737322: {
                                if (!string2.equals((Object)"INNER_TAB_BOOKMARKS_HOLD_ON")) break;
                                return "TYPE_RELEASE";
                            }
                            case -119111553: {
                                if (!string2.equals((Object)"INNER_TAB_BOOKMARKS_HISTORY")) break;
                                return "TYPE_RELEASE";
                            }
                            case -1630519434: {
                                if (!string2.equals((Object)"INNER_TAB_BOOKMARKS_COMPLETED")) break;
                                return "TYPE_RELEASE";
                            }
                            case -1817489912: {
                                if (!string2.equals((Object)"INNER_TAB_BOOKMARKS_WATCHING")) break;
                                return "TYPE_RELEASE";
                            }
                            case -2012826750: {
                                if (!string2.equals((Object)"INNER_TAB_BOOKMARKS_FAVORITES")) break;
                                return "TYPE_RELEASE";
                            }
                            case -2109617152: {
                                if (string2.equals((Object)"INNER_TAB_BOOKMARKS_COLLECTIONS")) break block0;
                            }
                        }
                        StringBuilder stringBuilder = a.u((String)"Invalid inner tab: ");
                        stringBuilder.append(this.d);
                        throw new Exception(stringBuilder.toString());
                    }
                    break block25;
                }
                case -51137291: {
                    if (string.equals((Object)"TAB_COLLECTIONS_PROFILE")) {
                        break;
                    }
                    break block25;
                }
                case -95141015: {
                    if (string.equals((Object)"TAB_HOME")) {
                        return "TYPE_RELEASE";
                    }
                    break block25;
                }
                case -943792100: {
                    if (string.equals((Object)"SECTION_MY_COLLECTIONS")) {
                        break;
                    }
                    break block25;
                }
                case -1069630785: {
                    if (string.equals((Object)"TAB_PROFILE")) {
                        return "TYPE_PROFILE";
                    }
                    break block25;
                }
                case -1818334861: {
                    if (string.equals((Object)"TAB_DISCOVER")) {
                        return "TYPE_RELEASE";
                    }
                    break block25;
                }
                case -1836047621: {
                    if (!string.equals((Object)"SECTION_COLLECTIONS")) break block25;
                }
            }
            return "TYPE_COLLECTION";
        }
        StringBuilder stringBuilder = a.u((String)"Invalid tab: ");
        stringBuilder.append(this.c);
        throw new Exception(stringBuilder.toString());
    }

    final void e(@NotNull String string) {
        Intrinsics.h((Object)string, (String)"<set-?>");
        this.h = string;
    }

    final void f(@NotNull String string) {
        this.g = string;
    }
}

