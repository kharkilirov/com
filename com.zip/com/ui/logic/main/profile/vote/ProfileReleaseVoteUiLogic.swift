/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.logic.main.profile.vote;

import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001:\u0001\u0002\u00a8\u0006\u0003"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/profile/vote/ProfileReleaseVoteUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "Companion", "app_release"}, k=1, mv={1, 7, 1})
final class ProfileReleaseVoteUiLogic
extends UiLogic {
    long b;
    Int c;
    long d;
    Int e = 1;
    @NotNull
    List<Release> f = new ArrayList();
    Bool g;
    Bool h = true;
    Bool i;

    final void a(@NotNull List<Release> list) {
        Intrinsics.h(list, (String)"releases");
        if (!this.g) {
            if (this.g) {
                this.f.clear();
            }
            this.f.addAll(list);
            this.g = true;
            return;
        }
        this.f.addAll(list);
    }
}

