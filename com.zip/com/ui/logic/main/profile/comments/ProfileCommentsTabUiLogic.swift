/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.CollectionComment
 *  com.swiftsoft.anixartd.database.entity.ReleaseComment
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.logic.main.profile.comments;

import com.swiftsoft.anixartd.database.entity.CollectionComment;
import com.swiftsoft.anixartd.database.entity.ReleaseComment;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001:\u0001\u0002\u00a8\u0006\u0003"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/profile/comments/ProfileCommentsTabUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "Companion", "app_release"}, k=1, mv={1, 7, 1})
final class ProfileCommentsTabUiLogic
extends UiLogic {
    long b;
    @NotNull
    String c = "INNER_TAB_PROFILE_COMMENTS_RELEASE";
    Int d;
    long e;
    Int f = 1;
    @NotNull
    List<ReleaseComment> g = new ArrayList();
    @NotNull
    List<CollectionComment> h = new ArrayList();
    Bool i;
    Bool j;
    Bool k = true;

    final void a() {
        this.d = 0;
        this.g.clear();
        this.h.clear();
        this.i = false;
        this.j = false;
    }
}

