/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.ReleaseVideo
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.logic.main.profile.videos;

import com.swiftsoft.anixartd.database.entity.ReleaseVideo;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/profile/videos/ProfileReleaseVideosTabUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "app_release"}, k=1, mv={1, 7, 1})
final class ProfileReleaseVideosTabUiLogic
extends UiLogic {
    long b;
    @NotNull
    String c = "INNER_TAB_PROFILE_VIDEOS_ALL";
    Int d;
    long e;
    long f;
    @NotNull
    List<ReleaseVideo> g = new ArrayList();
    @NotNull
    List<ReleaseVideo> h = new ArrayList();
    @NotNull
    List<ReleaseVideo> i = new ArrayList();
    Bool j;
    Bool k;

    final void a() {
        this.d = 0;
        this.g.clear();
        this.h.clear();
        this.i.clear();
        this.j = false;
        this.k = false;
    }

    final void b(@NotNull List<? extends ReleaseVideo> list, @NotNull List<? extends ReleaseVideo> list2) {
        Intrinsics.h(list, (String)"videoUploads");
        Intrinsics.h(list2, (String)"videoAppeals");
        if (!this.k) {
            if (this.k) {
                this.h.clear();
                this.i.clear();
            }
            this.h.addAll(list);
            this.i.addAll(list2);
            this.k = true;
            return;
        }
        this.h.addAll(list);
        this.i.addAll(list2);
    }
}

