/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Profile
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  com.swiftsoft.anixartd.ui.logic.main.profile.friends.ProfileFriendsUiLogic$Companion
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.logic.main.profile.friends;

import com.swiftsoft.anixartd.database.entity.Profile;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import com.swiftsoft.anixartd.ui.logic.main.profile.friends.ProfileFriendsUiLogic;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.NotNull;

/*
 * Exception performing whole class analysis.
 */
@Metadata(bv={}, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001:\u0001\u0002\u00a8\u0006\u0003"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/profile/friends/ProfileFriendsUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "Companion", "app_release"}, k=1, mv={1, 7, 1})
final class ProfileFriendsUiLogic
extends UiLogic {
    @NotNull
    static final Companion l;
    long b;
    Int c;
    @NotNull
    List<Profile> d;
    @NotNull
    List<Profile> e;
    long f;
    @NotNull
    List<Profile> g;
    long h;
    @NotNull
    List<Profile> i;
    long j;
    Bool k;

    static {
        l = new /* Unavailable Anonymous Inner Class!! */;
    }

    init() {
        this.d = new ArrayList();
        this.e = new ArrayList();
        this.g = new ArrayList();
        this.i = new ArrayList();
    }

    final void a() {
        this.c = 0;
        this.f = 0L;
        this.h = 0L;
        this.j = 0L;
        this.d.clear();
        this.e.clear();
        this.g.clear();
        this.i.clear();
        this.k = false;
    }
}

