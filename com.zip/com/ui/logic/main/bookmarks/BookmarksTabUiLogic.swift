/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Collection
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.logic.main.bookmarks;

import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001:\u0001\u0002\u00a8\u0006\u0003"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/bookmarks/BookmarksTabUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "Companion", "app_release"}, k=1, mv={1, 7, 1})
final class BookmarksTabUiLogic
extends UiLogic {
    @NotNull
    String b = "INNER_TAB_BOOKMARKS_FAVORITES";
    Int c;
    long d;
    Int e = 1;
    @NotNull
    List<Release> f = new ArrayList();
    @NotNull
    List<com.swiftsoft.anixartd.database.entity.Collection> g = new ArrayList();
    Bool h;
    Bool i;
    Bool j;

    final void a() {
        this.c = 0;
        this.f.clear();
        this.g.clear();
        this.h = false;
        this.i = false;
    }

    final void b(@NotNull Release release) {
        Int n;
        block3 : {
            Iterator iterator = this.f.iterator();
            n = 0;
            while (iterator.hasNext()) {
                Bool bl = ((Release)iterator.next()).getId() == release.getId();
                if (!bl) {
                    ++n;
                    continue;
                }
                break block3;
            }
            n = -1;
        }
        if (n < 0) {
            this.f.add(0, (Object)release);
            return;
        }
        this.f.set(n, (Object)release);
    }

    final void c(@NotNull List<Release> list) {
        Intrinsics.h(list, (String)"releases");
        if (!this.h) {
            if (this.h) {
                this.a();
            }
            this.f.addAll(list);
            this.h = true;
            return;
        }
        this.f.addAll(list);
    }

    final Int d() {
        String string = this.b;
        switch (string.hashCode()) {
            default: {
                break;
            }
            case 2121300245: {
                if (!string.equals((Object)"INNER_TAB_BOOKMARKS_PLANS")) break;
                return 2;
            }
            case 879690667: {
                if (!string.equals((Object)"INNER_TAB_BOOKMARKS_DROPPED")) break;
                return 5;
            }
            case 45737322: {
                if (!string.equals((Object)"INNER_TAB_BOOKMARKS_HOLD_ON")) break;
                return 4;
            }
            case -1630519434: {
                if (!string.equals((Object)"INNER_TAB_BOOKMARKS_COMPLETED")) break;
                return 3;
            }
            case -1817489912: {
                if (!string.equals((Object)"INNER_TAB_BOOKMARKS_WATCHING")) break;
                return 1;
            }
        }
        throw new Exception("Invalid inner position");
    }
}

