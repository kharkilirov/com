/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  java.lang.Integer
 *  java.lang.String
 *  java.util.HashMap
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.logic.main.genres;

import com.swiftsoft.anixartd.ui.logic.UiLogic;
import java.util.HashMap;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/genres/ChooseGenresUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "app_release"}, k=1, mv={1, 7, 1})
final class ChooseGenresUiLogic
extends UiLogic {
    String[] b;
    @NotNull
    HashMap<Integer, String> c = new HashMap();

    @NotNull
    final String[] a() {
        String[] arrstring = this.b;
        if (arrstring != null) {
            return arrstring;
        }
        Intrinsics.r((String)"genres");
        throw null;
    }

    final Bool b() {
        return this.c.size() == this.a().length;
    }
}

