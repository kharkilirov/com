/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.collections.EmptyList
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.logic.main.filtered;

import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.EmptyList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001:\u0001\u0002\u00a8\u0006\u0003"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/filtered/FilteredUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "Companion", "app_release"}, k=1, mv={1, 7, 1})
final class FilteredUiLogic
extends UiLogic {
    @Nullable
    Long b;
    @Nullable
    Long c;
    @Nullable
    Integer d;
    @Nullable
    Integer e;
    @NotNull
    String f = "";
    @Nullable
    Integer g;
    @Nullable
    Integer h;
    @NotNull
    String i = "";
    @Nullable
    Integer j;
    @Nullable
    Integer k;
    @NotNull
    List<String> l;
    @NotNull
    List<Integer> m;
    @NotNull
    List<Long> n;
    @NotNull
    List<Integer> o;
    Bool p;
    Int q;
    @NotNull
    List<Release> r;
    Bool s;

    init() {
        EmptyList emptyList;
        this.l = emptyList = EmptyList.b;
        this.m = emptyList;
        this.n = emptyList;
        this.o = emptyList;
        this.r = new ArrayList();
    }
}

