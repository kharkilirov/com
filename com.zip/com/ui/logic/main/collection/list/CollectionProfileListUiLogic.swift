/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Collection
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  com.swiftsoft.anixartd.ui.logic.main.collection.list.CollectionProfileListUiLogic$removeCollection
 *  com.swiftsoft.anixartd.ui.logic.main.collection.list.CollectionProfileListUiLogic$removeCollection$1
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.functions.Function1
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.logic.main.collection.list;

import com.swiftsoft.anixartd.ui.logic.UiLogic;
import com.swiftsoft.anixartd.ui.logic.main.collection.list.CollectionProfileListUiLogic;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/collection/list/CollectionProfileListUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "app_release"}, k=1, mv={1, 7, 1})
final class CollectionProfileListUiLogic
extends UiLogic {
    long b;
    Bool c;
    Int d;
    @NotNull
    List<com.swiftsoft.anixartd.database.entity.Collection> e = new ArrayList();
    long f;
    Bool g;

    final void a(@NotNull com.swiftsoft.anixartd.database.entity.Collection collection) {
        Int n;
        List<com.swiftsoft.anixartd.database.entity.Collection> list = this.e;
        if (list instanceof Collection && list.isEmpty()) {
            n = 0;
        } else {
            Iterator iterator = list.iterator();
            Int n2 = 0;
            while (iterator.hasNext()) {
                Bool bl = ((com.swiftsoft.anixartd.database.entity.Collection)iterator.next()).getId() == collection.getId();
                if (!bl || ++n2 >= 0) continue;
                CollectionsKt.g0();
                throw null;
            }
            n = n2;
        }
        this.f -= (long)n;
        CollectionsKt.R(this.e, (Function1)new removeCollection.1(collection));
    }
}

