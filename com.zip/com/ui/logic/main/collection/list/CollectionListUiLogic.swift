/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Collection
 *  com.swiftsoft.anixartd.ui.logic.Pagination
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  com.swiftsoft.anixartd.ui.logic.main.collection.list.CollectionListUiLogic$removeCollection
 *  com.swiftsoft.anixartd.ui.logic.main.collection.list.CollectionListUiLogic$removeCollection$1
 *  java.lang.Boolean
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.functions.Function1
 *  kotlin.random.Random
 *  kotlin.random.Random$Default
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.logic.main.collection.list;

import com.swiftsoft.anixartd.database.entity.Collection;
import com.swiftsoft.anixartd.ui.logic.Pagination;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import com.swiftsoft.anixartd.ui.logic.main.collection.list.CollectionListUiLogic;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.random.Random;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001:\u0001\u0002\u00a8\u0006\u0003"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/collection/list/CollectionListUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "Companion", "app_release"}, k=1, mv={1, 7, 1})
final class CollectionListUiLogic
extends UiLogic {
    @NotNull
    Pagination b = new Pagination();
    @NotNull
    List<Collection> c = new ArrayList();
    Int d = 1;
    Int e = Random.b.d(2, 7);
    Bool f;

    final void a() {
        Pagination pagination = this.b;
        pagination.a = new Boolean[0];
        pagination.b = 0;
        pagination.c = 0;
        pagination.e = false;
        this.c.clear();
        if (this.e == 6) {
            this.b.c = -1;
        }
    }

    final void b(@NotNull Collection collection) {
        CollectionsKt.R(this.c, (Function1)new removeCollection.1(collection));
    }
}

