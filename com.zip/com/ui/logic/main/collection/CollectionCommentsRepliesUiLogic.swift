/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.CollectionComment
 *  com.swiftsoft.anixartd.database.entity.Profile
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.logic.main.collection;

import com.swiftsoft.anixartd.database.entity.CollectionComment;
import com.swiftsoft.anixartd.database.entity.Profile;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/collection/CollectionCommentsRepliesUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "app_release"}, k=1, mv={1, 7, 1})
final class CollectionCommentsRepliesUiLogic
extends UiLogic {
    long b;
    long c;
    Bool d;
    Bool e;
    CollectionComment f;
    Int g = 2;
    @NotNull
    List<CollectionComment> h = new ArrayList();
    Bool i;
    long j;
    @Nullable
    Profile k;
    Bool l;

    final void a() {
        this.j = 0L;
        this.k = null;
        this.l = false;
        this.h.clear();
    }

    final Bool b(@NotNull CollectionComment collectionComment) {
        Int n;
        block4 : {
            if (collectionComment.getId() == this.c) {
                this.f = collectionComment;
                return true;
            }
            Iterator iterator = this.h.iterator();
            n = 0;
            while (iterator.hasNext()) {
                Bool bl = ((CollectionComment)iterator.next()).getId() == collectionComment.getId();
                if (!bl) {
                    ++n;
                    continue;
                }
                break block4;
            }
            n = -1;
        }
        if (n >= 0) {
            this.h.set(n, (Object)collectionComment);
        }
        return n >= 0;
    }

    @Nullable
    final CollectionComment c(long l) {
        Object object2;
        block2 : {
            if (l == this.d().getId()) {
                return this.d();
            }
            for (Object object2 : this.h) {
                Bool bl = ((CollectionComment)object2).getId() == l;
                if (!bl) continue;
                break block2;
            }
            object2 = null;
        }
        return (CollectionComment)object2;
    }

    @NotNull
    final CollectionComment d() {
        CollectionComment collectionComment = this.f;
        if (collectionComment != null) {
            return collectionComment;
        }
        Intrinsics.r((String)"parentCollectionComment");
        throw null;
    }
}

