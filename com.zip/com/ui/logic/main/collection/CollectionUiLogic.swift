/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Collection
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.logic.main.collection;

import com.swiftsoft.anixartd.database.entity.Collection;
import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/collection/CollectionUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "app_release"}, k=1, mv={1, 7, 1})
final class CollectionUiLogic
extends UiLogic {
    Collection b;
    long c;
    Int d;
    long e;
    long f;
    long g;
    long h;
    long i;
    long j;
    @NotNull
    List<Release> k = new ArrayList();
    Bool l;

    final void a() {
        this.d = 0;
        this.e = 0L;
        this.k.clear();
        this.l = false;
    }

    @NotNull
    final Collection b() {
        Collection collection = this.b;
        if (collection != null) {
            return collection;
        }
        Intrinsics.r((String)"collection");
        throw null;
    }

    final void c(Int n, Int n2) {
        if (n != 1) {
            if (n != 2) {
                if (n != 3) {
                    if (n != 4) {
                        if (n != 5) {
                            return;
                        }
                        this.j += (long)n2;
                        return;
                    }
                    this.i += (long)n2;
                    return;
                }
                this.h += (long)n2;
                return;
            }
            this.g += (long)n2;
            return;
        }
        this.f += (long)n2;
    }
}

