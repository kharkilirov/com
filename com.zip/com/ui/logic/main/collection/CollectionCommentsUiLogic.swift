/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Collection
 *  com.swiftsoft.anixartd.database.entity.CollectionComment
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.logic.main.collection;

import com.swiftsoft.anixartd.database.entity.Collection;
import com.swiftsoft.anixartd.database.entity.CollectionComment;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001:\u0001\u0002\u00a8\u0006\u0003"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/collection/CollectionCommentsUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "Companion", "app_release"}, k=1, mv={1, 7, 1})
final class CollectionCommentsUiLogic
extends UiLogic {
    long b;
    Collection c;
    Int d;
    Int e = 1;
    @NotNull
    List<CollectionComment> f = new ArrayList();
    long g;
    Bool h;
    Bool i;

    final void a() {
        this.d = 0;
        this.g = 0L;
        this.h = false;
        this.f.clear();
    }

    final Bool b(@NotNull CollectionComment collectionComment) {
        Int n;
        block6 : {
            Iterator iterator = this.f.iterator();
            n = 0;
            while (iterator.hasNext()) {
                Bool bl = ((CollectionComment)iterator.next()).getId() == collectionComment.getId();
                if (!bl) {
                    ++n;
                    continue;
                }
                break block6;
            }
            n = -1;
        }
        if (n >= 0) {
            Collection collection = this.c;
            if (collection != null) {
                long l;
                this.g = l = -1L + this.g;
                collection.setCommentCount(l);
                this.f.remove(n);
            } else {
                Intrinsics.r((String)"collection");
                throw null;
            }
        }
        Bool bl = false;
        if (n >= 0) {
            bl = true;
        }
        return bl;
    }
}

