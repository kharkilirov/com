/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.notification.ProfileFriendNotification
 *  com.swiftsoft.anixartd.database.entity.notification.ProfileMyCollectionCommentNotification
 *  com.swiftsoft.anixartd.database.entity.notification.ProfileNotification
 *  com.swiftsoft.anixartd.database.entity.notification.collection.ProfileCollectionCommentNotification
 *  com.swiftsoft.anixartd.database.entity.notification.episode.ProfileEpisodeNotification
 *  com.swiftsoft.anixartd.database.entity.notification.related.ProfileRelatedReleaseNotification
 *  com.swiftsoft.anixartd.database.entity.notification.release.ProfileReleaseCommentNotification
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.logic.main.notifications;

import com.swiftsoft.anixartd.database.entity.notification.ProfileFriendNotification;
import com.swiftsoft.anixartd.database.entity.notification.ProfileMyCollectionCommentNotification;
import com.swiftsoft.anixartd.database.entity.notification.ProfileNotification;
import com.swiftsoft.anixartd.database.entity.notification.collection.ProfileCollectionCommentNotification;
import com.swiftsoft.anixartd.database.entity.notification.episode.ProfileEpisodeNotification;
import com.swiftsoft.anixartd.database.entity.notification.related.ProfileRelatedReleaseNotification;
import com.swiftsoft.anixartd.database.entity.notification.release.ProfileReleaseCommentNotification;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001:\u0001\u0002\u00a8\u0006\u0003"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/notifications/NotificationsUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "Companion", "app_release"}, k=1, mv={1, 7, 1})
final class NotificationsUiLogic
extends UiLogic {
    Int b;
    Int c = 1;
    Bool d;
    Bool e;
    Bool f;
    Bool g;
    @NotNull
    List<ProfileFriendNotification> h = new ArrayList();
    @NotNull
    List<ProfileEpisodeNotification> i = new ArrayList();
    @NotNull
    List<ProfileReleaseCommentNotification> j = new ArrayList();
    @NotNull
    List<ProfileCollectionCommentNotification> k = new ArrayList();
    @NotNull
    List<ProfileMyCollectionCommentNotification> l = new ArrayList();
    @NotNull
    List<ProfileRelatedReleaseNotification> m = new ArrayList();
    @NotNull
    List<ProfileNotification> n = new ArrayList();
    Bool o;
    Bool p;

    final void a() {
        this.b = 0;
        this.h.clear();
        this.i.clear();
        this.j.clear();
        this.k.clear();
        this.l.clear();
        this.m.clear();
        this.n.clear();
        this.p = false;
    }
}

