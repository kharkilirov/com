/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.database.entity.ReleaseStreamingPlatform
 *  com.swiftsoft.anixartd.database.entity.ReleaseVideo
 *  com.swiftsoft.anixartd.database.entity.ReleaseVideoBlock
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.logic.main.release.video;

import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.database.entity.ReleaseStreamingPlatform;
import com.swiftsoft.anixartd.database.entity.ReleaseVideo;
import com.swiftsoft.anixartd.database.entity.ReleaseVideoBlock;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/release/video/ReleaseVideosUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "app_release"}, k=1, mv={1, 7, 1})
final class ReleaseVideosUiLogic
extends UiLogic {
    long b;
    Int c;
    @Nullable
    Release d;
    @NotNull
    List<ReleaseVideo> e = new ArrayList();
    @NotNull
    List<ReleaseVideoBlock> f = new ArrayList();
    @NotNull
    List<ReleaseStreamingPlatform> g = new ArrayList();
    Bool h;
    @NotNull
    List<ReleaseVideo> i = new ArrayList();
    Bool j;
    Bool k;
}

