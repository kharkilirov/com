/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.database.entity.ReleaseComment
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.logic.main.release;

import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.database.entity.ReleaseComment;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001:\u0001\u0002\u00a8\u0006\u0003"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/release/ReleaseCommentsUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "Companion", "app_release"}, k=1, mv={1, 7, 1})
final class ReleaseCommentsUiLogic
extends UiLogic {
    long b;
    Release c;
    Int d;
    Int e = 1;
    @NotNull
    List<ReleaseComment> f = new ArrayList();
    long g;
    Bool h;
    Bool i;

    final void a() {
        this.d = 0;
        this.g = 0L;
        this.h = false;
        this.f.clear();
    }

    final Bool b(@NotNull ReleaseComment releaseComment) {
        Int n;
        block6 : {
            Iterator iterator = this.f.iterator();
            n = 0;
            while (iterator.hasNext()) {
                Bool bl = ((ReleaseComment)iterator.next()).getId() == releaseComment.getId();
                if (!bl) {
                    ++n;
                    continue;
                }
                break block6;
            }
            n = -1;
        }
        if (n >= 0) {
            Release release = this.c;
            if (release != null) {
                long l;
                this.g = l = -1L + this.g;
                release.setCommentCount(l);
                this.f.remove(n);
            } else {
                Intrinsics.r((String)"release");
                throw null;
            }
        }
        Bool bl = false;
        if (n >= 0) {
            bl = true;
        }
        return bl;
    }
}

