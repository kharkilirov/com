/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Profile
 *  com.swiftsoft.anixartd.database.entity.ReleaseComment
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.logic.main.release;

import com.swiftsoft.anixartd.database.entity.Profile;
import com.swiftsoft.anixartd.database.entity.ReleaseComment;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/release/ReleaseCommentsRepliesUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "app_release"}, k=1, mv={1, 7, 1})
final class ReleaseCommentsRepliesUiLogic
extends UiLogic {
    long b;
    long c;
    Bool d;
    Bool e;
    ReleaseComment f;
    Int g = 2;
    @NotNull
    List<ReleaseComment> h = new ArrayList();
    Bool i;
    long j;
    @Nullable
    Profile k;
    Bool l;

    final void a() {
        this.j = 0L;
        this.k = null;
        this.l = false;
        this.h.clear();
    }

    final Bool b(@NotNull ReleaseComment releaseComment) {
        Int n;
        block4 : {
            if (releaseComment.getId() == this.c) {
                this.f = releaseComment;
                return true;
            }
            Iterator iterator = this.h.iterator();
            n = 0;
            while (iterator.hasNext()) {
                Bool bl = ((ReleaseComment)iterator.next()).getId() == releaseComment.getId();
                if (!bl) {
                    ++n;
                    continue;
                }
                break block4;
            }
            n = -1;
        }
        if (n >= 0) {
            this.h.set(n, (Object)releaseComment);
        }
        return n >= 0;
    }

    @Nullable
    final ReleaseComment c(long l) {
        Object object2;
        block2 : {
            if (l == this.d().getId()) {
                return this.d();
            }
            for (Object object2 : this.h) {
                Bool bl = ((ReleaseComment)object2).getId() == l;
                if (!bl) continue;
                break block2;
            }
            object2 = null;
        }
        return (ReleaseComment)object2;
    }

    @NotNull
    final ReleaseComment d() {
        ReleaseComment releaseComment = this.f;
        if (releaseComment != null) {
            return releaseComment;
        }
        Intrinsics.r((String)"parentReleaseComment");
        throw null;
    }
}

