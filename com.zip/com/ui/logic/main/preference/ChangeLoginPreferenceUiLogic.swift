/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.ChangeLogin
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.logic.main.preference;

import com.swiftsoft.anixartd.database.entity.ChangeLogin;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/preference/ChangeLoginPreferenceUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "app_release"}, k=1, mv={1, 7, 1})
final class ChangeLoginPreferenceUiLogic
extends UiLogic {
    Int b;
    @NotNull
    List<ChangeLogin> c = new ArrayList();
    @NotNull
    String d = "";
    @NotNull
    String e = "";
    Bool f;
    long g;
    Bool h;
}

