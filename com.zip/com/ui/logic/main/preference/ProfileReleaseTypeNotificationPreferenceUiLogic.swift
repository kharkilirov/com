/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  java.lang.Long
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.LinkedHashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 *  kotlin.Metadata
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.logic.main.preference;

import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/main/preference/ProfileReleaseTypeNotificationPreferenceUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "app_release"}, k=1, mv={1, 7, 1})
final class ProfileReleaseTypeNotificationPreferenceUiLogic
extends UiLogic {
    Int b;
    @NotNull
    String[] c = new String[0];
    @NotNull
    String[] d = new String[0];
    @NotNull
    List<Release> e = new ArrayList();
    long f = -1L;
    @NotNull
    Map<Long, Set<Long>> g = new LinkedHashMap();
    Bool h;
}

