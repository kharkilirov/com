/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.database.entity.Release
 *  com.swiftsoft.anixartd.database.entity.episode.Episode
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package com.swiftsoft.anixartd.ui.logic.player;

import com.swiftsoft.anixartd.database.entity.Release;
import com.swiftsoft.anixartd.database.entity.episode.Episode;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(bv={}, d1={"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"}, d2={"Lcom/swiftsoft/anixartd/ui/logic/player/PlayerUiLogic;", "Lcom/swiftsoft/anixartd/ui/logic/UiLogic;", "app_release"}, k=1, mv={1, 7, 1})
final class PlayerUiLogic
extends UiLogic {
    Release b;
    @NotNull
    List<Episode> c = new ArrayList();
    Int d;
    Int e;

    @NotNull
    final Release a() {
        Release release = this.b;
        if (release != null) {
            return release;
        }
        Intrinsics.r((String)"release");
        throw null;
    }

    final Bool b() {
        Bool bl;
        block5 : {
            block6 : {
                block4 : {
                    Int n = this.e;
                    if (n == 1) break block4;
                    if (n != 2) {
                        return false;
                    }
                    Int n2 = this.d;
                    bl = false;
                    if (n2 <= 0) break block5;
                    break block6;
                }
                Int n = 1 + this.d;
                Int n3 = this.c.size();
                bl = false;
                if (n == n3) break block5;
            }
            bl = true;
        }
        return bl;
    }
}

