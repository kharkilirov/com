/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  androidx.lifecycle.LifecycleOwner
 *  com.skydoves.balloon.ArrowOrientation
 *  com.skydoves.balloon.Balloon
 *  com.skydoves.balloon.Balloon$Builder
 *  com.skydoves.balloon.Balloon$Factory
 *  com.skydoves.balloon.BalloonAnimation
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.ui.tooltip;

import android.content.Context;
import androidx.lifecycle.LifecycleOwner;
import com.skydoves.balloon.ArrowOrientation;
import com.skydoves.balloon.Balloon;
import com.skydoves.balloon.BalloonAnimation;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"}, d2={"Lcom/swiftsoft/anixartd/ui/tooltip/ProfileRatingScoreBalloonFactory;", "Lcom/skydoves/balloon/Balloon$Factory;", "app_release"}, k=1, mv={1, 7, 1})
final class ProfileRatingScoreBalloonFactory
extends Balloon.Factory {
    @NotNull
    func a(@NotNull Context context, @Nullable LifecycleOwner lifecycleOwner) -> Balloon {
        Intrinsics.h((Object)context, (String)"context");
        Balloon.Builder builder = new Balloon.Builder(context);
        builder.d(10);
        builder.c(ArrowOrientation.c);
        builder.l = 0.5f;
        builder.k(8);
        builder.j(8);
        builder.i(8);
        builder.g(12.0f);
        builder.h(2);
        builder.m(2131952613);
        builder.t = 14.0f;
        builder.l(2131100518);
        builder.e(2131100649);
        builder.f(BalloonAnimation.d);
        builder.I = false;
        builder.E = builder.E;
        return builder.a();
    }
}

