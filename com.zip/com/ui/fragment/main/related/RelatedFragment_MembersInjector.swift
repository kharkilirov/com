/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.ui.fragment.main.related.RelatedFragment
 *  dagger.MembersInjector
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.QualifierMetadata
 *  java.lang.Object
 */
package com.swiftsoft.anixartd.ui.fragment.main.related;

import com.swiftsoft.anixartd.ui.fragment.main.related.RelatedFragment;
import dagger.MembersInjector;
import dagger.internal.DaggerGenerated;
import dagger.internal.QualifierMetadata;

@DaggerGenerated
@QualifierMetadata
final class RelatedFragment_MembersInjector
implements MembersInjector<RelatedFragment> {
}

