/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.swiftsoft.anixartd.ui.fragment.main.release.video.category.ReleaseVideoCategoryFragment
 *  dagger.MembersInjector
 *  dagger.internal.DaggerGenerated
 *  dagger.internal.QualifierMetadata
 *  java.lang.Object
 */
package com.swiftsoft.anixartd.ui.fragment.main.release.video.category;

import com.swiftsoft.anixartd.ui.fragment.main.release.video.category.ReleaseVideoCategoryFragment;
import dagger.MembersInjector;
import dagger.internal.DaggerGenerated;
import dagger.internal.QualifierMetadata;

@DaggerGenerated
@QualifierMetadata
final class ReleaseVideoCategoryFragment_MembersInjector
implements MembersInjector<ReleaseVideoCategoryFragment> {
}

