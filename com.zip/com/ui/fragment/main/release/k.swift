/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.widget.ImageView
 *  androidx.fragment.app.Fragment
 *  androidx.swiperefreshlayout.widget.SwipeRefreshLayout
 *  androidx.swiperefreshlayout.widget.SwipeRefreshLayout$OnRefreshListener
 *  com.bumptech.glide.request.target.ViewTarget
 *  com.stfalcon.imageviewer.loader.ImageLoader
 *  com.swiftsoft.anixartd.Prefs
 *  com.swiftsoft.anixartd.database.entity.ReleaseComment
 *  com.swiftsoft.anixartd.presentation.main.release.ReleasePresenter
 *  com.swiftsoft.anixartd.ui.fragment.main.release.ReleaseFragment
 *  com.swiftsoft.anixartd.ui.fragment.main.release.ReleaseFragment$Listener
 *  com.swiftsoft.anixartd.ui.logic.UiLogic
 *  com.swiftsoft.anixartd.utils.Common
 *  com.swiftsoft.anixartd.utils.GlideApp
 *  com.swiftsoft.anixartd.utils.GlideRequest
 *  com.swiftsoft.anixartd.utils.GlideRequests
 *  com.swiftsoft.anixartd.utils.ReleaseLinkMovementMethod
 *  com.swiftsoft.anixartd.utils.ReleaseLinkMovementMethod$ClickListener
 *  java.lang.CharSequence
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  java.util.Set
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 */
package com.swiftsoft.anixartd.ui.fragment.main.release;

import android.widget.ImageView;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.bumptech.glide.request.target.ViewTarget;
import com.stfalcon.imageviewer.loader.ImageLoader;
import com.swiftsoft.anixartd.Prefs;
import com.swiftsoft.anixartd.database.entity.ReleaseComment;
import com.swiftsoft.anixartd.presentation.main.release.ReleasePresenter;
import com.swiftsoft.anixartd.ui.fragment.main.release.ReleaseFragment;
import com.swiftsoft.anixartd.ui.logic.UiLogic;
import com.swiftsoft.anixartd.ui.logic.main.release.ReleaseUiLogic;
import com.swiftsoft.anixartd.utils.Common;
import com.swiftsoft.anixartd.utils.GlideApp;
import com.swiftsoft.anixartd.utils.GlideRequest;
import com.swiftsoft.anixartd.utils.GlideRequests;
import com.swiftsoft.anixartd.utils.ReleaseLinkMovementMethod;
import java.util.List;
import java.util.Set;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

final class k
implements ImageLoader,
SwipeRefreshLayout.OnRefreshListener,
ReleaseLinkMovementMethod.ClickListener {
    final /* synthetic */ Int b;
    final /* synthetic */ ReleaseFragment c;

    /* synthetic */ k(ReleaseFragment releaseFragment, Int n) {
        this.b = n;
        this.c = releaseFragment;
    }

    func a(String string) -> Bool {
        switch (this.b) {
            default: {
                break;
            }
            case 2: {
                ReleaseFragment releaseFragment = this.c;
                Intrinsics.h((Object)releaseFragment, (String)"this$0");
                Intrinsics.g((Object)string, (String)"it");
                if (StringsKt.t((CharSequence)string, (CharSequence)"studio#", (Bool)false, (Int)2, null)) {
                    releaseFragment.q.c(StringsKt.Q((String)string, (String)"studio#", (String)"", (Bool)false, (Int)4, null));
                    return true;
                }
                if (StringsKt.t((CharSequence)string, (CharSequence)"director#", (Bool)false, (Int)2, null)) {
                    releaseFragment.q.a(StringsKt.Q((String)string, (String)"director#", (String)"", (Bool)false, (Int)4, null));
                    return true;
                }
                if (StringsKt.t((CharSequence)string, (CharSequence)"author#", (Bool)false, (Int)2, null)) {
                    releaseFragment.q.d(StringsKt.Q((String)string, (String)"author#", (String)"", (Bool)false, (Int)4, null));
                }
                return true;
            }
        }
        ReleaseFragment releaseFragment = this.c;
        Intrinsics.h((Object)releaseFragment, (String)"this$0");
        Intrinsics.g((Object)string, (String)"it");
        if (StringsKt.t((CharSequence)string, (CharSequence)"genre#", (Bool)false, (Int)2, null)) {
            releaseFragment.q.b(StringsKt.Q((String)string, (String)"genre#", (String)"", (Bool)false, (Int)4, null));
        }
        return true;
    }

    func b(ImageView imageView, Object object) -> void {
        switch (this.b) {
            default: {
                break;
            }
            case 0: {
                ReleaseFragment releaseFragment = this.c;
                String string = (String)object;
                Intrinsics.h((Object)releaseFragment, (String)"this$0");
                GlideRequests glideRequests = GlideApp.b((Fragment)releaseFragment);
                Common common = new Common();
                glideRequests.t(common.c(string, releaseFragment.e4().g.y())).K(imageView);
                return;
            }
        }
        ReleaseFragment releaseFragment = this.c;
        String string = (String)object;
        Intrinsics.h((Object)releaseFragment, (String)"this$0");
        GlideApp.b((Fragment)releaseFragment).t(new Common().c(string, releaseFragment.e4().g.y())).K(imageView);
    }

    func u() -> void {
        ReleaseFragment releaseFragment = this.c;
        Intrinsics.h((Object)releaseFragment, (String)"this$0");
        ReleasePresenter releasePresenter = releaseFragment.e4();
        ReleaseUiLogic releaseUiLogic = releasePresenter.h;
        if (releaseUiLogic.a) {
            releaseUiLogic.m = false;
            releaseUiLogic.f.clear();
            releaseUiLogic.o.clear();
            releaseUiLogic.r.clear();
            if (releasePresenter.a()) {
                ReleasePresenter.l((ReleasePresenter)releasePresenter, (Int)0, (Bool)false, (Bool)false, (Int)7);
                return;
            }
            ReleasePresenter.l((ReleasePresenter)releasePresenter, (Int)0, (Bool)false, (Bool)true, (Int)1);
        }
    }
}

