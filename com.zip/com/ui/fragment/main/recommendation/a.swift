/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.MenuItem
 *  androidx.appcompat.widget.PopupMenu
 *  androidx.appcompat.widget.PopupMenu$OnMenuItemClickListener
 *  androidx.swiperefreshlayout.widget.SwipeRefreshLayout
 *  androidx.swiperefreshlayout.widget.SwipeRefreshLayout$OnRefreshListener
 *  com.swiftsoft.anixartd.ui.fragment.main.recommendation.RecommendationFragment
 *  com.swiftsoft.anixartd.ui.fragment.main.related.RelatedFragment
 *  com.swiftsoft.anixartd.ui.fragment.main.release.video.ReleaseVideosFragment
 *  com.swiftsoft.anixartd.ui.fragment.main.release.video.category.ReleaseVideoCategoryFragment
 *  com.swiftsoft.anixartd.ui.fragment.main.watching.WatchingFragment
 *  com.swiftsoft.anixartd.ui.model.main.collections.CollectionHeaderModel$Listener
 *  com.yandex.div.core.expression.ExpressionResolverImpl
 *  com.yandex.div.core.expression.variables.VariableController
 *  com.yandex.div.data.Variable
 *  com.yandex.div.evaluable.VariableProvider
 *  com.yandex.mobile.ads.exo.offline.c
 *  com.yandex.mobile.ads.exo.offline.e
 *  com.yandex.mobile.ads.impl.lg
 *  com.yandex.mobile.ads.impl.lg$a
 *  com.yandex.mobile.ads.impl.ow0
 *  com.yandex.mobile.ads.impl.ow0$b
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  kotlin.jvm.internal.Intrinsics
 *  org.jsoup.nodes.Element
 *  org.jsoup.nodes.Node
 *  org.jsoup.select.NodeVisitor
 */
package com.swiftsoft.anixartd.ui.fragment.main.recommendation;

import android.view.MenuItem;
import androidx.appcompat.widget.PopupMenu;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.swiftsoft.anixartd.ui.fragment.main.recommendation.RecommendationFragment;
import com.swiftsoft.anixartd.ui.fragment.main.related.RelatedFragment;
import com.swiftsoft.anixartd.ui.fragment.main.release.video.ReleaseVideosFragment;
import com.swiftsoft.anixartd.ui.fragment.main.release.video.category.ReleaseVideoCategoryFragment;
import com.swiftsoft.anixartd.ui.fragment.main.watching.WatchingFragment;
import com.swiftsoft.anixartd.ui.model.main.collections.CollectionHeaderModel;
import com.yandex.div.core.expression.ExpressionResolverImpl;
import com.yandex.div.core.expression.variables.VariableController;
import com.yandex.div.data.Variable;
import com.yandex.div.evaluable.VariableProvider;
import com.yandex.mobile.ads.exo.offline.c;
import com.yandex.mobile.ads.exo.offline.e;
import com.yandex.mobile.ads.impl.lg;
import com.yandex.mobile.ads.impl.ow0;
import kotlin.jvm.internal.Intrinsics;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.NodeVisitor;

final class a
implements SwipeRefreshLayout.OnRefreshListener,
PopupMenu.OnMenuItemClickListener,
VariableProvider,
ow0.b,
lg.a,
NodeVisitor {
    final /* synthetic */ Int b;
    final /* synthetic */ Object c;

    /* synthetic */ a(Object object, Int n) {
        this.b = n;
        this.c = object;
    }

    func a(long l, long l2, long l3) -> void {
        e.a((e)((e)this.c), (long)l, (long)l2, (long)l3);
    }

    func a(ow0 ow02, Int n) -> void {
        c.b((c)((c)this.c), (ow0)ow02, (Int)n);
    }

    func a(Node node, Int n) -> void {
        Element.I((Node)node, (StringBuilder)((StringBuilder)this.c));
    }

    /* synthetic */ void b(Node node, Int n) {
    }

    func get(String string) -> Object {
        ExpressionResolverImpl expressionResolverImpl = (ExpressionResolverImpl)this.c;
        Intrinsics.h((Object)expressionResolverImpl, (String)"this$0");
        Intrinsics.h((Object)string, (String)"variableName");
        Variable variable = expressionResolverImpl.b.c(string);
        if (variable == null) {
            return null;
        }
        return variable.b();
    }

    func onMenuItemClick(MenuItem menuItem) -> Bool {
        CollectionHeaderModel collectionHeaderModel = (CollectionHeaderModel)((Object)this.c);
        Intrinsics.h((Object)((Object)collectionHeaderModel), (String)"this$0");
        Int n = menuItem.getItemId();
        if (n != 2131362728) {
            if (n != 2131362809) {
                if (n == 2131362812) {
                    collectionHeaderModel.v2().j0();
                }
            } else {
                collectionHeaderModel.v2().Q0();
            }
        } else {
            collectionHeaderModel.v2().W0();
        }
        return true;
    }

    func u() -> void {
        switch (this.b) {
            default: {
                break;
            }
            case 3: {
                ReleaseVideoCategoryFragment releaseVideoCategoryFragment = (ReleaseVideoCategoryFragment)this.c;
                Intrinsics.h((Object)releaseVideoCategoryFragment, (String)"this$0");
                releaseVideoCategoryFragment.u();
                return;
            }
            case 2: {
                ReleaseVideosFragment releaseVideosFragment = (ReleaseVideosFragment)this.c;
                Intrinsics.h((Object)releaseVideosFragment, (String)"this$0");
                releaseVideosFragment.u();
                return;
            }
            case 1: {
                RelatedFragment relatedFragment = (RelatedFragment)this.c;
                Intrinsics.h((Object)relatedFragment, (String)"this$0");
                relatedFragment.u();
                return;
            }
            case 0: {
                RecommendationFragment recommendationFragment = (RecommendationFragment)this.c;
                Intrinsics.h((Object)recommendationFragment, (String)"this$0");
                recommendationFragment.u();
                return;
            }
        }
        WatchingFragment watchingFragment = (WatchingFragment)this.c;
        Intrinsics.h((Object)watchingFragment, (String)"this$0");
        watchingFragment.u();
    }
}

