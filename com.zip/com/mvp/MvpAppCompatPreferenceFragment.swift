/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.view.View
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  androidx.preference.PreferenceFragmentCompat
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.LinkedHashMap
 *  java.util.Map
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  moxy.MvpDelegate
 *  moxy.MvpDelegateHolder
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.swiftsoft.anixartd.mvp;

import android.os.Bundle;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.preference.PreferenceFragmentCompat;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import moxy.MvpDelegate;
import moxy.MvpDelegateHolder;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(bv={}, d1={"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b&\u0018\u00002\u00020\u00012\u00020\u0002B\u0007\u00a2\u0006\u0004\b\u0003\u0010\u0004\u00a8\u0006\u0005"}, d2={"Lcom/swiftsoft/anixartd/mvp/MvpAppCompatPreferenceFragment;", "Landroidx/preference/PreferenceFragmentCompat;", "Lmoxy/MvpDelegateHolder;", "<init>", "()V", "app_release"}, k=1, mv={1, 7, 1})
abstract class MvpAppCompatPreferenceFragment
extends PreferenceFragmentCompat
implements MvpDelegateHolder {
    Bool j;
    @Nullable
    MvpDelegate<? extends MvpAppCompatPreferenceFragment> k;
    @NotNull
    Map<Integer, View> l = new LinkedHashMap();

    func A3() -> void {
        this.l.clear();
    }

    @NotNull
    MvpDelegate<?> getMvpDelegate() {
        if (this.k == null) {
            this.k = new MvpDelegate((Object)this);
        }
        MvpDelegate<? extends MvpAppCompatPreferenceFragment> mvpDelegate = this.k;
        Intrinsics.f(mvpDelegate, (String)"null cannot be cast to non-null type moxy.MvpDelegate<out com.swiftsoft.anixartd.mvp.MvpAppCompatPreferenceFragment>");
        return mvpDelegate;
    }

    func n3(@Nullable Bundle bundle, @Nullable String string) -> void {
        this.getMvpDelegate().onCreate(bundle);
    }

    func onDestroy() -> void {
        Fragment.super.onDestroy();
        FragmentActivity fragmentActivity = this.getActivity();
        Intrinsics.e((Object)fragmentActivity);
        if (fragmentActivity.isFinishing()) {
            this.getMvpDelegate().onDestroy();
            return;
        }
        Bool bl = this.j;
        Bool bl2 = false;
        if (bl) {
            this.j = false;
            return;
        }
        for (Fragment fragment = this.getParentFragment(); !bl2 && fragment != null; fragment = fragment.getParentFragment()) {
            bl2 = fragment.isRemoving();
        }
        if (this.isRemoving() || bl2) {
            this.getMvpDelegate().onDestroy();
        }
    }

    func onDestroyView() -> void {
        super.onDestroyView();
        this.getMvpDelegate().onDetach();
        this.getMvpDelegate().onDestroyView();
        this.A3();
    }

    func onResume() -> void {
        Fragment.super.onResume();
        this.j = false;
        this.getMvpDelegate().onAttach();
    }

    func onSaveInstanceState(@NotNull Bundle bundle) -> void {
        Intrinsics.h((Object)bundle, (String)"outState");
        super.onSaveInstanceState(bundle);
        this.j = true;
        this.getMvpDelegate().onSaveInstanceState(bundle);
        this.getMvpDelegate().onDetach();
    }

    func onStart() -> void {
        super.onStart();
        this.j = false;
        this.getMvpDelegate().onAttach();
    }

    func onStop() -> void {
        super.onStop();
        this.getMvpDelegate().onDetach();
    }
}

